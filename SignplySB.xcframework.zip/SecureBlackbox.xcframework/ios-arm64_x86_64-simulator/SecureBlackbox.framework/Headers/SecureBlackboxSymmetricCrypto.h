/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//CRYPTOENCODINGTYPES
#define CET_DEFAULT                                        0

#define CET_BINARY                                         1

#define CET_BASE_64                                        2

#define CET_COMPACT                                        3

#define CET_JSON                                           4

//SYMMETRICCRYPTOMODES
#define SCM_DEFAULT                                        0

#define SCM_ECB                                            1

#define SCM_CBC                                            2

#define SCM_CTR                                            3

#define SCM_CFB8                                           4

#define SCM_GCM                                            5

#define SCM_CCM                                            6

#define SCM_POLY_1305                                      7

#define SCM_OCB                                            8

//SYMMETRICCRYPTOPADDINGS
#define SCP_NONE                                           0

#define SCP_PKCS5                                          1

#define SCP_ANSIX923                                       2

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxSymmetricCryptoDelegate <NSObject>
@optional
- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onProgress:(long long)total :(long long)current :(int*)cancel NS_SWIFT_NAME(onProgress(_:_:_:));

@end

@interface SecureBlackboxSymmetricCrypto : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxSymmetricCryptoDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasError;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasProgress;

}

+ (SecureBlackboxSymmetricCrypto*)symmetriccrypto;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxSymmetricCryptoDelegate> delegate;
- (id <SecureBlackboxSymmetricCryptoDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxSymmetricCryptoDelegate>)anObject;

  /* Events */

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onProgress:(long long)total :(long long)current :(int*)cancel NS_SWIFT_NAME(onProgress(_:_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readwrite,assign,getter=associatedData,setter=setAssociatedData:) NSData* associatedData NS_SWIFT_NAME(associatedData);

- (NSData*)associatedData NS_SWIFT_NAME(associatedData());
- (void)setAssociatedData :(NSData*)newAssociatedData NS_SWIFT_NAME(setAssociatedData(_:));

@property (nonatomic,readonly,assign,getter=blockSize) int blockSize NS_SWIFT_NAME(blockSize);

- (int)blockSize NS_SWIFT_NAME(blockSize());

@property (nonatomic,readwrite,assign,getter=encryptionAlgorithm,setter=setEncryptionAlgorithm:) NSString* encryptionAlgorithm NS_SWIFT_NAME(encryptionAlgorithm);

- (NSString*)encryptionAlgorithm NS_SWIFT_NAME(encryptionAlgorithm());
- (void)setEncryptionAlgorithm :(NSString*)newEncryptionAlgorithm NS_SWIFT_NAME(setEncryptionAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=hashAlgorithm,setter=setHashAlgorithm:) NSString* hashAlgorithm NS_SWIFT_NAME(hashAlgorithm);

- (NSString*)hashAlgorithm NS_SWIFT_NAME(hashAlgorithm());
- (void)setHashAlgorithm :(NSString*)newHashAlgorithm NS_SWIFT_NAME(setHashAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=inputEncoding,setter=setInputEncoding:) int inputEncoding NS_SWIFT_NAME(inputEncoding);

- (int)inputEncoding NS_SWIFT_NAME(inputEncoding());
- (void)setInputEncoding :(int)newInputEncoding NS_SWIFT_NAME(setInputEncoding(_:));

@property (nonatomic,readwrite,assign,getter=keyAlgorithm,setter=setKeyAlgorithm:) NSString* keyAlgorithm NS_SWIFT_NAME(keyAlgorithm);

- (NSString*)keyAlgorithm NS_SWIFT_NAME(keyAlgorithm());
- (void)setKeyAlgorithm :(NSString*)newKeyAlgorithm NS_SWIFT_NAME(setKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=keyBits) int keyBits NS_SWIFT_NAME(keyBits);

- (int)keyBits NS_SWIFT_NAME(keyBits());

@property (nonatomic,readwrite,assign,getter=keyCurve,setter=setKeyCurve:) NSString* keyCurve NS_SWIFT_NAME(keyCurve);

- (NSString*)keyCurve NS_SWIFT_NAME(keyCurve());
- (void)setKeyCurve :(NSString*)newKeyCurve NS_SWIFT_NAME(setKeyCurve(_:));

@property (nonatomic,readonly,assign,getter=keyExportable) BOOL keyExportable NS_SWIFT_NAME(keyExportable);

- (BOOL)keyExportable NS_SWIFT_NAME(keyExportable());

@property (nonatomic,readonly,assign,getter=keyFingerprint) NSString* keyFingerprint NS_SWIFT_NAME(keyFingerprint);

- (NSString*)keyFingerprint NS_SWIFT_NAME(keyFingerprint());

@property (nonatomic,readwrite,assign,getter=keyHandle,setter=setKeyHandle:) long long keyHandle NS_SWIFT_NAME(keyHandle);

- (long long)keyHandle NS_SWIFT_NAME(keyHandle());
- (void)setKeyHandle :(long long)newKeyHandle NS_SWIFT_NAME(setKeyHandle(_:));

@property (nonatomic,readwrite,assign,getter=keyID,setter=setKeyID:) NSData* keyID NS_SWIFT_NAME(keyID);

- (NSData*)keyID NS_SWIFT_NAME(keyID());
- (void)setKeyID :(NSData*)newKeyID NS_SWIFT_NAME(setKeyID(_:));

@property (nonatomic,readwrite,assign,getter=keyIV,setter=setKeyIV:) NSData* keyIV NS_SWIFT_NAME(keyIV);

- (NSData*)keyIV NS_SWIFT_NAME(keyIV());
- (void)setKeyIV :(NSData*)newKeyIV NS_SWIFT_NAME(setKeyIV(_:));

@property (nonatomic,readonly,assign,getter=keyKey) NSData* keyKey NS_SWIFT_NAME(keyKey);

- (NSData*)keyKey NS_SWIFT_NAME(keyKey());

@property (nonatomic,readwrite,assign,getter=keyNonce,setter=setKeyNonce:) NSData* keyNonce NS_SWIFT_NAME(keyNonce);

- (NSData*)keyNonce NS_SWIFT_NAME(keyNonce());
- (void)setKeyNonce :(NSData*)newKeyNonce NS_SWIFT_NAME(setKeyNonce(_:));

@property (nonatomic,readonly,assign,getter=keyPrivate) BOOL keyPrivate NS_SWIFT_NAME(keyPrivate);

- (BOOL)keyPrivate NS_SWIFT_NAME(keyPrivate());

@property (nonatomic,readonly,assign,getter=keyPublic) BOOL keyPublic NS_SWIFT_NAME(keyPublic);

- (BOOL)keyPublic NS_SWIFT_NAME(keyPublic());

@property (nonatomic,readwrite,assign,getter=keySubject,setter=setKeySubject:) NSData* keySubject NS_SWIFT_NAME(keySubject);

- (NSData*)keySubject NS_SWIFT_NAME(keySubject());
- (void)setKeySubject :(NSData*)newKeySubject NS_SWIFT_NAME(setKeySubject(_:));

@property (nonatomic,readonly,assign,getter=keySymmetric) BOOL keySymmetric NS_SWIFT_NAME(keySymmetric);

- (BOOL)keySymmetric NS_SWIFT_NAME(keySymmetric());

@property (nonatomic,readonly,assign,getter=keyValid) BOOL keyValid NS_SWIFT_NAME(keyValid);

- (BOOL)keyValid NS_SWIFT_NAME(keyValid());

@property (nonatomic,readonly,assign,getter=keySize) int keySize NS_SWIFT_NAME(keySize);

- (int)keySize NS_SWIFT_NAME(keySize());

@property (nonatomic,readwrite,assign,getter=MACAlgorithm,setter=setMACAlgorithm:) NSString* MACAlgorithm NS_SWIFT_NAME(MACAlgorithm);

- (NSString*)MACAlgorithm NS_SWIFT_NAME(MACAlgorithm());
- (void)setMACAlgorithm :(NSString*)newMACAlgorithm NS_SWIFT_NAME(setMACAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=mode,setter=setMode:) int mode NS_SWIFT_NAME(mode);

- (int)mode NS_SWIFT_NAME(mode());
- (void)setMode :(int)newMode NS_SWIFT_NAME(setMode(_:));

@property (nonatomic,readwrite,assign,getter=nonce,setter=setNonce:) NSData* nonce NS_SWIFT_NAME(nonce);

- (NSData*)nonce NS_SWIFT_NAME(nonce());
- (void)setNonce :(NSData*)newNonce NS_SWIFT_NAME(setNonce(_:));

@property (nonatomic,readwrite,assign,getter=outputEncoding,setter=setOutputEncoding:) int outputEncoding NS_SWIFT_NAME(outputEncoding);

- (int)outputEncoding NS_SWIFT_NAME(outputEncoding());
- (void)setOutputEncoding :(int)newOutputEncoding NS_SWIFT_NAME(setOutputEncoding(_:));

@property (nonatomic,readwrite,assign,getter=padding,setter=setPadding:) int padding NS_SWIFT_NAME(padding);

- (int)padding NS_SWIFT_NAME(padding());
- (void)setPadding :(int)newPadding NS_SWIFT_NAME(setPadding(_:));

@property (nonatomic,readwrite,assign,getter=payloadSize,setter=setPayloadSize:) int payloadSize NS_SWIFT_NAME(payloadSize);

- (int)payloadSize NS_SWIFT_NAME(payloadSize());
- (void)setPayloadSize :(int)newPayloadSize NS_SWIFT_NAME(setPayloadSize(_:));

@property (nonatomic,readonly,assign,getter=streamCipher) BOOL streamCipher NS_SWIFT_NAME(streamCipher);

- (BOOL)streamCipher NS_SWIFT_NAME(streamCipher());

@property (nonatomic,readwrite,assign,getter=tagSize,setter=setTagSize:) int tagSize NS_SWIFT_NAME(tagSize);

- (int)tagSize NS_SWIFT_NAME(tagSize());
- (void)setTagSize :(int)newTagSize NS_SWIFT_NAME(setTagSize(_:));

  /* Methods */

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSData*)decrypt:(NSData*)buffer NS_SWIFT_NAME(decrypt(_:));

- (void)decryptFile:(NSString*)sourceFile :(NSString*)destFile NS_SWIFT_NAME(decryptFile(_:_:));

- (NSData*)decryptFinal NS_SWIFT_NAME(decryptFinal());

- (void)decryptInit NS_SWIFT_NAME(decryptInit());

- (NSData*)decryptUpdate:(NSData*)buffer NS_SWIFT_NAME(decryptUpdate(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (NSData*)encrypt:(NSData*)buffer NS_SWIFT_NAME(encrypt(_:));

- (void)encryptFile:(NSString*)sourceFile :(NSString*)destFile NS_SWIFT_NAME(encryptFile(_:_:));

- (NSData*)encryptFinal NS_SWIFT_NAME(encryptFinal());

- (void)encryptInit NS_SWIFT_NAME(encryptInit());

- (NSData*)encryptUpdate:(NSData*)buffer NS_SWIFT_NAME(encryptUpdate(_:));

- (void)reset NS_SWIFT_NAME(reset());

@end

