/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

//ASYNCSIGNMETHODS
#define ASMD_PKCS1                                         0

#define ASMD_PKCS7                                         1

//EXTERNALCRYPTOMODES
#define ECM_DEFAULT                                        0

#define ECM_DISABLED                                       1

#define ECM_GENERIC                                        2

#define ECM_DCAUTH                                         3

#define ECM_DCAUTH_JSON                                    4

//CHAINVALIDITIES
#define CVT_VALID                                          0

#define CVT_VALID_BUT_UNTRUSTED                            1

#define CVT_INVALID                                        2

#define CVT_CANT_BE_ESTABLISHED                            3

//DNSRESOLVEMODES
#define DM_AUTO                                            0

#define DM_PLATFORM                                        1

#define DM_OWN                                             2

#define DM_OWN_SECURE                                      3

//SECURETRANSPORTPREDEFINEDCONFIGURATIONS
#define STPC_DEFAULT                                       0

#define STPC_COMPATIBLE                                    1

#define STPC_COMPREHENSIVE_INSECURE                        2

#define STPC_HIGHLY_SECURE                                 3

//CLIENTAUTHTYPES
#define CCAT_NO_AUTH                                       0

#define CCAT_REQUEST_CERT                                  1

#define CCAT_REQUIRE_CERT                                  2

//RENEGOTIATIONATTACKPREVENTIONMODES
#define CRAPM_COMPATIBLE                                   0

#define CRAPM_STRICT                                       1

#define CRAPM_AUTO                                         2

//REVOCATIONCHECKKINDS
#define CRC_NONE                                           0

#define CRC_AUTO                                           1

#define CRC_ALL_CRL                                        2

#define CRC_ALL_OCSP                                       3

#define CRC_ALL_CRLAND_OCSP                                4

#define CRC_ANY_CRL                                        5

#define CRC_ANY_OCSP                                       6

#define CRC_ANY_CRLOR_OCSP                                 7

#define CRC_ANY_OCSPOR_CRL                                 8

//SSLMODES
#define SM_DEFAULT                                         0

#define SM_NO_TLS                                          1

#define SM_EXPLICIT_TLS                                    2

#define SM_IMPLICIT_TLS                                    3

#define SM_MIXED_TLS                                       4

//OTPALGORITHMS
#define OA_NONE                                            0

#define OA_HMAC                                            1

#define OA_TIME                                            2

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxKMIPServerDelegate <NSObject>
@optional
- (void)onAccept:(NSString*)remoteAddress :(int)remotePort :(int*)accept NS_SWIFT_NAME(onAccept(_:_:_:));

- (void)onActivateObject:(long long)connectionId :(NSString*)objectId :(int*)operationStatus NS_SWIFT_NAME(onActivateObject(_:_:_:));

- (void)onAdd:(long long)connectionId :(NSString**)group :(NSString**)certId :(int*)operationStatus NS_SWIFT_NAME(onAdd(_:_:_:_:));

- (void)onAddKey:(long long)connectionId :(NSString**)group :(NSString**)keyId :(int*)operationStatus NS_SWIFT_NAME(onAddKey(_:_:_:_:));

- (void)onAfterAdd:(long long)connectionId :(NSString**)group :(NSString**)certId :(int*)operationStatus NS_SWIFT_NAME(onAfterAdd(_:_:_:_:));

- (void)onAfterAddKey:(long long)connectionId :(NSString**)group :(NSString**)keyId :(int*)operationStatus NS_SWIFT_NAME(onAfterAddKey(_:_:_:_:));

- (void)onAfterBrowse:(long long)connectionID :(NSString*)objectId :(int*)operationStatus NS_SWIFT_NAME(onAfterBrowse(_:_:_:));

- (void)onAfterDecrypt:(long long)connectionId :(NSString*)objectId :(NSData*)decryptedData :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onAfterDecrypt(_:_:_:_:_:));

- (void)onAfterDeriveKey:(long long)connectionId :(NSString**)newKeyId :(int*)operationStatus NS_SWIFT_NAME(onAfterDeriveKey(_:_:_:));

- (void)onAfterEdit:(long long)connectionID :(NSString*)objectId :(int*)operationStatus NS_SWIFT_NAME(onAfterEdit(_:_:_:));

- (void)onAfterEncrypt:(long long)connectionId :(NSString*)objectId :(NSData*)encryptedData :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onAfterEncrypt(_:_:_:_:_:));

- (void)onAfterGenerate:(long long)connectionId :(NSString**)certId :(int*)operationStatus NS_SWIFT_NAME(onAfterGenerate(_:_:_:));

- (void)onAfterGenerateKey:(long long)connectionId :(NSString**)keyId :(int*)operationStatus NS_SWIFT_NAME(onAfterGenerateKey(_:_:_:));

- (void)onAfterGenerateKeyPair:(long long)connectionId :(NSString**)privateKeyId :(NSString**)publicKeyId :(int*)operationStatus NS_SWIFT_NAME(onAfterGenerateKeyPair(_:_:_:_:));

- (void)onAfterHash:(long long)connectionId :(NSString*)objectId :(NSData*)hashData :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onAfterHash(_:_:_:_:_:));

- (void)onAfterList:(long long)connectionId :(int)objectType :(int)objectStatus :(BOOL)onlyFreshObjects :(NSString**)objectIds :(int*)operationStatus NS_SWIFT_NAME(onAfterList(_:_:_:_:_:_:));

- (void)onAfterObtainLease:(long long)connectionId :(NSString*)objectId :(int*)leaseTime :(NSString**)lastChangeDate :(int*)operationStatus NS_SWIFT_NAME(onAfterObtainLease(_:_:_:_:_:));

- (void)onAfterReadObject:(long long)connectionId :(NSString*)objectId :(int)objectType :(int*)operationStatus NS_SWIFT_NAME(onAfterReadObject(_:_:_:_:));

- (void)onAfterReCertify:(long long)connectionId :(NSString**)newCertId :(int*)operationStatus NS_SWIFT_NAME(onAfterReCertify(_:_:_:));

- (void)onAfterReKey:(long long)connectionId :(NSString**)newKeyId :(int*)operationStatus NS_SWIFT_NAME(onAfterReKey(_:_:_:));

- (void)onAfterRekeyKeyPair:(long long)connectionId :(NSString**)newPrivateKeyId :(NSString**)newPublicKeyId :(int*)operationStatus NS_SWIFT_NAME(onAfterRekeyKeyPair(_:_:_:_:));

- (void)onAfterRemoveObject:(long long)connectionId :(NSString*)objectId :(int*)operationStatus NS_SWIFT_NAME(onAfterRemoveObject(_:_:_:));

- (void)onAfterSign:(long long)connectionId :(NSString*)objectId :(BOOL)inputIsHash :(NSData*)signatureData :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onAfterSign(_:_:_:_:_:_:));

- (void)onAfterVerify:(long long)connectionId :(NSString*)objectId :(BOOL)inputIsHash :(int*)validationResult :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onAfterVerify(_:_:_:_:_:_:));

- (void)onAfterVerifyHash:(long long)connectionId :(NSString*)objectId :(int*)isValid :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onAfterVerifyHash(_:_:_:_:_:));

- (void)onArchiveObject:(long long)connectionId :(NSString*)objectId :(int*)operationStatus NS_SWIFT_NAME(onArchiveObject(_:_:_:));

- (void)onAuthAttempt:(long long)connectionID :(NSString*)HTTPMethod :(NSString*)URI :(NSString*)authMethod :(NSString*)username :(NSString*)password :(int*)allow NS_SWIFT_NAME(onAuthAttempt(_:_:_:_:_:_:_:));

- (void)onBeforeAdd:(long long)connectionId :(NSString**)group :(int*)action NS_SWIFT_NAME(onBeforeAdd(_:_:_:));

- (void)onBeforeAddKey:(long long)connectionId :(NSString**)group :(int*)action NS_SWIFT_NAME(onBeforeAddKey(_:_:_:));

- (void)onBeforeBrowse:(long long)connectionID :(NSString*)objectId :(int*)action NS_SWIFT_NAME(onBeforeBrowse(_:_:_:));

- (void)onBeforeDecrypt:(long long)connectionId :(NSString*)objectId :(NSString**)correlationValue :(int*)action NS_SWIFT_NAME(onBeforeDecrypt(_:_:_:_:));

- (void)onBeforeDeriveKey:(long long)connectionId :(int)objectType :(NSString*)objectIds :(NSString*)derivationMethod :(int*)action NS_SWIFT_NAME(onBeforeDeriveKey(_:_:_:_:_:));

- (void)onBeforeEdit:(long long)connectionID :(NSString*)objectId :(int*)action NS_SWIFT_NAME(onBeforeEdit(_:_:_:));

- (void)onBeforeEncrypt:(long long)connectionId :(NSString*)objectId :(NSString**)correlationValue :(int*)action NS_SWIFT_NAME(onBeforeEncrypt(_:_:_:_:));

- (void)onBeforeGenerate:(long long)connectionId :(NSString*)publicKeyId :(int*)action NS_SWIFT_NAME(onBeforeGenerate(_:_:_:));

- (void)onBeforeGenerateKey:(long long)connectionId :(NSString**)keyAlgorithm :(int*)keyLength :(int*)action NS_SWIFT_NAME(onBeforeGenerateKey(_:_:_:_:));

- (void)onBeforeGenerateKeyPair:(long long)connectionId :(NSString**)keyAlgorithm :(int*)keyLength :(NSString**)scheme :(NSString**)schemeParams :(int*)action NS_SWIFT_NAME(onBeforeGenerateKeyPair(_:_:_:_:_:_:));

- (void)onBeforeHash:(long long)connectionId :(NSString*)objectId :(NSString*)hashAlgorithm :(NSString**)correlationValue :(int*)action NS_SWIFT_NAME(onBeforeHash(_:_:_:_:_:));

- (void)onBeforeList:(long long)connectionId :(int)objectType :(int)objectStatus :(BOOL)onlyFreshObjects :(int*)action NS_SWIFT_NAME(onBeforeList(_:_:_:_:_:));

- (void)onBeforeObtainLease:(long long)connectionId :(NSString*)objectId :(int*)action NS_SWIFT_NAME(onBeforeObtainLease(_:_:_:));

- (void)onBeforeReadObject:(long long)connectionId :(NSString*)objectId :(int*)action NS_SWIFT_NAME(onBeforeReadObject(_:_:_:));

- (void)onBeforeReCertify:(long long)connectionId :(NSString*)oldCertId :(int*)action NS_SWIFT_NAME(onBeforeReCertify(_:_:_:));

- (void)onBeforeReKey:(long long)connectionId :(NSString*)oldKeyId :(int*)action NS_SWIFT_NAME(onBeforeReKey(_:_:_:));

- (void)onBeforeRekeyKeyPair:(long long)connectionId :(NSString*)oldPrivateKeyId :(int*)action NS_SWIFT_NAME(onBeforeRekeyKeyPair(_:_:_:));

- (void)onBeforeRemoveObject:(long long)connectionId :(NSString*)objectId :(int*)action NS_SWIFT_NAME(onBeforeRemoveObject(_:_:_:));

- (void)onBeforeSign:(long long)connectionId :(NSString*)objectId :(NSString*)algorithm :(NSString*)hashAlgorithm :(BOOL)inputIsHash :(NSString**)correlationValue :(int*)action NS_SWIFT_NAME(onBeforeSign(_:_:_:_:_:_:_:));

- (void)onBeforeVerify:(long long)connectionId :(NSString*)objectId :(NSString*)hashAlgorithm :(BOOL)inputIsHash :(NSString**)correlationValue :(int*)action NS_SWIFT_NAME(onBeforeVerify(_:_:_:_:_:_:));

- (void)onBeforeVerifyHash:(long long)connectionId :(NSString*)objectId :(NSString*)hashAlgorithm :(NSString**)correlationValue :(int*)action NS_SWIFT_NAME(onBeforeVerifyHash(_:_:_:_:_:));

- (void)onCancel:(long long)connectionId :(NSString*)asyncCorrelationValue :(int*)cancellationResult :(int*)operationStatus NS_SWIFT_NAME(onCancel(_:_:_:_:));

- (void)onCheck:(long long)connectionId :(NSString*)objectId :(long long*)usageLimitsCount :(int*)cryptographicUsageMask :(int*)leaseTime :(int*)operationStatus NS_SWIFT_NAME(onCheck(_:_:_:_:_:_:));

- (void)onConnect:(long long)connectionID :(NSString*)remoteAddress :(int)remotePort NS_SWIFT_NAME(onConnect(_:_:_:));

- (void)onDecrypt:(long long)connectionId :(NSString*)objectId :(NSData*)data :(NSString*)IV :(BOOL)initIndicator :(BOOL)finalIndicator :(NSString*)blockCipherMode :(int)tagLength :(NSString*)paddingMethod :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onDecrypt(_:_:_:_:_:_:_:_:_:_:_:));

- (void)onDeleteAttribute:(long long)connectionId :(NSString*)objectId :(NSString*)attributeName :(NSString**)attributeValue :(int*)operationStatus NS_SWIFT_NAME(onDeleteAttribute(_:_:_:_:_:));

- (void)onDeriveKey:(long long)connectionId :(int)objectType :(NSString*)objectIds :(NSString*)derivationMethod :(NSData*)initializationVector :(NSData*)derivationData :(NSString**)newKeyId :(int*)operationStatus NS_SWIFT_NAME(onDeriveKey(_:_:_:_:_:_:_:_:));

- (void)onDisconnect:(long long)connectionID NS_SWIFT_NAME(onDisconnect(_:));

- (void)onEncrypt:(long long)connectionId :(NSString*)objectId :(NSData*)data :(BOOL)initIndicator :(BOOL)finalIndicator :(NSString*)blockCipherMode :(int)tagLength :(NSString*)paddingMethod :(BOOL)randomIV :(NSString**)IV :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onEncrypt(_:_:_:_:_:_:_:_:_:_:_:_:));

- (void)onError:(long long)connectionID :(int)errorCode :(BOOL)fatal :(BOOL)remote :(NSString*)description NS_SWIFT_NAME(onError(_:_:_:_:_:));

- (void)onExternalSign:(long long)connectionID :(NSString*)operationId :(NSString*)hashAlgorithm :(NSString*)pars :(NSString*)data :(NSString**)signedData NS_SWIFT_NAME(onExternalSign(_:_:_:_:_:_:));

- (void)onGenerate:(long long)connectionId :(NSString*)publicKeyId :(NSString**)certId :(int*)operationStatus NS_SWIFT_NAME(onGenerate(_:_:_:_:));

- (void)onGenerateKey:(long long)connectionId :(NSString*)keyAlgorithm :(int)keyLength :(NSString*)group :(NSString**)keyId :(int*)operationStatus NS_SWIFT_NAME(onGenerateKey(_:_:_:_:_:_:));

- (void)onGenerateKeyPair:(long long)connectionId :(NSString*)keyAlgorithm :(int)keyLength :(NSString*)scheme :(NSString*)schemeParams :(NSString*)group :(NSString**)privateKeyId :(NSString**)publicKeyId :(int*)operationStatus NS_SWIFT_NAME(onGenerateKeyPair(_:_:_:_:_:_:_:_:_:));

- (void)onGetUsageAllocation:(long long)connectionId :(NSString*)objectId :(int)usageLimitsCount :(int*)operationStatus NS_SWIFT_NAME(onGetUsageAllocation(_:_:_:_:));

- (void)onHash:(long long)connectionId :(NSString*)objectId :(NSString*)hashAlgorithm :(NSData*)data :(BOOL)initIndicator :(BOOL)finalIndicator :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onHash(_:_:_:_:_:_:_:_:));

- (void)onHeadersPrepared:(long long)connectionID NS_SWIFT_NAME(onHeadersPrepared(_:));

- (void)onKMIPAuthAttempt:(long long)connectionId :(NSString*)username :(NSString*)password :(int*)accept NS_SWIFT_NAME(onKMIPAuthAttempt(_:_:_:_:));

- (void)onList:(long long)connectionId :(int)objectType :(int)objectStatus :(BOOL)onlyFreshObjects :(int)offsetItems :(int)maximumItems :(NSString**)objectIds :(int*)locatedItems :(int*)operationStatus NS_SWIFT_NAME(onList(_:_:_:_:_:_:_:_:_:));

- (void)onListAttributes:(long long)connectionId :(NSString*)objectId :(NSString**)attributeNames :(int*)operationStatus NS_SWIFT_NAME(onListAttributes(_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onObtainLease:(long long)connectionId :(NSString*)objectId :(int*)leaseTime :(NSString**)lastChangeDate :(int*)operationStatus NS_SWIFT_NAME(onObtainLease(_:_:_:_:_:));

- (void)onOperationAttempt:(long long)connectionId :(NSString*)operation :(NSString*)username :(int*)reject NS_SWIFT_NAME(onOperationAttempt(_:_:_:_:));

- (void)onPoll:(long long)connectionId :(NSString*)asyncCorrelationValue :(int*)operationStatus NS_SWIFT_NAME(onPoll(_:_:_:));

- (void)onReadAttribute:(long long)connectionId :(NSString*)objectId :(NSString*)attributeName :(NSString**)attributeValue :(int*)operationStatus NS_SWIFT_NAME(onReadAttribute(_:_:_:_:_:));

- (void)onReadObject:(long long)connectionId :(NSString*)objectId :(int*)objectType :(int*)operationStatus NS_SWIFT_NAME(onReadObject(_:_:_:_:));

- (void)onReCertify:(long long)connectionId :(NSString*)oldCertId :(int)offset :(NSString*)group :(NSString**)newCertId :(int*)operationStatus NS_SWIFT_NAME(onReCertify(_:_:_:_:_:_:));

- (void)onRecoverObject:(long long)connectionId :(NSString*)objectId :(int*)operationStatus NS_SWIFT_NAME(onRecoverObject(_:_:_:));

- (void)onReKey:(long long)connectionId :(NSString*)oldKeyId :(int)offset :(NSString*)group :(NSString**)newKeyId :(int*)operationStatus NS_SWIFT_NAME(onReKey(_:_:_:_:_:_:));

- (void)onRekeyKeyPair:(long long)connectionId :(NSString*)oldPrivateKeyId :(int)offset :(NSString*)group :(NSString**)newPrivateKeyId :(NSString**)newPublicKeyId :(int*)operationStatus NS_SWIFT_NAME(onRekeyKeyPair(_:_:_:_:_:_:_:));

- (void)onRemoveObject:(long long)connectionId :(NSString*)objectId :(int*)operationStatus NS_SWIFT_NAME(onRemoveObject(_:_:_:));

- (void)onRequest:(long long)connectionId :(NSData*)requestData NS_SWIFT_NAME(onRequest(_:_:));

- (void)onResponse:(long long)connectionId :(NSData*)responseData NS_SWIFT_NAME(onResponse(_:_:));

- (void)onRevokeObject:(long long)connectionId :(NSString*)objectId :(int)reasonCode :(NSString*)reasonMessage :(int*)operationStatus NS_SWIFT_NAME(onRevokeObject(_:_:_:_:_:));

- (void)onRNGGenerate:(long long)connectionId :(int)dataLength :(int*)operationStatus NS_SWIFT_NAME(onRNGGenerate(_:_:_:));

- (void)onRNGSeed:(long long)connectionId :(NSData*)data :(int*)bytesUsed :(int*)operationStatus NS_SWIFT_NAME(onRNGSeed(_:_:_:_:));

- (void)onSetAttribute:(long long)connectionId :(NSString*)objectId :(NSString*)attributeName :(NSString*)attributeValue :(int*)operationStatus NS_SWIFT_NAME(onSetAttribute(_:_:_:_:_:));

- (void)onSign:(long long)connectionId :(NSString*)objectId :(NSString*)algorithm :(NSString*)hashAlgorithm :(BOOL)inputIsHash :(NSData*)data :(BOOL)initIndicator :(BOOL)finalIndicator :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onSign(_:_:_:_:_:_:_:_:_:_:));

- (void)onTLSCertValidate:(long long)connectionID :(int*)accept NS_SWIFT_NAME(onTLSCertValidate(_:_:));

- (void)onTLSEstablished:(long long)connectionID NS_SWIFT_NAME(onTLSEstablished(_:));

- (void)onTLSHandshake:(long long)connectionID :(NSString*)serverName :(int*)abort NS_SWIFT_NAME(onTLSHandshake(_:_:_:));

- (void)onTLSPSK:(long long)connectionID :(NSString*)identity :(NSString**)PSK :(NSString**)ciphersuite NS_SWIFT_NAME(onTLSPSK(_:_:_:_:));

- (void)onTLSShutdown:(long long)connectionID NS_SWIFT_NAME(onTLSShutdown(_:));

- (void)onValidateChain:(long long)connectionId :(NSString*)objectIds :(int*)validity :(int*)operationStatus NS_SWIFT_NAME(onValidateChain(_:_:_:_:));

- (void)onVerify:(long long)connectionId :(NSString*)objectId :(NSString*)hashAlgorithm :(BOOL)inputIsHash :(NSData*)data :(NSData*)signatureData :(BOOL)initIndicator :(BOOL)finalIndicator :(int*)validationResult :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onVerify(_:_:_:_:_:_:_:_:_:_:_:));

- (void)onVerifyHash:(long long)connectionId :(NSString*)objectId :(NSString*)hashAlgorithm :(NSData*)data :(NSData*)hash :(BOOL)initIndicator :(BOOL)finalIndicator :(int*)isValid :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onVerifyHash(_:_:_:_:_:_:_:_:_:_:));

@end

@interface SecureBlackboxKMIPServer : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxKMIPServerDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasAccept;

  BOOL m_delegateHasActivateObject;

  BOOL m_delegateHasAdd;

  BOOL m_delegateHasAddKey;

  BOOL m_delegateHasAfterAdd;

  BOOL m_delegateHasAfterAddKey;

  BOOL m_delegateHasAfterBrowse;

  BOOL m_delegateHasAfterDecrypt;

  BOOL m_delegateHasAfterDeriveKey;

  BOOL m_delegateHasAfterEdit;

  BOOL m_delegateHasAfterEncrypt;

  BOOL m_delegateHasAfterGenerate;

  BOOL m_delegateHasAfterGenerateKey;

  BOOL m_delegateHasAfterGenerateKeyPair;

  BOOL m_delegateHasAfterHash;

  BOOL m_delegateHasAfterList;

  BOOL m_delegateHasAfterObtainLease;

  BOOL m_delegateHasAfterReadObject;

  BOOL m_delegateHasAfterReCertify;

  BOOL m_delegateHasAfterReKey;

  BOOL m_delegateHasAfterRekeyKeyPair;

  BOOL m_delegateHasAfterRemoveObject;

  BOOL m_delegateHasAfterSign;

  BOOL m_delegateHasAfterVerify;

  BOOL m_delegateHasAfterVerifyHash;

  BOOL m_delegateHasArchiveObject;

  BOOL m_delegateHasAuthAttempt;

  BOOL m_delegateHasBeforeAdd;

  BOOL m_delegateHasBeforeAddKey;

  BOOL m_delegateHasBeforeBrowse;

  BOOL m_delegateHasBeforeDecrypt;

  BOOL m_delegateHasBeforeDeriveKey;

  BOOL m_delegateHasBeforeEdit;

  BOOL m_delegateHasBeforeEncrypt;

  BOOL m_delegateHasBeforeGenerate;

  BOOL m_delegateHasBeforeGenerateKey;

  BOOL m_delegateHasBeforeGenerateKeyPair;

  BOOL m_delegateHasBeforeHash;

  BOOL m_delegateHasBeforeList;

  BOOL m_delegateHasBeforeObtainLease;

  BOOL m_delegateHasBeforeReadObject;

  BOOL m_delegateHasBeforeReCertify;

  BOOL m_delegateHasBeforeReKey;

  BOOL m_delegateHasBeforeRekeyKeyPair;

  BOOL m_delegateHasBeforeRemoveObject;

  BOOL m_delegateHasBeforeSign;

  BOOL m_delegateHasBeforeVerify;

  BOOL m_delegateHasBeforeVerifyHash;

  BOOL m_delegateHasCancel;

  BOOL m_delegateHasCheck;

  BOOL m_delegateHasConnect;

  BOOL m_delegateHasDecrypt;

  BOOL m_delegateHasDeleteAttribute;

  BOOL m_delegateHasDeriveKey;

  BOOL m_delegateHasDisconnect;

  BOOL m_delegateHasEncrypt;

  BOOL m_delegateHasError;

  BOOL m_delegateHasExternalSign;

  BOOL m_delegateHasGenerate;

  BOOL m_delegateHasGenerateKey;

  BOOL m_delegateHasGenerateKeyPair;

  BOOL m_delegateHasGetUsageAllocation;

  BOOL m_delegateHasHash;

  BOOL m_delegateHasHeadersPrepared;

  BOOL m_delegateHasKMIPAuthAttempt;

  BOOL m_delegateHasList;

  BOOL m_delegateHasListAttributes;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasObtainLease;

  BOOL m_delegateHasOperationAttempt;

  BOOL m_delegateHasPoll;

  BOOL m_delegateHasReadAttribute;

  BOOL m_delegateHasReadObject;

  BOOL m_delegateHasReCertify;

  BOOL m_delegateHasRecoverObject;

  BOOL m_delegateHasReKey;

  BOOL m_delegateHasRekeyKeyPair;

  BOOL m_delegateHasRemoveObject;

  BOOL m_delegateHasRequest;

  BOOL m_delegateHasResponse;

  BOOL m_delegateHasRevokeObject;

  BOOL m_delegateHasRNGGenerate;

  BOOL m_delegateHasRNGSeed;

  BOOL m_delegateHasSetAttribute;

  BOOL m_delegateHasSign;

  BOOL m_delegateHasTLSCertValidate;

  BOOL m_delegateHasTLSEstablished;

  BOOL m_delegateHasTLSHandshake;

  BOOL m_delegateHasTLSPSK;

  BOOL m_delegateHasTLSShutdown;

  BOOL m_delegateHasValidateChain;

  BOOL m_delegateHasVerify;

  BOOL m_delegateHasVerifyHash;

}

+ (SecureBlackboxKMIPServer*)kmipserver;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxKMIPServerDelegate> delegate;
- (id <SecureBlackboxKMIPServerDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxKMIPServerDelegate>)anObject;

  /* Events */

- (void)onAccept:(NSString*)remoteAddress :(int)remotePort :(int*)accept NS_SWIFT_NAME(onAccept(_:_:_:));

- (void)onActivateObject:(long long)connectionId :(NSString*)objectId :(int*)operationStatus NS_SWIFT_NAME(onActivateObject(_:_:_:));

- (void)onAdd:(long long)connectionId :(NSString**)group :(NSString**)certId :(int*)operationStatus NS_SWIFT_NAME(onAdd(_:_:_:_:));

- (void)onAddKey:(long long)connectionId :(NSString**)group :(NSString**)keyId :(int*)operationStatus NS_SWIFT_NAME(onAddKey(_:_:_:_:));

- (void)onAfterAdd:(long long)connectionId :(NSString**)group :(NSString**)certId :(int*)operationStatus NS_SWIFT_NAME(onAfterAdd(_:_:_:_:));

- (void)onAfterAddKey:(long long)connectionId :(NSString**)group :(NSString**)keyId :(int*)operationStatus NS_SWIFT_NAME(onAfterAddKey(_:_:_:_:));

- (void)onAfterBrowse:(long long)connectionID :(NSString*)objectId :(int*)operationStatus NS_SWIFT_NAME(onAfterBrowse(_:_:_:));

- (void)onAfterDecrypt:(long long)connectionId :(NSString*)objectId :(NSData*)decryptedData :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onAfterDecrypt(_:_:_:_:_:));

- (void)onAfterDeriveKey:(long long)connectionId :(NSString**)newKeyId :(int*)operationStatus NS_SWIFT_NAME(onAfterDeriveKey(_:_:_:));

- (void)onAfterEdit:(long long)connectionID :(NSString*)objectId :(int*)operationStatus NS_SWIFT_NAME(onAfterEdit(_:_:_:));

- (void)onAfterEncrypt:(long long)connectionId :(NSString*)objectId :(NSData*)encryptedData :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onAfterEncrypt(_:_:_:_:_:));

- (void)onAfterGenerate:(long long)connectionId :(NSString**)certId :(int*)operationStatus NS_SWIFT_NAME(onAfterGenerate(_:_:_:));

- (void)onAfterGenerateKey:(long long)connectionId :(NSString**)keyId :(int*)operationStatus NS_SWIFT_NAME(onAfterGenerateKey(_:_:_:));

- (void)onAfterGenerateKeyPair:(long long)connectionId :(NSString**)privateKeyId :(NSString**)publicKeyId :(int*)operationStatus NS_SWIFT_NAME(onAfterGenerateKeyPair(_:_:_:_:));

- (void)onAfterHash:(long long)connectionId :(NSString*)objectId :(NSData*)hashData :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onAfterHash(_:_:_:_:_:));

- (void)onAfterList:(long long)connectionId :(int)objectType :(int)objectStatus :(BOOL)onlyFreshObjects :(NSString**)objectIds :(int*)operationStatus NS_SWIFT_NAME(onAfterList(_:_:_:_:_:_:));

- (void)onAfterObtainLease:(long long)connectionId :(NSString*)objectId :(int*)leaseTime :(NSString**)lastChangeDate :(int*)operationStatus NS_SWIFT_NAME(onAfterObtainLease(_:_:_:_:_:));

- (void)onAfterReadObject:(long long)connectionId :(NSString*)objectId :(int)objectType :(int*)operationStatus NS_SWIFT_NAME(onAfterReadObject(_:_:_:_:));

- (void)onAfterReCertify:(long long)connectionId :(NSString**)newCertId :(int*)operationStatus NS_SWIFT_NAME(onAfterReCertify(_:_:_:));

- (void)onAfterReKey:(long long)connectionId :(NSString**)newKeyId :(int*)operationStatus NS_SWIFT_NAME(onAfterReKey(_:_:_:));

- (void)onAfterRekeyKeyPair:(long long)connectionId :(NSString**)newPrivateKeyId :(NSString**)newPublicKeyId :(int*)operationStatus NS_SWIFT_NAME(onAfterRekeyKeyPair(_:_:_:_:));

- (void)onAfterRemoveObject:(long long)connectionId :(NSString*)objectId :(int*)operationStatus NS_SWIFT_NAME(onAfterRemoveObject(_:_:_:));

- (void)onAfterSign:(long long)connectionId :(NSString*)objectId :(BOOL)inputIsHash :(NSData*)signatureData :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onAfterSign(_:_:_:_:_:_:));

- (void)onAfterVerify:(long long)connectionId :(NSString*)objectId :(BOOL)inputIsHash :(int*)validationResult :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onAfterVerify(_:_:_:_:_:_:));

- (void)onAfterVerifyHash:(long long)connectionId :(NSString*)objectId :(int*)isValid :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onAfterVerifyHash(_:_:_:_:_:));

- (void)onArchiveObject:(long long)connectionId :(NSString*)objectId :(int*)operationStatus NS_SWIFT_NAME(onArchiveObject(_:_:_:));

- (void)onAuthAttempt:(long long)connectionID :(NSString*)HTTPMethod :(NSString*)URI :(NSString*)authMethod :(NSString*)username :(NSString*)password :(int*)allow NS_SWIFT_NAME(onAuthAttempt(_:_:_:_:_:_:_:));

- (void)onBeforeAdd:(long long)connectionId :(NSString**)group :(int*)action NS_SWIFT_NAME(onBeforeAdd(_:_:_:));

- (void)onBeforeAddKey:(long long)connectionId :(NSString**)group :(int*)action NS_SWIFT_NAME(onBeforeAddKey(_:_:_:));

- (void)onBeforeBrowse:(long long)connectionID :(NSString*)objectId :(int*)action NS_SWIFT_NAME(onBeforeBrowse(_:_:_:));

- (void)onBeforeDecrypt:(long long)connectionId :(NSString*)objectId :(NSString**)correlationValue :(int*)action NS_SWIFT_NAME(onBeforeDecrypt(_:_:_:_:));

- (void)onBeforeDeriveKey:(long long)connectionId :(int)objectType :(NSString*)objectIds :(NSString*)derivationMethod :(int*)action NS_SWIFT_NAME(onBeforeDeriveKey(_:_:_:_:_:));

- (void)onBeforeEdit:(long long)connectionID :(NSString*)objectId :(int*)action NS_SWIFT_NAME(onBeforeEdit(_:_:_:));

- (void)onBeforeEncrypt:(long long)connectionId :(NSString*)objectId :(NSString**)correlationValue :(int*)action NS_SWIFT_NAME(onBeforeEncrypt(_:_:_:_:));

- (void)onBeforeGenerate:(long long)connectionId :(NSString*)publicKeyId :(int*)action NS_SWIFT_NAME(onBeforeGenerate(_:_:_:));

- (void)onBeforeGenerateKey:(long long)connectionId :(NSString**)keyAlgorithm :(int*)keyLength :(int*)action NS_SWIFT_NAME(onBeforeGenerateKey(_:_:_:_:));

- (void)onBeforeGenerateKeyPair:(long long)connectionId :(NSString**)keyAlgorithm :(int*)keyLength :(NSString**)scheme :(NSString**)schemeParams :(int*)action NS_SWIFT_NAME(onBeforeGenerateKeyPair(_:_:_:_:_:_:));

- (void)onBeforeHash:(long long)connectionId :(NSString*)objectId :(NSString*)hashAlgorithm :(NSString**)correlationValue :(int*)action NS_SWIFT_NAME(onBeforeHash(_:_:_:_:_:));

- (void)onBeforeList:(long long)connectionId :(int)objectType :(int)objectStatus :(BOOL)onlyFreshObjects :(int*)action NS_SWIFT_NAME(onBeforeList(_:_:_:_:_:));

- (void)onBeforeObtainLease:(long long)connectionId :(NSString*)objectId :(int*)action NS_SWIFT_NAME(onBeforeObtainLease(_:_:_:));

- (void)onBeforeReadObject:(long long)connectionId :(NSString*)objectId :(int*)action NS_SWIFT_NAME(onBeforeReadObject(_:_:_:));

- (void)onBeforeReCertify:(long long)connectionId :(NSString*)oldCertId :(int*)action NS_SWIFT_NAME(onBeforeReCertify(_:_:_:));

- (void)onBeforeReKey:(long long)connectionId :(NSString*)oldKeyId :(int*)action NS_SWIFT_NAME(onBeforeReKey(_:_:_:));

- (void)onBeforeRekeyKeyPair:(long long)connectionId :(NSString*)oldPrivateKeyId :(int*)action NS_SWIFT_NAME(onBeforeRekeyKeyPair(_:_:_:));

- (void)onBeforeRemoveObject:(long long)connectionId :(NSString*)objectId :(int*)action NS_SWIFT_NAME(onBeforeRemoveObject(_:_:_:));

- (void)onBeforeSign:(long long)connectionId :(NSString*)objectId :(NSString*)algorithm :(NSString*)hashAlgorithm :(BOOL)inputIsHash :(NSString**)correlationValue :(int*)action NS_SWIFT_NAME(onBeforeSign(_:_:_:_:_:_:_:));

- (void)onBeforeVerify:(long long)connectionId :(NSString*)objectId :(NSString*)hashAlgorithm :(BOOL)inputIsHash :(NSString**)correlationValue :(int*)action NS_SWIFT_NAME(onBeforeVerify(_:_:_:_:_:_:));

- (void)onBeforeVerifyHash:(long long)connectionId :(NSString*)objectId :(NSString*)hashAlgorithm :(NSString**)correlationValue :(int*)action NS_SWIFT_NAME(onBeforeVerifyHash(_:_:_:_:_:));

- (void)onCancel:(long long)connectionId :(NSString*)asyncCorrelationValue :(int*)cancellationResult :(int*)operationStatus NS_SWIFT_NAME(onCancel(_:_:_:_:));

- (void)onCheck:(long long)connectionId :(NSString*)objectId :(long long*)usageLimitsCount :(int*)cryptographicUsageMask :(int*)leaseTime :(int*)operationStatus NS_SWIFT_NAME(onCheck(_:_:_:_:_:_:));

- (void)onConnect:(long long)connectionID :(NSString*)remoteAddress :(int)remotePort NS_SWIFT_NAME(onConnect(_:_:_:));

- (void)onDecrypt:(long long)connectionId :(NSString*)objectId :(NSData*)data :(NSString*)IV :(BOOL)initIndicator :(BOOL)finalIndicator :(NSString*)blockCipherMode :(int)tagLength :(NSString*)paddingMethod :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onDecrypt(_:_:_:_:_:_:_:_:_:_:_:));

- (void)onDeleteAttribute:(long long)connectionId :(NSString*)objectId :(NSString*)attributeName :(NSString**)attributeValue :(int*)operationStatus NS_SWIFT_NAME(onDeleteAttribute(_:_:_:_:_:));

- (void)onDeriveKey:(long long)connectionId :(int)objectType :(NSString*)objectIds :(NSString*)derivationMethod :(NSData*)initializationVector :(NSData*)derivationData :(NSString**)newKeyId :(int*)operationStatus NS_SWIFT_NAME(onDeriveKey(_:_:_:_:_:_:_:_:));

- (void)onDisconnect:(long long)connectionID NS_SWIFT_NAME(onDisconnect(_:));

- (void)onEncrypt:(long long)connectionId :(NSString*)objectId :(NSData*)data :(BOOL)initIndicator :(BOOL)finalIndicator :(NSString*)blockCipherMode :(int)tagLength :(NSString*)paddingMethod :(BOOL)randomIV :(NSString**)IV :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onEncrypt(_:_:_:_:_:_:_:_:_:_:_:_:));

- (void)onError:(long long)connectionID :(int)errorCode :(BOOL)fatal :(BOOL)remote :(NSString*)description NS_SWIFT_NAME(onError(_:_:_:_:_:));

- (void)onExternalSign:(long long)connectionID :(NSString*)operationId :(NSString*)hashAlgorithm :(NSString*)pars :(NSString*)data :(NSString**)signedData NS_SWIFT_NAME(onExternalSign(_:_:_:_:_:_:));

- (void)onGenerate:(long long)connectionId :(NSString*)publicKeyId :(NSString**)certId :(int*)operationStatus NS_SWIFT_NAME(onGenerate(_:_:_:_:));

- (void)onGenerateKey:(long long)connectionId :(NSString*)keyAlgorithm :(int)keyLength :(NSString*)group :(NSString**)keyId :(int*)operationStatus NS_SWIFT_NAME(onGenerateKey(_:_:_:_:_:_:));

- (void)onGenerateKeyPair:(long long)connectionId :(NSString*)keyAlgorithm :(int)keyLength :(NSString*)scheme :(NSString*)schemeParams :(NSString*)group :(NSString**)privateKeyId :(NSString**)publicKeyId :(int*)operationStatus NS_SWIFT_NAME(onGenerateKeyPair(_:_:_:_:_:_:_:_:_:));

- (void)onGetUsageAllocation:(long long)connectionId :(NSString*)objectId :(int)usageLimitsCount :(int*)operationStatus NS_SWIFT_NAME(onGetUsageAllocation(_:_:_:_:));

- (void)onHash:(long long)connectionId :(NSString*)objectId :(NSString*)hashAlgorithm :(NSData*)data :(BOOL)initIndicator :(BOOL)finalIndicator :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onHash(_:_:_:_:_:_:_:_:));

- (void)onHeadersPrepared:(long long)connectionID NS_SWIFT_NAME(onHeadersPrepared(_:));

- (void)onKMIPAuthAttempt:(long long)connectionId :(NSString*)username :(NSString*)password :(int*)accept NS_SWIFT_NAME(onKMIPAuthAttempt(_:_:_:_:));

- (void)onList:(long long)connectionId :(int)objectType :(int)objectStatus :(BOOL)onlyFreshObjects :(int)offsetItems :(int)maximumItems :(NSString**)objectIds :(int*)locatedItems :(int*)operationStatus NS_SWIFT_NAME(onList(_:_:_:_:_:_:_:_:_:));

- (void)onListAttributes:(long long)connectionId :(NSString*)objectId :(NSString**)attributeNames :(int*)operationStatus NS_SWIFT_NAME(onListAttributes(_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onObtainLease:(long long)connectionId :(NSString*)objectId :(int*)leaseTime :(NSString**)lastChangeDate :(int*)operationStatus NS_SWIFT_NAME(onObtainLease(_:_:_:_:_:));

- (void)onOperationAttempt:(long long)connectionId :(NSString*)operation :(NSString*)username :(int*)reject NS_SWIFT_NAME(onOperationAttempt(_:_:_:_:));

- (void)onPoll:(long long)connectionId :(NSString*)asyncCorrelationValue :(int*)operationStatus NS_SWIFT_NAME(onPoll(_:_:_:));

- (void)onReadAttribute:(long long)connectionId :(NSString*)objectId :(NSString*)attributeName :(NSString**)attributeValue :(int*)operationStatus NS_SWIFT_NAME(onReadAttribute(_:_:_:_:_:));

- (void)onReadObject:(long long)connectionId :(NSString*)objectId :(int*)objectType :(int*)operationStatus NS_SWIFT_NAME(onReadObject(_:_:_:_:));

- (void)onReCertify:(long long)connectionId :(NSString*)oldCertId :(int)offset :(NSString*)group :(NSString**)newCertId :(int*)operationStatus NS_SWIFT_NAME(onReCertify(_:_:_:_:_:_:));

- (void)onRecoverObject:(long long)connectionId :(NSString*)objectId :(int*)operationStatus NS_SWIFT_NAME(onRecoverObject(_:_:_:));

- (void)onReKey:(long long)connectionId :(NSString*)oldKeyId :(int)offset :(NSString*)group :(NSString**)newKeyId :(int*)operationStatus NS_SWIFT_NAME(onReKey(_:_:_:_:_:_:));

- (void)onRekeyKeyPair:(long long)connectionId :(NSString*)oldPrivateKeyId :(int)offset :(NSString*)group :(NSString**)newPrivateKeyId :(NSString**)newPublicKeyId :(int*)operationStatus NS_SWIFT_NAME(onRekeyKeyPair(_:_:_:_:_:_:_:));

- (void)onRemoveObject:(long long)connectionId :(NSString*)objectId :(int*)operationStatus NS_SWIFT_NAME(onRemoveObject(_:_:_:));

- (void)onRequest:(long long)connectionId :(NSData*)requestData NS_SWIFT_NAME(onRequest(_:_:));

- (void)onResponse:(long long)connectionId :(NSData*)responseData NS_SWIFT_NAME(onResponse(_:_:));

- (void)onRevokeObject:(long long)connectionId :(NSString*)objectId :(int)reasonCode :(NSString*)reasonMessage :(int*)operationStatus NS_SWIFT_NAME(onRevokeObject(_:_:_:_:_:));

- (void)onRNGGenerate:(long long)connectionId :(int)dataLength :(int*)operationStatus NS_SWIFT_NAME(onRNGGenerate(_:_:_:));

- (void)onRNGSeed:(long long)connectionId :(NSData*)data :(int*)bytesUsed :(int*)operationStatus NS_SWIFT_NAME(onRNGSeed(_:_:_:_:));

- (void)onSetAttribute:(long long)connectionId :(NSString*)objectId :(NSString*)attributeName :(NSString*)attributeValue :(int*)operationStatus NS_SWIFT_NAME(onSetAttribute(_:_:_:_:_:));

- (void)onSign:(long long)connectionId :(NSString*)objectId :(NSString*)algorithm :(NSString*)hashAlgorithm :(BOOL)inputIsHash :(NSData*)data :(BOOL)initIndicator :(BOOL)finalIndicator :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onSign(_:_:_:_:_:_:_:_:_:_:));

- (void)onTLSCertValidate:(long long)connectionID :(int*)accept NS_SWIFT_NAME(onTLSCertValidate(_:_:));

- (void)onTLSEstablished:(long long)connectionID NS_SWIFT_NAME(onTLSEstablished(_:));

- (void)onTLSHandshake:(long long)connectionID :(NSString*)serverName :(int*)abort NS_SWIFT_NAME(onTLSHandshake(_:_:_:));

- (void)onTLSPSK:(long long)connectionID :(NSString*)identity :(NSString**)PSK :(NSString**)ciphersuite NS_SWIFT_NAME(onTLSPSK(_:_:_:_:));

- (void)onTLSShutdown:(long long)connectionID NS_SWIFT_NAME(onTLSShutdown(_:));

- (void)onValidateChain:(long long)connectionId :(NSString*)objectIds :(int*)validity :(int*)operationStatus NS_SWIFT_NAME(onValidateChain(_:_:_:_:));

- (void)onVerify:(long long)connectionId :(NSString*)objectId :(NSString*)hashAlgorithm :(BOOL)inputIsHash :(NSData*)data :(NSData*)signatureData :(BOOL)initIndicator :(BOOL)finalIndicator :(int*)validationResult :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onVerify(_:_:_:_:_:_:_:_:_:_:_:));

- (void)onVerifyHash:(long long)connectionId :(NSString*)objectId :(NSString*)hashAlgorithm :(NSData*)data :(NSData*)hash :(BOOL)initIndicator :(BOOL)finalIndicator :(int*)isValid :(NSString**)correlationValue :(int*)operationStatus NS_SWIFT_NAME(onVerifyHash(_:_:_:_:_:_:_:_:_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readonly,assign,getter=active) BOOL active NS_SWIFT_NAME(active);

- (BOOL)active NS_SWIFT_NAME(active());

@property (nonatomic,readwrite,assign,getter=allowKeepAlive,setter=setAllowKeepAlive:) BOOL allowKeepAlive NS_SWIFT_NAME(allowKeepAlive);

- (BOOL)allowKeepAlive NS_SWIFT_NAME(allowKeepAlive());
- (void)setAllowKeepAlive :(BOOL)newAllowKeepAlive NS_SWIFT_NAME(setAllowKeepAlive(_:));

@property (nonatomic,readwrite,assign,getter=authRealm,setter=setAuthRealm:) NSString* authRealm NS_SWIFT_NAME(authRealm);

- (NSString*)authRealm NS_SWIFT_NAME(authRealm());
- (void)setAuthRealm :(NSString*)newAuthRealm NS_SWIFT_NAME(setAuthRealm(_:));

@property (nonatomic,readwrite,assign,getter=authTypes,setter=setAuthTypes:) int authTypes NS_SWIFT_NAME(authTypes);

- (int)authTypes NS_SWIFT_NAME(authTypes());
- (void)setAuthTypes :(int)newAuthTypes NS_SWIFT_NAME(setAuthTypes(_:));

@property (nonatomic,readonly,assign,getter=boundPort) int boundPort NS_SWIFT_NAME(boundPort);

- (int)boundPort NS_SWIFT_NAME(boundPort());

@property (nonatomic,readonly,assign,getter=CACertBytes) NSData* CACertBytes NS_SWIFT_NAME(CACertBytes);

- (NSData*)CACertBytes NS_SWIFT_NAME(CACertBytes());

@property (nonatomic,readwrite,assign,getter=CACertCA,setter=setCACertCA:) BOOL CACertCA NS_SWIFT_NAME(CACertCA);

- (BOOL)CACertCA NS_SWIFT_NAME(CACertCA());
- (void)setCACertCA :(BOOL)newCACertCA NS_SWIFT_NAME(setCACertCA(_:));

@property (nonatomic,readonly,assign,getter=CACertCAKeyID) NSData* CACertCAKeyID NS_SWIFT_NAME(CACertCAKeyID);

- (NSData*)CACertCAKeyID NS_SWIFT_NAME(CACertCAKeyID());

@property (nonatomic,readonly,assign,getter=CACertCertType) int CACertCertType NS_SWIFT_NAME(CACertCertType);

- (int)CACertCertType NS_SWIFT_NAME(CACertCertType());

@property (nonatomic,readwrite,assign,getter=CACertCRLDistributionPoints,setter=setCACertCRLDistributionPoints:) NSString* CACertCRLDistributionPoints NS_SWIFT_NAME(CACertCRLDistributionPoints);

- (NSString*)CACertCRLDistributionPoints NS_SWIFT_NAME(CACertCRLDistributionPoints());
- (void)setCACertCRLDistributionPoints :(NSString*)newCACertCRLDistributionPoints NS_SWIFT_NAME(setCACertCRLDistributionPoints(_:));

@property (nonatomic,readwrite,assign,getter=CACertCurve,setter=setCACertCurve:) NSString* CACertCurve NS_SWIFT_NAME(CACertCurve);

- (NSString*)CACertCurve NS_SWIFT_NAME(CACertCurve());
- (void)setCACertCurve :(NSString*)newCACertCurve NS_SWIFT_NAME(setCACertCurve(_:));

@property (nonatomic,readonly,assign,getter=CACertFingerprint) NSString* CACertFingerprint NS_SWIFT_NAME(CACertFingerprint);

- (NSString*)CACertFingerprint NS_SWIFT_NAME(CACertFingerprint());

@property (nonatomic,readonly,assign,getter=CACertFriendlyName) NSString* CACertFriendlyName NS_SWIFT_NAME(CACertFriendlyName);

- (NSString*)CACertFriendlyName NS_SWIFT_NAME(CACertFriendlyName());

@property (nonatomic,readwrite,assign,getter=CACertHandle,setter=setCACertHandle:) long long CACertHandle NS_SWIFT_NAME(CACertHandle);

- (long long)CACertHandle NS_SWIFT_NAME(CACertHandle());
- (void)setCACertHandle :(long long)newCACertHandle NS_SWIFT_NAME(setCACertHandle(_:));

@property (nonatomic,readwrite,assign,getter=CACertHashAlgorithm,setter=setCACertHashAlgorithm:) NSString* CACertHashAlgorithm NS_SWIFT_NAME(CACertHashAlgorithm);

- (NSString*)CACertHashAlgorithm NS_SWIFT_NAME(CACertHashAlgorithm());
- (void)setCACertHashAlgorithm :(NSString*)newCACertHashAlgorithm NS_SWIFT_NAME(setCACertHashAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=CACertIssuer) NSString* CACertIssuer NS_SWIFT_NAME(CACertIssuer);

- (NSString*)CACertIssuer NS_SWIFT_NAME(CACertIssuer());

@property (nonatomic,readwrite,assign,getter=CACertIssuerRDN,setter=setCACertIssuerRDN:) NSString* CACertIssuerRDN NS_SWIFT_NAME(CACertIssuerRDN);

- (NSString*)CACertIssuerRDN NS_SWIFT_NAME(CACertIssuerRDN());
- (void)setCACertIssuerRDN :(NSString*)newCACertIssuerRDN NS_SWIFT_NAME(setCACertIssuerRDN(_:));

@property (nonatomic,readwrite,assign,getter=CACertKeyAlgorithm,setter=setCACertKeyAlgorithm:) NSString* CACertKeyAlgorithm NS_SWIFT_NAME(CACertKeyAlgorithm);

- (NSString*)CACertKeyAlgorithm NS_SWIFT_NAME(CACertKeyAlgorithm());
- (void)setCACertKeyAlgorithm :(NSString*)newCACertKeyAlgorithm NS_SWIFT_NAME(setCACertKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=CACertKeyBits) int CACertKeyBits NS_SWIFT_NAME(CACertKeyBits);

- (int)CACertKeyBits NS_SWIFT_NAME(CACertKeyBits());

@property (nonatomic,readonly,assign,getter=CACertKeyFingerprint) NSString* CACertKeyFingerprint NS_SWIFT_NAME(CACertKeyFingerprint);

- (NSString*)CACertKeyFingerprint NS_SWIFT_NAME(CACertKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=CACertKeyUsage,setter=setCACertKeyUsage:) int CACertKeyUsage NS_SWIFT_NAME(CACertKeyUsage);

- (int)CACertKeyUsage NS_SWIFT_NAME(CACertKeyUsage());
- (void)setCACertKeyUsage :(int)newCACertKeyUsage NS_SWIFT_NAME(setCACertKeyUsage(_:));

@property (nonatomic,readonly,assign,getter=CACertKeyValid) BOOL CACertKeyValid NS_SWIFT_NAME(CACertKeyValid);

- (BOOL)CACertKeyValid NS_SWIFT_NAME(CACertKeyValid());

@property (nonatomic,readwrite,assign,getter=CACertOCSPLocations,setter=setCACertOCSPLocations:) NSString* CACertOCSPLocations NS_SWIFT_NAME(CACertOCSPLocations);

- (NSString*)CACertOCSPLocations NS_SWIFT_NAME(CACertOCSPLocations());
- (void)setCACertOCSPLocations :(NSString*)newCACertOCSPLocations NS_SWIFT_NAME(setCACertOCSPLocations(_:));

@property (nonatomic,readwrite,assign,getter=CACertOCSPNoCheck,setter=setCACertOCSPNoCheck:) BOOL CACertOCSPNoCheck NS_SWIFT_NAME(CACertOCSPNoCheck);

- (BOOL)CACertOCSPNoCheck NS_SWIFT_NAME(CACertOCSPNoCheck());
- (void)setCACertOCSPNoCheck :(BOOL)newCACertOCSPNoCheck NS_SWIFT_NAME(setCACertOCSPNoCheck(_:));

@property (nonatomic,readonly,assign,getter=CACertOrigin) int CACertOrigin NS_SWIFT_NAME(CACertOrigin);

- (int)CACertOrigin NS_SWIFT_NAME(CACertOrigin());

@property (nonatomic,readwrite,assign,getter=CACertPolicyIDs,setter=setCACertPolicyIDs:) NSString* CACertPolicyIDs NS_SWIFT_NAME(CACertPolicyIDs);

- (NSString*)CACertPolicyIDs NS_SWIFT_NAME(CACertPolicyIDs());
- (void)setCACertPolicyIDs :(NSString*)newCACertPolicyIDs NS_SWIFT_NAME(setCACertPolicyIDs(_:));

@property (nonatomic,readonly,assign,getter=CACertPrivateKeyBytes) NSData* CACertPrivateKeyBytes NS_SWIFT_NAME(CACertPrivateKeyBytes);

- (NSData*)CACertPrivateKeyBytes NS_SWIFT_NAME(CACertPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=CACertPrivateKeyExists) BOOL CACertPrivateKeyExists NS_SWIFT_NAME(CACertPrivateKeyExists);

- (BOOL)CACertPrivateKeyExists NS_SWIFT_NAME(CACertPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=CACertPrivateKeyExtractable) BOOL CACertPrivateKeyExtractable NS_SWIFT_NAME(CACertPrivateKeyExtractable);

- (BOOL)CACertPrivateKeyExtractable NS_SWIFT_NAME(CACertPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=CACertPublicKeyBytes) NSData* CACertPublicKeyBytes NS_SWIFT_NAME(CACertPublicKeyBytes);

- (NSData*)CACertPublicKeyBytes NS_SWIFT_NAME(CACertPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=CACertQualified) BOOL CACertQualified NS_SWIFT_NAME(CACertQualified);

- (BOOL)CACertQualified NS_SWIFT_NAME(CACertQualified());

@property (nonatomic,readwrite,assign,getter=CACertQualifiedStatements,setter=setCACertQualifiedStatements:) int CACertQualifiedStatements NS_SWIFT_NAME(CACertQualifiedStatements);

- (int)CACertQualifiedStatements NS_SWIFT_NAME(CACertQualifiedStatements());
- (void)setCACertQualifiedStatements :(int)newCACertQualifiedStatements NS_SWIFT_NAME(setCACertQualifiedStatements(_:));

@property (nonatomic,readonly,assign,getter=CACertQualifiers) NSString* CACertQualifiers NS_SWIFT_NAME(CACertQualifiers);

- (NSString*)CACertQualifiers NS_SWIFT_NAME(CACertQualifiers());

@property (nonatomic,readonly,assign,getter=CACertSelfSigned) BOOL CACertSelfSigned NS_SWIFT_NAME(CACertSelfSigned);

- (BOOL)CACertSelfSigned NS_SWIFT_NAME(CACertSelfSigned());

@property (nonatomic,readwrite,assign,getter=CACertSerialNumber,setter=setCACertSerialNumber:) NSData* CACertSerialNumber NS_SWIFT_NAME(CACertSerialNumber);

- (NSData*)CACertSerialNumber NS_SWIFT_NAME(CACertSerialNumber());
- (void)setCACertSerialNumber :(NSData*)newCACertSerialNumber NS_SWIFT_NAME(setCACertSerialNumber(_:));

@property (nonatomic,readonly,assign,getter=CACertSigAlgorithm) NSString* CACertSigAlgorithm NS_SWIFT_NAME(CACertSigAlgorithm);

- (NSString*)CACertSigAlgorithm NS_SWIFT_NAME(CACertSigAlgorithm());

@property (nonatomic,readonly,assign,getter=CACertSource) int CACertSource NS_SWIFT_NAME(CACertSource);

- (int)CACertSource NS_SWIFT_NAME(CACertSource());

@property (nonatomic,readonly,assign,getter=CACertSubject) NSString* CACertSubject NS_SWIFT_NAME(CACertSubject);

- (NSString*)CACertSubject NS_SWIFT_NAME(CACertSubject());

@property (nonatomic,readwrite,assign,getter=CACertSubjectAlternativeName,setter=setCACertSubjectAlternativeName:) NSString* CACertSubjectAlternativeName NS_SWIFT_NAME(CACertSubjectAlternativeName);

- (NSString*)CACertSubjectAlternativeName NS_SWIFT_NAME(CACertSubjectAlternativeName());
- (void)setCACertSubjectAlternativeName :(NSString*)newCACertSubjectAlternativeName NS_SWIFT_NAME(setCACertSubjectAlternativeName(_:));

@property (nonatomic,readwrite,assign,getter=CACertSubjectKeyID,setter=setCACertSubjectKeyID:) NSData* CACertSubjectKeyID NS_SWIFT_NAME(CACertSubjectKeyID);

- (NSData*)CACertSubjectKeyID NS_SWIFT_NAME(CACertSubjectKeyID());
- (void)setCACertSubjectKeyID :(NSData*)newCACertSubjectKeyID NS_SWIFT_NAME(setCACertSubjectKeyID(_:));

@property (nonatomic,readwrite,assign,getter=CACertSubjectRDN,setter=setCACertSubjectRDN:) NSString* CACertSubjectRDN NS_SWIFT_NAME(CACertSubjectRDN);

- (NSString*)CACertSubjectRDN NS_SWIFT_NAME(CACertSubjectRDN());
- (void)setCACertSubjectRDN :(NSString*)newCACertSubjectRDN NS_SWIFT_NAME(setCACertSubjectRDN(_:));

@property (nonatomic,readonly,assign,getter=CACertValid) BOOL CACertValid NS_SWIFT_NAME(CACertValid);

- (BOOL)CACertValid NS_SWIFT_NAME(CACertValid());

@property (nonatomic,readwrite,assign,getter=CACertValidFrom,setter=setCACertValidFrom:) NSString* CACertValidFrom NS_SWIFT_NAME(CACertValidFrom);

- (NSString*)CACertValidFrom NS_SWIFT_NAME(CACertValidFrom());
- (void)setCACertValidFrom :(NSString*)newCACertValidFrom NS_SWIFT_NAME(setCACertValidFrom(_:));

@property (nonatomic,readwrite,assign,getter=CACertValidTo,setter=setCACertValidTo:) NSString* CACertValidTo NS_SWIFT_NAME(CACertValidTo);

- (NSString*)CACertValidTo NS_SWIFT_NAME(CACertValidTo());
- (void)setCACertValidTo :(NSString*)newCACertValidTo NS_SWIFT_NAME(setCACertValidTo(_:));

@property (nonatomic,readonly,assign,getter=certificateBytes) NSData* certificateBytes NS_SWIFT_NAME(certificateBytes);

- (NSData*)certificateBytes NS_SWIFT_NAME(certificateBytes());

@property (nonatomic,readwrite,assign,getter=certificateCA,setter=setCertificateCA:) BOOL certificateCA NS_SWIFT_NAME(certificateCA);

- (BOOL)certificateCA NS_SWIFT_NAME(certificateCA());
- (void)setCertificateCA :(BOOL)newCertificateCA NS_SWIFT_NAME(setCertificateCA(_:));

@property (nonatomic,readonly,assign,getter=certificateCAKeyID) NSData* certificateCAKeyID NS_SWIFT_NAME(certificateCAKeyID);

- (NSData*)certificateCAKeyID NS_SWIFT_NAME(certificateCAKeyID());

@property (nonatomic,readonly,assign,getter=certificateCertType) int certificateCertType NS_SWIFT_NAME(certificateCertType);

- (int)certificateCertType NS_SWIFT_NAME(certificateCertType());

@property (nonatomic,readwrite,assign,getter=certificateCRLDistributionPoints,setter=setCertificateCRLDistributionPoints:) NSString* certificateCRLDistributionPoints NS_SWIFT_NAME(certificateCRLDistributionPoints);

- (NSString*)certificateCRLDistributionPoints NS_SWIFT_NAME(certificateCRLDistributionPoints());
- (void)setCertificateCRLDistributionPoints :(NSString*)newCertificateCRLDistributionPoints NS_SWIFT_NAME(setCertificateCRLDistributionPoints(_:));

@property (nonatomic,readwrite,assign,getter=certificateCurve,setter=setCertificateCurve:) NSString* certificateCurve NS_SWIFT_NAME(certificateCurve);

- (NSString*)certificateCurve NS_SWIFT_NAME(certificateCurve());
- (void)setCertificateCurve :(NSString*)newCertificateCurve NS_SWIFT_NAME(setCertificateCurve(_:));

@property (nonatomic,readonly,assign,getter=certificateFingerprint) NSString* certificateFingerprint NS_SWIFT_NAME(certificateFingerprint);

- (NSString*)certificateFingerprint NS_SWIFT_NAME(certificateFingerprint());

@property (nonatomic,readonly,assign,getter=certificateFriendlyName) NSString* certificateFriendlyName NS_SWIFT_NAME(certificateFriendlyName);

- (NSString*)certificateFriendlyName NS_SWIFT_NAME(certificateFriendlyName());

@property (nonatomic,readwrite,assign,getter=certificateHandle,setter=setCertificateHandle:) long long certificateHandle NS_SWIFT_NAME(certificateHandle);

- (long long)certificateHandle NS_SWIFT_NAME(certificateHandle());
- (void)setCertificateHandle :(long long)newCertificateHandle NS_SWIFT_NAME(setCertificateHandle(_:));

@property (nonatomic,readwrite,assign,getter=certificateHashAlgorithm,setter=setCertificateHashAlgorithm:) NSString* certificateHashAlgorithm NS_SWIFT_NAME(certificateHashAlgorithm);

- (NSString*)certificateHashAlgorithm NS_SWIFT_NAME(certificateHashAlgorithm());
- (void)setCertificateHashAlgorithm :(NSString*)newCertificateHashAlgorithm NS_SWIFT_NAME(setCertificateHashAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=certificateIssuer) NSString* certificateIssuer NS_SWIFT_NAME(certificateIssuer);

- (NSString*)certificateIssuer NS_SWIFT_NAME(certificateIssuer());

@property (nonatomic,readwrite,assign,getter=certificateIssuerRDN,setter=setCertificateIssuerRDN:) NSString* certificateIssuerRDN NS_SWIFT_NAME(certificateIssuerRDN);

- (NSString*)certificateIssuerRDN NS_SWIFT_NAME(certificateIssuerRDN());
- (void)setCertificateIssuerRDN :(NSString*)newCertificateIssuerRDN NS_SWIFT_NAME(setCertificateIssuerRDN(_:));

@property (nonatomic,readwrite,assign,getter=certificateKeyAlgorithm,setter=setCertificateKeyAlgorithm:) NSString* certificateKeyAlgorithm NS_SWIFT_NAME(certificateKeyAlgorithm);

- (NSString*)certificateKeyAlgorithm NS_SWIFT_NAME(certificateKeyAlgorithm());
- (void)setCertificateKeyAlgorithm :(NSString*)newCertificateKeyAlgorithm NS_SWIFT_NAME(setCertificateKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=certificateKeyBits) int certificateKeyBits NS_SWIFT_NAME(certificateKeyBits);

- (int)certificateKeyBits NS_SWIFT_NAME(certificateKeyBits());

@property (nonatomic,readonly,assign,getter=certificateKeyFingerprint) NSString* certificateKeyFingerprint NS_SWIFT_NAME(certificateKeyFingerprint);

- (NSString*)certificateKeyFingerprint NS_SWIFT_NAME(certificateKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=certificateKeyUsage,setter=setCertificateKeyUsage:) int certificateKeyUsage NS_SWIFT_NAME(certificateKeyUsage);

- (int)certificateKeyUsage NS_SWIFT_NAME(certificateKeyUsage());
- (void)setCertificateKeyUsage :(int)newCertificateKeyUsage NS_SWIFT_NAME(setCertificateKeyUsage(_:));

@property (nonatomic,readonly,assign,getter=certificateKeyValid) BOOL certificateKeyValid NS_SWIFT_NAME(certificateKeyValid);

- (BOOL)certificateKeyValid NS_SWIFT_NAME(certificateKeyValid());

@property (nonatomic,readwrite,assign,getter=certificateOCSPLocations,setter=setCertificateOCSPLocations:) NSString* certificateOCSPLocations NS_SWIFT_NAME(certificateOCSPLocations);

- (NSString*)certificateOCSPLocations NS_SWIFT_NAME(certificateOCSPLocations());
- (void)setCertificateOCSPLocations :(NSString*)newCertificateOCSPLocations NS_SWIFT_NAME(setCertificateOCSPLocations(_:));

@property (nonatomic,readwrite,assign,getter=certificateOCSPNoCheck,setter=setCertificateOCSPNoCheck:) BOOL certificateOCSPNoCheck NS_SWIFT_NAME(certificateOCSPNoCheck);

- (BOOL)certificateOCSPNoCheck NS_SWIFT_NAME(certificateOCSPNoCheck());
- (void)setCertificateOCSPNoCheck :(BOOL)newCertificateOCSPNoCheck NS_SWIFT_NAME(setCertificateOCSPNoCheck(_:));

@property (nonatomic,readonly,assign,getter=certificateOrigin) int certificateOrigin NS_SWIFT_NAME(certificateOrigin);

- (int)certificateOrigin NS_SWIFT_NAME(certificateOrigin());

@property (nonatomic,readwrite,assign,getter=certificatePolicyIDs,setter=setCertificatePolicyIDs:) NSString* certificatePolicyIDs NS_SWIFT_NAME(certificatePolicyIDs);

- (NSString*)certificatePolicyIDs NS_SWIFT_NAME(certificatePolicyIDs());
- (void)setCertificatePolicyIDs :(NSString*)newCertificatePolicyIDs NS_SWIFT_NAME(setCertificatePolicyIDs(_:));

@property (nonatomic,readonly,assign,getter=certificatePrivateKeyBytes) NSData* certificatePrivateKeyBytes NS_SWIFT_NAME(certificatePrivateKeyBytes);

- (NSData*)certificatePrivateKeyBytes NS_SWIFT_NAME(certificatePrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=certificatePrivateKeyExists) BOOL certificatePrivateKeyExists NS_SWIFT_NAME(certificatePrivateKeyExists);

- (BOOL)certificatePrivateKeyExists NS_SWIFT_NAME(certificatePrivateKeyExists());

@property (nonatomic,readonly,assign,getter=certificatePrivateKeyExtractable) BOOL certificatePrivateKeyExtractable NS_SWIFT_NAME(certificatePrivateKeyExtractable);

- (BOOL)certificatePrivateKeyExtractable NS_SWIFT_NAME(certificatePrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=certificatePublicKeyBytes) NSData* certificatePublicKeyBytes NS_SWIFT_NAME(certificatePublicKeyBytes);

- (NSData*)certificatePublicKeyBytes NS_SWIFT_NAME(certificatePublicKeyBytes());

@property (nonatomic,readonly,assign,getter=certificateQualified) BOOL certificateQualified NS_SWIFT_NAME(certificateQualified);

- (BOOL)certificateQualified NS_SWIFT_NAME(certificateQualified());

@property (nonatomic,readwrite,assign,getter=certificateQualifiedStatements,setter=setCertificateQualifiedStatements:) int certificateQualifiedStatements NS_SWIFT_NAME(certificateQualifiedStatements);

- (int)certificateQualifiedStatements NS_SWIFT_NAME(certificateQualifiedStatements());
- (void)setCertificateQualifiedStatements :(int)newCertificateQualifiedStatements NS_SWIFT_NAME(setCertificateQualifiedStatements(_:));

@property (nonatomic,readonly,assign,getter=certificateQualifiers) NSString* certificateQualifiers NS_SWIFT_NAME(certificateQualifiers);

- (NSString*)certificateQualifiers NS_SWIFT_NAME(certificateQualifiers());

@property (nonatomic,readonly,assign,getter=certificateSelfSigned) BOOL certificateSelfSigned NS_SWIFT_NAME(certificateSelfSigned);

- (BOOL)certificateSelfSigned NS_SWIFT_NAME(certificateSelfSigned());

@property (nonatomic,readwrite,assign,getter=certificateSerialNumber,setter=setCertificateSerialNumber:) NSData* certificateSerialNumber NS_SWIFT_NAME(certificateSerialNumber);

- (NSData*)certificateSerialNumber NS_SWIFT_NAME(certificateSerialNumber());
- (void)setCertificateSerialNumber :(NSData*)newCertificateSerialNumber NS_SWIFT_NAME(setCertificateSerialNumber(_:));

@property (nonatomic,readonly,assign,getter=certificateSigAlgorithm) NSString* certificateSigAlgorithm NS_SWIFT_NAME(certificateSigAlgorithm);

- (NSString*)certificateSigAlgorithm NS_SWIFT_NAME(certificateSigAlgorithm());

@property (nonatomic,readonly,assign,getter=certificateSource) int certificateSource NS_SWIFT_NAME(certificateSource);

- (int)certificateSource NS_SWIFT_NAME(certificateSource());

@property (nonatomic,readonly,assign,getter=certificateSubject) NSString* certificateSubject NS_SWIFT_NAME(certificateSubject);

- (NSString*)certificateSubject NS_SWIFT_NAME(certificateSubject());

@property (nonatomic,readwrite,assign,getter=certificateSubjectAlternativeName,setter=setCertificateSubjectAlternativeName:) NSString* certificateSubjectAlternativeName NS_SWIFT_NAME(certificateSubjectAlternativeName);

- (NSString*)certificateSubjectAlternativeName NS_SWIFT_NAME(certificateSubjectAlternativeName());
- (void)setCertificateSubjectAlternativeName :(NSString*)newCertificateSubjectAlternativeName NS_SWIFT_NAME(setCertificateSubjectAlternativeName(_:));

@property (nonatomic,readwrite,assign,getter=certificateSubjectKeyID,setter=setCertificateSubjectKeyID:) NSData* certificateSubjectKeyID NS_SWIFT_NAME(certificateSubjectKeyID);

- (NSData*)certificateSubjectKeyID NS_SWIFT_NAME(certificateSubjectKeyID());
- (void)setCertificateSubjectKeyID :(NSData*)newCertificateSubjectKeyID NS_SWIFT_NAME(setCertificateSubjectKeyID(_:));

@property (nonatomic,readwrite,assign,getter=certificateSubjectRDN,setter=setCertificateSubjectRDN:) NSString* certificateSubjectRDN NS_SWIFT_NAME(certificateSubjectRDN);

- (NSString*)certificateSubjectRDN NS_SWIFT_NAME(certificateSubjectRDN());
- (void)setCertificateSubjectRDN :(NSString*)newCertificateSubjectRDN NS_SWIFT_NAME(setCertificateSubjectRDN(_:));

@property (nonatomic,readonly,assign,getter=certificateValid) BOOL certificateValid NS_SWIFT_NAME(certificateValid);

- (BOOL)certificateValid NS_SWIFT_NAME(certificateValid());

@property (nonatomic,readwrite,assign,getter=certificateValidFrom,setter=setCertificateValidFrom:) NSString* certificateValidFrom NS_SWIFT_NAME(certificateValidFrom);

- (NSString*)certificateValidFrom NS_SWIFT_NAME(certificateValidFrom());
- (void)setCertificateValidFrom :(NSString*)newCertificateValidFrom NS_SWIFT_NAME(setCertificateValidFrom(_:));

@property (nonatomic,readwrite,assign,getter=certificateValidTo,setter=setCertificateValidTo:) NSString* certificateValidTo NS_SWIFT_NAME(certificateValidTo);

- (NSString*)certificateValidTo NS_SWIFT_NAME(certificateValidTo());
- (void)setCertificateValidTo :(NSString*)newCertificateValidTo NS_SWIFT_NAME(setCertificateValidTo(_:));

@property (nonatomic,readwrite,assign,getter=compressionLevel,setter=setCompressionLevel:) int compressionLevel NS_SWIFT_NAME(compressionLevel);

- (int)compressionLevel NS_SWIFT_NAME(compressionLevel());
- (void)setCompressionLevel :(int)newCompressionLevel NS_SWIFT_NAME(setCompressionLevel(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoAsyncDocumentID,setter=setExternalCryptoAsyncDocumentID:) NSString* externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID);

- (NSString*)externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID());
- (void)setExternalCryptoAsyncDocumentID :(NSString*)newExternalCryptoAsyncDocumentID NS_SWIFT_NAME(setExternalCryptoAsyncDocumentID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoCustomParams,setter=setExternalCryptoCustomParams:) NSString* externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams);

- (NSString*)externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams());
- (void)setExternalCryptoCustomParams :(NSString*)newExternalCryptoCustomParams NS_SWIFT_NAME(setExternalCryptoCustomParams(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoData,setter=setExternalCryptoData:) NSString* externalCryptoData NS_SWIFT_NAME(externalCryptoData);

- (NSString*)externalCryptoData NS_SWIFT_NAME(externalCryptoData());
- (void)setExternalCryptoData :(NSString*)newExternalCryptoData NS_SWIFT_NAME(setExternalCryptoData(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoExternalHashCalculation,setter=setExternalCryptoExternalHashCalculation:) BOOL externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation);

- (BOOL)externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation());
- (void)setExternalCryptoExternalHashCalculation :(BOOL)newExternalCryptoExternalHashCalculation NS_SWIFT_NAME(setExternalCryptoExternalHashCalculation(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoHashAlgorithm,setter=setExternalCryptoHashAlgorithm:) NSString* externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm);

- (NSString*)externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm());
- (void)setExternalCryptoHashAlgorithm :(NSString*)newExternalCryptoHashAlgorithm NS_SWIFT_NAME(setExternalCryptoHashAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeyID,setter=setExternalCryptoKeyID:) NSString* externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID);

- (NSString*)externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID());
- (void)setExternalCryptoKeyID :(NSString*)newExternalCryptoKeyID NS_SWIFT_NAME(setExternalCryptoKeyID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeySecret,setter=setExternalCryptoKeySecret:) NSString* externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret);

- (NSString*)externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret());
- (void)setExternalCryptoKeySecret :(NSString*)newExternalCryptoKeySecret NS_SWIFT_NAME(setExternalCryptoKeySecret(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMethod,setter=setExternalCryptoMethod:) int externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod);

- (int)externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod());
- (void)setExternalCryptoMethod :(int)newExternalCryptoMethod NS_SWIFT_NAME(setExternalCryptoMethod(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMode,setter=setExternalCryptoMode:) int externalCryptoMode NS_SWIFT_NAME(externalCryptoMode);

- (int)externalCryptoMode NS_SWIFT_NAME(externalCryptoMode());
- (void)setExternalCryptoMode :(int)newExternalCryptoMode NS_SWIFT_NAME(setExternalCryptoMode(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoPublicKeyAlgorithm,setter=setExternalCryptoPublicKeyAlgorithm:) NSString* externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm);

- (NSString*)externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm());
- (void)setExternalCryptoPublicKeyAlgorithm :(NSString*)newExternalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(setExternalCryptoPublicKeyAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=handshakeTimeout,setter=setHandshakeTimeout:) int handshakeTimeout NS_SWIFT_NAME(handshakeTimeout);

- (int)handshakeTimeout NS_SWIFT_NAME(handshakeTimeout());
- (void)setHandshakeTimeout :(int)newHandshakeTimeout NS_SWIFT_NAME(setHandshakeTimeout(_:));

@property (nonatomic,readwrite,assign,getter=host,setter=setHost:) NSString* host NS_SWIFT_NAME(host);

- (NSString*)host NS_SWIFT_NAME(host());
- (void)setHost :(NSString*)newHost NS_SWIFT_NAME(setHost(_:));

@property (nonatomic,readwrite,assign,getter=keyAlgorithm,setter=setKeyAlgorithm:) NSString* keyAlgorithm NS_SWIFT_NAME(keyAlgorithm);

- (NSString*)keyAlgorithm NS_SWIFT_NAME(keyAlgorithm());
- (void)setKeyAlgorithm :(NSString*)newKeyAlgorithm NS_SWIFT_NAME(setKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=keyBits) int keyBits NS_SWIFT_NAME(keyBits);

- (int)keyBits NS_SWIFT_NAME(keyBits());

@property (nonatomic,readwrite,assign,getter=keyCurve,setter=setKeyCurve:) NSString* keyCurve NS_SWIFT_NAME(keyCurve);

- (NSString*)keyCurve NS_SWIFT_NAME(keyCurve());
- (void)setKeyCurve :(NSString*)newKeyCurve NS_SWIFT_NAME(setKeyCurve(_:));

@property (nonatomic,readonly,assign,getter=keyExportable) BOOL keyExportable NS_SWIFT_NAME(keyExportable);

- (BOOL)keyExportable NS_SWIFT_NAME(keyExportable());

@property (nonatomic,readonly,assign,getter=keyFingerprint) NSString* keyFingerprint NS_SWIFT_NAME(keyFingerprint);

- (NSString*)keyFingerprint NS_SWIFT_NAME(keyFingerprint());

@property (nonatomic,readwrite,assign,getter=keyHandle,setter=setKeyHandle:) long long keyHandle NS_SWIFT_NAME(keyHandle);

- (long long)keyHandle NS_SWIFT_NAME(keyHandle());
- (void)setKeyHandle :(long long)newKeyHandle NS_SWIFT_NAME(setKeyHandle(_:));

@property (nonatomic,readwrite,assign,getter=keyID,setter=setKeyID:) NSData* keyID NS_SWIFT_NAME(keyID);

- (NSData*)keyID NS_SWIFT_NAME(keyID());
- (void)setKeyID :(NSData*)newKeyID NS_SWIFT_NAME(setKeyID(_:));

@property (nonatomic,readwrite,assign,getter=keyIV,setter=setKeyIV:) NSData* keyIV NS_SWIFT_NAME(keyIV);

- (NSData*)keyIV NS_SWIFT_NAME(keyIV());
- (void)setKeyIV :(NSData*)newKeyIV NS_SWIFT_NAME(setKeyIV(_:));

@property (nonatomic,readonly,assign,getter=keyKey) NSData* keyKey NS_SWIFT_NAME(keyKey);

- (NSData*)keyKey NS_SWIFT_NAME(keyKey());

@property (nonatomic,readwrite,assign,getter=keyNonce,setter=setKeyNonce:) NSData* keyNonce NS_SWIFT_NAME(keyNonce);

- (NSData*)keyNonce NS_SWIFT_NAME(keyNonce());
- (void)setKeyNonce :(NSData*)newKeyNonce NS_SWIFT_NAME(setKeyNonce(_:));

@property (nonatomic,readonly,assign,getter=keyPrivate) BOOL keyPrivate NS_SWIFT_NAME(keyPrivate);

- (BOOL)keyPrivate NS_SWIFT_NAME(keyPrivate());

@property (nonatomic,readonly,assign,getter=keyPublic) BOOL keyPublic NS_SWIFT_NAME(keyPublic);

- (BOOL)keyPublic NS_SWIFT_NAME(keyPublic());

@property (nonatomic,readwrite,assign,getter=keySubject,setter=setKeySubject:) NSData* keySubject NS_SWIFT_NAME(keySubject);

- (NSData*)keySubject NS_SWIFT_NAME(keySubject());
- (void)setKeySubject :(NSData*)newKeySubject NS_SWIFT_NAME(setKeySubject(_:));

@property (nonatomic,readonly,assign,getter=keySymmetric) BOOL keySymmetric NS_SWIFT_NAME(keySymmetric);

- (BOOL)keySymmetric NS_SWIFT_NAME(keySymmetric());

@property (nonatomic,readonly,assign,getter=keyValid) BOOL keyValid NS_SWIFT_NAME(keyValid);

- (BOOL)keyValid NS_SWIFT_NAME(keyValid());

@property (nonatomic,readonly,assign,getter=pinnedClientAEADCipher) BOOL pinnedClientAEADCipher NS_SWIFT_NAME(pinnedClientAEADCipher);

- (BOOL)pinnedClientAEADCipher NS_SWIFT_NAME(pinnedClientAEADCipher());

@property (nonatomic,readonly,assign,getter=pinnedClientChainValidationDetails) int pinnedClientChainValidationDetails NS_SWIFT_NAME(pinnedClientChainValidationDetails);

- (int)pinnedClientChainValidationDetails NS_SWIFT_NAME(pinnedClientChainValidationDetails());

@property (nonatomic,readonly,assign,getter=pinnedClientChainValidationResult) int pinnedClientChainValidationResult NS_SWIFT_NAME(pinnedClientChainValidationResult);

- (int)pinnedClientChainValidationResult NS_SWIFT_NAME(pinnedClientChainValidationResult());

@property (nonatomic,readonly,assign,getter=pinnedClientCiphersuite) NSString* pinnedClientCiphersuite NS_SWIFT_NAME(pinnedClientCiphersuite);

- (NSString*)pinnedClientCiphersuite NS_SWIFT_NAME(pinnedClientCiphersuite());

@property (nonatomic,readonly,assign,getter=pinnedClientClientAuthenticated) BOOL pinnedClientClientAuthenticated NS_SWIFT_NAME(pinnedClientClientAuthenticated);

- (BOOL)pinnedClientClientAuthenticated NS_SWIFT_NAME(pinnedClientClientAuthenticated());

@property (nonatomic,readonly,assign,getter=pinnedClientClientAuthRequested) BOOL pinnedClientClientAuthRequested NS_SWIFT_NAME(pinnedClientClientAuthRequested);

- (BOOL)pinnedClientClientAuthRequested NS_SWIFT_NAME(pinnedClientClientAuthRequested());

@property (nonatomic,readonly,assign,getter=pinnedClientConnectionEstablished) BOOL pinnedClientConnectionEstablished NS_SWIFT_NAME(pinnedClientConnectionEstablished);

- (BOOL)pinnedClientConnectionEstablished NS_SWIFT_NAME(pinnedClientConnectionEstablished());

@property (nonatomic,readonly,assign,getter=pinnedClientConnectionID) NSData* pinnedClientConnectionID NS_SWIFT_NAME(pinnedClientConnectionID);

- (NSData*)pinnedClientConnectionID NS_SWIFT_NAME(pinnedClientConnectionID());

@property (nonatomic,readonly,assign,getter=pinnedClientDigestAlgorithm) NSString* pinnedClientDigestAlgorithm NS_SWIFT_NAME(pinnedClientDigestAlgorithm);

- (NSString*)pinnedClientDigestAlgorithm NS_SWIFT_NAME(pinnedClientDigestAlgorithm());

@property (nonatomic,readonly,assign,getter=pinnedClientEncryptionAlgorithm) NSString* pinnedClientEncryptionAlgorithm NS_SWIFT_NAME(pinnedClientEncryptionAlgorithm);

- (NSString*)pinnedClientEncryptionAlgorithm NS_SWIFT_NAME(pinnedClientEncryptionAlgorithm());

@property (nonatomic,readonly,assign,getter=pinnedClientExportable) BOOL pinnedClientExportable NS_SWIFT_NAME(pinnedClientExportable);

- (BOOL)pinnedClientExportable NS_SWIFT_NAME(pinnedClientExportable());

@property (nonatomic,readonly,assign,getter=pinnedClientID) long long pinnedClientID NS_SWIFT_NAME(pinnedClientID);

- (long long)pinnedClientID NS_SWIFT_NAME(pinnedClientID());

@property (nonatomic,readonly,assign,getter=pinnedClientKeyExchangeAlgorithm) NSString* pinnedClientKeyExchangeAlgorithm NS_SWIFT_NAME(pinnedClientKeyExchangeAlgorithm);

- (NSString*)pinnedClientKeyExchangeAlgorithm NS_SWIFT_NAME(pinnedClientKeyExchangeAlgorithm());

@property (nonatomic,readonly,assign,getter=pinnedClientKeyExchangeKeyBits) int pinnedClientKeyExchangeKeyBits NS_SWIFT_NAME(pinnedClientKeyExchangeKeyBits);

- (int)pinnedClientKeyExchangeKeyBits NS_SWIFT_NAME(pinnedClientKeyExchangeKeyBits());

@property (nonatomic,readonly,assign,getter=pinnedClientNamedECCurve) NSString* pinnedClientNamedECCurve NS_SWIFT_NAME(pinnedClientNamedECCurve);

- (NSString*)pinnedClientNamedECCurve NS_SWIFT_NAME(pinnedClientNamedECCurve());

@property (nonatomic,readonly,assign,getter=pinnedClientPFSCipher) BOOL pinnedClientPFSCipher NS_SWIFT_NAME(pinnedClientPFSCipher);

- (BOOL)pinnedClientPFSCipher NS_SWIFT_NAME(pinnedClientPFSCipher());

@property (nonatomic,readonly,assign,getter=pinnedClientPreSharedIdentity) NSString* pinnedClientPreSharedIdentity NS_SWIFT_NAME(pinnedClientPreSharedIdentity);

- (NSString*)pinnedClientPreSharedIdentity NS_SWIFT_NAME(pinnedClientPreSharedIdentity());

@property (nonatomic,readonly,assign,getter=pinnedClientPreSharedIdentityHint) NSString* pinnedClientPreSharedIdentityHint NS_SWIFT_NAME(pinnedClientPreSharedIdentityHint);

- (NSString*)pinnedClientPreSharedIdentityHint NS_SWIFT_NAME(pinnedClientPreSharedIdentityHint());

@property (nonatomic,readonly,assign,getter=pinnedClientPublicKeyBits) int pinnedClientPublicKeyBits NS_SWIFT_NAME(pinnedClientPublicKeyBits);

- (int)pinnedClientPublicKeyBits NS_SWIFT_NAME(pinnedClientPublicKeyBits());

@property (nonatomic,readonly,assign,getter=pinnedClientRemoteAddress) NSString* pinnedClientRemoteAddress NS_SWIFT_NAME(pinnedClientRemoteAddress);

- (NSString*)pinnedClientRemoteAddress NS_SWIFT_NAME(pinnedClientRemoteAddress());

@property (nonatomic,readonly,assign,getter=pinnedClientRemotePort) int pinnedClientRemotePort NS_SWIFT_NAME(pinnedClientRemotePort);

- (int)pinnedClientRemotePort NS_SWIFT_NAME(pinnedClientRemotePort());

@property (nonatomic,readonly,assign,getter=pinnedClientResumedSession) BOOL pinnedClientResumedSession NS_SWIFT_NAME(pinnedClientResumedSession);

- (BOOL)pinnedClientResumedSession NS_SWIFT_NAME(pinnedClientResumedSession());

@property (nonatomic,readonly,assign,getter=pinnedClientSecureConnection) BOOL pinnedClientSecureConnection NS_SWIFT_NAME(pinnedClientSecureConnection);

- (BOOL)pinnedClientSecureConnection NS_SWIFT_NAME(pinnedClientSecureConnection());

@property (nonatomic,readonly,assign,getter=pinnedClientServerAuthenticated) BOOL pinnedClientServerAuthenticated NS_SWIFT_NAME(pinnedClientServerAuthenticated);

- (BOOL)pinnedClientServerAuthenticated NS_SWIFT_NAME(pinnedClientServerAuthenticated());

@property (nonatomic,readonly,assign,getter=pinnedClientSignatureAlgorithm) NSString* pinnedClientSignatureAlgorithm NS_SWIFT_NAME(pinnedClientSignatureAlgorithm);

- (NSString*)pinnedClientSignatureAlgorithm NS_SWIFT_NAME(pinnedClientSignatureAlgorithm());

@property (nonatomic,readonly,assign,getter=pinnedClientSymmetricBlockSize) int pinnedClientSymmetricBlockSize NS_SWIFT_NAME(pinnedClientSymmetricBlockSize);

- (int)pinnedClientSymmetricBlockSize NS_SWIFT_NAME(pinnedClientSymmetricBlockSize());

@property (nonatomic,readonly,assign,getter=pinnedClientSymmetricKeyBits) int pinnedClientSymmetricKeyBits NS_SWIFT_NAME(pinnedClientSymmetricKeyBits);

- (int)pinnedClientSymmetricKeyBits NS_SWIFT_NAME(pinnedClientSymmetricKeyBits());

@property (nonatomic,readonly,assign,getter=pinnedClientTotalBytesReceived) long long pinnedClientTotalBytesReceived NS_SWIFT_NAME(pinnedClientTotalBytesReceived);

- (long long)pinnedClientTotalBytesReceived NS_SWIFT_NAME(pinnedClientTotalBytesReceived());

@property (nonatomic,readonly,assign,getter=pinnedClientTotalBytesSent) long long pinnedClientTotalBytesSent NS_SWIFT_NAME(pinnedClientTotalBytesSent);

- (long long)pinnedClientTotalBytesSent NS_SWIFT_NAME(pinnedClientTotalBytesSent());

@property (nonatomic,readonly,assign,getter=pinnedClientValidationLog) NSString* pinnedClientValidationLog NS_SWIFT_NAME(pinnedClientValidationLog);

- (NSString*)pinnedClientValidationLog NS_SWIFT_NAME(pinnedClientValidationLog());

@property (nonatomic,readonly,assign,getter=pinnedClientVersion) NSString* pinnedClientVersion NS_SWIFT_NAME(pinnedClientVersion);

- (NSString*)pinnedClientVersion NS_SWIFT_NAME(pinnedClientVersion());

@property (nonatomic,readonly,assign,getter=pinnedClientCertCount) int pinnedClientCertCount NS_SWIFT_NAME(pinnedClientCertCount);

- (int)pinnedClientCertCount NS_SWIFT_NAME(pinnedClientCertCount());

- (NSData*)pinnedClientCertBytes:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertBytes(_:));

- (BOOL)pinnedClientCertCA:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertCA(_:));

- (NSData*)pinnedClientCertCAKeyID:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertCAKeyID(_:));

- (int)pinnedClientCertCertType:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertCertType(_:));

- (NSString*)pinnedClientCertCRLDistributionPoints:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertCRLDistributionPoints(_:));

- (NSString*)pinnedClientCertCurve:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertCurve(_:));

- (NSString*)pinnedClientCertFingerprint:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertFingerprint(_:));

- (NSString*)pinnedClientCertFriendlyName:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertFriendlyName(_:));

- (long long)pinnedClientCertHandle:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertHandle(_:));

- (NSString*)pinnedClientCertHashAlgorithm:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertHashAlgorithm(_:));

- (NSString*)pinnedClientCertIssuer:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertIssuer(_:));

- (NSString*)pinnedClientCertIssuerRDN:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertIssuerRDN(_:));

- (NSString*)pinnedClientCertKeyAlgorithm:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertKeyAlgorithm(_:));

- (int)pinnedClientCertKeyBits:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertKeyBits(_:));

- (NSString*)pinnedClientCertKeyFingerprint:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertKeyFingerprint(_:));

- (int)pinnedClientCertKeyUsage:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertKeyUsage(_:));

- (BOOL)pinnedClientCertKeyValid:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertKeyValid(_:));

- (NSString*)pinnedClientCertOCSPLocations:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertOCSPLocations(_:));

- (BOOL)pinnedClientCertOCSPNoCheck:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertOCSPNoCheck(_:));

- (int)pinnedClientCertOrigin:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertOrigin(_:));

- (NSString*)pinnedClientCertPolicyIDs:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertPolicyIDs(_:));

- (NSData*)pinnedClientCertPrivateKeyBytes:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertPrivateKeyBytes(_:));

- (BOOL)pinnedClientCertPrivateKeyExists:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertPrivateKeyExists(_:));

- (BOOL)pinnedClientCertPrivateKeyExtractable:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertPrivateKeyExtractable(_:));

- (NSData*)pinnedClientCertPublicKeyBytes:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertPublicKeyBytes(_:));

- (BOOL)pinnedClientCertQualified:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertQualified(_:));

- (int)pinnedClientCertQualifiedStatements:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertQualifiedStatements(_:));

- (NSString*)pinnedClientCertQualifiers:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertQualifiers(_:));

- (BOOL)pinnedClientCertSelfSigned:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSelfSigned(_:));

- (NSData*)pinnedClientCertSerialNumber:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSerialNumber(_:));

- (NSString*)pinnedClientCertSigAlgorithm:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSigAlgorithm(_:));

- (int)pinnedClientCertSource:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSource(_:));

- (NSString*)pinnedClientCertSubject:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSubject(_:));

- (NSString*)pinnedClientCertSubjectAlternativeName:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSubjectAlternativeName(_:));

- (NSData*)pinnedClientCertSubjectKeyID:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSubjectKeyID(_:));

- (NSString*)pinnedClientCertSubjectRDN:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSubjectRDN(_:));

- (BOOL)pinnedClientCertValid:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertValid(_:));

- (NSString*)pinnedClientCertValidFrom:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertValidFrom(_:));

- (NSString*)pinnedClientCertValidTo:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertValidTo(_:));

@property (nonatomic,readwrite,assign,getter=port,setter=setPort:) int port NS_SWIFT_NAME(port);

- (int)port NS_SWIFT_NAME(port());
- (void)setPort :(int)newPort NS_SWIFT_NAME(setPort(_:));

@property (nonatomic,readwrite,assign,getter=readOnly,setter=setReadOnly:) BOOL readOnly NS_SWIFT_NAME(readOnly);

- (BOOL)readOnly NS_SWIFT_NAME(readOnly());
- (void)setReadOnly :(BOOL)newReadOnly NS_SWIFT_NAME(setReadOnly(_:));

@property (nonatomic,readwrite,assign,getter=sessionTimeout,setter=setSessionTimeout:) int sessionTimeout NS_SWIFT_NAME(sessionTimeout);

- (int)sessionTimeout NS_SWIFT_NAME(sessionTimeout());
- (void)setSessionTimeout :(int)newSessionTimeout NS_SWIFT_NAME(setSessionTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSMode,setter=setSocketDNSMode:) int socketDNSMode NS_SWIFT_NAME(socketDNSMode);

- (int)socketDNSMode NS_SWIFT_NAME(socketDNSMode());
- (void)setSocketDNSMode :(int)newSocketDNSMode NS_SWIFT_NAME(setSocketDNSMode(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSPort,setter=setSocketDNSPort:) int socketDNSPort NS_SWIFT_NAME(socketDNSPort);

- (int)socketDNSPort NS_SWIFT_NAME(socketDNSPort());
- (void)setSocketDNSPort :(int)newSocketDNSPort NS_SWIFT_NAME(setSocketDNSPort(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSQueryTimeout,setter=setSocketDNSQueryTimeout:) int socketDNSQueryTimeout NS_SWIFT_NAME(socketDNSQueryTimeout);

- (int)socketDNSQueryTimeout NS_SWIFT_NAME(socketDNSQueryTimeout());
- (void)setSocketDNSQueryTimeout :(int)newSocketDNSQueryTimeout NS_SWIFT_NAME(setSocketDNSQueryTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSServers,setter=setSocketDNSServers:) NSString* socketDNSServers NS_SWIFT_NAME(socketDNSServers);

- (NSString*)socketDNSServers NS_SWIFT_NAME(socketDNSServers());
- (void)setSocketDNSServers :(NSString*)newSocketDNSServers NS_SWIFT_NAME(setSocketDNSServers(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSTotalTimeout,setter=setSocketDNSTotalTimeout:) int socketDNSTotalTimeout NS_SWIFT_NAME(socketDNSTotalTimeout);

- (int)socketDNSTotalTimeout NS_SWIFT_NAME(socketDNSTotalTimeout());
- (void)setSocketDNSTotalTimeout :(int)newSocketDNSTotalTimeout NS_SWIFT_NAME(setSocketDNSTotalTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketIncomingSpeedLimit,setter=setSocketIncomingSpeedLimit:) int socketIncomingSpeedLimit NS_SWIFT_NAME(socketIncomingSpeedLimit);

- (int)socketIncomingSpeedLimit NS_SWIFT_NAME(socketIncomingSpeedLimit());
- (void)setSocketIncomingSpeedLimit :(int)newSocketIncomingSpeedLimit NS_SWIFT_NAME(setSocketIncomingSpeedLimit(_:));

@property (nonatomic,readwrite,assign,getter=socketLocalAddress,setter=setSocketLocalAddress:) NSString* socketLocalAddress NS_SWIFT_NAME(socketLocalAddress);

- (NSString*)socketLocalAddress NS_SWIFT_NAME(socketLocalAddress());
- (void)setSocketLocalAddress :(NSString*)newSocketLocalAddress NS_SWIFT_NAME(setSocketLocalAddress(_:));

@property (nonatomic,readwrite,assign,getter=socketLocalPort,setter=setSocketLocalPort:) int socketLocalPort NS_SWIFT_NAME(socketLocalPort);

- (int)socketLocalPort NS_SWIFT_NAME(socketLocalPort());
- (void)setSocketLocalPort :(int)newSocketLocalPort NS_SWIFT_NAME(setSocketLocalPort(_:));

@property (nonatomic,readwrite,assign,getter=socketOutgoingSpeedLimit,setter=setSocketOutgoingSpeedLimit:) int socketOutgoingSpeedLimit NS_SWIFT_NAME(socketOutgoingSpeedLimit);

- (int)socketOutgoingSpeedLimit NS_SWIFT_NAME(socketOutgoingSpeedLimit());
- (void)setSocketOutgoingSpeedLimit :(int)newSocketOutgoingSpeedLimit NS_SWIFT_NAME(setSocketOutgoingSpeedLimit(_:));

@property (nonatomic,readwrite,assign,getter=socketTimeout,setter=setSocketTimeout:) int socketTimeout NS_SWIFT_NAME(socketTimeout);

- (int)socketTimeout NS_SWIFT_NAME(socketTimeout());
- (void)setSocketTimeout :(int)newSocketTimeout NS_SWIFT_NAME(setSocketTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketUseIPv6,setter=setSocketUseIPv6:) BOOL socketUseIPv6 NS_SWIFT_NAME(socketUseIPv6);

- (BOOL)socketUseIPv6 NS_SWIFT_NAME(socketUseIPv6());
- (void)setSocketUseIPv6 :(BOOL)newSocketUseIPv6 NS_SWIFT_NAME(setSocketUseIPv6(_:));

@property (nonatomic,readwrite,assign,getter=storageFileName,setter=setStorageFileName:) NSString* storageFileName NS_SWIFT_NAME(storageFileName);

- (NSString*)storageFileName NS_SWIFT_NAME(storageFileName());
- (void)setStorageFileName :(NSString*)newStorageFileName NS_SWIFT_NAME(setStorageFileName(_:));

@property (nonatomic,readwrite,assign,getter=TLSServerCertCount,setter=setTLSServerCertCount:) int TLSServerCertCount NS_SWIFT_NAME(TLSServerCertCount);

- (int)TLSServerCertCount NS_SWIFT_NAME(TLSServerCertCount());
- (void)setTLSServerCertCount :(int)newTLSServerCertCount NS_SWIFT_NAME(setTLSServerCertCount(_:));

- (NSData*)TLSServerCertBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertBytes(_:));

- (BOOL)TLSServerCertCA:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCA(_:));
- (void)setTLSServerCertCA:(int)tLSServerCertIndex :(BOOL)newTLSServerCertCA NS_SWIFT_NAME(setTLSServerCertCA(_:_:));

- (NSData*)TLSServerCertCAKeyID:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCAKeyID(_:));

- (int)TLSServerCertCertType:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCertType(_:));

- (NSString*)TLSServerCertCRLDistributionPoints:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCRLDistributionPoints(_:));
- (void)setTLSServerCertCRLDistributionPoints:(int)tLSServerCertIndex :(NSString*)newTLSServerCertCRLDistributionPoints NS_SWIFT_NAME(setTLSServerCertCRLDistributionPoints(_:_:));

- (NSString*)TLSServerCertCurve:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCurve(_:));
- (void)setTLSServerCertCurve:(int)tLSServerCertIndex :(NSString*)newTLSServerCertCurve NS_SWIFT_NAME(setTLSServerCertCurve(_:_:));

- (NSString*)TLSServerCertFingerprint:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertFingerprint(_:));

- (NSString*)TLSServerCertFriendlyName:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertFriendlyName(_:));

- (long long)TLSServerCertHandle:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertHandle(_:));
- (void)setTLSServerCertHandle:(int)tLSServerCertIndex :(long long)newTLSServerCertHandle NS_SWIFT_NAME(setTLSServerCertHandle(_:_:));

- (NSString*)TLSServerCertHashAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertHashAlgorithm(_:));
- (void)setTLSServerCertHashAlgorithm:(int)tLSServerCertIndex :(NSString*)newTLSServerCertHashAlgorithm NS_SWIFT_NAME(setTLSServerCertHashAlgorithm(_:_:));

- (NSString*)TLSServerCertIssuer:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertIssuer(_:));

- (NSString*)TLSServerCertIssuerRDN:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertIssuerRDN(_:));
- (void)setTLSServerCertIssuerRDN:(int)tLSServerCertIndex :(NSString*)newTLSServerCertIssuerRDN NS_SWIFT_NAME(setTLSServerCertIssuerRDN(_:_:));

- (NSString*)TLSServerCertKeyAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyAlgorithm(_:));
- (void)setTLSServerCertKeyAlgorithm:(int)tLSServerCertIndex :(NSString*)newTLSServerCertKeyAlgorithm NS_SWIFT_NAME(setTLSServerCertKeyAlgorithm(_:_:));

- (int)TLSServerCertKeyBits:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyBits(_:));

- (NSString*)TLSServerCertKeyFingerprint:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyFingerprint(_:));

- (int)TLSServerCertKeyUsage:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyUsage(_:));
- (void)setTLSServerCertKeyUsage:(int)tLSServerCertIndex :(int)newTLSServerCertKeyUsage NS_SWIFT_NAME(setTLSServerCertKeyUsage(_:_:));

- (BOOL)TLSServerCertKeyValid:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyValid(_:));

- (NSString*)TLSServerCertOCSPLocations:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOCSPLocations(_:));
- (void)setTLSServerCertOCSPLocations:(int)tLSServerCertIndex :(NSString*)newTLSServerCertOCSPLocations NS_SWIFT_NAME(setTLSServerCertOCSPLocations(_:_:));

- (BOOL)TLSServerCertOCSPNoCheck:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOCSPNoCheck(_:));
- (void)setTLSServerCertOCSPNoCheck:(int)tLSServerCertIndex :(BOOL)newTLSServerCertOCSPNoCheck NS_SWIFT_NAME(setTLSServerCertOCSPNoCheck(_:_:));

- (int)TLSServerCertOrigin:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOrigin(_:));

- (NSString*)TLSServerCertPolicyIDs:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPolicyIDs(_:));
- (void)setTLSServerCertPolicyIDs:(int)tLSServerCertIndex :(NSString*)newTLSServerCertPolicyIDs NS_SWIFT_NAME(setTLSServerCertPolicyIDs(_:_:));

- (NSData*)TLSServerCertPrivateKeyBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyBytes(_:));

- (BOOL)TLSServerCertPrivateKeyExists:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyExists(_:));

- (BOOL)TLSServerCertPrivateKeyExtractable:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyExtractable(_:));

- (NSData*)TLSServerCertPublicKeyBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPublicKeyBytes(_:));

- (BOOL)TLSServerCertQualified:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualified(_:));

- (int)TLSServerCertQualifiedStatements:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualifiedStatements(_:));
- (void)setTLSServerCertQualifiedStatements:(int)tLSServerCertIndex :(int)newTLSServerCertQualifiedStatements NS_SWIFT_NAME(setTLSServerCertQualifiedStatements(_:_:));

- (NSString*)TLSServerCertQualifiers:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualifiers(_:));

- (BOOL)TLSServerCertSelfSigned:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSelfSigned(_:));

- (NSData*)TLSServerCertSerialNumber:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSerialNumber(_:));
- (void)setTLSServerCertSerialNumber:(int)tLSServerCertIndex :(NSData*)newTLSServerCertSerialNumber NS_SWIFT_NAME(setTLSServerCertSerialNumber(_:_:));

- (NSString*)TLSServerCertSigAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSigAlgorithm(_:));

- (int)TLSServerCertSource:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSource(_:));

- (NSString*)TLSServerCertSubject:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubject(_:));

- (NSString*)TLSServerCertSubjectAlternativeName:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectAlternativeName(_:));
- (void)setTLSServerCertSubjectAlternativeName:(int)tLSServerCertIndex :(NSString*)newTLSServerCertSubjectAlternativeName NS_SWIFT_NAME(setTLSServerCertSubjectAlternativeName(_:_:));

- (NSData*)TLSServerCertSubjectKeyID:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectKeyID(_:));
- (void)setTLSServerCertSubjectKeyID:(int)tLSServerCertIndex :(NSData*)newTLSServerCertSubjectKeyID NS_SWIFT_NAME(setTLSServerCertSubjectKeyID(_:_:));

- (NSString*)TLSServerCertSubjectRDN:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectRDN(_:));
- (void)setTLSServerCertSubjectRDN:(int)tLSServerCertIndex :(NSString*)newTLSServerCertSubjectRDN NS_SWIFT_NAME(setTLSServerCertSubjectRDN(_:_:));

- (BOOL)TLSServerCertValid:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValid(_:));

- (NSString*)TLSServerCertValidFrom:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValidFrom(_:));
- (void)setTLSServerCertValidFrom:(int)tLSServerCertIndex :(NSString*)newTLSServerCertValidFrom NS_SWIFT_NAME(setTLSServerCertValidFrom(_:_:));

- (NSString*)TLSServerCertValidTo:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValidTo(_:));
- (void)setTLSServerCertValidTo:(int)tLSServerCertIndex :(NSString*)newTLSServerCertValidTo NS_SWIFT_NAME(setTLSServerCertValidTo(_:_:));

@property (nonatomic,readwrite,assign,getter=TLSAutoValidateCertificates,setter=setTLSAutoValidateCertificates:) BOOL TLSAutoValidateCertificates NS_SWIFT_NAME(TLSAutoValidateCertificates);

- (BOOL)TLSAutoValidateCertificates NS_SWIFT_NAME(TLSAutoValidateCertificates());
- (void)setTLSAutoValidateCertificates :(BOOL)newTLSAutoValidateCertificates NS_SWIFT_NAME(setTLSAutoValidateCertificates(_:));

@property (nonatomic,readwrite,assign,getter=TLSBaseConfiguration,setter=setTLSBaseConfiguration:) int TLSBaseConfiguration NS_SWIFT_NAME(TLSBaseConfiguration);

- (int)TLSBaseConfiguration NS_SWIFT_NAME(TLSBaseConfiguration());
- (void)setTLSBaseConfiguration :(int)newTLSBaseConfiguration NS_SWIFT_NAME(setTLSBaseConfiguration(_:));

@property (nonatomic,readwrite,assign,getter=TLSCiphersuites,setter=setTLSCiphersuites:) NSString* TLSCiphersuites NS_SWIFT_NAME(TLSCiphersuites);

- (NSString*)TLSCiphersuites NS_SWIFT_NAME(TLSCiphersuites());
- (void)setTLSCiphersuites :(NSString*)newTLSCiphersuites NS_SWIFT_NAME(setTLSCiphersuites(_:));

@property (nonatomic,readwrite,assign,getter=TLSClientAuth,setter=setTLSClientAuth:) int TLSClientAuth NS_SWIFT_NAME(TLSClientAuth);

- (int)TLSClientAuth NS_SWIFT_NAME(TLSClientAuth());
- (void)setTLSClientAuth :(int)newTLSClientAuth NS_SWIFT_NAME(setTLSClientAuth(_:));

@property (nonatomic,readwrite,assign,getter=TLSECCurves,setter=setTLSECCurves:) NSString* TLSECCurves NS_SWIFT_NAME(TLSECCurves);

- (NSString*)TLSECCurves NS_SWIFT_NAME(TLSECCurves());
- (void)setTLSECCurves :(NSString*)newTLSECCurves NS_SWIFT_NAME(setTLSECCurves(_:));

@property (nonatomic,readwrite,assign,getter=TLSExtensions,setter=setTLSExtensions:) NSString* TLSExtensions NS_SWIFT_NAME(TLSExtensions);

- (NSString*)TLSExtensions NS_SWIFT_NAME(TLSExtensions());
- (void)setTLSExtensions :(NSString*)newTLSExtensions NS_SWIFT_NAME(setTLSExtensions(_:));

@property (nonatomic,readwrite,assign,getter=TLSForceResumeIfDestinationChanges,setter=setTLSForceResumeIfDestinationChanges:) BOOL TLSForceResumeIfDestinationChanges NS_SWIFT_NAME(TLSForceResumeIfDestinationChanges);

- (BOOL)TLSForceResumeIfDestinationChanges NS_SWIFT_NAME(TLSForceResumeIfDestinationChanges());
- (void)setTLSForceResumeIfDestinationChanges :(BOOL)newTLSForceResumeIfDestinationChanges NS_SWIFT_NAME(setTLSForceResumeIfDestinationChanges(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedIdentity,setter=setTLSPreSharedIdentity:) NSString* TLSPreSharedIdentity NS_SWIFT_NAME(TLSPreSharedIdentity);

- (NSString*)TLSPreSharedIdentity NS_SWIFT_NAME(TLSPreSharedIdentity());
- (void)setTLSPreSharedIdentity :(NSString*)newTLSPreSharedIdentity NS_SWIFT_NAME(setTLSPreSharedIdentity(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedKey,setter=setTLSPreSharedKey:) NSString* TLSPreSharedKey NS_SWIFT_NAME(TLSPreSharedKey);

- (NSString*)TLSPreSharedKey NS_SWIFT_NAME(TLSPreSharedKey());
- (void)setTLSPreSharedKey :(NSString*)newTLSPreSharedKey NS_SWIFT_NAME(setTLSPreSharedKey(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedKeyCiphersuite,setter=setTLSPreSharedKeyCiphersuite:) NSString* TLSPreSharedKeyCiphersuite NS_SWIFT_NAME(TLSPreSharedKeyCiphersuite);

- (NSString*)TLSPreSharedKeyCiphersuite NS_SWIFT_NAME(TLSPreSharedKeyCiphersuite());
- (void)setTLSPreSharedKeyCiphersuite :(NSString*)newTLSPreSharedKeyCiphersuite NS_SWIFT_NAME(setTLSPreSharedKeyCiphersuite(_:));

@property (nonatomic,readwrite,assign,getter=TLSRenegotiationAttackPreventionMode,setter=setTLSRenegotiationAttackPreventionMode:) int TLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(TLSRenegotiationAttackPreventionMode);

- (int)TLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(TLSRenegotiationAttackPreventionMode());
- (void)setTLSRenegotiationAttackPreventionMode :(int)newTLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(setTLSRenegotiationAttackPreventionMode(_:));

@property (nonatomic,readwrite,assign,getter=TLSRevocationCheck,setter=setTLSRevocationCheck:) int TLSRevocationCheck NS_SWIFT_NAME(TLSRevocationCheck);

- (int)TLSRevocationCheck NS_SWIFT_NAME(TLSRevocationCheck());
- (void)setTLSRevocationCheck :(int)newTLSRevocationCheck NS_SWIFT_NAME(setTLSRevocationCheck(_:));

@property (nonatomic,readwrite,assign,getter=TLSSSLOptions,setter=setTLSSSLOptions:) int TLSSSLOptions NS_SWIFT_NAME(TLSSSLOptions);

- (int)TLSSSLOptions NS_SWIFT_NAME(TLSSSLOptions());
- (void)setTLSSSLOptions :(int)newTLSSSLOptions NS_SWIFT_NAME(setTLSSSLOptions(_:));

@property (nonatomic,readwrite,assign,getter=TLSTLSMode,setter=setTLSTLSMode:) int TLSTLSMode NS_SWIFT_NAME(TLSTLSMode);

- (int)TLSTLSMode NS_SWIFT_NAME(TLSTLSMode());
- (void)setTLSTLSMode :(int)newTLSTLSMode NS_SWIFT_NAME(setTLSTLSMode(_:));

@property (nonatomic,readwrite,assign,getter=TLSUseExtendedMasterSecret,setter=setTLSUseExtendedMasterSecret:) BOOL TLSUseExtendedMasterSecret NS_SWIFT_NAME(TLSUseExtendedMasterSecret);

- (BOOL)TLSUseExtendedMasterSecret NS_SWIFT_NAME(TLSUseExtendedMasterSecret());
- (void)setTLSUseExtendedMasterSecret :(BOOL)newTLSUseExtendedMasterSecret NS_SWIFT_NAME(setTLSUseExtendedMasterSecret(_:));

@property (nonatomic,readwrite,assign,getter=TLSUseSessionResumption,setter=setTLSUseSessionResumption:) BOOL TLSUseSessionResumption NS_SWIFT_NAME(TLSUseSessionResumption);

- (BOOL)TLSUseSessionResumption NS_SWIFT_NAME(TLSUseSessionResumption());
- (void)setTLSUseSessionResumption :(BOOL)newTLSUseSessionResumption NS_SWIFT_NAME(setTLSUseSessionResumption(_:));

@property (nonatomic,readwrite,assign,getter=TLSVersions,setter=setTLSVersions:) int TLSVersions NS_SWIFT_NAME(TLSVersions);

- (int)TLSVersions NS_SWIFT_NAME(TLSVersions());
- (void)setTLSVersions :(int)newTLSVersions NS_SWIFT_NAME(setTLSVersions(_:));

@property (nonatomic,readwrite,assign,getter=useChunkedTransfer,setter=setUseChunkedTransfer:) BOOL useChunkedTransfer NS_SWIFT_NAME(useChunkedTransfer);

- (BOOL)useChunkedTransfer NS_SWIFT_NAME(useChunkedTransfer());
- (void)setUseChunkedTransfer :(BOOL)newUseChunkedTransfer NS_SWIFT_NAME(setUseChunkedTransfer(_:));

@property (nonatomic,readwrite,assign,getter=useCompression,setter=setUseCompression:) BOOL useCompression NS_SWIFT_NAME(useCompression);

- (BOOL)useCompression NS_SWIFT_NAME(useCompression());
- (void)setUseCompression :(BOOL)newUseCompression NS_SWIFT_NAME(setUseCompression(_:));

@property (nonatomic,readwrite,assign,getter=useHTTP,setter=setUseHTTP:) BOOL useHTTP NS_SWIFT_NAME(useHTTP);

- (BOOL)useHTTP NS_SWIFT_NAME(useHTTP());
- (void)setUseHTTP :(BOOL)newUseHTTP NS_SWIFT_NAME(setUseHTTP(_:));

@property (nonatomic,readwrite,assign,getter=userCount,setter=setUserCount:) int userCount NS_SWIFT_NAME(userCount);

- (int)userCount NS_SWIFT_NAME(userCount());
- (void)setUserCount :(int)newUserCount NS_SWIFT_NAME(setUserCount(_:));

- (NSData*)userAssociatedData:(int)userIndex NS_SWIFT_NAME(userAssociatedData(_:));
- (void)setUserAssociatedData:(int)userIndex :(NSData*)newUserAssociatedData NS_SWIFT_NAME(setUserAssociatedData(_:_:));

- (NSString*)userBasePath:(int)userIndex NS_SWIFT_NAME(userBasePath(_:));
- (void)setUserBasePath:(int)userIndex :(NSString*)newUserBasePath NS_SWIFT_NAME(setUserBasePath(_:_:));

- (NSData*)userCertificate:(int)userIndex NS_SWIFT_NAME(userCertificate(_:));
- (void)setUserCertificate:(int)userIndex :(NSData*)newUserCertificate NS_SWIFT_NAME(setUserCertificate(_:_:));

- (NSString*)userData:(int)userIndex NS_SWIFT_NAME(userData(_:));
- (void)setUserData:(int)userIndex :(NSString*)newUserData NS_SWIFT_NAME(setUserData(_:_:));

- (NSString*)userEmail:(int)userIndex NS_SWIFT_NAME(userEmail(_:));
- (void)setUserEmail:(int)userIndex :(NSString*)newUserEmail NS_SWIFT_NAME(setUserEmail(_:_:));

- (long long)userHandle:(int)userIndex NS_SWIFT_NAME(userHandle(_:));
- (void)setUserHandle:(int)userIndex :(long long)newUserHandle NS_SWIFT_NAME(setUserHandle(_:_:));

- (NSString*)userHashAlgorithm:(int)userIndex NS_SWIFT_NAME(userHashAlgorithm(_:));
- (void)setUserHashAlgorithm:(int)userIndex :(NSString*)newUserHashAlgorithm NS_SWIFT_NAME(setUserHashAlgorithm(_:_:));

- (int)userIncomingSpeedLimit:(int)userIndex NS_SWIFT_NAME(userIncomingSpeedLimit(_:));
- (void)setUserIncomingSpeedLimit:(int)userIndex :(int)newUserIncomingSpeedLimit NS_SWIFT_NAME(setUserIncomingSpeedLimit(_:_:));

- (int)userOtpAlgorithm:(int)userIndex NS_SWIFT_NAME(userOtpAlgorithm(_:));
- (void)setUserOtpAlgorithm:(int)userIndex :(int)newUserOtpAlgorithm NS_SWIFT_NAME(setUserOtpAlgorithm(_:_:));

- (int)userOTPLen:(int)userIndex NS_SWIFT_NAME(userOTPLen(_:));
- (void)setUserOTPLen:(int)userIndex :(int)newUserOTPLen NS_SWIFT_NAME(setUserOTPLen(_:_:));

- (int)userOtpValue:(int)userIndex NS_SWIFT_NAME(userOtpValue(_:));
- (void)setUserOtpValue:(int)userIndex :(int)newUserOtpValue NS_SWIFT_NAME(setUserOtpValue(_:_:));

- (int)userOutgoingSpeedLimit:(int)userIndex NS_SWIFT_NAME(userOutgoingSpeedLimit(_:));
- (void)setUserOutgoingSpeedLimit:(int)userIndex :(int)newUserOutgoingSpeedLimit NS_SWIFT_NAME(setUserOutgoingSpeedLimit(_:_:));

- (NSString*)userPassword:(int)userIndex NS_SWIFT_NAME(userPassword(_:));
- (void)setUserPassword:(int)userIndex :(NSString*)newUserPassword NS_SWIFT_NAME(setUserPassword(_:_:));

- (NSData*)userSharedSecret:(int)userIndex NS_SWIFT_NAME(userSharedSecret(_:));
- (void)setUserSharedSecret:(int)userIndex :(NSData*)newUserSharedSecret NS_SWIFT_NAME(setUserSharedSecret(_:_:));

- (NSData*)userSSHKey:(int)userIndex NS_SWIFT_NAME(userSSHKey(_:));
- (void)setUserSSHKey:(int)userIndex :(NSData*)newUserSSHKey NS_SWIFT_NAME(setUserSSHKey(_:_:));

- (NSString*)userUsername:(int)userIndex NS_SWIFT_NAME(userUsername(_:));
- (void)setUserUsername:(int)userIndex :(NSString*)newUserUsername NS_SWIFT_NAME(setUserUsername(_:_:));

  /* Methods */

- (void)cleanup NS_SWIFT_NAME(cleanup());

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (void)dropClient:(long long)connectionId :(BOOL)forced NS_SWIFT_NAME(dropClient(_:_:));

- (void)getClientCert:(long long)connectionID NS_SWIFT_NAME(getClientCert(_:));

- (void)getClientKey:(long long)connectionID NS_SWIFT_NAME(getClientKey(_:));

- (NSString*)getRequestHeader:(long long)connectionId :(NSString*)headerName NS_SWIFT_NAME(getRequestHeader(_:_:));

- (NSString*)getResponseHeader:(long long)connectionId :(NSString*)headerName NS_SWIFT_NAME(getResponseHeader(_:_:));

- (NSString*)listClients NS_SWIFT_NAME(listClients());

- (void)pinClient:(long long)connectionId NS_SWIFT_NAME(pinClient(_:));

- (NSData*)processGenericRequest:(long long)connectionId :(NSData*)requestBytes NS_SWIFT_NAME(processGenericRequest(_:_:));

- (void)reset NS_SWIFT_NAME(reset());

- (void)setClientBytes:(long long)connectionID :(NSData*)value NS_SWIFT_NAME(setClientBytes(_:_:));

- (void)setClientCert:(long long)connectionID NS_SWIFT_NAME(setClientCert(_:));

- (void)setClientKey:(long long)connectionID NS_SWIFT_NAME(setClientKey(_:));

- (void)setResponseHeader:(long long)connectionId :(NSString*)headerName :(NSString*)value NS_SWIFT_NAME(setResponseHeader(_:_:_:));

- (void)start NS_SWIFT_NAME(start());

- (void)stop NS_SWIFT_NAME(stop());

@end

