/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//PGPPROTECTIONTYPES
#define PPT_NONE                                           0

#define PPT_LOW                                            1

#define PPT_NORMAL                                         2

#define PPT_HIGH                                           3

//ASYNCSIGNMETHODS
#define ASMD_PKCS1                                         0

#define ASMD_PKCS7                                         1

//EXTERNALCRYPTOMODES
#define ECM_DEFAULT                                        0

#define ECM_DISABLED                                       1

#define ECM_GENERIC                                        2

#define ECM_DCAUTH                                         3

#define ECM_DCAUTH_JSON                                    4

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxPGPWriterDelegate <NSObject>
@optional
- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onExternalSign:(NSString*)operationId :(NSString*)hashAlgorithm :(NSString*)pars :(NSString*)data :(NSString**)signedData NS_SWIFT_NAME(onExternalSign(_:_:_:_:_:));

- (void)onKeyPassphraseNeeded:(NSString*)keyID :(NSString*)userID :(BOOL)mainKey :(NSString**)passphrase :(int*)skip NS_SWIFT_NAME(onKeyPassphraseNeeded(_:_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onProgress:(long long)current :(long long)total :(int*)cancel NS_SWIFT_NAME(onProgress(_:_:_:));

@end

@interface SecureBlackboxPGPWriter : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxPGPWriterDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasError;

  BOOL m_delegateHasExternalSign;

  BOOL m_delegateHasKeyPassphraseNeeded;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasProgress;

}

+ (SecureBlackboxPGPWriter*)pgpwriter;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxPGPWriterDelegate> delegate;
- (id <SecureBlackboxPGPWriterDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxPGPWriterDelegate>)anObject;

  /* Events */

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onExternalSign:(NSString*)operationId :(NSString*)hashAlgorithm :(NSString*)pars :(NSString*)data :(NSString**)signedData NS_SWIFT_NAME(onExternalSign(_:_:_:_:_:));

- (void)onKeyPassphraseNeeded:(NSString*)keyID :(NSString*)userID :(BOOL)mainKey :(NSString**)passphrase :(int*)skip NS_SWIFT_NAME(onKeyPassphraseNeeded(_:_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onProgress:(long long)current :(long long)total :(int*)cancel NS_SWIFT_NAME(onProgress(_:_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readwrite,assign,getter=armor,setter=setArmor:) BOOL armor NS_SWIFT_NAME(armor);

- (BOOL)armor NS_SWIFT_NAME(armor());
- (void)setArmor :(BOOL)newArmor NS_SWIFT_NAME(setArmor(_:));

@property (nonatomic,readwrite,assign,getter=armorBoundary,setter=setArmorBoundary:) NSString* armorBoundary NS_SWIFT_NAME(armorBoundary);

- (NSString*)armorBoundary NS_SWIFT_NAME(armorBoundary());
- (void)setArmorBoundary :(NSString*)newArmorBoundary NS_SWIFT_NAME(setArmorBoundary(_:));

@property (nonatomic,readwrite,assign,getter=armorHeaders,setter=setArmorHeaders:) NSString* armorHeaders NS_SWIFT_NAME(armorHeaders);

- (NSString*)armorHeaders NS_SWIFT_NAME(armorHeaders());
- (void)setArmorHeaders :(NSString*)newArmorHeaders NS_SWIFT_NAME(setArmorHeaders(_:));

@property (nonatomic,readwrite,assign,getter=compress,setter=setCompress:) BOOL compress NS_SWIFT_NAME(compress);

- (BOOL)compress NS_SWIFT_NAME(compress());
- (void)setCompress :(BOOL)newCompress NS_SWIFT_NAME(setCompress(_:));

@property (nonatomic,readwrite,assign,getter=compressionAlgorithm,setter=setCompressionAlgorithm:) NSString* compressionAlgorithm NS_SWIFT_NAME(compressionAlgorithm);

- (NSString*)compressionAlgorithm NS_SWIFT_NAME(compressionAlgorithm());
- (void)setCompressionAlgorithm :(NSString*)newCompressionAlgorithm NS_SWIFT_NAME(setCompressionAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=compressionLevel,setter=setCompressionLevel:) int compressionLevel NS_SWIFT_NAME(compressionLevel);

- (int)compressionLevel NS_SWIFT_NAME(compressionLevel());
- (void)setCompressionLevel :(int)newCompressionLevel NS_SWIFT_NAME(setCompressionLevel(_:));

@property (nonatomic,readwrite,assign,getter=encryptingKeyCount,setter=setEncryptingKeyCount:) int encryptingKeyCount NS_SWIFT_NAME(encryptingKeyCount);

- (int)encryptingKeyCount NS_SWIFT_NAME(encryptingKeyCount());
- (void)setEncryptingKeyCount :(int)newEncryptingKeyCount NS_SWIFT_NAME(setEncryptingKeyCount(_:));

- (int)encryptingKeyBitsInKey:(int)encryptingKeyIndex NS_SWIFT_NAME(encryptingKeyBitsInKey(_:));

- (BOOL)encryptingKeyCanEncrypt:(int)encryptingKeyIndex NS_SWIFT_NAME(encryptingKeyCanEncrypt(_:));

- (BOOL)encryptingKeyCanSign:(int)encryptingKeyIndex NS_SWIFT_NAME(encryptingKeyCanSign(_:));

- (NSString*)encryptingKeyCurve:(int)encryptingKeyIndex NS_SWIFT_NAME(encryptingKeyCurve(_:));

- (BOOL)encryptingKeyEnabled:(int)encryptingKeyIndex NS_SWIFT_NAME(encryptingKeyEnabled(_:));
- (void)setEncryptingKeyEnabled:(int)encryptingKeyIndex :(BOOL)newEncryptingKeyEnabled NS_SWIFT_NAME(setEncryptingKeyEnabled(_:_:));

- (NSString*)encryptingKeyEncryptionAlgorithm:(int)encryptingKeyIndex NS_SWIFT_NAME(encryptingKeyEncryptionAlgorithm(_:));

- (long long)encryptingKeyHandle:(int)encryptingKeyIndex NS_SWIFT_NAME(encryptingKeyHandle(_:));
- (void)setEncryptingKeyHandle:(int)encryptingKeyIndex :(long long)newEncryptingKeyHandle NS_SWIFT_NAME(setEncryptingKeyHandle(_:_:));

- (BOOL)encryptingKeyIsPublic:(int)encryptingKeyIndex NS_SWIFT_NAME(encryptingKeyIsPublic(_:));

- (BOOL)encryptingKeyIsSecret:(int)encryptingKeyIndex NS_SWIFT_NAME(encryptingKeyIsSecret(_:));

- (BOOL)encryptingKeyIsSubkey:(int)encryptingKeyIndex NS_SWIFT_NAME(encryptingKeyIsSubkey(_:));

- (NSString*)encryptingKeyKeyFP:(int)encryptingKeyIndex NS_SWIFT_NAME(encryptingKeyKeyFP(_:));

- (NSString*)encryptingKeyKeyID:(int)encryptingKeyIndex NS_SWIFT_NAME(encryptingKeyKeyID(_:));

- (NSString*)encryptingKeyPassphrase:(int)encryptingKeyIndex NS_SWIFT_NAME(encryptingKeyPassphrase(_:));
- (void)setEncryptingKeyPassphrase:(int)encryptingKeyIndex :(NSString*)newEncryptingKeyPassphrase NS_SWIFT_NAME(setEncryptingKeyPassphrase(_:_:));

- (BOOL)encryptingKeyPassphraseValid:(int)encryptingKeyIndex NS_SWIFT_NAME(encryptingKeyPassphraseValid(_:));

- (NSString*)encryptingKeyPrimaryKeyID:(int)encryptingKeyIndex NS_SWIFT_NAME(encryptingKeyPrimaryKeyID(_:));

- (int)encryptingKeyProtection:(int)encryptingKeyIndex NS_SWIFT_NAME(encryptingKeyProtection(_:));

- (NSString*)encryptingKeyPublicKeyAlgorithm:(int)encryptingKeyIndex NS_SWIFT_NAME(encryptingKeyPublicKeyAlgorithm(_:));

- (int)encryptingKeyQBits:(int)encryptingKeyIndex NS_SWIFT_NAME(encryptingKeyQBits(_:));

- (NSString*)encryptingKeyTimestamp:(int)encryptingKeyIndex NS_SWIFT_NAME(encryptingKeyTimestamp(_:));

- (NSString*)encryptingKeyUsername:(int)encryptingKeyIndex NS_SWIFT_NAME(encryptingKeyUsername(_:));

- (NSString*)encryptingKeyValidTo:(int)encryptingKeyIndex NS_SWIFT_NAME(encryptingKeyValidTo(_:));

- (int)encryptingKeyVersion:(int)encryptingKeyIndex NS_SWIFT_NAME(encryptingKeyVersion(_:));

@property (nonatomic,readwrite,assign,getter=encryptionAlgorithm,setter=setEncryptionAlgorithm:) NSString* encryptionAlgorithm NS_SWIFT_NAME(encryptionAlgorithm);

- (NSString*)encryptionAlgorithm NS_SWIFT_NAME(encryptionAlgorithm());
- (void)setEncryptionAlgorithm :(NSString*)newEncryptionAlgorithm NS_SWIFT_NAME(setEncryptionAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoAsyncDocumentID,setter=setExternalCryptoAsyncDocumentID:) NSString* externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID);

- (NSString*)externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID());
- (void)setExternalCryptoAsyncDocumentID :(NSString*)newExternalCryptoAsyncDocumentID NS_SWIFT_NAME(setExternalCryptoAsyncDocumentID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoCustomParams,setter=setExternalCryptoCustomParams:) NSString* externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams);

- (NSString*)externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams());
- (void)setExternalCryptoCustomParams :(NSString*)newExternalCryptoCustomParams NS_SWIFT_NAME(setExternalCryptoCustomParams(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoData,setter=setExternalCryptoData:) NSString* externalCryptoData NS_SWIFT_NAME(externalCryptoData);

- (NSString*)externalCryptoData NS_SWIFT_NAME(externalCryptoData());
- (void)setExternalCryptoData :(NSString*)newExternalCryptoData NS_SWIFT_NAME(setExternalCryptoData(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoExternalHashCalculation,setter=setExternalCryptoExternalHashCalculation:) BOOL externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation);

- (BOOL)externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation());
- (void)setExternalCryptoExternalHashCalculation :(BOOL)newExternalCryptoExternalHashCalculation NS_SWIFT_NAME(setExternalCryptoExternalHashCalculation(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoHashAlgorithm,setter=setExternalCryptoHashAlgorithm:) NSString* externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm);

- (NSString*)externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm());
- (void)setExternalCryptoHashAlgorithm :(NSString*)newExternalCryptoHashAlgorithm NS_SWIFT_NAME(setExternalCryptoHashAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeyID,setter=setExternalCryptoKeyID:) NSString* externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID);

- (NSString*)externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID());
- (void)setExternalCryptoKeyID :(NSString*)newExternalCryptoKeyID NS_SWIFT_NAME(setExternalCryptoKeyID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeySecret,setter=setExternalCryptoKeySecret:) NSString* externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret);

- (NSString*)externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret());
- (void)setExternalCryptoKeySecret :(NSString*)newExternalCryptoKeySecret NS_SWIFT_NAME(setExternalCryptoKeySecret(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMethod,setter=setExternalCryptoMethod:) int externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod);

- (int)externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod());
- (void)setExternalCryptoMethod :(int)newExternalCryptoMethod NS_SWIFT_NAME(setExternalCryptoMethod(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMode,setter=setExternalCryptoMode:) int externalCryptoMode NS_SWIFT_NAME(externalCryptoMode);

- (int)externalCryptoMode NS_SWIFT_NAME(externalCryptoMode());
- (void)setExternalCryptoMode :(int)newExternalCryptoMode NS_SWIFT_NAME(setExternalCryptoMode(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoPublicKeyAlgorithm,setter=setExternalCryptoPublicKeyAlgorithm:) NSString* externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm);

- (NSString*)externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm());
- (void)setExternalCryptoPublicKeyAlgorithm :(NSString*)newExternalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(setExternalCryptoPublicKeyAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=fileName,setter=setFileName:) NSString* fileName NS_SWIFT_NAME(fileName);

- (NSString*)fileName NS_SWIFT_NAME(fileName());
- (void)setFileName :(NSString*)newFileName NS_SWIFT_NAME(setFileName(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=hashAlgorithm,setter=setHashAlgorithm:) NSString* hashAlgorithm NS_SWIFT_NAME(hashAlgorithm);

- (NSString*)hashAlgorithm NS_SWIFT_NAME(hashAlgorithm());
- (void)setHashAlgorithm :(NSString*)newHashAlgorithm NS_SWIFT_NAME(setHashAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=inputBytes,setter=setInputBytes:) NSData* inputBytes NS_SWIFT_NAME(inputBytes);

- (NSData*)inputBytes NS_SWIFT_NAME(inputBytes());
- (void)setInputBytes :(NSData*)newInputBytes NS_SWIFT_NAME(setInputBytes(_:));

@property (nonatomic,readwrite,assign,getter=inputFile,setter=setInputFile:) NSString* inputFile NS_SWIFT_NAME(inputFile);

- (NSString*)inputFile NS_SWIFT_NAME(inputFile());
- (void)setInputFile :(NSString*)newInputFile NS_SWIFT_NAME(setInputFile(_:));

@property (nonatomic,readwrite,assign,getter=inputIsText,setter=setInputIsText:) BOOL inputIsText NS_SWIFT_NAME(inputIsText);

- (BOOL)inputIsText NS_SWIFT_NAME(inputIsText());
- (void)setInputIsText :(BOOL)newInputIsText NS_SWIFT_NAME(setInputIsText(_:));

@property (nonatomic,readonly,assign,getter=outputBytes) NSData* outputBytes NS_SWIFT_NAME(outputBytes);

- (NSData*)outputBytes NS_SWIFT_NAME(outputBytes());

@property (nonatomic,readwrite,assign,getter=outputFile,setter=setOutputFile:) NSString* outputFile NS_SWIFT_NAME(outputFile);

- (NSString*)outputFile NS_SWIFT_NAME(outputFile());
- (void)setOutputFile :(NSString*)newOutputFile NS_SWIFT_NAME(setOutputFile(_:));

@property (nonatomic,readwrite,assign,getter=passphrase,setter=setPassphrase:) NSString* passphrase NS_SWIFT_NAME(passphrase);

- (NSString*)passphrase NS_SWIFT_NAME(passphrase());
- (void)setPassphrase :(NSString*)newPassphrase NS_SWIFT_NAME(setPassphrase(_:));

@property (nonatomic,readwrite,assign,getter=profile,setter=setProfile:) NSString* profile NS_SWIFT_NAME(profile);

- (NSString*)profile NS_SWIFT_NAME(profile());
- (void)setProfile :(NSString*)newProfile NS_SWIFT_NAME(setProfile(_:));

@property (nonatomic,readwrite,assign,getter=protection,setter=setProtection:) int protection NS_SWIFT_NAME(protection);

- (int)protection NS_SWIFT_NAME(protection());
- (void)setProtection :(int)newProtection NS_SWIFT_NAME(setProtection(_:));

@property (nonatomic,readwrite,assign,getter=signingKeyCount,setter=setSigningKeyCount:) int signingKeyCount NS_SWIFT_NAME(signingKeyCount);

- (int)signingKeyCount NS_SWIFT_NAME(signingKeyCount());
- (void)setSigningKeyCount :(int)newSigningKeyCount NS_SWIFT_NAME(setSigningKeyCount(_:));

- (int)signingKeyBitsInKey:(int)signingKeyIndex NS_SWIFT_NAME(signingKeyBitsInKey(_:));

- (BOOL)signingKeyCanEncrypt:(int)signingKeyIndex NS_SWIFT_NAME(signingKeyCanEncrypt(_:));

- (BOOL)signingKeyCanSign:(int)signingKeyIndex NS_SWIFT_NAME(signingKeyCanSign(_:));

- (NSString*)signingKeyCurve:(int)signingKeyIndex NS_SWIFT_NAME(signingKeyCurve(_:));

- (BOOL)signingKeyEnabled:(int)signingKeyIndex NS_SWIFT_NAME(signingKeyEnabled(_:));
- (void)setSigningKeyEnabled:(int)signingKeyIndex :(BOOL)newSigningKeyEnabled NS_SWIFT_NAME(setSigningKeyEnabled(_:_:));

- (NSString*)signingKeyEncryptionAlgorithm:(int)signingKeyIndex NS_SWIFT_NAME(signingKeyEncryptionAlgorithm(_:));

- (long long)signingKeyHandle:(int)signingKeyIndex NS_SWIFT_NAME(signingKeyHandle(_:));
- (void)setSigningKeyHandle:(int)signingKeyIndex :(long long)newSigningKeyHandle NS_SWIFT_NAME(setSigningKeyHandle(_:_:));

- (BOOL)signingKeyIsPublic:(int)signingKeyIndex NS_SWIFT_NAME(signingKeyIsPublic(_:));

- (BOOL)signingKeyIsSecret:(int)signingKeyIndex NS_SWIFT_NAME(signingKeyIsSecret(_:));

- (BOOL)signingKeyIsSubkey:(int)signingKeyIndex NS_SWIFT_NAME(signingKeyIsSubkey(_:));

- (NSString*)signingKeyKeyFP:(int)signingKeyIndex NS_SWIFT_NAME(signingKeyKeyFP(_:));

- (NSString*)signingKeyKeyID:(int)signingKeyIndex NS_SWIFT_NAME(signingKeyKeyID(_:));

- (NSString*)signingKeyPassphrase:(int)signingKeyIndex NS_SWIFT_NAME(signingKeyPassphrase(_:));
- (void)setSigningKeyPassphrase:(int)signingKeyIndex :(NSString*)newSigningKeyPassphrase NS_SWIFT_NAME(setSigningKeyPassphrase(_:_:));

- (BOOL)signingKeyPassphraseValid:(int)signingKeyIndex NS_SWIFT_NAME(signingKeyPassphraseValid(_:));

- (NSString*)signingKeyPrimaryKeyID:(int)signingKeyIndex NS_SWIFT_NAME(signingKeyPrimaryKeyID(_:));

- (int)signingKeyProtection:(int)signingKeyIndex NS_SWIFT_NAME(signingKeyProtection(_:));

- (NSString*)signingKeyPublicKeyAlgorithm:(int)signingKeyIndex NS_SWIFT_NAME(signingKeyPublicKeyAlgorithm(_:));

- (int)signingKeyQBits:(int)signingKeyIndex NS_SWIFT_NAME(signingKeyQBits(_:));

- (NSString*)signingKeyTimestamp:(int)signingKeyIndex NS_SWIFT_NAME(signingKeyTimestamp(_:));

- (NSString*)signingKeyUsername:(int)signingKeyIndex NS_SWIFT_NAME(signingKeyUsername(_:));

- (NSString*)signingKeyValidTo:(int)signingKeyIndex NS_SWIFT_NAME(signingKeyValidTo(_:));

- (int)signingKeyVersion:(int)signingKeyIndex NS_SWIFT_NAME(signingKeyVersion(_:));

@property (nonatomic,readwrite,assign,getter=timestamp,setter=setTimestamp:) NSString* timestamp NS_SWIFT_NAME(timestamp);

- (NSString*)timestamp NS_SWIFT_NAME(timestamp());
- (void)setTimestamp :(NSString*)newTimestamp NS_SWIFT_NAME(setTimestamp(_:));

  /* Methods */

- (void)clearTextSign NS_SWIFT_NAME(clearTextSign());

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (void)encrypt NS_SWIFT_NAME(encrypt());

- (void)encryptAndSign NS_SWIFT_NAME(encryptAndSign());

- (void)reset NS_SWIFT_NAME(reset());

- (void)sign:(BOOL)detached NS_SWIFT_NAME(sign(_:));

@end

