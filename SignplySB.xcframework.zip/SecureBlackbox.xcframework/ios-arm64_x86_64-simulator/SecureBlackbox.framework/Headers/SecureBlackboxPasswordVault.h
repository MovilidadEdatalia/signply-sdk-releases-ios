/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxPasswordVaultDelegate <NSObject>
@optional
- (void)onEntryKeyNeeded:(NSString*)entryName :(int*)cancel NS_SWIFT_NAME(onEntryKeyNeeded(_:_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onKeyNeeded:(int*)cancel NS_SWIFT_NAME(onKeyNeeded(_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

@end

@interface SecureBlackboxPasswordVault : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxPasswordVaultDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasEntryKeyNeeded;

  BOOL m_delegateHasError;

  BOOL m_delegateHasKeyNeeded;

  BOOL m_delegateHasNotification;

}

+ (SecureBlackboxPasswordVault*)passwordvault;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxPasswordVaultDelegate> delegate;
- (id <SecureBlackboxPasswordVaultDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxPasswordVaultDelegate>)anObject;

  /* Events */

- (void)onEntryKeyNeeded:(NSString*)entryName :(int*)cancel NS_SWIFT_NAME(onEntryKeyNeeded(_:_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onKeyNeeded:(int*)cancel NS_SWIFT_NAME(onKeyNeeded(_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readwrite,assign,getter=description,setter=setDescription:) NSString* description NS_SWIFT_NAME(description);

- (NSString*)description NS_SWIFT_NAME(description());
- (NSString*)description_ NS_SWIFT_NAME(description_());
- (void)setDescription :(NSString*)newDescription NS_SWIFT_NAME(setDescription(_:));
- (void)setDescription_ :(NSString*)newDescription NS_SWIFT_NAME(setDescription_(_:));

@property (nonatomic,readwrite,assign,getter=entryKey,setter=setEntryKey:) NSData* entryKey NS_SWIFT_NAME(entryKey);

- (NSData*)entryKey NS_SWIFT_NAME(entryKey());
- (void)setEntryKey :(NSData*)newEntryKey NS_SWIFT_NAME(setEntryKey(_:));

@property (nonatomic,readwrite,assign,getter=entryPassword,setter=setEntryPassword:) NSString* entryPassword NS_SWIFT_NAME(entryPassword);

- (NSString*)entryPassword NS_SWIFT_NAME(entryPassword());
- (void)setEntryPassword :(NSString*)newEntryPassword NS_SWIFT_NAME(setEntryPassword(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=key,setter=setKey:) NSData* key NS_SWIFT_NAME(key);

- (NSData*)key NS_SWIFT_NAME(key());
- (void)setKey :(NSData*)newKey NS_SWIFT_NAME(setKey(_:));

@property (nonatomic,readwrite,assign,getter=password,setter=setPassword:) NSString* password NS_SWIFT_NAME(password);

- (NSString*)password NS_SWIFT_NAME(password());
- (void)setPassword :(NSString*)newPassword NS_SWIFT_NAME(setPassword(_:));

@property (nonatomic,readwrite,assign,getter=platformProtection,setter=setPlatformProtection:) BOOL platformProtection NS_SWIFT_NAME(platformProtection);

- (BOOL)platformProtection NS_SWIFT_NAME(platformProtection());
- (void)setPlatformProtection :(BOOL)newPlatformProtection NS_SWIFT_NAME(setPlatformProtection(_:));

@property (nonatomic,readwrite,assign,getter=title,setter=setTitle:) NSString* title NS_SWIFT_NAME(title);

- (NSString*)title NS_SWIFT_NAME(title());
- (void)setTitle :(NSString*)newTitle NS_SWIFT_NAME(setTitle(_:));

  /* Methods */

- (void)addEntry:(NSString*)entryName NS_SWIFT_NAME(addEntry(_:));

- (void)changeEntryKey:(NSString*)entryName :(NSData*)newKey NS_SWIFT_NAME(changeEntryKey(_:_:));

- (void)changeEntryPassword:(NSString*)entryName :(NSString*)newPassword NS_SWIFT_NAME(changeEntryPassword(_:_:));

- (void)close NS_SWIFT_NAME(close());

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (void)createNew NS_SWIFT_NAME(createNew());

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (NSData*)getEntryValue:(NSString*)entryName :(NSString*)fieldName NS_SWIFT_NAME(getEntryValue(_:_:));

- (NSString*)getEntryValueStr:(NSString*)entryName :(NSString*)fieldName NS_SWIFT_NAME(getEntryValueStr(_:_:));

- (NSString*)listEntries NS_SWIFT_NAME(listEntries());

- (NSString*)listFields:(NSString*)entryName :(BOOL)includeEncrypted NS_SWIFT_NAME(listFields(_:_:));

- (void)openBytes:(NSData*)vaultBytes NS_SWIFT_NAME(openBytes(_:));

- (void)openFile:(NSString*)fileName NS_SWIFT_NAME(openFile(_:));

- (void)removeAllEntries NS_SWIFT_NAME(removeAllEntries());

- (void)removeEntry:(NSString*)entryName NS_SWIFT_NAME(removeEntry(_:));

- (void)removeField:(NSString*)entryName :(NSString*)fieldName NS_SWIFT_NAME(removeField(_:_:));

- (void)reset NS_SWIFT_NAME(reset());

- (NSData*)saveBytes NS_SWIFT_NAME(saveBytes());

- (void)saveFile:(NSString*)fileName NS_SWIFT_NAME(saveFile(_:));

- (void)setEntryValue:(NSString*)entryName :(NSString*)fieldName :(NSData*)fieldValue :(BOOL)encrypted NS_SWIFT_NAME(setEntryValue(_:_:_:_:));

- (void)setEntryValueStr:(NSString*)entryName :(NSString*)fieldName :(NSString*)fieldValueStr :(BOOL)encrypted NS_SWIFT_NAME(setEntryValueStr(_:_:_:_:));

@end

