/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//XMLENCRYPTEDDATATYPES
#define CXEDT_ELEMENT                                      0

#define CXEDT_CONTENT                                      1

#define CXEDT_EXTERNAL                                     2

//ASYNCSIGNMETHODS
#define ASMD_PKCS1                                         0

#define ASMD_PKCS7                                         1

//EXTERNALCRYPTOMODES
#define ECM_DEFAULT                                        0

#define ECM_DISABLED                                       1

#define ECM_GENERIC                                        2

#define ECM_DCAUTH                                         3

#define ECM_DCAUTH_JSON                                    4

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

//XMLKEYENCRYPTIONTYPES
#define CXET_KEY_TRANSPORT                                 0

#define CXET_KEY_WRAP                                      1

//XMLKEYTRANSPORTMETHODS
#define CXKT_RSA15                                         0

#define CXKT_RSAOAEP                                       1

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxXMLDecryptorDelegate <NSObject>
@optional
- (void)onDecryptionInfoNeeded:(int*)cancelDecryption NS_SWIFT_NAME(onDecryptionInfoNeeded(_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onExternalDecrypt:(NSString*)operationId :(NSString*)algorithm :(NSString*)pars :(NSString*)encryptedData :(NSString**)data NS_SWIFT_NAME(onExternalDecrypt(_:_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onSaveExternalData:(NSData*)externalData NS_SWIFT_NAME(onSaveExternalData(_:));

@end

@interface SecureBlackboxXMLDecryptor : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxXMLDecryptorDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasDecryptionInfoNeeded;

  BOOL m_delegateHasError;

  BOOL m_delegateHasExternalDecrypt;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasSaveExternalData;

}

+ (SecureBlackboxXMLDecryptor*)xmldecryptor;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxXMLDecryptorDelegate> delegate;
- (id <SecureBlackboxXMLDecryptorDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxXMLDecryptorDelegate>)anObject;

  /* Events */

- (void)onDecryptionInfoNeeded:(int*)cancelDecryption NS_SWIFT_NAME(onDecryptionInfoNeeded(_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onExternalDecrypt:(NSString*)operationId :(NSString*)algorithm :(NSString*)pars :(NSString*)encryptedData :(NSString**)data NS_SWIFT_NAME(onExternalDecrypt(_:_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onSaveExternalData:(NSData*)externalData NS_SWIFT_NAME(onSaveExternalData(_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readwrite,assign,getter=decryptionKey,setter=setDecryptionKey:) NSData* decryptionKey NS_SWIFT_NAME(decryptionKey);

- (NSData*)decryptionKey NS_SWIFT_NAME(decryptionKey());
- (void)setDecryptionKey :(NSData*)newDecryptionKey NS_SWIFT_NAME(setDecryptionKey(_:));

@property (nonatomic,readwrite,assign,getter=encoding,setter=setEncoding:) NSString* encoding NS_SWIFT_NAME(encoding);

- (NSString*)encoding NS_SWIFT_NAME(encoding());
- (void)setEncoding :(NSString*)newEncoding NS_SWIFT_NAME(setEncoding(_:));

@property (nonatomic,readonly,assign,getter=encryptedDataType) int encryptedDataType NS_SWIFT_NAME(encryptedDataType);

- (int)encryptedDataType NS_SWIFT_NAME(encryptedDataType());

@property (nonatomic,readonly,assign,getter=encryptionMethod) NSString* encryptionMethod NS_SWIFT_NAME(encryptionMethod);

- (NSString*)encryptionMethod NS_SWIFT_NAME(encryptionMethod());

@property (nonatomic,readonly,assign,getter=encryptKey) BOOL encryptKey NS_SWIFT_NAME(encryptKey);

- (BOOL)encryptKey NS_SWIFT_NAME(encryptKey());

@property (nonatomic,readwrite,assign,getter=externalCryptoAsyncDocumentID,setter=setExternalCryptoAsyncDocumentID:) NSString* externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID);

- (NSString*)externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID());
- (void)setExternalCryptoAsyncDocumentID :(NSString*)newExternalCryptoAsyncDocumentID NS_SWIFT_NAME(setExternalCryptoAsyncDocumentID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoCustomParams,setter=setExternalCryptoCustomParams:) NSString* externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams);

- (NSString*)externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams());
- (void)setExternalCryptoCustomParams :(NSString*)newExternalCryptoCustomParams NS_SWIFT_NAME(setExternalCryptoCustomParams(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoData,setter=setExternalCryptoData:) NSString* externalCryptoData NS_SWIFT_NAME(externalCryptoData);

- (NSString*)externalCryptoData NS_SWIFT_NAME(externalCryptoData());
- (void)setExternalCryptoData :(NSString*)newExternalCryptoData NS_SWIFT_NAME(setExternalCryptoData(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoExternalHashCalculation,setter=setExternalCryptoExternalHashCalculation:) BOOL externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation);

- (BOOL)externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation());
- (void)setExternalCryptoExternalHashCalculation :(BOOL)newExternalCryptoExternalHashCalculation NS_SWIFT_NAME(setExternalCryptoExternalHashCalculation(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoHashAlgorithm,setter=setExternalCryptoHashAlgorithm:) NSString* externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm);

- (NSString*)externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm());
- (void)setExternalCryptoHashAlgorithm :(NSString*)newExternalCryptoHashAlgorithm NS_SWIFT_NAME(setExternalCryptoHashAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeyID,setter=setExternalCryptoKeyID:) NSString* externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID);

- (NSString*)externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID());
- (void)setExternalCryptoKeyID :(NSString*)newExternalCryptoKeyID NS_SWIFT_NAME(setExternalCryptoKeyID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeySecret,setter=setExternalCryptoKeySecret:) NSString* externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret);

- (NSString*)externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret());
- (void)setExternalCryptoKeySecret :(NSString*)newExternalCryptoKeySecret NS_SWIFT_NAME(setExternalCryptoKeySecret(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMethod,setter=setExternalCryptoMethod:) int externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod);

- (int)externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod());
- (void)setExternalCryptoMethod :(int)newExternalCryptoMethod NS_SWIFT_NAME(setExternalCryptoMethod(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMode,setter=setExternalCryptoMode:) int externalCryptoMode NS_SWIFT_NAME(externalCryptoMode);

- (int)externalCryptoMode NS_SWIFT_NAME(externalCryptoMode());
- (void)setExternalCryptoMode :(int)newExternalCryptoMode NS_SWIFT_NAME(setExternalCryptoMode(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoPublicKeyAlgorithm,setter=setExternalCryptoPublicKeyAlgorithm:) NSString* externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm);

- (NSString*)externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm());
- (void)setExternalCryptoPublicKeyAlgorithm :(NSString*)newExternalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(setExternalCryptoPublicKeyAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=externalData,setter=setExternalData:) NSData* externalData NS_SWIFT_NAME(externalData);

- (NSData*)externalData NS_SWIFT_NAME(externalData());
- (void)setExternalData :(NSData*)newExternalData NS_SWIFT_NAME(setExternalData(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=inputBytes,setter=setInputBytes:) NSData* inputBytes NS_SWIFT_NAME(inputBytes);

- (NSData*)inputBytes NS_SWIFT_NAME(inputBytes());
- (void)setInputBytes :(NSData*)newInputBytes NS_SWIFT_NAME(setInputBytes(_:));

@property (nonatomic,readwrite,assign,getter=inputFile,setter=setInputFile:) NSString* inputFile NS_SWIFT_NAME(inputFile);

- (NSString*)inputFile NS_SWIFT_NAME(inputFile());
- (void)setInputFile :(NSString*)newInputFile NS_SWIFT_NAME(setInputFile(_:));

@property (nonatomic,readonly,assign,getter=keyDecryptionCertBytes) NSData* keyDecryptionCertBytes NS_SWIFT_NAME(keyDecryptionCertBytes);

- (NSData*)keyDecryptionCertBytes NS_SWIFT_NAME(keyDecryptionCertBytes());

@property (nonatomic,readwrite,assign,getter=keyDecryptionCertCA,setter=setKeyDecryptionCertCA:) BOOL keyDecryptionCertCA NS_SWIFT_NAME(keyDecryptionCertCA);

- (BOOL)keyDecryptionCertCA NS_SWIFT_NAME(keyDecryptionCertCA());
- (void)setKeyDecryptionCertCA :(BOOL)newKeyDecryptionCertCA NS_SWIFT_NAME(setKeyDecryptionCertCA(_:));

@property (nonatomic,readonly,assign,getter=keyDecryptionCertCAKeyID) NSData* keyDecryptionCertCAKeyID NS_SWIFT_NAME(keyDecryptionCertCAKeyID);

- (NSData*)keyDecryptionCertCAKeyID NS_SWIFT_NAME(keyDecryptionCertCAKeyID());

@property (nonatomic,readonly,assign,getter=keyDecryptionCertCertType) int keyDecryptionCertCertType NS_SWIFT_NAME(keyDecryptionCertCertType);

- (int)keyDecryptionCertCertType NS_SWIFT_NAME(keyDecryptionCertCertType());

@property (nonatomic,readwrite,assign,getter=keyDecryptionCertCRLDistributionPoints,setter=setKeyDecryptionCertCRLDistributionPoints:) NSString* keyDecryptionCertCRLDistributionPoints NS_SWIFT_NAME(keyDecryptionCertCRLDistributionPoints);

- (NSString*)keyDecryptionCertCRLDistributionPoints NS_SWIFT_NAME(keyDecryptionCertCRLDistributionPoints());
- (void)setKeyDecryptionCertCRLDistributionPoints :(NSString*)newKeyDecryptionCertCRLDistributionPoints NS_SWIFT_NAME(setKeyDecryptionCertCRLDistributionPoints(_:));

@property (nonatomic,readwrite,assign,getter=keyDecryptionCertCurve,setter=setKeyDecryptionCertCurve:) NSString* keyDecryptionCertCurve NS_SWIFT_NAME(keyDecryptionCertCurve);

- (NSString*)keyDecryptionCertCurve NS_SWIFT_NAME(keyDecryptionCertCurve());
- (void)setKeyDecryptionCertCurve :(NSString*)newKeyDecryptionCertCurve NS_SWIFT_NAME(setKeyDecryptionCertCurve(_:));

@property (nonatomic,readonly,assign,getter=keyDecryptionCertFingerprint) NSString* keyDecryptionCertFingerprint NS_SWIFT_NAME(keyDecryptionCertFingerprint);

- (NSString*)keyDecryptionCertFingerprint NS_SWIFT_NAME(keyDecryptionCertFingerprint());

@property (nonatomic,readonly,assign,getter=keyDecryptionCertFriendlyName) NSString* keyDecryptionCertFriendlyName NS_SWIFT_NAME(keyDecryptionCertFriendlyName);

- (NSString*)keyDecryptionCertFriendlyName NS_SWIFT_NAME(keyDecryptionCertFriendlyName());

@property (nonatomic,readwrite,assign,getter=keyDecryptionCertHandle,setter=setKeyDecryptionCertHandle:) long long keyDecryptionCertHandle NS_SWIFT_NAME(keyDecryptionCertHandle);

- (long long)keyDecryptionCertHandle NS_SWIFT_NAME(keyDecryptionCertHandle());
- (void)setKeyDecryptionCertHandle :(long long)newKeyDecryptionCertHandle NS_SWIFT_NAME(setKeyDecryptionCertHandle(_:));

@property (nonatomic,readwrite,assign,getter=keyDecryptionCertHashAlgorithm,setter=setKeyDecryptionCertHashAlgorithm:) NSString* keyDecryptionCertHashAlgorithm NS_SWIFT_NAME(keyDecryptionCertHashAlgorithm);

- (NSString*)keyDecryptionCertHashAlgorithm NS_SWIFT_NAME(keyDecryptionCertHashAlgorithm());
- (void)setKeyDecryptionCertHashAlgorithm :(NSString*)newKeyDecryptionCertHashAlgorithm NS_SWIFT_NAME(setKeyDecryptionCertHashAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=keyDecryptionCertIssuer) NSString* keyDecryptionCertIssuer NS_SWIFT_NAME(keyDecryptionCertIssuer);

- (NSString*)keyDecryptionCertIssuer NS_SWIFT_NAME(keyDecryptionCertIssuer());

@property (nonatomic,readwrite,assign,getter=keyDecryptionCertIssuerRDN,setter=setKeyDecryptionCertIssuerRDN:) NSString* keyDecryptionCertIssuerRDN NS_SWIFT_NAME(keyDecryptionCertIssuerRDN);

- (NSString*)keyDecryptionCertIssuerRDN NS_SWIFT_NAME(keyDecryptionCertIssuerRDN());
- (void)setKeyDecryptionCertIssuerRDN :(NSString*)newKeyDecryptionCertIssuerRDN NS_SWIFT_NAME(setKeyDecryptionCertIssuerRDN(_:));

@property (nonatomic,readwrite,assign,getter=keyDecryptionCertKeyAlgorithm,setter=setKeyDecryptionCertKeyAlgorithm:) NSString* keyDecryptionCertKeyAlgorithm NS_SWIFT_NAME(keyDecryptionCertKeyAlgorithm);

- (NSString*)keyDecryptionCertKeyAlgorithm NS_SWIFT_NAME(keyDecryptionCertKeyAlgorithm());
- (void)setKeyDecryptionCertKeyAlgorithm :(NSString*)newKeyDecryptionCertKeyAlgorithm NS_SWIFT_NAME(setKeyDecryptionCertKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=keyDecryptionCertKeyBits) int keyDecryptionCertKeyBits NS_SWIFT_NAME(keyDecryptionCertKeyBits);

- (int)keyDecryptionCertKeyBits NS_SWIFT_NAME(keyDecryptionCertKeyBits());

@property (nonatomic,readonly,assign,getter=keyDecryptionCertKeyFingerprint) NSString* keyDecryptionCertKeyFingerprint NS_SWIFT_NAME(keyDecryptionCertKeyFingerprint);

- (NSString*)keyDecryptionCertKeyFingerprint NS_SWIFT_NAME(keyDecryptionCertKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=keyDecryptionCertKeyUsage,setter=setKeyDecryptionCertKeyUsage:) int keyDecryptionCertKeyUsage NS_SWIFT_NAME(keyDecryptionCertKeyUsage);

- (int)keyDecryptionCertKeyUsage NS_SWIFT_NAME(keyDecryptionCertKeyUsage());
- (void)setKeyDecryptionCertKeyUsage :(int)newKeyDecryptionCertKeyUsage NS_SWIFT_NAME(setKeyDecryptionCertKeyUsage(_:));

@property (nonatomic,readonly,assign,getter=keyDecryptionCertKeyValid) BOOL keyDecryptionCertKeyValid NS_SWIFT_NAME(keyDecryptionCertKeyValid);

- (BOOL)keyDecryptionCertKeyValid NS_SWIFT_NAME(keyDecryptionCertKeyValid());

@property (nonatomic,readwrite,assign,getter=keyDecryptionCertOCSPLocations,setter=setKeyDecryptionCertOCSPLocations:) NSString* keyDecryptionCertOCSPLocations NS_SWIFT_NAME(keyDecryptionCertOCSPLocations);

- (NSString*)keyDecryptionCertOCSPLocations NS_SWIFT_NAME(keyDecryptionCertOCSPLocations());
- (void)setKeyDecryptionCertOCSPLocations :(NSString*)newKeyDecryptionCertOCSPLocations NS_SWIFT_NAME(setKeyDecryptionCertOCSPLocations(_:));

@property (nonatomic,readwrite,assign,getter=keyDecryptionCertOCSPNoCheck,setter=setKeyDecryptionCertOCSPNoCheck:) BOOL keyDecryptionCertOCSPNoCheck NS_SWIFT_NAME(keyDecryptionCertOCSPNoCheck);

- (BOOL)keyDecryptionCertOCSPNoCheck NS_SWIFT_NAME(keyDecryptionCertOCSPNoCheck());
- (void)setKeyDecryptionCertOCSPNoCheck :(BOOL)newKeyDecryptionCertOCSPNoCheck NS_SWIFT_NAME(setKeyDecryptionCertOCSPNoCheck(_:));

@property (nonatomic,readonly,assign,getter=keyDecryptionCertOrigin) int keyDecryptionCertOrigin NS_SWIFT_NAME(keyDecryptionCertOrigin);

- (int)keyDecryptionCertOrigin NS_SWIFT_NAME(keyDecryptionCertOrigin());

@property (nonatomic,readwrite,assign,getter=keyDecryptionCertPolicyIDs,setter=setKeyDecryptionCertPolicyIDs:) NSString* keyDecryptionCertPolicyIDs NS_SWIFT_NAME(keyDecryptionCertPolicyIDs);

- (NSString*)keyDecryptionCertPolicyIDs NS_SWIFT_NAME(keyDecryptionCertPolicyIDs());
- (void)setKeyDecryptionCertPolicyIDs :(NSString*)newKeyDecryptionCertPolicyIDs NS_SWIFT_NAME(setKeyDecryptionCertPolicyIDs(_:));

@property (nonatomic,readonly,assign,getter=keyDecryptionCertPrivateKeyBytes) NSData* keyDecryptionCertPrivateKeyBytes NS_SWIFT_NAME(keyDecryptionCertPrivateKeyBytes);

- (NSData*)keyDecryptionCertPrivateKeyBytes NS_SWIFT_NAME(keyDecryptionCertPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=keyDecryptionCertPrivateKeyExists) BOOL keyDecryptionCertPrivateKeyExists NS_SWIFT_NAME(keyDecryptionCertPrivateKeyExists);

- (BOOL)keyDecryptionCertPrivateKeyExists NS_SWIFT_NAME(keyDecryptionCertPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=keyDecryptionCertPrivateKeyExtractable) BOOL keyDecryptionCertPrivateKeyExtractable NS_SWIFT_NAME(keyDecryptionCertPrivateKeyExtractable);

- (BOOL)keyDecryptionCertPrivateKeyExtractable NS_SWIFT_NAME(keyDecryptionCertPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=keyDecryptionCertPublicKeyBytes) NSData* keyDecryptionCertPublicKeyBytes NS_SWIFT_NAME(keyDecryptionCertPublicKeyBytes);

- (NSData*)keyDecryptionCertPublicKeyBytes NS_SWIFT_NAME(keyDecryptionCertPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=keyDecryptionCertQualified) BOOL keyDecryptionCertQualified NS_SWIFT_NAME(keyDecryptionCertQualified);

- (BOOL)keyDecryptionCertQualified NS_SWIFT_NAME(keyDecryptionCertQualified());

@property (nonatomic,readwrite,assign,getter=keyDecryptionCertQualifiedStatements,setter=setKeyDecryptionCertQualifiedStatements:) int keyDecryptionCertQualifiedStatements NS_SWIFT_NAME(keyDecryptionCertQualifiedStatements);

- (int)keyDecryptionCertQualifiedStatements NS_SWIFT_NAME(keyDecryptionCertQualifiedStatements());
- (void)setKeyDecryptionCertQualifiedStatements :(int)newKeyDecryptionCertQualifiedStatements NS_SWIFT_NAME(setKeyDecryptionCertQualifiedStatements(_:));

@property (nonatomic,readonly,assign,getter=keyDecryptionCertQualifiers) NSString* keyDecryptionCertQualifiers NS_SWIFT_NAME(keyDecryptionCertQualifiers);

- (NSString*)keyDecryptionCertQualifiers NS_SWIFT_NAME(keyDecryptionCertQualifiers());

@property (nonatomic,readonly,assign,getter=keyDecryptionCertSelfSigned) BOOL keyDecryptionCertSelfSigned NS_SWIFT_NAME(keyDecryptionCertSelfSigned);

- (BOOL)keyDecryptionCertSelfSigned NS_SWIFT_NAME(keyDecryptionCertSelfSigned());

@property (nonatomic,readwrite,assign,getter=keyDecryptionCertSerialNumber,setter=setKeyDecryptionCertSerialNumber:) NSData* keyDecryptionCertSerialNumber NS_SWIFT_NAME(keyDecryptionCertSerialNumber);

- (NSData*)keyDecryptionCertSerialNumber NS_SWIFT_NAME(keyDecryptionCertSerialNumber());
- (void)setKeyDecryptionCertSerialNumber :(NSData*)newKeyDecryptionCertSerialNumber NS_SWIFT_NAME(setKeyDecryptionCertSerialNumber(_:));

@property (nonatomic,readonly,assign,getter=keyDecryptionCertSigAlgorithm) NSString* keyDecryptionCertSigAlgorithm NS_SWIFT_NAME(keyDecryptionCertSigAlgorithm);

- (NSString*)keyDecryptionCertSigAlgorithm NS_SWIFT_NAME(keyDecryptionCertSigAlgorithm());

@property (nonatomic,readonly,assign,getter=keyDecryptionCertSource) int keyDecryptionCertSource NS_SWIFT_NAME(keyDecryptionCertSource);

- (int)keyDecryptionCertSource NS_SWIFT_NAME(keyDecryptionCertSource());

@property (nonatomic,readonly,assign,getter=keyDecryptionCertSubject) NSString* keyDecryptionCertSubject NS_SWIFT_NAME(keyDecryptionCertSubject);

- (NSString*)keyDecryptionCertSubject NS_SWIFT_NAME(keyDecryptionCertSubject());

@property (nonatomic,readwrite,assign,getter=keyDecryptionCertSubjectAlternativeName,setter=setKeyDecryptionCertSubjectAlternativeName:) NSString* keyDecryptionCertSubjectAlternativeName NS_SWIFT_NAME(keyDecryptionCertSubjectAlternativeName);

- (NSString*)keyDecryptionCertSubjectAlternativeName NS_SWIFT_NAME(keyDecryptionCertSubjectAlternativeName());
- (void)setKeyDecryptionCertSubjectAlternativeName :(NSString*)newKeyDecryptionCertSubjectAlternativeName NS_SWIFT_NAME(setKeyDecryptionCertSubjectAlternativeName(_:));

@property (nonatomic,readwrite,assign,getter=keyDecryptionCertSubjectKeyID,setter=setKeyDecryptionCertSubjectKeyID:) NSData* keyDecryptionCertSubjectKeyID NS_SWIFT_NAME(keyDecryptionCertSubjectKeyID);

- (NSData*)keyDecryptionCertSubjectKeyID NS_SWIFT_NAME(keyDecryptionCertSubjectKeyID());
- (void)setKeyDecryptionCertSubjectKeyID :(NSData*)newKeyDecryptionCertSubjectKeyID NS_SWIFT_NAME(setKeyDecryptionCertSubjectKeyID(_:));

@property (nonatomic,readwrite,assign,getter=keyDecryptionCertSubjectRDN,setter=setKeyDecryptionCertSubjectRDN:) NSString* keyDecryptionCertSubjectRDN NS_SWIFT_NAME(keyDecryptionCertSubjectRDN);

- (NSString*)keyDecryptionCertSubjectRDN NS_SWIFT_NAME(keyDecryptionCertSubjectRDN());
- (void)setKeyDecryptionCertSubjectRDN :(NSString*)newKeyDecryptionCertSubjectRDN NS_SWIFT_NAME(setKeyDecryptionCertSubjectRDN(_:));

@property (nonatomic,readonly,assign,getter=keyDecryptionCertValid) BOOL keyDecryptionCertValid NS_SWIFT_NAME(keyDecryptionCertValid);

- (BOOL)keyDecryptionCertValid NS_SWIFT_NAME(keyDecryptionCertValid());

@property (nonatomic,readwrite,assign,getter=keyDecryptionCertValidFrom,setter=setKeyDecryptionCertValidFrom:) NSString* keyDecryptionCertValidFrom NS_SWIFT_NAME(keyDecryptionCertValidFrom);

- (NSString*)keyDecryptionCertValidFrom NS_SWIFT_NAME(keyDecryptionCertValidFrom());
- (void)setKeyDecryptionCertValidFrom :(NSString*)newKeyDecryptionCertValidFrom NS_SWIFT_NAME(setKeyDecryptionCertValidFrom(_:));

@property (nonatomic,readwrite,assign,getter=keyDecryptionCertValidTo,setter=setKeyDecryptionCertValidTo:) NSString* keyDecryptionCertValidTo NS_SWIFT_NAME(keyDecryptionCertValidTo);

- (NSString*)keyDecryptionCertValidTo NS_SWIFT_NAME(keyDecryptionCertValidTo());
- (void)setKeyDecryptionCertValidTo :(NSString*)newKeyDecryptionCertValidTo NS_SWIFT_NAME(setKeyDecryptionCertValidTo(_:));

@property (nonatomic,readwrite,assign,getter=keyDecryptionKey,setter=setKeyDecryptionKey:) NSData* keyDecryptionKey NS_SWIFT_NAME(keyDecryptionKey);

- (NSData*)keyDecryptionKey NS_SWIFT_NAME(keyDecryptionKey());
- (void)setKeyDecryptionKey :(NSData*)newKeyDecryptionKey NS_SWIFT_NAME(setKeyDecryptionKey(_:));

@property (nonatomic,readonly,assign,getter=keyEncryptionType) int keyEncryptionType NS_SWIFT_NAME(keyEncryptionType);

- (int)keyEncryptionType NS_SWIFT_NAME(keyEncryptionType());

@property (nonatomic,readonly,assign,getter=keyInfoItemCount) int keyInfoItemCount NS_SWIFT_NAME(keyInfoItemCount);

- (int)keyInfoItemCount NS_SWIFT_NAME(keyInfoItemCount());

- (NSString*)keyInfoItemIssuerRDN:(int)keyInfoItemIndex NS_SWIFT_NAME(keyInfoItemIssuerRDN(_:));

- (NSData*)keyInfoItemSerialNumber:(int)keyInfoItemIndex NS_SWIFT_NAME(keyInfoItemSerialNumber(_:));

- (NSData*)keyInfoItemSubjectKeyID:(int)keyInfoItemIndex NS_SWIFT_NAME(keyInfoItemSubjectKeyID(_:));

- (NSString*)keyInfoItemSubjectRDN:(int)keyInfoItemIndex NS_SWIFT_NAME(keyInfoItemSubjectRDN(_:));

@property (nonatomic,readonly,assign,getter=keyInfoCertificateCount) int keyInfoCertificateCount NS_SWIFT_NAME(keyInfoCertificateCount);

- (int)keyInfoCertificateCount NS_SWIFT_NAME(keyInfoCertificateCount());

- (NSData*)keyInfoCertificateBytes:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateBytes(_:));

- (BOOL)keyInfoCertificateCA:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateCA(_:));

- (NSData*)keyInfoCertificateCAKeyID:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateCAKeyID(_:));

- (int)keyInfoCertificateCertType:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateCertType(_:));

- (NSString*)keyInfoCertificateCRLDistributionPoints:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateCRLDistributionPoints(_:));

- (NSString*)keyInfoCertificateCurve:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateCurve(_:));

- (NSString*)keyInfoCertificateFingerprint:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateFingerprint(_:));

- (NSString*)keyInfoCertificateFriendlyName:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateFriendlyName(_:));

- (long long)keyInfoCertificateHandle:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateHandle(_:));

- (NSString*)keyInfoCertificateHashAlgorithm:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateHashAlgorithm(_:));

- (NSString*)keyInfoCertificateIssuer:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateIssuer(_:));

- (NSString*)keyInfoCertificateIssuerRDN:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateIssuerRDN(_:));

- (NSString*)keyInfoCertificateKeyAlgorithm:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateKeyAlgorithm(_:));

- (int)keyInfoCertificateKeyBits:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateKeyBits(_:));

- (NSString*)keyInfoCertificateKeyFingerprint:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateKeyFingerprint(_:));

- (int)keyInfoCertificateKeyUsage:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateKeyUsage(_:));

- (BOOL)keyInfoCertificateKeyValid:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateKeyValid(_:));

- (NSString*)keyInfoCertificateOCSPLocations:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateOCSPLocations(_:));

- (BOOL)keyInfoCertificateOCSPNoCheck:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateOCSPNoCheck(_:));

- (int)keyInfoCertificateOrigin:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateOrigin(_:));

- (NSString*)keyInfoCertificatePolicyIDs:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificatePolicyIDs(_:));

- (NSData*)keyInfoCertificatePrivateKeyBytes:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificatePrivateKeyBytes(_:));

- (BOOL)keyInfoCertificatePrivateKeyExists:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificatePrivateKeyExists(_:));

- (BOOL)keyInfoCertificatePrivateKeyExtractable:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificatePrivateKeyExtractable(_:));

- (NSData*)keyInfoCertificatePublicKeyBytes:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificatePublicKeyBytes(_:));

- (BOOL)keyInfoCertificateQualified:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateQualified(_:));

- (int)keyInfoCertificateQualifiedStatements:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateQualifiedStatements(_:));

- (NSString*)keyInfoCertificateQualifiers:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateQualifiers(_:));

- (BOOL)keyInfoCertificateSelfSigned:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateSelfSigned(_:));

- (NSData*)keyInfoCertificateSerialNumber:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateSerialNumber(_:));

- (NSString*)keyInfoCertificateSigAlgorithm:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateSigAlgorithm(_:));

- (int)keyInfoCertificateSource:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateSource(_:));

- (NSString*)keyInfoCertificateSubject:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateSubject(_:));

- (NSString*)keyInfoCertificateSubjectAlternativeName:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateSubjectAlternativeName(_:));

- (NSData*)keyInfoCertificateSubjectKeyID:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateSubjectKeyID(_:));

- (NSString*)keyInfoCertificateSubjectRDN:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateSubjectRDN(_:));

- (BOOL)keyInfoCertificateValid:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateValid(_:));

- (NSString*)keyInfoCertificateValidFrom:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateValidFrom(_:));

- (NSString*)keyInfoCertificateValidTo:(int)keyInfoCertificateIndex NS_SWIFT_NAME(keyInfoCertificateValidTo(_:));

@property (nonatomic,readonly,assign,getter=keyTransportMethod) int keyTransportMethod NS_SWIFT_NAME(keyTransportMethod);

- (int)keyTransportMethod NS_SWIFT_NAME(keyTransportMethod());

@property (nonatomic,readonly,assign,getter=keyWrapMethod) NSString* keyWrapMethod NS_SWIFT_NAME(keyWrapMethod);

- (NSString*)keyWrapMethod NS_SWIFT_NAME(keyWrapMethod());

@property (nonatomic,readonly,assign,getter=outputBytes) NSData* outputBytes NS_SWIFT_NAME(outputBytes);

- (NSData*)outputBytes NS_SWIFT_NAME(outputBytes());

@property (nonatomic,readwrite,assign,getter=outputFile,setter=setOutputFile:) NSString* outputFile NS_SWIFT_NAME(outputFile);

- (NSString*)outputFile NS_SWIFT_NAME(outputFile());
- (void)setOutputFile :(NSString*)newOutputFile NS_SWIFT_NAME(setOutputFile(_:));

@property (nonatomic,readonly,assign,getter=useGCM) BOOL useGCM NS_SWIFT_NAME(useGCM);

- (BOOL)useGCM NS_SWIFT_NAME(useGCM());

@property (nonatomic,readwrite,assign,getter=XMLElement,setter=setXMLElement:) NSString* XMLElement NS_SWIFT_NAME(XMLElement);

- (NSString*)XMLElement NS_SWIFT_NAME(XMLElement());
- (void)setXMLElement :(NSString*)newXMLElement NS_SWIFT_NAME(setXMLElement(_:));

  /* Methods */

- (void)addKnownNamespace:(NSString*)prefix :(NSString*)URI NS_SWIFT_NAME(addKnownNamespace(_:_:));

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (void)decrypt NS_SWIFT_NAME(decrypt());

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (void)reset NS_SWIFT_NAME(reset());

@end

