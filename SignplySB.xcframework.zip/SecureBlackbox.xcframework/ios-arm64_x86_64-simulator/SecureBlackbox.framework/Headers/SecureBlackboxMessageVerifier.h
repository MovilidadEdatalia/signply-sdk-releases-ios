/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

//MESSAGESIGNATURETYPES
#define ST_UNKNOWN                                         0

#define ST_PKCS1DETACHED                                   1

#define ST_PKCS7DETACHED                                   2

#define ST_PKCS7ENVELOPING                                 3

#define ST_PKCS7MACDETACHED                                4

#define ST_PKCS7MACENVELOPING                              5

//SIGNATUREVALIDITIES
#define SVT_VALID                                          0

#define SVT_UNKNOWN                                        1

#define SVT_CORRUPTED                                      2

#define SVT_SIGNER_NOT_FOUND                               3

#define SVT_FAILURE                                        4

#define SVT_REFERENCE_CORRUPTED                            5

//CHAINVALIDITIES
#define CVT_VALID                                          0

#define CVT_VALID_BUT_UNTRUSTED                            1

#define CVT_INVALID                                        2

#define CVT_CANT_BE_ESTABLISHED                            3

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxMessageVerifierDelegate <NSObject>
@optional
- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onRecipientFound:(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(BOOL)certFound NS_SWIFT_NAME(onRecipientFound(_:_:_:_:));

- (void)onSignatureFound:(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(BOOL)certFound :(int*)validateSignature :(int*)validateChain NS_SWIFT_NAME(onSignatureFound(_:_:_:_:_:_:));

- (void)onSignatureValidated:(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(int)validationResult NS_SWIFT_NAME(onSignatureValidated(_:_:_:_:));

- (void)onTimestampFound:(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(BOOL)certFound :(int*)validateTimestamp :(int*)validateChain NS_SWIFT_NAME(onTimestampFound(_:_:_:_:_:_:));

- (void)onTimestampValidated:(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(NSString*)time :(int)validationResult :(int)chainValidationResult :(int)chainValidationDetails NS_SWIFT_NAME(onTimestampValidated(_:_:_:_:_:_:_:));

@end

@interface SecureBlackboxMessageVerifier : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxMessageVerifierDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasError;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasRecipientFound;

  BOOL m_delegateHasSignatureFound;

  BOOL m_delegateHasSignatureValidated;

  BOOL m_delegateHasTimestampFound;

  BOOL m_delegateHasTimestampValidated;

}

+ (SecureBlackboxMessageVerifier*)messageverifier;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxMessageVerifierDelegate> delegate;
- (id <SecureBlackboxMessageVerifierDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxMessageVerifierDelegate>)anObject;

  /* Events */

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onRecipientFound:(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(BOOL)certFound NS_SWIFT_NAME(onRecipientFound(_:_:_:_:));

- (void)onSignatureFound:(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(BOOL)certFound :(int*)validateSignature :(int*)validateChain NS_SWIFT_NAME(onSignatureFound(_:_:_:_:_:_:));

- (void)onSignatureValidated:(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(int)validationResult NS_SWIFT_NAME(onSignatureValidated(_:_:_:_:));

- (void)onTimestampFound:(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(BOOL)certFound :(int*)validateTimestamp :(int*)validateChain NS_SWIFT_NAME(onTimestampFound(_:_:_:_:_:_:));

- (void)onTimestampValidated:(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(NSString*)time :(int)validationResult :(int)chainValidationResult :(int)chainValidationDetails NS_SWIFT_NAME(onTimestampValidated(_:_:_:_:_:_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readonly,assign,getter=certCount) int certCount NS_SWIFT_NAME(certCount);

- (int)certCount NS_SWIFT_NAME(certCount());

- (NSData*)certBytes:(int)certIndex NS_SWIFT_NAME(certBytes(_:));

- (BOOL)certCA:(int)certIndex NS_SWIFT_NAME(certCA(_:));

- (NSData*)certCAKeyID:(int)certIndex NS_SWIFT_NAME(certCAKeyID(_:));

- (int)certCertType:(int)certIndex NS_SWIFT_NAME(certCertType(_:));

- (NSString*)certCRLDistributionPoints:(int)certIndex NS_SWIFT_NAME(certCRLDistributionPoints(_:));

- (NSString*)certCurve:(int)certIndex NS_SWIFT_NAME(certCurve(_:));

- (NSString*)certFingerprint:(int)certIndex NS_SWIFT_NAME(certFingerprint(_:));

- (NSString*)certFriendlyName:(int)certIndex NS_SWIFT_NAME(certFriendlyName(_:));

- (long long)certHandle:(int)certIndex NS_SWIFT_NAME(certHandle(_:));

- (NSString*)certHashAlgorithm:(int)certIndex NS_SWIFT_NAME(certHashAlgorithm(_:));

- (NSString*)certIssuer:(int)certIndex NS_SWIFT_NAME(certIssuer(_:));

- (NSString*)certIssuerRDN:(int)certIndex NS_SWIFT_NAME(certIssuerRDN(_:));

- (NSString*)certKeyAlgorithm:(int)certIndex NS_SWIFT_NAME(certKeyAlgorithm(_:));

- (int)certKeyBits:(int)certIndex NS_SWIFT_NAME(certKeyBits(_:));

- (NSString*)certKeyFingerprint:(int)certIndex NS_SWIFT_NAME(certKeyFingerprint(_:));

- (int)certKeyUsage:(int)certIndex NS_SWIFT_NAME(certKeyUsage(_:));

- (BOOL)certKeyValid:(int)certIndex NS_SWIFT_NAME(certKeyValid(_:));

- (NSString*)certOCSPLocations:(int)certIndex NS_SWIFT_NAME(certOCSPLocations(_:));

- (BOOL)certOCSPNoCheck:(int)certIndex NS_SWIFT_NAME(certOCSPNoCheck(_:));

- (int)certOrigin:(int)certIndex NS_SWIFT_NAME(certOrigin(_:));

- (NSString*)certPolicyIDs:(int)certIndex NS_SWIFT_NAME(certPolicyIDs(_:));

- (NSData*)certPrivateKeyBytes:(int)certIndex NS_SWIFT_NAME(certPrivateKeyBytes(_:));

- (BOOL)certPrivateKeyExists:(int)certIndex NS_SWIFT_NAME(certPrivateKeyExists(_:));

- (BOOL)certPrivateKeyExtractable:(int)certIndex NS_SWIFT_NAME(certPrivateKeyExtractable(_:));

- (NSData*)certPublicKeyBytes:(int)certIndex NS_SWIFT_NAME(certPublicKeyBytes(_:));

- (BOOL)certQualified:(int)certIndex NS_SWIFT_NAME(certQualified(_:));

- (int)certQualifiedStatements:(int)certIndex NS_SWIFT_NAME(certQualifiedStatements(_:));

- (NSString*)certQualifiers:(int)certIndex NS_SWIFT_NAME(certQualifiers(_:));

- (BOOL)certSelfSigned:(int)certIndex NS_SWIFT_NAME(certSelfSigned(_:));

- (NSData*)certSerialNumber:(int)certIndex NS_SWIFT_NAME(certSerialNumber(_:));

- (NSString*)certSigAlgorithm:(int)certIndex NS_SWIFT_NAME(certSigAlgorithm(_:));

- (int)certSource:(int)certIndex NS_SWIFT_NAME(certSource(_:));

- (NSString*)certSubject:(int)certIndex NS_SWIFT_NAME(certSubject(_:));

- (NSString*)certSubjectAlternativeName:(int)certIndex NS_SWIFT_NAME(certSubjectAlternativeName(_:));

- (NSData*)certSubjectKeyID:(int)certIndex NS_SWIFT_NAME(certSubjectKeyID(_:));

- (NSString*)certSubjectRDN:(int)certIndex NS_SWIFT_NAME(certSubjectRDN(_:));

- (BOOL)certValid:(int)certIndex NS_SWIFT_NAME(certValid(_:));

- (NSString*)certValidFrom:(int)certIndex NS_SWIFT_NAME(certValidFrom(_:));

- (NSString*)certValidTo:(int)certIndex NS_SWIFT_NAME(certValidTo(_:));

@property (nonatomic,readonly,assign,getter=claimedSigningTime) NSString* claimedSigningTime NS_SWIFT_NAME(claimedSigningTime);

- (NSString*)claimedSigningTime NS_SWIFT_NAME(claimedSigningTime());

@property (nonatomic,readonly,assign,getter=contentType) NSString* contentType NS_SWIFT_NAME(contentType);

- (NSString*)contentType NS_SWIFT_NAME(contentType());

@property (nonatomic,readwrite,assign,getter=dataBytes,setter=setDataBytes:) NSData* dataBytes NS_SWIFT_NAME(dataBytes);

- (NSData*)dataBytes NS_SWIFT_NAME(dataBytes());
- (void)setDataBytes :(NSData*)newDataBytes NS_SWIFT_NAME(setDataBytes(_:));

@property (nonatomic,readwrite,assign,getter=dataFile,setter=setDataFile:) NSString* dataFile NS_SWIFT_NAME(dataFile);

- (NSString*)dataFile NS_SWIFT_NAME(dataFile());
- (void)setDataFile :(NSString*)newDataFile NS_SWIFT_NAME(setDataFile(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=hashAlgorithm,setter=setHashAlgorithm:) NSString* hashAlgorithm NS_SWIFT_NAME(hashAlgorithm);

- (NSString*)hashAlgorithm NS_SWIFT_NAME(hashAlgorithm());
- (void)setHashAlgorithm :(NSString*)newHashAlgorithm NS_SWIFT_NAME(setHashAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=inputBytes,setter=setInputBytes:) NSData* inputBytes NS_SWIFT_NAME(inputBytes);

- (NSData*)inputBytes NS_SWIFT_NAME(inputBytes());
- (void)setInputBytes :(NSData*)newInputBytes NS_SWIFT_NAME(setInputBytes(_:));

@property (nonatomic,readwrite,assign,getter=inputFile,setter=setInputFile:) NSString* inputFile NS_SWIFT_NAME(inputFile);

- (NSString*)inputFile NS_SWIFT_NAME(inputFile());
- (void)setInputFile :(NSString*)newInputFile NS_SWIFT_NAME(setInputFile(_:));

@property (nonatomic,readwrite,assign,getter=inputIsHash,setter=setInputIsHash:) BOOL inputIsHash NS_SWIFT_NAME(inputIsHash);

- (BOOL)inputIsHash NS_SWIFT_NAME(inputIsHash());
- (void)setInputIsHash :(BOOL)newInputIsHash NS_SWIFT_NAME(setInputIsHash(_:));

@property (nonatomic,readwrite,assign,getter=knownCertCount,setter=setKnownCertCount:) int knownCertCount NS_SWIFT_NAME(knownCertCount);

- (int)knownCertCount NS_SWIFT_NAME(knownCertCount());
- (void)setKnownCertCount :(int)newKnownCertCount NS_SWIFT_NAME(setKnownCertCount(_:));

- (NSData*)knownCertBytes:(int)knownCertIndex NS_SWIFT_NAME(knownCertBytes(_:));

- (BOOL)knownCertCA:(int)knownCertIndex NS_SWIFT_NAME(knownCertCA(_:));
- (void)setKnownCertCA:(int)knownCertIndex :(BOOL)newKnownCertCA NS_SWIFT_NAME(setKnownCertCA(_:_:));

- (NSData*)knownCertCAKeyID:(int)knownCertIndex NS_SWIFT_NAME(knownCertCAKeyID(_:));

- (int)knownCertCertType:(int)knownCertIndex NS_SWIFT_NAME(knownCertCertType(_:));

- (NSString*)knownCertCRLDistributionPoints:(int)knownCertIndex NS_SWIFT_NAME(knownCertCRLDistributionPoints(_:));
- (void)setKnownCertCRLDistributionPoints:(int)knownCertIndex :(NSString*)newKnownCertCRLDistributionPoints NS_SWIFT_NAME(setKnownCertCRLDistributionPoints(_:_:));

- (NSString*)knownCertCurve:(int)knownCertIndex NS_SWIFT_NAME(knownCertCurve(_:));
- (void)setKnownCertCurve:(int)knownCertIndex :(NSString*)newKnownCertCurve NS_SWIFT_NAME(setKnownCertCurve(_:_:));

- (NSString*)knownCertFingerprint:(int)knownCertIndex NS_SWIFT_NAME(knownCertFingerprint(_:));

- (NSString*)knownCertFriendlyName:(int)knownCertIndex NS_SWIFT_NAME(knownCertFriendlyName(_:));

- (long long)knownCertHandle:(int)knownCertIndex NS_SWIFT_NAME(knownCertHandle(_:));
- (void)setKnownCertHandle:(int)knownCertIndex :(long long)newKnownCertHandle NS_SWIFT_NAME(setKnownCertHandle(_:_:));

- (NSString*)knownCertHashAlgorithm:(int)knownCertIndex NS_SWIFT_NAME(knownCertHashAlgorithm(_:));
- (void)setKnownCertHashAlgorithm:(int)knownCertIndex :(NSString*)newKnownCertHashAlgorithm NS_SWIFT_NAME(setKnownCertHashAlgorithm(_:_:));

- (NSString*)knownCertIssuer:(int)knownCertIndex NS_SWIFT_NAME(knownCertIssuer(_:));

- (NSString*)knownCertIssuerRDN:(int)knownCertIndex NS_SWIFT_NAME(knownCertIssuerRDN(_:));
- (void)setKnownCertIssuerRDN:(int)knownCertIndex :(NSString*)newKnownCertIssuerRDN NS_SWIFT_NAME(setKnownCertIssuerRDN(_:_:));

- (NSString*)knownCertKeyAlgorithm:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyAlgorithm(_:));
- (void)setKnownCertKeyAlgorithm:(int)knownCertIndex :(NSString*)newKnownCertKeyAlgorithm NS_SWIFT_NAME(setKnownCertKeyAlgorithm(_:_:));

- (int)knownCertKeyBits:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyBits(_:));

- (NSString*)knownCertKeyFingerprint:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyFingerprint(_:));

- (int)knownCertKeyUsage:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyUsage(_:));
- (void)setKnownCertKeyUsage:(int)knownCertIndex :(int)newKnownCertKeyUsage NS_SWIFT_NAME(setKnownCertKeyUsage(_:_:));

- (BOOL)knownCertKeyValid:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyValid(_:));

- (NSString*)knownCertOCSPLocations:(int)knownCertIndex NS_SWIFT_NAME(knownCertOCSPLocations(_:));
- (void)setKnownCertOCSPLocations:(int)knownCertIndex :(NSString*)newKnownCertOCSPLocations NS_SWIFT_NAME(setKnownCertOCSPLocations(_:_:));

- (BOOL)knownCertOCSPNoCheck:(int)knownCertIndex NS_SWIFT_NAME(knownCertOCSPNoCheck(_:));
- (void)setKnownCertOCSPNoCheck:(int)knownCertIndex :(BOOL)newKnownCertOCSPNoCheck NS_SWIFT_NAME(setKnownCertOCSPNoCheck(_:_:));

- (int)knownCertOrigin:(int)knownCertIndex NS_SWIFT_NAME(knownCertOrigin(_:));

- (NSString*)knownCertPolicyIDs:(int)knownCertIndex NS_SWIFT_NAME(knownCertPolicyIDs(_:));
- (void)setKnownCertPolicyIDs:(int)knownCertIndex :(NSString*)newKnownCertPolicyIDs NS_SWIFT_NAME(setKnownCertPolicyIDs(_:_:));

- (NSData*)knownCertPrivateKeyBytes:(int)knownCertIndex NS_SWIFT_NAME(knownCertPrivateKeyBytes(_:));

- (BOOL)knownCertPrivateKeyExists:(int)knownCertIndex NS_SWIFT_NAME(knownCertPrivateKeyExists(_:));

- (BOOL)knownCertPrivateKeyExtractable:(int)knownCertIndex NS_SWIFT_NAME(knownCertPrivateKeyExtractable(_:));

- (NSData*)knownCertPublicKeyBytes:(int)knownCertIndex NS_SWIFT_NAME(knownCertPublicKeyBytes(_:));

- (BOOL)knownCertQualified:(int)knownCertIndex NS_SWIFT_NAME(knownCertQualified(_:));

- (int)knownCertQualifiedStatements:(int)knownCertIndex NS_SWIFT_NAME(knownCertQualifiedStatements(_:));
- (void)setKnownCertQualifiedStatements:(int)knownCertIndex :(int)newKnownCertQualifiedStatements NS_SWIFT_NAME(setKnownCertQualifiedStatements(_:_:));

- (NSString*)knownCertQualifiers:(int)knownCertIndex NS_SWIFT_NAME(knownCertQualifiers(_:));

- (BOOL)knownCertSelfSigned:(int)knownCertIndex NS_SWIFT_NAME(knownCertSelfSigned(_:));

- (NSData*)knownCertSerialNumber:(int)knownCertIndex NS_SWIFT_NAME(knownCertSerialNumber(_:));
- (void)setKnownCertSerialNumber:(int)knownCertIndex :(NSData*)newKnownCertSerialNumber NS_SWIFT_NAME(setKnownCertSerialNumber(_:_:));

- (NSString*)knownCertSigAlgorithm:(int)knownCertIndex NS_SWIFT_NAME(knownCertSigAlgorithm(_:));

- (int)knownCertSource:(int)knownCertIndex NS_SWIFT_NAME(knownCertSource(_:));

- (NSString*)knownCertSubject:(int)knownCertIndex NS_SWIFT_NAME(knownCertSubject(_:));

- (NSString*)knownCertSubjectAlternativeName:(int)knownCertIndex NS_SWIFT_NAME(knownCertSubjectAlternativeName(_:));
- (void)setKnownCertSubjectAlternativeName:(int)knownCertIndex :(NSString*)newKnownCertSubjectAlternativeName NS_SWIFT_NAME(setKnownCertSubjectAlternativeName(_:_:));

- (NSData*)knownCertSubjectKeyID:(int)knownCertIndex NS_SWIFT_NAME(knownCertSubjectKeyID(_:));
- (void)setKnownCertSubjectKeyID:(int)knownCertIndex :(NSData*)newKnownCertSubjectKeyID NS_SWIFT_NAME(setKnownCertSubjectKeyID(_:_:));

- (NSString*)knownCertSubjectRDN:(int)knownCertIndex NS_SWIFT_NAME(knownCertSubjectRDN(_:));
- (void)setKnownCertSubjectRDN:(int)knownCertIndex :(NSString*)newKnownCertSubjectRDN NS_SWIFT_NAME(setKnownCertSubjectRDN(_:_:));

- (BOOL)knownCertValid:(int)knownCertIndex NS_SWIFT_NAME(knownCertValid(_:));

- (NSString*)knownCertValidFrom:(int)knownCertIndex NS_SWIFT_NAME(knownCertValidFrom(_:));
- (void)setKnownCertValidFrom:(int)knownCertIndex :(NSString*)newKnownCertValidFrom NS_SWIFT_NAME(setKnownCertValidFrom(_:_:));

- (NSString*)knownCertValidTo:(int)knownCertIndex NS_SWIFT_NAME(knownCertValidTo(_:));
- (void)setKnownCertValidTo:(int)knownCertIndex :(NSString*)newKnownCertValidTo NS_SWIFT_NAME(setKnownCertValidTo(_:_:));

@property (nonatomic,readonly,assign,getter=MACAlgorithm) NSString* MACAlgorithm NS_SWIFT_NAME(MACAlgorithm);

- (NSString*)MACAlgorithm NS_SWIFT_NAME(MACAlgorithm());

@property (nonatomic,readonly,assign,getter=outputBytes) NSData* outputBytes NS_SWIFT_NAME(outputBytes);

- (NSData*)outputBytes NS_SWIFT_NAME(outputBytes());

@property (nonatomic,readwrite,assign,getter=outputFile,setter=setOutputFile:) NSString* outputFile NS_SWIFT_NAME(outputFile);

- (NSString*)outputFile NS_SWIFT_NAME(outputFile());
- (void)setOutputFile :(NSString*)newOutputFile NS_SWIFT_NAME(setOutputFile(_:));

@property (nonatomic,readonly,assign,getter=signatureType) int signatureType NS_SWIFT_NAME(signatureType);

- (int)signatureType NS_SWIFT_NAME(signatureType());

@property (nonatomic,readonly,assign,getter=signatureValidationResult) int signatureValidationResult NS_SWIFT_NAME(signatureValidationResult);

- (int)signatureValidationResult NS_SWIFT_NAME(signatureValidationResult());

@property (nonatomic,readonly,assign,getter=signedAttributeCount) int signedAttributeCount NS_SWIFT_NAME(signedAttributeCount);

- (int)signedAttributeCount NS_SWIFT_NAME(signedAttributeCount());

- (NSString*)signedAttributeOID:(int)signedAttributeIndex NS_SWIFT_NAME(signedAttributeOID(_:));

- (NSData*)signedAttributeValue:(int)signedAttributeIndex NS_SWIFT_NAME(signedAttributeValue(_:));

@property (nonatomic,readonly,assign,getter=signingCertBytes) NSData* signingCertBytes NS_SWIFT_NAME(signingCertBytes);

- (NSData*)signingCertBytes NS_SWIFT_NAME(signingCertBytes());

@property (nonatomic,readonly,assign,getter=signingCertCA) BOOL signingCertCA NS_SWIFT_NAME(signingCertCA);

- (BOOL)signingCertCA NS_SWIFT_NAME(signingCertCA());

@property (nonatomic,readonly,assign,getter=signingCertCAKeyID) NSData* signingCertCAKeyID NS_SWIFT_NAME(signingCertCAKeyID);

- (NSData*)signingCertCAKeyID NS_SWIFT_NAME(signingCertCAKeyID());

@property (nonatomic,readonly,assign,getter=signingCertCertType) int signingCertCertType NS_SWIFT_NAME(signingCertCertType);

- (int)signingCertCertType NS_SWIFT_NAME(signingCertCertType());

@property (nonatomic,readonly,assign,getter=signingCertCRLDistributionPoints) NSString* signingCertCRLDistributionPoints NS_SWIFT_NAME(signingCertCRLDistributionPoints);

- (NSString*)signingCertCRLDistributionPoints NS_SWIFT_NAME(signingCertCRLDistributionPoints());

@property (nonatomic,readonly,assign,getter=signingCertCurve) NSString* signingCertCurve NS_SWIFT_NAME(signingCertCurve);

- (NSString*)signingCertCurve NS_SWIFT_NAME(signingCertCurve());

@property (nonatomic,readonly,assign,getter=signingCertFingerprint) NSString* signingCertFingerprint NS_SWIFT_NAME(signingCertFingerprint);

- (NSString*)signingCertFingerprint NS_SWIFT_NAME(signingCertFingerprint());

@property (nonatomic,readonly,assign,getter=signingCertFriendlyName) NSString* signingCertFriendlyName NS_SWIFT_NAME(signingCertFriendlyName);

- (NSString*)signingCertFriendlyName NS_SWIFT_NAME(signingCertFriendlyName());

@property (nonatomic,readonly,assign,getter=signingCertHandle) long long signingCertHandle NS_SWIFT_NAME(signingCertHandle);

- (long long)signingCertHandle NS_SWIFT_NAME(signingCertHandle());

@property (nonatomic,readonly,assign,getter=signingCertHashAlgorithm) NSString* signingCertHashAlgorithm NS_SWIFT_NAME(signingCertHashAlgorithm);

- (NSString*)signingCertHashAlgorithm NS_SWIFT_NAME(signingCertHashAlgorithm());

@property (nonatomic,readonly,assign,getter=signingCertIssuer) NSString* signingCertIssuer NS_SWIFT_NAME(signingCertIssuer);

- (NSString*)signingCertIssuer NS_SWIFT_NAME(signingCertIssuer());

@property (nonatomic,readonly,assign,getter=signingCertIssuerRDN) NSString* signingCertIssuerRDN NS_SWIFT_NAME(signingCertIssuerRDN);

- (NSString*)signingCertIssuerRDN NS_SWIFT_NAME(signingCertIssuerRDN());

@property (nonatomic,readonly,assign,getter=signingCertKeyAlgorithm) NSString* signingCertKeyAlgorithm NS_SWIFT_NAME(signingCertKeyAlgorithm);

- (NSString*)signingCertKeyAlgorithm NS_SWIFT_NAME(signingCertKeyAlgorithm());

@property (nonatomic,readonly,assign,getter=signingCertKeyBits) int signingCertKeyBits NS_SWIFT_NAME(signingCertKeyBits);

- (int)signingCertKeyBits NS_SWIFT_NAME(signingCertKeyBits());

@property (nonatomic,readonly,assign,getter=signingCertKeyFingerprint) NSString* signingCertKeyFingerprint NS_SWIFT_NAME(signingCertKeyFingerprint);

- (NSString*)signingCertKeyFingerprint NS_SWIFT_NAME(signingCertKeyFingerprint());

@property (nonatomic,readonly,assign,getter=signingCertKeyUsage) int signingCertKeyUsage NS_SWIFT_NAME(signingCertKeyUsage);

- (int)signingCertKeyUsage NS_SWIFT_NAME(signingCertKeyUsage());

@property (nonatomic,readonly,assign,getter=signingCertKeyValid) BOOL signingCertKeyValid NS_SWIFT_NAME(signingCertKeyValid);

- (BOOL)signingCertKeyValid NS_SWIFT_NAME(signingCertKeyValid());

@property (nonatomic,readonly,assign,getter=signingCertOCSPLocations) NSString* signingCertOCSPLocations NS_SWIFT_NAME(signingCertOCSPLocations);

- (NSString*)signingCertOCSPLocations NS_SWIFT_NAME(signingCertOCSPLocations());

@property (nonatomic,readonly,assign,getter=signingCertOCSPNoCheck) BOOL signingCertOCSPNoCheck NS_SWIFT_NAME(signingCertOCSPNoCheck);

- (BOOL)signingCertOCSPNoCheck NS_SWIFT_NAME(signingCertOCSPNoCheck());

@property (nonatomic,readonly,assign,getter=signingCertOrigin) int signingCertOrigin NS_SWIFT_NAME(signingCertOrigin);

- (int)signingCertOrigin NS_SWIFT_NAME(signingCertOrigin());

@property (nonatomic,readonly,assign,getter=signingCertPolicyIDs) NSString* signingCertPolicyIDs NS_SWIFT_NAME(signingCertPolicyIDs);

- (NSString*)signingCertPolicyIDs NS_SWIFT_NAME(signingCertPolicyIDs());

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyBytes) NSData* signingCertPrivateKeyBytes NS_SWIFT_NAME(signingCertPrivateKeyBytes);

- (NSData*)signingCertPrivateKeyBytes NS_SWIFT_NAME(signingCertPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyExists) BOOL signingCertPrivateKeyExists NS_SWIFT_NAME(signingCertPrivateKeyExists);

- (BOOL)signingCertPrivateKeyExists NS_SWIFT_NAME(signingCertPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyExtractable) BOOL signingCertPrivateKeyExtractable NS_SWIFT_NAME(signingCertPrivateKeyExtractable);

- (BOOL)signingCertPrivateKeyExtractable NS_SWIFT_NAME(signingCertPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=signingCertPublicKeyBytes) NSData* signingCertPublicKeyBytes NS_SWIFT_NAME(signingCertPublicKeyBytes);

- (NSData*)signingCertPublicKeyBytes NS_SWIFT_NAME(signingCertPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=signingCertQualified) BOOL signingCertQualified NS_SWIFT_NAME(signingCertQualified);

- (BOOL)signingCertQualified NS_SWIFT_NAME(signingCertQualified());

@property (nonatomic,readonly,assign,getter=signingCertQualifiedStatements) int signingCertQualifiedStatements NS_SWIFT_NAME(signingCertQualifiedStatements);

- (int)signingCertQualifiedStatements NS_SWIFT_NAME(signingCertQualifiedStatements());

@property (nonatomic,readonly,assign,getter=signingCertQualifiers) NSString* signingCertQualifiers NS_SWIFT_NAME(signingCertQualifiers);

- (NSString*)signingCertQualifiers NS_SWIFT_NAME(signingCertQualifiers());

@property (nonatomic,readonly,assign,getter=signingCertSelfSigned) BOOL signingCertSelfSigned NS_SWIFT_NAME(signingCertSelfSigned);

- (BOOL)signingCertSelfSigned NS_SWIFT_NAME(signingCertSelfSigned());

@property (nonatomic,readonly,assign,getter=signingCertSerialNumber) NSData* signingCertSerialNumber NS_SWIFT_NAME(signingCertSerialNumber);

- (NSData*)signingCertSerialNumber NS_SWIFT_NAME(signingCertSerialNumber());

@property (nonatomic,readonly,assign,getter=signingCertSigAlgorithm) NSString* signingCertSigAlgorithm NS_SWIFT_NAME(signingCertSigAlgorithm);

- (NSString*)signingCertSigAlgorithm NS_SWIFT_NAME(signingCertSigAlgorithm());

@property (nonatomic,readonly,assign,getter=signingCertSource) int signingCertSource NS_SWIFT_NAME(signingCertSource);

- (int)signingCertSource NS_SWIFT_NAME(signingCertSource());

@property (nonatomic,readonly,assign,getter=signingCertSubject) NSString* signingCertSubject NS_SWIFT_NAME(signingCertSubject);

- (NSString*)signingCertSubject NS_SWIFT_NAME(signingCertSubject());

@property (nonatomic,readonly,assign,getter=signingCertSubjectAlternativeName) NSString* signingCertSubjectAlternativeName NS_SWIFT_NAME(signingCertSubjectAlternativeName);

- (NSString*)signingCertSubjectAlternativeName NS_SWIFT_NAME(signingCertSubjectAlternativeName());

@property (nonatomic,readonly,assign,getter=signingCertSubjectKeyID) NSData* signingCertSubjectKeyID NS_SWIFT_NAME(signingCertSubjectKeyID);

- (NSData*)signingCertSubjectKeyID NS_SWIFT_NAME(signingCertSubjectKeyID());

@property (nonatomic,readonly,assign,getter=signingCertSubjectRDN) NSString* signingCertSubjectRDN NS_SWIFT_NAME(signingCertSubjectRDN);

- (NSString*)signingCertSubjectRDN NS_SWIFT_NAME(signingCertSubjectRDN());

@property (nonatomic,readonly,assign,getter=signingCertValid) BOOL signingCertValid NS_SWIFT_NAME(signingCertValid);

- (BOOL)signingCertValid NS_SWIFT_NAME(signingCertValid());

@property (nonatomic,readonly,assign,getter=signingCertValidFrom) NSString* signingCertValidFrom NS_SWIFT_NAME(signingCertValidFrom);

- (NSString*)signingCertValidFrom NS_SWIFT_NAME(signingCertValidFrom());

@property (nonatomic,readonly,assign,getter=signingCertValidTo) NSString* signingCertValidTo NS_SWIFT_NAME(signingCertValidTo);

- (NSString*)signingCertValidTo NS_SWIFT_NAME(signingCertValidTo());

@property (nonatomic,readonly,assign,getter=timestampAccuracy) long long timestampAccuracy NS_SWIFT_NAME(timestampAccuracy);

- (long long)timestampAccuracy NS_SWIFT_NAME(timestampAccuracy());

@property (nonatomic,readonly,assign,getter=timestampBytes) NSData* timestampBytes NS_SWIFT_NAME(timestampBytes);

- (NSData*)timestampBytes NS_SWIFT_NAME(timestampBytes());

@property (nonatomic,readonly,assign,getter=timestampCertificateIndex) int timestampCertificateIndex NS_SWIFT_NAME(timestampCertificateIndex);

- (int)timestampCertificateIndex NS_SWIFT_NAME(timestampCertificateIndex());

@property (nonatomic,readonly,assign,getter=timestampChainValidationDetails) int timestampChainValidationDetails NS_SWIFT_NAME(timestampChainValidationDetails);

- (int)timestampChainValidationDetails NS_SWIFT_NAME(timestampChainValidationDetails());

@property (nonatomic,readonly,assign,getter=timestampChainValidationResult) int timestampChainValidationResult NS_SWIFT_NAME(timestampChainValidationResult);

- (int)timestampChainValidationResult NS_SWIFT_NAME(timestampChainValidationResult());

@property (nonatomic,readonly,assign,getter=timestampContainsLongTermInfo) BOOL timestampContainsLongTermInfo NS_SWIFT_NAME(timestampContainsLongTermInfo);

- (BOOL)timestampContainsLongTermInfo NS_SWIFT_NAME(timestampContainsLongTermInfo());

@property (nonatomic,readonly,assign,getter=timestampEntityLabel) NSString* timestampEntityLabel NS_SWIFT_NAME(timestampEntityLabel);

- (NSString*)timestampEntityLabel NS_SWIFT_NAME(timestampEntityLabel());

@property (nonatomic,readonly,assign,getter=timestampHashAlgorithm) NSString* timestampHashAlgorithm NS_SWIFT_NAME(timestampHashAlgorithm);

- (NSString*)timestampHashAlgorithm NS_SWIFT_NAME(timestampHashAlgorithm());

@property (nonatomic,readonly,assign,getter=timestampParentEntity) NSString* timestampParentEntity NS_SWIFT_NAME(timestampParentEntity);

- (NSString*)timestampParentEntity NS_SWIFT_NAME(timestampParentEntity());

@property (nonatomic,readonly,assign,getter=timestampSerialNumber) NSData* timestampSerialNumber NS_SWIFT_NAME(timestampSerialNumber);

- (NSData*)timestampSerialNumber NS_SWIFT_NAME(timestampSerialNumber());

@property (nonatomic,readonly,assign,getter=timestampTime) NSString* timestampTime NS_SWIFT_NAME(timestampTime);

- (NSString*)timestampTime NS_SWIFT_NAME(timestampTime());

@property (nonatomic,readonly,assign,getter=timestampTimestampType) int timestampTimestampType NS_SWIFT_NAME(timestampTimestampType);

- (int)timestampTimestampType NS_SWIFT_NAME(timestampTimestampType());

@property (nonatomic,readonly,assign,getter=timestampTSAName) NSString* timestampTSAName NS_SWIFT_NAME(timestampTSAName);

- (NSString*)timestampTSAName NS_SWIFT_NAME(timestampTSAName());

@property (nonatomic,readonly,assign,getter=timestampValidationLog) NSString* timestampValidationLog NS_SWIFT_NAME(timestampValidationLog);

- (NSString*)timestampValidationLog NS_SWIFT_NAME(timestampValidationLog());

@property (nonatomic,readonly,assign,getter=timestampValidationResult) int timestampValidationResult NS_SWIFT_NAME(timestampValidationResult);

- (int)timestampValidationResult NS_SWIFT_NAME(timestampValidationResult());

@property (nonatomic,readonly,assign,getter=timestamped) BOOL timestamped NS_SWIFT_NAME(timestamped);

- (BOOL)timestamped NS_SWIFT_NAME(timestamped());

@property (nonatomic,readonly,assign,getter=TSACertBytes) NSData* TSACertBytes NS_SWIFT_NAME(TSACertBytes);

- (NSData*)TSACertBytes NS_SWIFT_NAME(TSACertBytes());

@property (nonatomic,readonly,assign,getter=TSACertCA) BOOL TSACertCA NS_SWIFT_NAME(TSACertCA);

- (BOOL)TSACertCA NS_SWIFT_NAME(TSACertCA());

@property (nonatomic,readonly,assign,getter=TSACertCAKeyID) NSData* TSACertCAKeyID NS_SWIFT_NAME(TSACertCAKeyID);

- (NSData*)TSACertCAKeyID NS_SWIFT_NAME(TSACertCAKeyID());

@property (nonatomic,readonly,assign,getter=TSACertCertType) int TSACertCertType NS_SWIFT_NAME(TSACertCertType);

- (int)TSACertCertType NS_SWIFT_NAME(TSACertCertType());

@property (nonatomic,readonly,assign,getter=TSACertCRLDistributionPoints) NSString* TSACertCRLDistributionPoints NS_SWIFT_NAME(TSACertCRLDistributionPoints);

- (NSString*)TSACertCRLDistributionPoints NS_SWIFT_NAME(TSACertCRLDistributionPoints());

@property (nonatomic,readonly,assign,getter=TSACertCurve) NSString* TSACertCurve NS_SWIFT_NAME(TSACertCurve);

- (NSString*)TSACertCurve NS_SWIFT_NAME(TSACertCurve());

@property (nonatomic,readonly,assign,getter=TSACertFingerprint) NSString* TSACertFingerprint NS_SWIFT_NAME(TSACertFingerprint);

- (NSString*)TSACertFingerprint NS_SWIFT_NAME(TSACertFingerprint());

@property (nonatomic,readonly,assign,getter=TSACertFriendlyName) NSString* TSACertFriendlyName NS_SWIFT_NAME(TSACertFriendlyName);

- (NSString*)TSACertFriendlyName NS_SWIFT_NAME(TSACertFriendlyName());

@property (nonatomic,readonly,assign,getter=TSACertHandle) long long TSACertHandle NS_SWIFT_NAME(TSACertHandle);

- (long long)TSACertHandle NS_SWIFT_NAME(TSACertHandle());

@property (nonatomic,readonly,assign,getter=TSACertHashAlgorithm) NSString* TSACertHashAlgorithm NS_SWIFT_NAME(TSACertHashAlgorithm);

- (NSString*)TSACertHashAlgorithm NS_SWIFT_NAME(TSACertHashAlgorithm());

@property (nonatomic,readonly,assign,getter=TSACertIssuer) NSString* TSACertIssuer NS_SWIFT_NAME(TSACertIssuer);

- (NSString*)TSACertIssuer NS_SWIFT_NAME(TSACertIssuer());

@property (nonatomic,readonly,assign,getter=TSACertIssuerRDN) NSString* TSACertIssuerRDN NS_SWIFT_NAME(TSACertIssuerRDN);

- (NSString*)TSACertIssuerRDN NS_SWIFT_NAME(TSACertIssuerRDN());

@property (nonatomic,readonly,assign,getter=TSACertKeyAlgorithm) NSString* TSACertKeyAlgorithm NS_SWIFT_NAME(TSACertKeyAlgorithm);

- (NSString*)TSACertKeyAlgorithm NS_SWIFT_NAME(TSACertKeyAlgorithm());

@property (nonatomic,readonly,assign,getter=TSACertKeyBits) int TSACertKeyBits NS_SWIFT_NAME(TSACertKeyBits);

- (int)TSACertKeyBits NS_SWIFT_NAME(TSACertKeyBits());

@property (nonatomic,readonly,assign,getter=TSACertKeyFingerprint) NSString* TSACertKeyFingerprint NS_SWIFT_NAME(TSACertKeyFingerprint);

- (NSString*)TSACertKeyFingerprint NS_SWIFT_NAME(TSACertKeyFingerprint());

@property (nonatomic,readonly,assign,getter=TSACertKeyUsage) int TSACertKeyUsage NS_SWIFT_NAME(TSACertKeyUsage);

- (int)TSACertKeyUsage NS_SWIFT_NAME(TSACertKeyUsage());

@property (nonatomic,readonly,assign,getter=TSACertKeyValid) BOOL TSACertKeyValid NS_SWIFT_NAME(TSACertKeyValid);

- (BOOL)TSACertKeyValid NS_SWIFT_NAME(TSACertKeyValid());

@property (nonatomic,readonly,assign,getter=TSACertOCSPLocations) NSString* TSACertOCSPLocations NS_SWIFT_NAME(TSACertOCSPLocations);

- (NSString*)TSACertOCSPLocations NS_SWIFT_NAME(TSACertOCSPLocations());

@property (nonatomic,readonly,assign,getter=TSACertOCSPNoCheck) BOOL TSACertOCSPNoCheck NS_SWIFT_NAME(TSACertOCSPNoCheck);

- (BOOL)TSACertOCSPNoCheck NS_SWIFT_NAME(TSACertOCSPNoCheck());

@property (nonatomic,readonly,assign,getter=TSACertOrigin) int TSACertOrigin NS_SWIFT_NAME(TSACertOrigin);

- (int)TSACertOrigin NS_SWIFT_NAME(TSACertOrigin());

@property (nonatomic,readonly,assign,getter=TSACertPolicyIDs) NSString* TSACertPolicyIDs NS_SWIFT_NAME(TSACertPolicyIDs);

- (NSString*)TSACertPolicyIDs NS_SWIFT_NAME(TSACertPolicyIDs());

@property (nonatomic,readonly,assign,getter=TSACertPrivateKeyBytes) NSData* TSACertPrivateKeyBytes NS_SWIFT_NAME(TSACertPrivateKeyBytes);

- (NSData*)TSACertPrivateKeyBytes NS_SWIFT_NAME(TSACertPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=TSACertPrivateKeyExists) BOOL TSACertPrivateKeyExists NS_SWIFT_NAME(TSACertPrivateKeyExists);

- (BOOL)TSACertPrivateKeyExists NS_SWIFT_NAME(TSACertPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=TSACertPrivateKeyExtractable) BOOL TSACertPrivateKeyExtractable NS_SWIFT_NAME(TSACertPrivateKeyExtractable);

- (BOOL)TSACertPrivateKeyExtractable NS_SWIFT_NAME(TSACertPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=TSACertPublicKeyBytes) NSData* TSACertPublicKeyBytes NS_SWIFT_NAME(TSACertPublicKeyBytes);

- (NSData*)TSACertPublicKeyBytes NS_SWIFT_NAME(TSACertPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=TSACertQualified) BOOL TSACertQualified NS_SWIFT_NAME(TSACertQualified);

- (BOOL)TSACertQualified NS_SWIFT_NAME(TSACertQualified());

@property (nonatomic,readonly,assign,getter=TSACertQualifiedStatements) int TSACertQualifiedStatements NS_SWIFT_NAME(TSACertQualifiedStatements);

- (int)TSACertQualifiedStatements NS_SWIFT_NAME(TSACertQualifiedStatements());

@property (nonatomic,readonly,assign,getter=TSACertQualifiers) NSString* TSACertQualifiers NS_SWIFT_NAME(TSACertQualifiers);

- (NSString*)TSACertQualifiers NS_SWIFT_NAME(TSACertQualifiers());

@property (nonatomic,readonly,assign,getter=TSACertSelfSigned) BOOL TSACertSelfSigned NS_SWIFT_NAME(TSACertSelfSigned);

- (BOOL)TSACertSelfSigned NS_SWIFT_NAME(TSACertSelfSigned());

@property (nonatomic,readonly,assign,getter=TSACertSerialNumber) NSData* TSACertSerialNumber NS_SWIFT_NAME(TSACertSerialNumber);

- (NSData*)TSACertSerialNumber NS_SWIFT_NAME(TSACertSerialNumber());

@property (nonatomic,readonly,assign,getter=TSACertSigAlgorithm) NSString* TSACertSigAlgorithm NS_SWIFT_NAME(TSACertSigAlgorithm);

- (NSString*)TSACertSigAlgorithm NS_SWIFT_NAME(TSACertSigAlgorithm());

@property (nonatomic,readonly,assign,getter=TSACertSource) int TSACertSource NS_SWIFT_NAME(TSACertSource);

- (int)TSACertSource NS_SWIFT_NAME(TSACertSource());

@property (nonatomic,readonly,assign,getter=TSACertSubject) NSString* TSACertSubject NS_SWIFT_NAME(TSACertSubject);

- (NSString*)TSACertSubject NS_SWIFT_NAME(TSACertSubject());

@property (nonatomic,readonly,assign,getter=TSACertSubjectAlternativeName) NSString* TSACertSubjectAlternativeName NS_SWIFT_NAME(TSACertSubjectAlternativeName);

- (NSString*)TSACertSubjectAlternativeName NS_SWIFT_NAME(TSACertSubjectAlternativeName());

@property (nonatomic,readonly,assign,getter=TSACertSubjectKeyID) NSData* TSACertSubjectKeyID NS_SWIFT_NAME(TSACertSubjectKeyID);

- (NSData*)TSACertSubjectKeyID NS_SWIFT_NAME(TSACertSubjectKeyID());

@property (nonatomic,readonly,assign,getter=TSACertSubjectRDN) NSString* TSACertSubjectRDN NS_SWIFT_NAME(TSACertSubjectRDN);

- (NSString*)TSACertSubjectRDN NS_SWIFT_NAME(TSACertSubjectRDN());

@property (nonatomic,readonly,assign,getter=TSACertValid) BOOL TSACertValid NS_SWIFT_NAME(TSACertValid);

- (BOOL)TSACertValid NS_SWIFT_NAME(TSACertValid());

@property (nonatomic,readonly,assign,getter=TSACertValidFrom) NSString* TSACertValidFrom NS_SWIFT_NAME(TSACertValidFrom);

- (NSString*)TSACertValidFrom NS_SWIFT_NAME(TSACertValidFrom());

@property (nonatomic,readonly,assign,getter=TSACertValidTo) NSString* TSACertValidTo NS_SWIFT_NAME(TSACertValidTo);

- (NSString*)TSACertValidTo NS_SWIFT_NAME(TSACertValidTo());

@property (nonatomic,readonly,assign,getter=unsignedAttributeCount) int unsignedAttributeCount NS_SWIFT_NAME(unsignedAttributeCount);

- (int)unsignedAttributeCount NS_SWIFT_NAME(unsignedAttributeCount());

- (NSString*)unsignedAttributeOID:(int)unsignedAttributeIndex NS_SWIFT_NAME(unsignedAttributeOID(_:));

- (NSData*)unsignedAttributeValue:(int)unsignedAttributeIndex NS_SWIFT_NAME(unsignedAttributeValue(_:));

@property (nonatomic,readonly,assign,getter=validatedSigningTime) NSString* validatedSigningTime NS_SWIFT_NAME(validatedSigningTime);

- (NSString*)validatedSigningTime NS_SWIFT_NAME(validatedSigningTime());

  /* Methods */

- (int)checkSignatureType NS_SWIFT_NAME(checkSignatureType());

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (void)reset NS_SWIFT_NAME(reset());

- (void)verify NS_SWIFT_NAME(verify());

- (void)verifyDetached NS_SWIFT_NAME(verifyDetached());

@end

