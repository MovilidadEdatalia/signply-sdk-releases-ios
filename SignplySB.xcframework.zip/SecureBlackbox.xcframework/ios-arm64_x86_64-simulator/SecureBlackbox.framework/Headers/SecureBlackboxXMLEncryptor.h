/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//XMLENCRYPTEDDATATYPES
#define CXEDT_ELEMENT                                      0

#define CXEDT_CONTENT                                      1

#define CXEDT_EXTERNAL                                     2

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

//XMLKEYENCRYPTIONTYPES
#define CXET_KEY_TRANSPORT                                 0

#define CXET_KEY_WRAP                                      1

//XMLKEYTRANSPORTMETHODS
#define CXKT_RSA15                                         0

#define CXKT_RSAOAEP                                       1

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxXMLEncryptorDelegate <NSObject>
@optional
- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onFormatElement:(NSString**)startTagWhitespace :(NSString**)endTagWhitespace :(int)level :(NSString*)path :(BOOL)hasChildElements NS_SWIFT_NAME(onFormatElement(_:_:_:_:_:));

- (void)onFormatText:(NSString**)text :(int)textType :(int)level :(NSString*)path NS_SWIFT_NAME(onFormatText(_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

@end

@interface SecureBlackboxXMLEncryptor : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxXMLEncryptorDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasError;

  BOOL m_delegateHasFormatElement;

  BOOL m_delegateHasFormatText;

  BOOL m_delegateHasNotification;

}

+ (SecureBlackboxXMLEncryptor*)xmlencryptor;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxXMLEncryptorDelegate> delegate;
- (id <SecureBlackboxXMLEncryptorDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxXMLEncryptorDelegate>)anObject;

  /* Events */

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onFormatElement:(NSString**)startTagWhitespace :(NSString**)endTagWhitespace :(int)level :(NSString*)path :(BOOL)hasChildElements NS_SWIFT_NAME(onFormatElement(_:_:_:_:_:));

- (void)onFormatText:(NSString**)text :(int)textType :(int)level :(NSString*)path NS_SWIFT_NAME(onFormatText(_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readwrite,assign,getter=encoding,setter=setEncoding:) NSString* encoding NS_SWIFT_NAME(encoding);

- (NSString*)encoding NS_SWIFT_NAME(encoding());
- (void)setEncoding :(NSString*)newEncoding NS_SWIFT_NAME(setEncoding(_:));

@property (nonatomic,readwrite,assign,getter=encryptedDataType,setter=setEncryptedDataType:) int encryptedDataType NS_SWIFT_NAME(encryptedDataType);

- (int)encryptedDataType NS_SWIFT_NAME(encryptedDataType());
- (void)setEncryptedDataType :(int)newEncryptedDataType NS_SWIFT_NAME(setEncryptedDataType(_:));

@property (nonatomic,readwrite,assign,getter=encryptionKey,setter=setEncryptionKey:) NSData* encryptionKey NS_SWIFT_NAME(encryptionKey);

- (NSData*)encryptionKey NS_SWIFT_NAME(encryptionKey());
- (void)setEncryptionKey :(NSData*)newEncryptionKey NS_SWIFT_NAME(setEncryptionKey(_:));

@property (nonatomic,readwrite,assign,getter=encryptionMethod,setter=setEncryptionMethod:) NSString* encryptionMethod NS_SWIFT_NAME(encryptionMethod);

- (NSString*)encryptionMethod NS_SWIFT_NAME(encryptionMethod());
- (void)setEncryptionMethod :(NSString*)newEncryptionMethod NS_SWIFT_NAME(setEncryptionMethod(_:));

@property (nonatomic,readwrite,assign,getter=encryptKey,setter=setEncryptKey:) BOOL encryptKey NS_SWIFT_NAME(encryptKey);

- (BOOL)encryptKey NS_SWIFT_NAME(encryptKey());
- (void)setEncryptKey :(BOOL)newEncryptKey NS_SWIFT_NAME(setEncryptKey(_:));

@property (nonatomic,readwrite,assign,getter=externalData,setter=setExternalData:) NSData* externalData NS_SWIFT_NAME(externalData);

- (NSData*)externalData NS_SWIFT_NAME(externalData());
- (void)setExternalData :(NSData*)newExternalData NS_SWIFT_NAME(setExternalData(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=inputBytes,setter=setInputBytes:) NSData* inputBytes NS_SWIFT_NAME(inputBytes);

- (NSData*)inputBytes NS_SWIFT_NAME(inputBytes());
- (void)setInputBytes :(NSData*)newInputBytes NS_SWIFT_NAME(setInputBytes(_:));

@property (nonatomic,readwrite,assign,getter=inputFile,setter=setInputFile:) NSString* inputFile NS_SWIFT_NAME(inputFile);

- (NSString*)inputFile NS_SWIFT_NAME(inputFile());
- (void)setInputFile :(NSString*)newInputFile NS_SWIFT_NAME(setInputFile(_:));

@property (nonatomic,readonly,assign,getter=keyEncryptionCertBytes) NSData* keyEncryptionCertBytes NS_SWIFT_NAME(keyEncryptionCertBytes);

- (NSData*)keyEncryptionCertBytes NS_SWIFT_NAME(keyEncryptionCertBytes());

@property (nonatomic,readwrite,assign,getter=keyEncryptionCertCA,setter=setKeyEncryptionCertCA:) BOOL keyEncryptionCertCA NS_SWIFT_NAME(keyEncryptionCertCA);

- (BOOL)keyEncryptionCertCA NS_SWIFT_NAME(keyEncryptionCertCA());
- (void)setKeyEncryptionCertCA :(BOOL)newKeyEncryptionCertCA NS_SWIFT_NAME(setKeyEncryptionCertCA(_:));

@property (nonatomic,readonly,assign,getter=keyEncryptionCertCAKeyID) NSData* keyEncryptionCertCAKeyID NS_SWIFT_NAME(keyEncryptionCertCAKeyID);

- (NSData*)keyEncryptionCertCAKeyID NS_SWIFT_NAME(keyEncryptionCertCAKeyID());

@property (nonatomic,readonly,assign,getter=keyEncryptionCertCertType) int keyEncryptionCertCertType NS_SWIFT_NAME(keyEncryptionCertCertType);

- (int)keyEncryptionCertCertType NS_SWIFT_NAME(keyEncryptionCertCertType());

@property (nonatomic,readwrite,assign,getter=keyEncryptionCertCRLDistributionPoints,setter=setKeyEncryptionCertCRLDistributionPoints:) NSString* keyEncryptionCertCRLDistributionPoints NS_SWIFT_NAME(keyEncryptionCertCRLDistributionPoints);

- (NSString*)keyEncryptionCertCRLDistributionPoints NS_SWIFT_NAME(keyEncryptionCertCRLDistributionPoints());
- (void)setKeyEncryptionCertCRLDistributionPoints :(NSString*)newKeyEncryptionCertCRLDistributionPoints NS_SWIFT_NAME(setKeyEncryptionCertCRLDistributionPoints(_:));

@property (nonatomic,readwrite,assign,getter=keyEncryptionCertCurve,setter=setKeyEncryptionCertCurve:) NSString* keyEncryptionCertCurve NS_SWIFT_NAME(keyEncryptionCertCurve);

- (NSString*)keyEncryptionCertCurve NS_SWIFT_NAME(keyEncryptionCertCurve());
- (void)setKeyEncryptionCertCurve :(NSString*)newKeyEncryptionCertCurve NS_SWIFT_NAME(setKeyEncryptionCertCurve(_:));

@property (nonatomic,readonly,assign,getter=keyEncryptionCertFingerprint) NSString* keyEncryptionCertFingerprint NS_SWIFT_NAME(keyEncryptionCertFingerprint);

- (NSString*)keyEncryptionCertFingerprint NS_SWIFT_NAME(keyEncryptionCertFingerprint());

@property (nonatomic,readonly,assign,getter=keyEncryptionCertFriendlyName) NSString* keyEncryptionCertFriendlyName NS_SWIFT_NAME(keyEncryptionCertFriendlyName);

- (NSString*)keyEncryptionCertFriendlyName NS_SWIFT_NAME(keyEncryptionCertFriendlyName());

@property (nonatomic,readwrite,assign,getter=keyEncryptionCertHandle,setter=setKeyEncryptionCertHandle:) long long keyEncryptionCertHandle NS_SWIFT_NAME(keyEncryptionCertHandle);

- (long long)keyEncryptionCertHandle NS_SWIFT_NAME(keyEncryptionCertHandle());
- (void)setKeyEncryptionCertHandle :(long long)newKeyEncryptionCertHandle NS_SWIFT_NAME(setKeyEncryptionCertHandle(_:));

@property (nonatomic,readwrite,assign,getter=keyEncryptionCertHashAlgorithm,setter=setKeyEncryptionCertHashAlgorithm:) NSString* keyEncryptionCertHashAlgorithm NS_SWIFT_NAME(keyEncryptionCertHashAlgorithm);

- (NSString*)keyEncryptionCertHashAlgorithm NS_SWIFT_NAME(keyEncryptionCertHashAlgorithm());
- (void)setKeyEncryptionCertHashAlgorithm :(NSString*)newKeyEncryptionCertHashAlgorithm NS_SWIFT_NAME(setKeyEncryptionCertHashAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=keyEncryptionCertIssuer) NSString* keyEncryptionCertIssuer NS_SWIFT_NAME(keyEncryptionCertIssuer);

- (NSString*)keyEncryptionCertIssuer NS_SWIFT_NAME(keyEncryptionCertIssuer());

@property (nonatomic,readwrite,assign,getter=keyEncryptionCertIssuerRDN,setter=setKeyEncryptionCertIssuerRDN:) NSString* keyEncryptionCertIssuerRDN NS_SWIFT_NAME(keyEncryptionCertIssuerRDN);

- (NSString*)keyEncryptionCertIssuerRDN NS_SWIFT_NAME(keyEncryptionCertIssuerRDN());
- (void)setKeyEncryptionCertIssuerRDN :(NSString*)newKeyEncryptionCertIssuerRDN NS_SWIFT_NAME(setKeyEncryptionCertIssuerRDN(_:));

@property (nonatomic,readwrite,assign,getter=keyEncryptionCertKeyAlgorithm,setter=setKeyEncryptionCertKeyAlgorithm:) NSString* keyEncryptionCertKeyAlgorithm NS_SWIFT_NAME(keyEncryptionCertKeyAlgorithm);

- (NSString*)keyEncryptionCertKeyAlgorithm NS_SWIFT_NAME(keyEncryptionCertKeyAlgorithm());
- (void)setKeyEncryptionCertKeyAlgorithm :(NSString*)newKeyEncryptionCertKeyAlgorithm NS_SWIFT_NAME(setKeyEncryptionCertKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=keyEncryptionCertKeyBits) int keyEncryptionCertKeyBits NS_SWIFT_NAME(keyEncryptionCertKeyBits);

- (int)keyEncryptionCertKeyBits NS_SWIFT_NAME(keyEncryptionCertKeyBits());

@property (nonatomic,readonly,assign,getter=keyEncryptionCertKeyFingerprint) NSString* keyEncryptionCertKeyFingerprint NS_SWIFT_NAME(keyEncryptionCertKeyFingerprint);

- (NSString*)keyEncryptionCertKeyFingerprint NS_SWIFT_NAME(keyEncryptionCertKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=keyEncryptionCertKeyUsage,setter=setKeyEncryptionCertKeyUsage:) int keyEncryptionCertKeyUsage NS_SWIFT_NAME(keyEncryptionCertKeyUsage);

- (int)keyEncryptionCertKeyUsage NS_SWIFT_NAME(keyEncryptionCertKeyUsage());
- (void)setKeyEncryptionCertKeyUsage :(int)newKeyEncryptionCertKeyUsage NS_SWIFT_NAME(setKeyEncryptionCertKeyUsage(_:));

@property (nonatomic,readonly,assign,getter=keyEncryptionCertKeyValid) BOOL keyEncryptionCertKeyValid NS_SWIFT_NAME(keyEncryptionCertKeyValid);

- (BOOL)keyEncryptionCertKeyValid NS_SWIFT_NAME(keyEncryptionCertKeyValid());

@property (nonatomic,readwrite,assign,getter=keyEncryptionCertOCSPLocations,setter=setKeyEncryptionCertOCSPLocations:) NSString* keyEncryptionCertOCSPLocations NS_SWIFT_NAME(keyEncryptionCertOCSPLocations);

- (NSString*)keyEncryptionCertOCSPLocations NS_SWIFT_NAME(keyEncryptionCertOCSPLocations());
- (void)setKeyEncryptionCertOCSPLocations :(NSString*)newKeyEncryptionCertOCSPLocations NS_SWIFT_NAME(setKeyEncryptionCertOCSPLocations(_:));

@property (nonatomic,readwrite,assign,getter=keyEncryptionCertOCSPNoCheck,setter=setKeyEncryptionCertOCSPNoCheck:) BOOL keyEncryptionCertOCSPNoCheck NS_SWIFT_NAME(keyEncryptionCertOCSPNoCheck);

- (BOOL)keyEncryptionCertOCSPNoCheck NS_SWIFT_NAME(keyEncryptionCertOCSPNoCheck());
- (void)setKeyEncryptionCertOCSPNoCheck :(BOOL)newKeyEncryptionCertOCSPNoCheck NS_SWIFT_NAME(setKeyEncryptionCertOCSPNoCheck(_:));

@property (nonatomic,readonly,assign,getter=keyEncryptionCertOrigin) int keyEncryptionCertOrigin NS_SWIFT_NAME(keyEncryptionCertOrigin);

- (int)keyEncryptionCertOrigin NS_SWIFT_NAME(keyEncryptionCertOrigin());

@property (nonatomic,readwrite,assign,getter=keyEncryptionCertPolicyIDs,setter=setKeyEncryptionCertPolicyIDs:) NSString* keyEncryptionCertPolicyIDs NS_SWIFT_NAME(keyEncryptionCertPolicyIDs);

- (NSString*)keyEncryptionCertPolicyIDs NS_SWIFT_NAME(keyEncryptionCertPolicyIDs());
- (void)setKeyEncryptionCertPolicyIDs :(NSString*)newKeyEncryptionCertPolicyIDs NS_SWIFT_NAME(setKeyEncryptionCertPolicyIDs(_:));

@property (nonatomic,readonly,assign,getter=keyEncryptionCertPrivateKeyBytes) NSData* keyEncryptionCertPrivateKeyBytes NS_SWIFT_NAME(keyEncryptionCertPrivateKeyBytes);

- (NSData*)keyEncryptionCertPrivateKeyBytes NS_SWIFT_NAME(keyEncryptionCertPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=keyEncryptionCertPrivateKeyExists) BOOL keyEncryptionCertPrivateKeyExists NS_SWIFT_NAME(keyEncryptionCertPrivateKeyExists);

- (BOOL)keyEncryptionCertPrivateKeyExists NS_SWIFT_NAME(keyEncryptionCertPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=keyEncryptionCertPrivateKeyExtractable) BOOL keyEncryptionCertPrivateKeyExtractable NS_SWIFT_NAME(keyEncryptionCertPrivateKeyExtractable);

- (BOOL)keyEncryptionCertPrivateKeyExtractable NS_SWIFT_NAME(keyEncryptionCertPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=keyEncryptionCertPublicKeyBytes) NSData* keyEncryptionCertPublicKeyBytes NS_SWIFT_NAME(keyEncryptionCertPublicKeyBytes);

- (NSData*)keyEncryptionCertPublicKeyBytes NS_SWIFT_NAME(keyEncryptionCertPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=keyEncryptionCertQualified) BOOL keyEncryptionCertQualified NS_SWIFT_NAME(keyEncryptionCertQualified);

- (BOOL)keyEncryptionCertQualified NS_SWIFT_NAME(keyEncryptionCertQualified());

@property (nonatomic,readwrite,assign,getter=keyEncryptionCertQualifiedStatements,setter=setKeyEncryptionCertQualifiedStatements:) int keyEncryptionCertQualifiedStatements NS_SWIFT_NAME(keyEncryptionCertQualifiedStatements);

- (int)keyEncryptionCertQualifiedStatements NS_SWIFT_NAME(keyEncryptionCertQualifiedStatements());
- (void)setKeyEncryptionCertQualifiedStatements :(int)newKeyEncryptionCertQualifiedStatements NS_SWIFT_NAME(setKeyEncryptionCertQualifiedStatements(_:));

@property (nonatomic,readonly,assign,getter=keyEncryptionCertQualifiers) NSString* keyEncryptionCertQualifiers NS_SWIFT_NAME(keyEncryptionCertQualifiers);

- (NSString*)keyEncryptionCertQualifiers NS_SWIFT_NAME(keyEncryptionCertQualifiers());

@property (nonatomic,readonly,assign,getter=keyEncryptionCertSelfSigned) BOOL keyEncryptionCertSelfSigned NS_SWIFT_NAME(keyEncryptionCertSelfSigned);

- (BOOL)keyEncryptionCertSelfSigned NS_SWIFT_NAME(keyEncryptionCertSelfSigned());

@property (nonatomic,readwrite,assign,getter=keyEncryptionCertSerialNumber,setter=setKeyEncryptionCertSerialNumber:) NSData* keyEncryptionCertSerialNumber NS_SWIFT_NAME(keyEncryptionCertSerialNumber);

- (NSData*)keyEncryptionCertSerialNumber NS_SWIFT_NAME(keyEncryptionCertSerialNumber());
- (void)setKeyEncryptionCertSerialNumber :(NSData*)newKeyEncryptionCertSerialNumber NS_SWIFT_NAME(setKeyEncryptionCertSerialNumber(_:));

@property (nonatomic,readonly,assign,getter=keyEncryptionCertSigAlgorithm) NSString* keyEncryptionCertSigAlgorithm NS_SWIFT_NAME(keyEncryptionCertSigAlgorithm);

- (NSString*)keyEncryptionCertSigAlgorithm NS_SWIFT_NAME(keyEncryptionCertSigAlgorithm());

@property (nonatomic,readonly,assign,getter=keyEncryptionCertSource) int keyEncryptionCertSource NS_SWIFT_NAME(keyEncryptionCertSource);

- (int)keyEncryptionCertSource NS_SWIFT_NAME(keyEncryptionCertSource());

@property (nonatomic,readonly,assign,getter=keyEncryptionCertSubject) NSString* keyEncryptionCertSubject NS_SWIFT_NAME(keyEncryptionCertSubject);

- (NSString*)keyEncryptionCertSubject NS_SWIFT_NAME(keyEncryptionCertSubject());

@property (nonatomic,readwrite,assign,getter=keyEncryptionCertSubjectAlternativeName,setter=setKeyEncryptionCertSubjectAlternativeName:) NSString* keyEncryptionCertSubjectAlternativeName NS_SWIFT_NAME(keyEncryptionCertSubjectAlternativeName);

- (NSString*)keyEncryptionCertSubjectAlternativeName NS_SWIFT_NAME(keyEncryptionCertSubjectAlternativeName());
- (void)setKeyEncryptionCertSubjectAlternativeName :(NSString*)newKeyEncryptionCertSubjectAlternativeName NS_SWIFT_NAME(setKeyEncryptionCertSubjectAlternativeName(_:));

@property (nonatomic,readwrite,assign,getter=keyEncryptionCertSubjectKeyID,setter=setKeyEncryptionCertSubjectKeyID:) NSData* keyEncryptionCertSubjectKeyID NS_SWIFT_NAME(keyEncryptionCertSubjectKeyID);

- (NSData*)keyEncryptionCertSubjectKeyID NS_SWIFT_NAME(keyEncryptionCertSubjectKeyID());
- (void)setKeyEncryptionCertSubjectKeyID :(NSData*)newKeyEncryptionCertSubjectKeyID NS_SWIFT_NAME(setKeyEncryptionCertSubjectKeyID(_:));

@property (nonatomic,readwrite,assign,getter=keyEncryptionCertSubjectRDN,setter=setKeyEncryptionCertSubjectRDN:) NSString* keyEncryptionCertSubjectRDN NS_SWIFT_NAME(keyEncryptionCertSubjectRDN);

- (NSString*)keyEncryptionCertSubjectRDN NS_SWIFT_NAME(keyEncryptionCertSubjectRDN());
- (void)setKeyEncryptionCertSubjectRDN :(NSString*)newKeyEncryptionCertSubjectRDN NS_SWIFT_NAME(setKeyEncryptionCertSubjectRDN(_:));

@property (nonatomic,readonly,assign,getter=keyEncryptionCertValid) BOOL keyEncryptionCertValid NS_SWIFT_NAME(keyEncryptionCertValid);

- (BOOL)keyEncryptionCertValid NS_SWIFT_NAME(keyEncryptionCertValid());

@property (nonatomic,readwrite,assign,getter=keyEncryptionCertValidFrom,setter=setKeyEncryptionCertValidFrom:) NSString* keyEncryptionCertValidFrom NS_SWIFT_NAME(keyEncryptionCertValidFrom);

- (NSString*)keyEncryptionCertValidFrom NS_SWIFT_NAME(keyEncryptionCertValidFrom());
- (void)setKeyEncryptionCertValidFrom :(NSString*)newKeyEncryptionCertValidFrom NS_SWIFT_NAME(setKeyEncryptionCertValidFrom(_:));

@property (nonatomic,readwrite,assign,getter=keyEncryptionCertValidTo,setter=setKeyEncryptionCertValidTo:) NSString* keyEncryptionCertValidTo NS_SWIFT_NAME(keyEncryptionCertValidTo);

- (NSString*)keyEncryptionCertValidTo NS_SWIFT_NAME(keyEncryptionCertValidTo());
- (void)setKeyEncryptionCertValidTo :(NSString*)newKeyEncryptionCertValidTo NS_SWIFT_NAME(setKeyEncryptionCertValidTo(_:));

@property (nonatomic,readwrite,assign,getter=keyEncryptionKey,setter=setKeyEncryptionKey:) NSData* keyEncryptionKey NS_SWIFT_NAME(keyEncryptionKey);

- (NSData*)keyEncryptionKey NS_SWIFT_NAME(keyEncryptionKey());
- (void)setKeyEncryptionKey :(NSData*)newKeyEncryptionKey NS_SWIFT_NAME(setKeyEncryptionKey(_:));

@property (nonatomic,readwrite,assign,getter=keyEncryptionType,setter=setKeyEncryptionType:) int keyEncryptionType NS_SWIFT_NAME(keyEncryptionType);

- (int)keyEncryptionType NS_SWIFT_NAME(keyEncryptionType());
- (void)setKeyEncryptionType :(int)newKeyEncryptionType NS_SWIFT_NAME(setKeyEncryptionType(_:));

@property (nonatomic,readwrite,assign,getter=keyTransportMethod,setter=setKeyTransportMethod:) int keyTransportMethod NS_SWIFT_NAME(keyTransportMethod);

- (int)keyTransportMethod NS_SWIFT_NAME(keyTransportMethod());
- (void)setKeyTransportMethod :(int)newKeyTransportMethod NS_SWIFT_NAME(setKeyTransportMethod(_:));

@property (nonatomic,readwrite,assign,getter=keyWrapMethod,setter=setKeyWrapMethod:) NSString* keyWrapMethod NS_SWIFT_NAME(keyWrapMethod);

- (NSString*)keyWrapMethod NS_SWIFT_NAME(keyWrapMethod());
- (void)setKeyWrapMethod :(NSString*)newKeyWrapMethod NS_SWIFT_NAME(setKeyWrapMethod(_:));

@property (nonatomic,readonly,assign,getter=outputBytes) NSData* outputBytes NS_SWIFT_NAME(outputBytes);

- (NSData*)outputBytes NS_SWIFT_NAME(outputBytes());

@property (nonatomic,readwrite,assign,getter=outputFile,setter=setOutputFile:) NSString* outputFile NS_SWIFT_NAME(outputFile);

- (NSString*)outputFile NS_SWIFT_NAME(outputFile());
- (void)setOutputFile :(NSString*)newOutputFile NS_SWIFT_NAME(setOutputFile(_:));

@property (nonatomic,readwrite,assign,getter=useGCM,setter=setUseGCM:) BOOL useGCM NS_SWIFT_NAME(useGCM);

- (BOOL)useGCM NS_SWIFT_NAME(useGCM());
- (void)setUseGCM :(BOOL)newUseGCM NS_SWIFT_NAME(setUseGCM(_:));

@property (nonatomic,readwrite,assign,getter=XMLNode,setter=setXMLNode:) NSString* XMLNode NS_SWIFT_NAME(XMLNode);

- (NSString*)XMLNode NS_SWIFT_NAME(XMLNode());
- (void)setXMLNode :(NSString*)newXMLNode NS_SWIFT_NAME(setXMLNode(_:));

  /* Methods */

- (void)addKnownNamespace:(NSString*)prefix :(NSString*)URI NS_SWIFT_NAME(addKnownNamespace(_:_:));

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (void)encrypt NS_SWIFT_NAME(encrypt());

- (void)reset NS_SWIFT_NAME(reset());

@end

