/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//PGPPROTECTIONTYPES
#define PPT_NONE                                           0

#define PPT_LOW                                            1

#define PPT_NORMAL                                         2

#define PPT_HIGH                                           3

//ASYNCSIGNMETHODS
#define ASMD_PKCS1                                         0

#define ASMD_PKCS7                                         1

//EXTERNALCRYPTOMODES
#define ECM_DEFAULT                                        0

#define ECM_DISABLED                                       1

#define ECM_GENERIC                                        2

#define ECM_DCAUTH                                         3

#define ECM_DCAUTH_JSON                                    4

//PGPCERTIFICATIONTYPES
#define PCT_GENERIC                                        0

#define PCT_PERSONA                                        1

#define PCT_CASUAL                                         2

#define PCT_POSITIVE                                       3

//PGPSIGNATURECLASSES
#define PSC_DOCUMENT                                       0

#define PSC_TEXT_DOCUMENT                                  1

#define PSC_STANDALONE                                     2

#define PSC_UIDGENERIC                                     3

#define PSC_UIDPERSONA                                     4

#define PSC_UIDCASUAL                                      5

#define PSC_UIDPOSITIVE                                    6

#define PSC_SUBKEY_BINDING                                 7

#define PSC_PRIMARY_KEY_BINDING                            8

#define PSC_DIRECT_KEY                                     9

#define PSC_KEY_REVOCATION                                 10

#define PSC_SUBKEY_REVOCATION                              11

#define PSC_CERT_REVOCATION                                12

#define PSC_TIMESTAMP                                      13

#define PSC_THIRD_PARTY                                    14

#define PSC_NOT_SPECIFIED                                  15

//SIGNATUREVALIDITIES
#define SVT_VALID                                          0

#define SVT_UNKNOWN                                        1

#define SVT_CORRUPTED                                      2

#define SVT_SIGNER_NOT_FOUND                               3

#define SVT_FAILURE                                        4

#define SVT_REFERENCE_CORRUPTED                            5

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxPGPReaderDelegate <NSObject>
@optional
- (void)onEncryptionInfo:(NSString*)keyIDs :(int)encryptedProtection :(BOOL)passphraseUsed NS_SWIFT_NAME(onEncryptionInfo(_:_:_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onExternalDecrypt:(NSString*)operationId :(NSString*)algorithm :(NSString*)pars :(NSString*)encryptedData :(NSString**)data NS_SWIFT_NAME(onExternalDecrypt(_:_:_:_:_:));

- (void)onFileExtractionFinish:(NSString*)fileName :(NSString*)timestamp NS_SWIFT_NAME(onFileExtractionFinish(_:_:));

- (void)onFileExtractionStart:(NSString*)fileName :(NSString*)timestamp :(int*)skip NS_SWIFT_NAME(onFileExtractionStart(_:_:_:));

- (void)onKeyPassphraseNeeded:(NSString*)keyID :(NSString*)userID :(BOOL)mainKey :(NSString**)passphrase :(int*)skip NS_SWIFT_NAME(onKeyPassphraseNeeded(_:_:_:_:_:));

- (void)onMultipleFilesFound:(NSString*)tarFileName :(int*)proceed NS_SWIFT_NAME(onMultipleFilesFound(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onPassphraseNeeded:(NSString**)passphrase :(int*)skip NS_SWIFT_NAME(onPassphraseNeeded(_:_:));

- (void)onProgress:(long long)current :(long long)total :(int*)cancel NS_SWIFT_NAME(onProgress(_:_:_:));

- (void)onSigned:(NSString*)keyIDs :(int)signatureType NS_SWIFT_NAME(onSigned(_:_:));

@end

@interface SecureBlackboxPGPReader : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxPGPReaderDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasEncryptionInfo;

  BOOL m_delegateHasError;

  BOOL m_delegateHasExternalDecrypt;

  BOOL m_delegateHasFileExtractionFinish;

  BOOL m_delegateHasFileExtractionStart;

  BOOL m_delegateHasKeyPassphraseNeeded;

  BOOL m_delegateHasMultipleFilesFound;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasPassphraseNeeded;

  BOOL m_delegateHasProgress;

  BOOL m_delegateHasSigned;

}

+ (SecureBlackboxPGPReader*)pgpreader;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxPGPReaderDelegate> delegate;
- (id <SecureBlackboxPGPReaderDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxPGPReaderDelegate>)anObject;

  /* Events */

- (void)onEncryptionInfo:(NSString*)keyIDs :(int)encryptedProtection :(BOOL)passphraseUsed NS_SWIFT_NAME(onEncryptionInfo(_:_:_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onExternalDecrypt:(NSString*)operationId :(NSString*)algorithm :(NSString*)pars :(NSString*)encryptedData :(NSString**)data NS_SWIFT_NAME(onExternalDecrypt(_:_:_:_:_:));

- (void)onFileExtractionFinish:(NSString*)fileName :(NSString*)timestamp NS_SWIFT_NAME(onFileExtractionFinish(_:_:));

- (void)onFileExtractionStart:(NSString*)fileName :(NSString*)timestamp :(int*)skip NS_SWIFT_NAME(onFileExtractionStart(_:_:_:));

- (void)onKeyPassphraseNeeded:(NSString*)keyID :(NSString*)userID :(BOOL)mainKey :(NSString**)passphrase :(int*)skip NS_SWIFT_NAME(onKeyPassphraseNeeded(_:_:_:_:_:));

- (void)onMultipleFilesFound:(NSString*)tarFileName :(int*)proceed NS_SWIFT_NAME(onMultipleFilesFound(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onPassphraseNeeded:(NSString**)passphrase :(int*)skip NS_SWIFT_NAME(onPassphraseNeeded(_:_:));

- (void)onProgress:(long long)current :(long long)total :(int*)cancel NS_SWIFT_NAME(onProgress(_:_:_:));

- (void)onSigned:(NSString*)keyIDs :(int)signatureType NS_SWIFT_NAME(onSigned(_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readonly,assign,getter=armored) BOOL armored NS_SWIFT_NAME(armored);

- (BOOL)armored NS_SWIFT_NAME(armored());

@property (nonatomic,readonly,assign,getter=compressed) BOOL compressed NS_SWIFT_NAME(compressed);

- (BOOL)compressed NS_SWIFT_NAME(compressed());

@property (nonatomic,readwrite,assign,getter=dataBytes,setter=setDataBytes:) NSData* dataBytes NS_SWIFT_NAME(dataBytes);

- (NSData*)dataBytes NS_SWIFT_NAME(dataBytes());
- (void)setDataBytes :(NSData*)newDataBytes NS_SWIFT_NAME(setDataBytes(_:));

@property (nonatomic,readwrite,assign,getter=dataFile,setter=setDataFile:) NSString* dataFile NS_SWIFT_NAME(dataFile);

- (NSString*)dataFile NS_SWIFT_NAME(dataFile());
- (void)setDataFile :(NSString*)newDataFile NS_SWIFT_NAME(setDataFile(_:));

@property (nonatomic,readwrite,assign,getter=decryptingKeyCount,setter=setDecryptingKeyCount:) int decryptingKeyCount NS_SWIFT_NAME(decryptingKeyCount);

- (int)decryptingKeyCount NS_SWIFT_NAME(decryptingKeyCount());
- (void)setDecryptingKeyCount :(int)newDecryptingKeyCount NS_SWIFT_NAME(setDecryptingKeyCount(_:));

- (int)decryptingKeyBitsInKey:(int)decryptingKeyIndex NS_SWIFT_NAME(decryptingKeyBitsInKey(_:));

- (BOOL)decryptingKeyCanEncrypt:(int)decryptingKeyIndex NS_SWIFT_NAME(decryptingKeyCanEncrypt(_:));

- (BOOL)decryptingKeyCanSign:(int)decryptingKeyIndex NS_SWIFT_NAME(decryptingKeyCanSign(_:));

- (NSString*)decryptingKeyCurve:(int)decryptingKeyIndex NS_SWIFT_NAME(decryptingKeyCurve(_:));

- (BOOL)decryptingKeyEnabled:(int)decryptingKeyIndex NS_SWIFT_NAME(decryptingKeyEnabled(_:));
- (void)setDecryptingKeyEnabled:(int)decryptingKeyIndex :(BOOL)newDecryptingKeyEnabled NS_SWIFT_NAME(setDecryptingKeyEnabled(_:_:));

- (NSString*)decryptingKeyEncryptionAlgorithm:(int)decryptingKeyIndex NS_SWIFT_NAME(decryptingKeyEncryptionAlgorithm(_:));

- (long long)decryptingKeyHandle:(int)decryptingKeyIndex NS_SWIFT_NAME(decryptingKeyHandle(_:));
- (void)setDecryptingKeyHandle:(int)decryptingKeyIndex :(long long)newDecryptingKeyHandle NS_SWIFT_NAME(setDecryptingKeyHandle(_:_:));

- (BOOL)decryptingKeyIsPublic:(int)decryptingKeyIndex NS_SWIFT_NAME(decryptingKeyIsPublic(_:));

- (BOOL)decryptingKeyIsSecret:(int)decryptingKeyIndex NS_SWIFT_NAME(decryptingKeyIsSecret(_:));

- (BOOL)decryptingKeyIsSubkey:(int)decryptingKeyIndex NS_SWIFT_NAME(decryptingKeyIsSubkey(_:));

- (NSString*)decryptingKeyKeyFP:(int)decryptingKeyIndex NS_SWIFT_NAME(decryptingKeyKeyFP(_:));

- (NSString*)decryptingKeyKeyID:(int)decryptingKeyIndex NS_SWIFT_NAME(decryptingKeyKeyID(_:));

- (NSString*)decryptingKeyPassphrase:(int)decryptingKeyIndex NS_SWIFT_NAME(decryptingKeyPassphrase(_:));
- (void)setDecryptingKeyPassphrase:(int)decryptingKeyIndex :(NSString*)newDecryptingKeyPassphrase NS_SWIFT_NAME(setDecryptingKeyPassphrase(_:_:));

- (BOOL)decryptingKeyPassphraseValid:(int)decryptingKeyIndex NS_SWIFT_NAME(decryptingKeyPassphraseValid(_:));

- (NSString*)decryptingKeyPrimaryKeyID:(int)decryptingKeyIndex NS_SWIFT_NAME(decryptingKeyPrimaryKeyID(_:));

- (int)decryptingKeyProtection:(int)decryptingKeyIndex NS_SWIFT_NAME(decryptingKeyProtection(_:));

- (NSString*)decryptingKeyPublicKeyAlgorithm:(int)decryptingKeyIndex NS_SWIFT_NAME(decryptingKeyPublicKeyAlgorithm(_:));

- (int)decryptingKeyQBits:(int)decryptingKeyIndex NS_SWIFT_NAME(decryptingKeyQBits(_:));

- (NSString*)decryptingKeyTimestamp:(int)decryptingKeyIndex NS_SWIFT_NAME(decryptingKeyTimestamp(_:));

- (NSString*)decryptingKeyUsername:(int)decryptingKeyIndex NS_SWIFT_NAME(decryptingKeyUsername(_:));

- (NSString*)decryptingKeyValidTo:(int)decryptingKeyIndex NS_SWIFT_NAME(decryptingKeyValidTo(_:));

- (int)decryptingKeyVersion:(int)decryptingKeyIndex NS_SWIFT_NAME(decryptingKeyVersion(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoAsyncDocumentID,setter=setExternalCryptoAsyncDocumentID:) NSString* externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID);

- (NSString*)externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID());
- (void)setExternalCryptoAsyncDocumentID :(NSString*)newExternalCryptoAsyncDocumentID NS_SWIFT_NAME(setExternalCryptoAsyncDocumentID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoCustomParams,setter=setExternalCryptoCustomParams:) NSString* externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams);

- (NSString*)externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams());
- (void)setExternalCryptoCustomParams :(NSString*)newExternalCryptoCustomParams NS_SWIFT_NAME(setExternalCryptoCustomParams(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoData,setter=setExternalCryptoData:) NSString* externalCryptoData NS_SWIFT_NAME(externalCryptoData);

- (NSString*)externalCryptoData NS_SWIFT_NAME(externalCryptoData());
- (void)setExternalCryptoData :(NSString*)newExternalCryptoData NS_SWIFT_NAME(setExternalCryptoData(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoExternalHashCalculation,setter=setExternalCryptoExternalHashCalculation:) BOOL externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation);

- (BOOL)externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation());
- (void)setExternalCryptoExternalHashCalculation :(BOOL)newExternalCryptoExternalHashCalculation NS_SWIFT_NAME(setExternalCryptoExternalHashCalculation(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoHashAlgorithm,setter=setExternalCryptoHashAlgorithm:) NSString* externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm);

- (NSString*)externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm());
- (void)setExternalCryptoHashAlgorithm :(NSString*)newExternalCryptoHashAlgorithm NS_SWIFT_NAME(setExternalCryptoHashAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeyID,setter=setExternalCryptoKeyID:) NSString* externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID);

- (NSString*)externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID());
- (void)setExternalCryptoKeyID :(NSString*)newExternalCryptoKeyID NS_SWIFT_NAME(setExternalCryptoKeyID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeySecret,setter=setExternalCryptoKeySecret:) NSString* externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret);

- (NSString*)externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret());
- (void)setExternalCryptoKeySecret :(NSString*)newExternalCryptoKeySecret NS_SWIFT_NAME(setExternalCryptoKeySecret(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMethod,setter=setExternalCryptoMethod:) int externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod);

- (int)externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod());
- (void)setExternalCryptoMethod :(int)newExternalCryptoMethod NS_SWIFT_NAME(setExternalCryptoMethod(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMode,setter=setExternalCryptoMode:) int externalCryptoMode NS_SWIFT_NAME(externalCryptoMode);

- (int)externalCryptoMode NS_SWIFT_NAME(externalCryptoMode());
- (void)setExternalCryptoMode :(int)newExternalCryptoMode NS_SWIFT_NAME(setExternalCryptoMode(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoPublicKeyAlgorithm,setter=setExternalCryptoPublicKeyAlgorithm:) NSString* externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm);

- (NSString*)externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm());
- (void)setExternalCryptoPublicKeyAlgorithm :(NSString*)newExternalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(setExternalCryptoPublicKeyAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=inputBytes,setter=setInputBytes:) NSData* inputBytes NS_SWIFT_NAME(inputBytes);

- (NSData*)inputBytes NS_SWIFT_NAME(inputBytes());
- (void)setInputBytes :(NSData*)newInputBytes NS_SWIFT_NAME(setInputBytes(_:));

@property (nonatomic,readwrite,assign,getter=inputFile,setter=setInputFile:) NSString* inputFile NS_SWIFT_NAME(inputFile);

- (NSString*)inputFile NS_SWIFT_NAME(inputFile());
- (void)setInputFile :(NSString*)newInputFile NS_SWIFT_NAME(setInputFile(_:));

@property (nonatomic,readwrite,assign,getter=keyPassphrase,setter=setKeyPassphrase:) NSString* keyPassphrase NS_SWIFT_NAME(keyPassphrase);

- (NSString*)keyPassphrase NS_SWIFT_NAME(keyPassphrase());
- (void)setKeyPassphrase :(NSString*)newKeyPassphrase NS_SWIFT_NAME(setKeyPassphrase(_:));

@property (nonatomic,readonly,assign,getter=outputBytes) NSData* outputBytes NS_SWIFT_NAME(outputBytes);

- (NSData*)outputBytes NS_SWIFT_NAME(outputBytes());

@property (nonatomic,readwrite,assign,getter=outputFile,setter=setOutputFile:) NSString* outputFile NS_SWIFT_NAME(outputFile);

- (NSString*)outputFile NS_SWIFT_NAME(outputFile());
- (void)setOutputFile :(NSString*)newOutputFile NS_SWIFT_NAME(setOutputFile(_:));

@property (nonatomic,readwrite,assign,getter=passphrase,setter=setPassphrase:) NSString* passphrase NS_SWIFT_NAME(passphrase);

- (NSString*)passphrase NS_SWIFT_NAME(passphrase());
- (void)setPassphrase :(NSString*)newPassphrase NS_SWIFT_NAME(setPassphrase(_:));

@property (nonatomic,readonly,assign,getter=processedLength) long long processedLength NS_SWIFT_NAME(processedLength);

- (long long)processedLength NS_SWIFT_NAME(processedLength());

@property (nonatomic,readwrite,assign,getter=profile,setter=setProfile:) NSString* profile NS_SWIFT_NAME(profile);

- (NSString*)profile NS_SWIFT_NAME(profile());
- (void)setProfile :(NSString*)newProfile NS_SWIFT_NAME(setProfile(_:));

@property (nonatomic,readonly,assign,getter=signatureCount) int signatureCount NS_SWIFT_NAME(signatureCount);

- (int)signatureCount NS_SWIFT_NAME(signatureCount());

- (int)signatureCertificationType:(int)signatureIndex NS_SWIFT_NAME(signatureCertificationType(_:));

- (NSString*)signatureCreationTime:(int)signatureIndex NS_SWIFT_NAME(signatureCreationTime(_:));

- (int)signatureExpirationTime:(int)signatureIndex NS_SWIFT_NAME(signatureExpirationTime(_:));

- (BOOL)signatureExportable:(int)signatureIndex NS_SWIFT_NAME(signatureExportable(_:));

- (long long)signatureHandle:(int)signatureIndex NS_SWIFT_NAME(signatureHandle(_:));

- (NSString*)signatureHashAlgorithm:(int)signatureIndex NS_SWIFT_NAME(signatureHashAlgorithm(_:));

- (int)signatureHashMark:(int)signatureIndex NS_SWIFT_NAME(signatureHashMark(_:));

- (int)signatureKeyExpirationTime:(int)signatureIndex NS_SWIFT_NAME(signatureKeyExpirationTime(_:));

- (int)signatureKeyFlags:(int)signatureIndex NS_SWIFT_NAME(signatureKeyFlags(_:));

- (BOOL)signatureLegacyFormat:(int)signatureIndex NS_SWIFT_NAME(signatureLegacyFormat(_:));

- (NSString*)signaturePolicyURL:(int)signatureIndex NS_SWIFT_NAME(signaturePolicyURL(_:));

- (NSString*)signaturePreferredAlgorithms:(int)signatureIndex NS_SWIFT_NAME(signaturePreferredAlgorithms(_:));

- (BOOL)signaturePrimaryUserID:(int)signatureIndex NS_SWIFT_NAME(signaturePrimaryUserID(_:));

- (NSString*)signatureReasonForRevocation:(int)signatureIndex NS_SWIFT_NAME(signatureReasonForRevocation(_:));

- (BOOL)signatureRevocable:(int)signatureIndex NS_SWIFT_NAME(signatureRevocable(_:));

- (BOOL)signatureRevocation:(int)signatureIndex NS_SWIFT_NAME(signatureRevocation(_:));

- (int)signatureSignatureClass:(int)signatureIndex NS_SWIFT_NAME(signatureSignatureClass(_:));

- (NSString*)signatureSignerKeyID:(int)signatureIndex NS_SWIFT_NAME(signatureSignerKeyID(_:));

- (NSString*)signatureSignerUserID:(int)signatureIndex NS_SWIFT_NAME(signatureSignerUserID(_:));

- (BOOL)signatureStrictlyValid:(int)signatureIndex NS_SWIFT_NAME(signatureStrictlyValid(_:));

- (NSString*)signatureTarget:(int)signatureIndex NS_SWIFT_NAME(signatureTarget(_:));

- (BOOL)signatureTextSignature:(int)signatureIndex NS_SWIFT_NAME(signatureTextSignature(_:));

- (int)signatureTrustAmount:(int)signatureIndex NS_SWIFT_NAME(signatureTrustAmount(_:));

- (int)signatureTrustLevel:(int)signatureIndex NS_SWIFT_NAME(signatureTrustLevel(_:));

- (BOOL)signatureValidated:(int)signatureIndex NS_SWIFT_NAME(signatureValidated(_:));

- (int)signatureValidity:(int)signatureIndex NS_SWIFT_NAME(signatureValidity(_:));

- (int)signatureVersion:(int)signatureIndex NS_SWIFT_NAME(signatureVersion(_:));

@property (nonatomic,readwrite,assign,getter=verifyingKeyCount,setter=setVerifyingKeyCount:) int verifyingKeyCount NS_SWIFT_NAME(verifyingKeyCount);

- (int)verifyingKeyCount NS_SWIFT_NAME(verifyingKeyCount());
- (void)setVerifyingKeyCount :(int)newVerifyingKeyCount NS_SWIFT_NAME(setVerifyingKeyCount(_:));

- (int)verifyingKeyBitsInKey:(int)verifyingKeyIndex NS_SWIFT_NAME(verifyingKeyBitsInKey(_:));

- (BOOL)verifyingKeyCanEncrypt:(int)verifyingKeyIndex NS_SWIFT_NAME(verifyingKeyCanEncrypt(_:));

- (BOOL)verifyingKeyCanSign:(int)verifyingKeyIndex NS_SWIFT_NAME(verifyingKeyCanSign(_:));

- (NSString*)verifyingKeyCurve:(int)verifyingKeyIndex NS_SWIFT_NAME(verifyingKeyCurve(_:));

- (BOOL)verifyingKeyEnabled:(int)verifyingKeyIndex NS_SWIFT_NAME(verifyingKeyEnabled(_:));
- (void)setVerifyingKeyEnabled:(int)verifyingKeyIndex :(BOOL)newVerifyingKeyEnabled NS_SWIFT_NAME(setVerifyingKeyEnabled(_:_:));

- (NSString*)verifyingKeyEncryptionAlgorithm:(int)verifyingKeyIndex NS_SWIFT_NAME(verifyingKeyEncryptionAlgorithm(_:));

- (long long)verifyingKeyHandle:(int)verifyingKeyIndex NS_SWIFT_NAME(verifyingKeyHandle(_:));
- (void)setVerifyingKeyHandle:(int)verifyingKeyIndex :(long long)newVerifyingKeyHandle NS_SWIFT_NAME(setVerifyingKeyHandle(_:_:));

- (BOOL)verifyingKeyIsPublic:(int)verifyingKeyIndex NS_SWIFT_NAME(verifyingKeyIsPublic(_:));

- (BOOL)verifyingKeyIsSecret:(int)verifyingKeyIndex NS_SWIFT_NAME(verifyingKeyIsSecret(_:));

- (BOOL)verifyingKeyIsSubkey:(int)verifyingKeyIndex NS_SWIFT_NAME(verifyingKeyIsSubkey(_:));

- (NSString*)verifyingKeyKeyFP:(int)verifyingKeyIndex NS_SWIFT_NAME(verifyingKeyKeyFP(_:));

- (NSString*)verifyingKeyKeyID:(int)verifyingKeyIndex NS_SWIFT_NAME(verifyingKeyKeyID(_:));

- (NSString*)verifyingKeyPassphrase:(int)verifyingKeyIndex NS_SWIFT_NAME(verifyingKeyPassphrase(_:));
- (void)setVerifyingKeyPassphrase:(int)verifyingKeyIndex :(NSString*)newVerifyingKeyPassphrase NS_SWIFT_NAME(setVerifyingKeyPassphrase(_:_:));

- (BOOL)verifyingKeyPassphraseValid:(int)verifyingKeyIndex NS_SWIFT_NAME(verifyingKeyPassphraseValid(_:));

- (NSString*)verifyingKeyPrimaryKeyID:(int)verifyingKeyIndex NS_SWIFT_NAME(verifyingKeyPrimaryKeyID(_:));

- (int)verifyingKeyProtection:(int)verifyingKeyIndex NS_SWIFT_NAME(verifyingKeyProtection(_:));

- (NSString*)verifyingKeyPublicKeyAlgorithm:(int)verifyingKeyIndex NS_SWIFT_NAME(verifyingKeyPublicKeyAlgorithm(_:));

- (int)verifyingKeyQBits:(int)verifyingKeyIndex NS_SWIFT_NAME(verifyingKeyQBits(_:));

- (NSString*)verifyingKeyTimestamp:(int)verifyingKeyIndex NS_SWIFT_NAME(verifyingKeyTimestamp(_:));

- (NSString*)verifyingKeyUsername:(int)verifyingKeyIndex NS_SWIFT_NAME(verifyingKeyUsername(_:));

- (NSString*)verifyingKeyValidTo:(int)verifyingKeyIndex NS_SWIFT_NAME(verifyingKeyValidTo(_:));

- (int)verifyingKeyVersion:(int)verifyingKeyIndex NS_SWIFT_NAME(verifyingKeyVersion(_:));

  /* Methods */

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (void)decryptAndVerify NS_SWIFT_NAME(decryptAndVerify());

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (void)reset NS_SWIFT_NAME(reset());

- (void)verifyDetached NS_SWIFT_NAME(verifyDetached());

@end

