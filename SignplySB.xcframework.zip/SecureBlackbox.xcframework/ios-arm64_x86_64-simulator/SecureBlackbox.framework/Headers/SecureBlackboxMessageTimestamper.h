/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//PROXYAUTHTYPES
#define PAT_NO_AUTHENTICATION                              0

#define PAT_BASIC                                          1

#define PAT_DIGEST                                         2

#define PAT_NTLM                                           3

//PROXYTYPES
#define CPT_NONE                                           0

#define CPT_SOCKS_4                                        1

#define CPT_SOCKS_5                                        2

#define CPT_WEB_TUNNEL                                     3

#define CPT_HTTP                                           4

//DNSRESOLVEMODES
#define DM_AUTO                                            0

#define DM_PLATFORM                                        1

#define DM_OWN                                             2

#define DM_OWN_SECURE                                      3

//TIMESTAMPFORMATS
#define MTF_UNKNOWN                                        0

#define MTF_RFC5544                                        1

#define MTF_CMS                                            2

#define MTF_TSPREPLY                                       3

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

//SECURETRANSPORTPREDEFINEDCONFIGURATIONS
#define STPC_DEFAULT                                       0

#define STPC_COMPATIBLE                                    1

#define STPC_COMPREHENSIVE_INSECURE                        2

#define STPC_HIGHLY_SECURE                                 3

//CLIENTAUTHTYPES
#define CCAT_NO_AUTH                                       0

#define CCAT_REQUEST_CERT                                  1

#define CCAT_REQUIRE_CERT                                  2

//RENEGOTIATIONATTACKPREVENTIONMODES
#define CRAPM_COMPATIBLE                                   0

#define CRAPM_STRICT                                       1

#define CRAPM_AUTO                                         2

//REVOCATIONCHECKKINDS
#define CRC_NONE                                           0

#define CRC_AUTO                                           1

#define CRC_ALL_CRL                                        2

#define CRC_ALL_OCSP                                       3

#define CRC_ALL_CRLAND_OCSP                                4

#define CRC_ANY_CRL                                        5

#define CRC_ANY_OCSP                                       6

#define CRC_ANY_CRLOR_OCSP                                 7

#define CRC_ANY_OCSPOR_CRL                                 8

//SSLMODES
#define SM_DEFAULT                                         0

#define SM_NO_TLS                                          1

#define SM_EXPLICIT_TLS                                    2

#define SM_IMPLICIT_TLS                                    3

#define SM_MIXED_TLS                                       4

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxMessageTimestamperDelegate <NSObject>
@optional
- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onTimestampRequest:(NSString*)TSA :(NSString*)timestampRequest :(NSString**)timestampResponse :(int*)suppressDefault NS_SWIFT_NAME(onTimestampRequest(_:_:_:_:));

- (void)onTLSCertNeeded:(NSString*)host :(NSString*)CANames NS_SWIFT_NAME(onTLSCertNeeded(_:_:));

- (void)onTLSCertValidate:(NSString*)serverHost :(NSString*)serverIP :(int*)accept NS_SWIFT_NAME(onTLSCertValidate(_:_:_:));

- (void)onTLSEstablished:(NSString*)host :(NSString*)version :(NSString*)ciphersuite :(NSData*)connectionId :(int*)abort NS_SWIFT_NAME(onTLSEstablished(_:_:_:_:_:));

- (void)onTLSHandshake:(NSString*)host :(int*)abort NS_SWIFT_NAME(onTLSHandshake(_:_:));

- (void)onTLSShutdown:(NSString*)host NS_SWIFT_NAME(onTLSShutdown(_:));

@end

@interface SecureBlackboxMessageTimestamper : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxMessageTimestamperDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasError;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasTimestampRequest;

  BOOL m_delegateHasTLSCertNeeded;

  BOOL m_delegateHasTLSCertValidate;

  BOOL m_delegateHasTLSEstablished;

  BOOL m_delegateHasTLSHandshake;

  BOOL m_delegateHasTLSShutdown;

}

+ (SecureBlackboxMessageTimestamper*)messagetimestamper;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxMessageTimestamperDelegate> delegate;
- (id <SecureBlackboxMessageTimestamperDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxMessageTimestamperDelegate>)anObject;

  /* Events */

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onTimestampRequest:(NSString*)TSA :(NSString*)timestampRequest :(NSString**)timestampResponse :(int*)suppressDefault NS_SWIFT_NAME(onTimestampRequest(_:_:_:_:));

- (void)onTLSCertNeeded:(NSString*)host :(NSString*)CANames NS_SWIFT_NAME(onTLSCertNeeded(_:_:));

- (void)onTLSCertValidate:(NSString*)serverHost :(NSString*)serverIP :(int*)accept NS_SWIFT_NAME(onTLSCertValidate(_:_:_:));

- (void)onTLSEstablished:(NSString*)host :(NSString*)version :(NSString*)ciphersuite :(NSData*)connectionId :(int*)abort NS_SWIFT_NAME(onTLSEstablished(_:_:_:_:_:));

- (void)onTLSHandshake:(NSString*)host :(int*)abort NS_SWIFT_NAME(onTLSHandshake(_:_:));

- (void)onTLSShutdown:(NSString*)host NS_SWIFT_NAME(onTLSShutdown(_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readwrite,assign,getter=dataFileName,setter=setDataFileName:) NSString* dataFileName NS_SWIFT_NAME(dataFileName);

- (NSString*)dataFileName NS_SWIFT_NAME(dataFileName());
- (void)setDataFileName :(NSString*)newDataFileName NS_SWIFT_NAME(setDataFileName(_:));

@property (nonatomic,readwrite,assign,getter=dataURI,setter=setDataURI:) NSString* dataURI NS_SWIFT_NAME(dataURI);

- (NSString*)dataURI NS_SWIFT_NAME(dataURI());
- (void)setDataURI :(NSString*)newDataURI NS_SWIFT_NAME(setDataURI(_:));

@property (nonatomic,readwrite,assign,getter=detached,setter=setDetached:) BOOL detached NS_SWIFT_NAME(detached);

- (BOOL)detached NS_SWIFT_NAME(detached());
- (void)setDetached :(BOOL)newDetached NS_SWIFT_NAME(setDetached(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=hashAlgorithm,setter=setHashAlgorithm:) NSString* hashAlgorithm NS_SWIFT_NAME(hashAlgorithm);

- (NSString*)hashAlgorithm NS_SWIFT_NAME(hashAlgorithm());
- (void)setHashAlgorithm :(NSString*)newHashAlgorithm NS_SWIFT_NAME(setHashAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=inputBytes,setter=setInputBytes:) NSData* inputBytes NS_SWIFT_NAME(inputBytes);

- (NSData*)inputBytes NS_SWIFT_NAME(inputBytes());
- (void)setInputBytes :(NSData*)newInputBytes NS_SWIFT_NAME(setInputBytes(_:));

@property (nonatomic,readwrite,assign,getter=inputFile,setter=setInputFile:) NSString* inputFile NS_SWIFT_NAME(inputFile);

- (NSString*)inputFile NS_SWIFT_NAME(inputFile());
- (void)setInputFile :(NSString*)newInputFile NS_SWIFT_NAME(setInputFile(_:));

@property (nonatomic,readwrite,assign,getter=inputIsHash,setter=setInputIsHash:) BOOL inputIsHash NS_SWIFT_NAME(inputIsHash);

- (BOOL)inputIsHash NS_SWIFT_NAME(inputIsHash());
- (void)setInputIsHash :(BOOL)newInputIsHash NS_SWIFT_NAME(setInputIsHash(_:));

@property (nonatomic,readonly,assign,getter=outputBytes) NSData* outputBytes NS_SWIFT_NAME(outputBytes);

- (NSData*)outputBytes NS_SWIFT_NAME(outputBytes());

@property (nonatomic,readwrite,assign,getter=outputFile,setter=setOutputFile:) NSString* outputFile NS_SWIFT_NAME(outputFile);

- (NSString*)outputFile NS_SWIFT_NAME(outputFile());
- (void)setOutputFile :(NSString*)newOutputFile NS_SWIFT_NAME(setOutputFile(_:));

@property (nonatomic,readwrite,assign,getter=proxyAddress,setter=setProxyAddress:) NSString* proxyAddress NS_SWIFT_NAME(proxyAddress);

- (NSString*)proxyAddress NS_SWIFT_NAME(proxyAddress());
- (void)setProxyAddress :(NSString*)newProxyAddress NS_SWIFT_NAME(setProxyAddress(_:));

@property (nonatomic,readwrite,assign,getter=proxyAuthentication,setter=setProxyAuthentication:) int proxyAuthentication NS_SWIFT_NAME(proxyAuthentication);

- (int)proxyAuthentication NS_SWIFT_NAME(proxyAuthentication());
- (void)setProxyAuthentication :(int)newProxyAuthentication NS_SWIFT_NAME(setProxyAuthentication(_:));

@property (nonatomic,readwrite,assign,getter=proxyPassword,setter=setProxyPassword:) NSString* proxyPassword NS_SWIFT_NAME(proxyPassword);

- (NSString*)proxyPassword NS_SWIFT_NAME(proxyPassword());
- (void)setProxyPassword :(NSString*)newProxyPassword NS_SWIFT_NAME(setProxyPassword(_:));

@property (nonatomic,readwrite,assign,getter=proxyPort,setter=setProxyPort:) int proxyPort NS_SWIFT_NAME(proxyPort);

- (int)proxyPort NS_SWIFT_NAME(proxyPort());
- (void)setProxyPort :(int)newProxyPort NS_SWIFT_NAME(setProxyPort(_:));

@property (nonatomic,readwrite,assign,getter=proxyProxyType,setter=setProxyProxyType:) int proxyProxyType NS_SWIFT_NAME(proxyProxyType);

- (int)proxyProxyType NS_SWIFT_NAME(proxyProxyType());
- (void)setProxyProxyType :(int)newProxyProxyType NS_SWIFT_NAME(setProxyProxyType(_:));

@property (nonatomic,readwrite,assign,getter=proxyRequestHeaders,setter=setProxyRequestHeaders:) NSString* proxyRequestHeaders NS_SWIFT_NAME(proxyRequestHeaders);

- (NSString*)proxyRequestHeaders NS_SWIFT_NAME(proxyRequestHeaders());
- (void)setProxyRequestHeaders :(NSString*)newProxyRequestHeaders NS_SWIFT_NAME(setProxyRequestHeaders(_:));

@property (nonatomic,readwrite,assign,getter=proxyResponseBody,setter=setProxyResponseBody:) NSString* proxyResponseBody NS_SWIFT_NAME(proxyResponseBody);

- (NSString*)proxyResponseBody NS_SWIFT_NAME(proxyResponseBody());
- (void)setProxyResponseBody :(NSString*)newProxyResponseBody NS_SWIFT_NAME(setProxyResponseBody(_:));

@property (nonatomic,readwrite,assign,getter=proxyResponseHeaders,setter=setProxyResponseHeaders:) NSString* proxyResponseHeaders NS_SWIFT_NAME(proxyResponseHeaders);

- (NSString*)proxyResponseHeaders NS_SWIFT_NAME(proxyResponseHeaders());
- (void)setProxyResponseHeaders :(NSString*)newProxyResponseHeaders NS_SWIFT_NAME(setProxyResponseHeaders(_:));

@property (nonatomic,readwrite,assign,getter=proxyUseIPv6,setter=setProxyUseIPv6:) BOOL proxyUseIPv6 NS_SWIFT_NAME(proxyUseIPv6);

- (BOOL)proxyUseIPv6 NS_SWIFT_NAME(proxyUseIPv6());
- (void)setProxyUseIPv6 :(BOOL)newProxyUseIPv6 NS_SWIFT_NAME(setProxyUseIPv6(_:));

@property (nonatomic,readwrite,assign,getter=proxyUsername,setter=setProxyUsername:) NSString* proxyUsername NS_SWIFT_NAME(proxyUsername);

- (NSString*)proxyUsername NS_SWIFT_NAME(proxyUsername());
- (void)setProxyUsername :(NSString*)newProxyUsername NS_SWIFT_NAME(setProxyUsername(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSMode,setter=setSocketDNSMode:) int socketDNSMode NS_SWIFT_NAME(socketDNSMode);

- (int)socketDNSMode NS_SWIFT_NAME(socketDNSMode());
- (void)setSocketDNSMode :(int)newSocketDNSMode NS_SWIFT_NAME(setSocketDNSMode(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSPort,setter=setSocketDNSPort:) int socketDNSPort NS_SWIFT_NAME(socketDNSPort);

- (int)socketDNSPort NS_SWIFT_NAME(socketDNSPort());
- (void)setSocketDNSPort :(int)newSocketDNSPort NS_SWIFT_NAME(setSocketDNSPort(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSQueryTimeout,setter=setSocketDNSQueryTimeout:) int socketDNSQueryTimeout NS_SWIFT_NAME(socketDNSQueryTimeout);

- (int)socketDNSQueryTimeout NS_SWIFT_NAME(socketDNSQueryTimeout());
- (void)setSocketDNSQueryTimeout :(int)newSocketDNSQueryTimeout NS_SWIFT_NAME(setSocketDNSQueryTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSServers,setter=setSocketDNSServers:) NSString* socketDNSServers NS_SWIFT_NAME(socketDNSServers);

- (NSString*)socketDNSServers NS_SWIFT_NAME(socketDNSServers());
- (void)setSocketDNSServers :(NSString*)newSocketDNSServers NS_SWIFT_NAME(setSocketDNSServers(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSTotalTimeout,setter=setSocketDNSTotalTimeout:) int socketDNSTotalTimeout NS_SWIFT_NAME(socketDNSTotalTimeout);

- (int)socketDNSTotalTimeout NS_SWIFT_NAME(socketDNSTotalTimeout());
- (void)setSocketDNSTotalTimeout :(int)newSocketDNSTotalTimeout NS_SWIFT_NAME(setSocketDNSTotalTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketIncomingSpeedLimit,setter=setSocketIncomingSpeedLimit:) int socketIncomingSpeedLimit NS_SWIFT_NAME(socketIncomingSpeedLimit);

- (int)socketIncomingSpeedLimit NS_SWIFT_NAME(socketIncomingSpeedLimit());
- (void)setSocketIncomingSpeedLimit :(int)newSocketIncomingSpeedLimit NS_SWIFT_NAME(setSocketIncomingSpeedLimit(_:));

@property (nonatomic,readwrite,assign,getter=socketLocalAddress,setter=setSocketLocalAddress:) NSString* socketLocalAddress NS_SWIFT_NAME(socketLocalAddress);

- (NSString*)socketLocalAddress NS_SWIFT_NAME(socketLocalAddress());
- (void)setSocketLocalAddress :(NSString*)newSocketLocalAddress NS_SWIFT_NAME(setSocketLocalAddress(_:));

@property (nonatomic,readwrite,assign,getter=socketLocalPort,setter=setSocketLocalPort:) int socketLocalPort NS_SWIFT_NAME(socketLocalPort);

- (int)socketLocalPort NS_SWIFT_NAME(socketLocalPort());
- (void)setSocketLocalPort :(int)newSocketLocalPort NS_SWIFT_NAME(setSocketLocalPort(_:));

@property (nonatomic,readwrite,assign,getter=socketOutgoingSpeedLimit,setter=setSocketOutgoingSpeedLimit:) int socketOutgoingSpeedLimit NS_SWIFT_NAME(socketOutgoingSpeedLimit);

- (int)socketOutgoingSpeedLimit NS_SWIFT_NAME(socketOutgoingSpeedLimit());
- (void)setSocketOutgoingSpeedLimit :(int)newSocketOutgoingSpeedLimit NS_SWIFT_NAME(setSocketOutgoingSpeedLimit(_:));

@property (nonatomic,readwrite,assign,getter=socketTimeout,setter=setSocketTimeout:) int socketTimeout NS_SWIFT_NAME(socketTimeout);

- (int)socketTimeout NS_SWIFT_NAME(socketTimeout());
- (void)setSocketTimeout :(int)newSocketTimeout NS_SWIFT_NAME(setSocketTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketUseIPv6,setter=setSocketUseIPv6:) BOOL socketUseIPv6 NS_SWIFT_NAME(socketUseIPv6);

- (BOOL)socketUseIPv6 NS_SWIFT_NAME(socketUseIPv6());
- (void)setSocketUseIPv6 :(BOOL)newSocketUseIPv6 NS_SWIFT_NAME(setSocketUseIPv6(_:));

@property (nonatomic,readwrite,assign,getter=timestampFormat,setter=setTimestampFormat:) int timestampFormat NS_SWIFT_NAME(timestampFormat);

- (int)timestampFormat NS_SWIFT_NAME(timestampFormat());
- (void)setTimestampFormat :(int)newTimestampFormat NS_SWIFT_NAME(setTimestampFormat(_:));

@property (nonatomic,readwrite,assign,getter=timestampServer,setter=setTimestampServer:) NSString* timestampServer NS_SWIFT_NAME(timestampServer);

- (NSString*)timestampServer NS_SWIFT_NAME(timestampServer());
- (void)setTimestampServer :(NSString*)newTimestampServer NS_SWIFT_NAME(setTimestampServer(_:));

@property (nonatomic,readwrite,assign,getter=TLSClientCertCount,setter=setTLSClientCertCount:) int TLSClientCertCount NS_SWIFT_NAME(TLSClientCertCount);

- (int)TLSClientCertCount NS_SWIFT_NAME(TLSClientCertCount());
- (void)setTLSClientCertCount :(int)newTLSClientCertCount NS_SWIFT_NAME(setTLSClientCertCount(_:));

- (NSData*)TLSClientCertBytes:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertBytes(_:));

- (BOOL)TLSClientCertCA:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCA(_:));
- (void)setTLSClientCertCA:(int)tLSClientCertIndex :(BOOL)newTLSClientCertCA NS_SWIFT_NAME(setTLSClientCertCA(_:_:));

- (NSData*)TLSClientCertCAKeyID:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCAKeyID(_:));

- (int)TLSClientCertCertType:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCertType(_:));

- (NSString*)TLSClientCertCRLDistributionPoints:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCRLDistributionPoints(_:));
- (void)setTLSClientCertCRLDistributionPoints:(int)tLSClientCertIndex :(NSString*)newTLSClientCertCRLDistributionPoints NS_SWIFT_NAME(setTLSClientCertCRLDistributionPoints(_:_:));

- (NSString*)TLSClientCertCurve:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCurve(_:));
- (void)setTLSClientCertCurve:(int)tLSClientCertIndex :(NSString*)newTLSClientCertCurve NS_SWIFT_NAME(setTLSClientCertCurve(_:_:));

- (NSString*)TLSClientCertFingerprint:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertFingerprint(_:));

- (NSString*)TLSClientCertFriendlyName:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertFriendlyName(_:));

- (long long)TLSClientCertHandle:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertHandle(_:));
- (void)setTLSClientCertHandle:(int)tLSClientCertIndex :(long long)newTLSClientCertHandle NS_SWIFT_NAME(setTLSClientCertHandle(_:_:));

- (NSString*)TLSClientCertHashAlgorithm:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertHashAlgorithm(_:));
- (void)setTLSClientCertHashAlgorithm:(int)tLSClientCertIndex :(NSString*)newTLSClientCertHashAlgorithm NS_SWIFT_NAME(setTLSClientCertHashAlgorithm(_:_:));

- (NSString*)TLSClientCertIssuer:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertIssuer(_:));

- (NSString*)TLSClientCertIssuerRDN:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertIssuerRDN(_:));
- (void)setTLSClientCertIssuerRDN:(int)tLSClientCertIndex :(NSString*)newTLSClientCertIssuerRDN NS_SWIFT_NAME(setTLSClientCertIssuerRDN(_:_:));

- (NSString*)TLSClientCertKeyAlgorithm:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyAlgorithm(_:));
- (void)setTLSClientCertKeyAlgorithm:(int)tLSClientCertIndex :(NSString*)newTLSClientCertKeyAlgorithm NS_SWIFT_NAME(setTLSClientCertKeyAlgorithm(_:_:));

- (int)TLSClientCertKeyBits:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyBits(_:));

- (NSString*)TLSClientCertKeyFingerprint:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyFingerprint(_:));

- (int)TLSClientCertKeyUsage:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyUsage(_:));
- (void)setTLSClientCertKeyUsage:(int)tLSClientCertIndex :(int)newTLSClientCertKeyUsage NS_SWIFT_NAME(setTLSClientCertKeyUsage(_:_:));

- (BOOL)TLSClientCertKeyValid:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyValid(_:));

- (NSString*)TLSClientCertOCSPLocations:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertOCSPLocations(_:));
- (void)setTLSClientCertOCSPLocations:(int)tLSClientCertIndex :(NSString*)newTLSClientCertOCSPLocations NS_SWIFT_NAME(setTLSClientCertOCSPLocations(_:_:));

- (BOOL)TLSClientCertOCSPNoCheck:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertOCSPNoCheck(_:));
- (void)setTLSClientCertOCSPNoCheck:(int)tLSClientCertIndex :(BOOL)newTLSClientCertOCSPNoCheck NS_SWIFT_NAME(setTLSClientCertOCSPNoCheck(_:_:));

- (int)TLSClientCertOrigin:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertOrigin(_:));

- (NSString*)TLSClientCertPolicyIDs:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPolicyIDs(_:));
- (void)setTLSClientCertPolicyIDs:(int)tLSClientCertIndex :(NSString*)newTLSClientCertPolicyIDs NS_SWIFT_NAME(setTLSClientCertPolicyIDs(_:_:));

- (NSData*)TLSClientCertPrivateKeyBytes:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPrivateKeyBytes(_:));

- (BOOL)TLSClientCertPrivateKeyExists:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPrivateKeyExists(_:));

- (BOOL)TLSClientCertPrivateKeyExtractable:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPrivateKeyExtractable(_:));

- (NSData*)TLSClientCertPublicKeyBytes:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPublicKeyBytes(_:));

- (BOOL)TLSClientCertQualified:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertQualified(_:));

- (int)TLSClientCertQualifiedStatements:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertQualifiedStatements(_:));
- (void)setTLSClientCertQualifiedStatements:(int)tLSClientCertIndex :(int)newTLSClientCertQualifiedStatements NS_SWIFT_NAME(setTLSClientCertQualifiedStatements(_:_:));

- (NSString*)TLSClientCertQualifiers:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertQualifiers(_:));

- (BOOL)TLSClientCertSelfSigned:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSelfSigned(_:));

- (NSData*)TLSClientCertSerialNumber:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSerialNumber(_:));
- (void)setTLSClientCertSerialNumber:(int)tLSClientCertIndex :(NSData*)newTLSClientCertSerialNumber NS_SWIFT_NAME(setTLSClientCertSerialNumber(_:_:));

- (NSString*)TLSClientCertSigAlgorithm:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSigAlgorithm(_:));

- (int)TLSClientCertSource:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSource(_:));

- (NSString*)TLSClientCertSubject:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSubject(_:));

- (NSString*)TLSClientCertSubjectAlternativeName:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSubjectAlternativeName(_:));
- (void)setTLSClientCertSubjectAlternativeName:(int)tLSClientCertIndex :(NSString*)newTLSClientCertSubjectAlternativeName NS_SWIFT_NAME(setTLSClientCertSubjectAlternativeName(_:_:));

- (NSData*)TLSClientCertSubjectKeyID:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSubjectKeyID(_:));
- (void)setTLSClientCertSubjectKeyID:(int)tLSClientCertIndex :(NSData*)newTLSClientCertSubjectKeyID NS_SWIFT_NAME(setTLSClientCertSubjectKeyID(_:_:));

- (NSString*)TLSClientCertSubjectRDN:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSubjectRDN(_:));
- (void)setTLSClientCertSubjectRDN:(int)tLSClientCertIndex :(NSString*)newTLSClientCertSubjectRDN NS_SWIFT_NAME(setTLSClientCertSubjectRDN(_:_:));

- (BOOL)TLSClientCertValid:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertValid(_:));

- (NSString*)TLSClientCertValidFrom:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertValidFrom(_:));
- (void)setTLSClientCertValidFrom:(int)tLSClientCertIndex :(NSString*)newTLSClientCertValidFrom NS_SWIFT_NAME(setTLSClientCertValidFrom(_:_:));

- (NSString*)TLSClientCertValidTo:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertValidTo(_:));
- (void)setTLSClientCertValidTo:(int)tLSClientCertIndex :(NSString*)newTLSClientCertValidTo NS_SWIFT_NAME(setTLSClientCertValidTo(_:_:));

@property (nonatomic,readonly,assign,getter=TLSServerCertCount) int TLSServerCertCount NS_SWIFT_NAME(TLSServerCertCount);

- (int)TLSServerCertCount NS_SWIFT_NAME(TLSServerCertCount());

- (NSData*)TLSServerCertBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertBytes(_:));

- (BOOL)TLSServerCertCA:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCA(_:));

- (NSData*)TLSServerCertCAKeyID:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCAKeyID(_:));

- (int)TLSServerCertCertType:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCertType(_:));

- (NSString*)TLSServerCertCRLDistributionPoints:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCRLDistributionPoints(_:));

- (NSString*)TLSServerCertCurve:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCurve(_:));

- (NSString*)TLSServerCertFingerprint:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertFingerprint(_:));

- (NSString*)TLSServerCertFriendlyName:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertFriendlyName(_:));

- (long long)TLSServerCertHandle:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertHandle(_:));

- (NSString*)TLSServerCertHashAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertHashAlgorithm(_:));

- (NSString*)TLSServerCertIssuer:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertIssuer(_:));

- (NSString*)TLSServerCertIssuerRDN:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertIssuerRDN(_:));

- (NSString*)TLSServerCertKeyAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyAlgorithm(_:));

- (int)TLSServerCertKeyBits:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyBits(_:));

- (NSString*)TLSServerCertKeyFingerprint:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyFingerprint(_:));

- (int)TLSServerCertKeyUsage:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyUsage(_:));

- (BOOL)TLSServerCertKeyValid:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyValid(_:));

- (NSString*)TLSServerCertOCSPLocations:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOCSPLocations(_:));

- (BOOL)TLSServerCertOCSPNoCheck:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOCSPNoCheck(_:));

- (int)TLSServerCertOrigin:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOrigin(_:));

- (NSString*)TLSServerCertPolicyIDs:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPolicyIDs(_:));

- (NSData*)TLSServerCertPrivateKeyBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyBytes(_:));

- (BOOL)TLSServerCertPrivateKeyExists:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyExists(_:));

- (BOOL)TLSServerCertPrivateKeyExtractable:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyExtractable(_:));

- (NSData*)TLSServerCertPublicKeyBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPublicKeyBytes(_:));

- (BOOL)TLSServerCertQualified:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualified(_:));

- (int)TLSServerCertQualifiedStatements:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualifiedStatements(_:));

- (NSString*)TLSServerCertQualifiers:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualifiers(_:));

- (BOOL)TLSServerCertSelfSigned:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSelfSigned(_:));

- (NSData*)TLSServerCertSerialNumber:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSerialNumber(_:));

- (NSString*)TLSServerCertSigAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSigAlgorithm(_:));

- (int)TLSServerCertSource:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSource(_:));

- (NSString*)TLSServerCertSubject:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubject(_:));

- (NSString*)TLSServerCertSubjectAlternativeName:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectAlternativeName(_:));

- (NSData*)TLSServerCertSubjectKeyID:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectKeyID(_:));

- (NSString*)TLSServerCertSubjectRDN:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectRDN(_:));

- (BOOL)TLSServerCertValid:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValid(_:));

- (NSString*)TLSServerCertValidFrom:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValidFrom(_:));

- (NSString*)TLSServerCertValidTo:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValidTo(_:));

@property (nonatomic,readwrite,assign,getter=TLSAutoValidateCertificates,setter=setTLSAutoValidateCertificates:) BOOL TLSAutoValidateCertificates NS_SWIFT_NAME(TLSAutoValidateCertificates);

- (BOOL)TLSAutoValidateCertificates NS_SWIFT_NAME(TLSAutoValidateCertificates());
- (void)setTLSAutoValidateCertificates :(BOOL)newTLSAutoValidateCertificates NS_SWIFT_NAME(setTLSAutoValidateCertificates(_:));

@property (nonatomic,readwrite,assign,getter=TLSBaseConfiguration,setter=setTLSBaseConfiguration:) int TLSBaseConfiguration NS_SWIFT_NAME(TLSBaseConfiguration);

- (int)TLSBaseConfiguration NS_SWIFT_NAME(TLSBaseConfiguration());
- (void)setTLSBaseConfiguration :(int)newTLSBaseConfiguration NS_SWIFT_NAME(setTLSBaseConfiguration(_:));

@property (nonatomic,readwrite,assign,getter=TLSCiphersuites,setter=setTLSCiphersuites:) NSString* TLSCiphersuites NS_SWIFT_NAME(TLSCiphersuites);

- (NSString*)TLSCiphersuites NS_SWIFT_NAME(TLSCiphersuites());
- (void)setTLSCiphersuites :(NSString*)newTLSCiphersuites NS_SWIFT_NAME(setTLSCiphersuites(_:));

@property (nonatomic,readwrite,assign,getter=TLSClientAuth,setter=setTLSClientAuth:) int TLSClientAuth NS_SWIFT_NAME(TLSClientAuth);

- (int)TLSClientAuth NS_SWIFT_NAME(TLSClientAuth());
- (void)setTLSClientAuth :(int)newTLSClientAuth NS_SWIFT_NAME(setTLSClientAuth(_:));

@property (nonatomic,readwrite,assign,getter=TLSECCurves,setter=setTLSECCurves:) NSString* TLSECCurves NS_SWIFT_NAME(TLSECCurves);

- (NSString*)TLSECCurves NS_SWIFT_NAME(TLSECCurves());
- (void)setTLSECCurves :(NSString*)newTLSECCurves NS_SWIFT_NAME(setTLSECCurves(_:));

@property (nonatomic,readwrite,assign,getter=TLSExtensions,setter=setTLSExtensions:) NSString* TLSExtensions NS_SWIFT_NAME(TLSExtensions);

- (NSString*)TLSExtensions NS_SWIFT_NAME(TLSExtensions());
- (void)setTLSExtensions :(NSString*)newTLSExtensions NS_SWIFT_NAME(setTLSExtensions(_:));

@property (nonatomic,readwrite,assign,getter=TLSForceResumeIfDestinationChanges,setter=setTLSForceResumeIfDestinationChanges:) BOOL TLSForceResumeIfDestinationChanges NS_SWIFT_NAME(TLSForceResumeIfDestinationChanges);

- (BOOL)TLSForceResumeIfDestinationChanges NS_SWIFT_NAME(TLSForceResumeIfDestinationChanges());
- (void)setTLSForceResumeIfDestinationChanges :(BOOL)newTLSForceResumeIfDestinationChanges NS_SWIFT_NAME(setTLSForceResumeIfDestinationChanges(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedIdentity,setter=setTLSPreSharedIdentity:) NSString* TLSPreSharedIdentity NS_SWIFT_NAME(TLSPreSharedIdentity);

- (NSString*)TLSPreSharedIdentity NS_SWIFT_NAME(TLSPreSharedIdentity());
- (void)setTLSPreSharedIdentity :(NSString*)newTLSPreSharedIdentity NS_SWIFT_NAME(setTLSPreSharedIdentity(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedKey,setter=setTLSPreSharedKey:) NSString* TLSPreSharedKey NS_SWIFT_NAME(TLSPreSharedKey);

- (NSString*)TLSPreSharedKey NS_SWIFT_NAME(TLSPreSharedKey());
- (void)setTLSPreSharedKey :(NSString*)newTLSPreSharedKey NS_SWIFT_NAME(setTLSPreSharedKey(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedKeyCiphersuite,setter=setTLSPreSharedKeyCiphersuite:) NSString* TLSPreSharedKeyCiphersuite NS_SWIFT_NAME(TLSPreSharedKeyCiphersuite);

- (NSString*)TLSPreSharedKeyCiphersuite NS_SWIFT_NAME(TLSPreSharedKeyCiphersuite());
- (void)setTLSPreSharedKeyCiphersuite :(NSString*)newTLSPreSharedKeyCiphersuite NS_SWIFT_NAME(setTLSPreSharedKeyCiphersuite(_:));

@property (nonatomic,readwrite,assign,getter=TLSRenegotiationAttackPreventionMode,setter=setTLSRenegotiationAttackPreventionMode:) int TLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(TLSRenegotiationAttackPreventionMode);

- (int)TLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(TLSRenegotiationAttackPreventionMode());
- (void)setTLSRenegotiationAttackPreventionMode :(int)newTLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(setTLSRenegotiationAttackPreventionMode(_:));

@property (nonatomic,readwrite,assign,getter=TLSRevocationCheck,setter=setTLSRevocationCheck:) int TLSRevocationCheck NS_SWIFT_NAME(TLSRevocationCheck);

- (int)TLSRevocationCheck NS_SWIFT_NAME(TLSRevocationCheck());
- (void)setTLSRevocationCheck :(int)newTLSRevocationCheck NS_SWIFT_NAME(setTLSRevocationCheck(_:));

@property (nonatomic,readwrite,assign,getter=TLSSSLOptions,setter=setTLSSSLOptions:) int TLSSSLOptions NS_SWIFT_NAME(TLSSSLOptions);

- (int)TLSSSLOptions NS_SWIFT_NAME(TLSSSLOptions());
- (void)setTLSSSLOptions :(int)newTLSSSLOptions NS_SWIFT_NAME(setTLSSSLOptions(_:));

@property (nonatomic,readwrite,assign,getter=TLSTLSMode,setter=setTLSTLSMode:) int TLSTLSMode NS_SWIFT_NAME(TLSTLSMode);

- (int)TLSTLSMode NS_SWIFT_NAME(TLSTLSMode());
- (void)setTLSTLSMode :(int)newTLSTLSMode NS_SWIFT_NAME(setTLSTLSMode(_:));

@property (nonatomic,readwrite,assign,getter=TLSUseExtendedMasterSecret,setter=setTLSUseExtendedMasterSecret:) BOOL TLSUseExtendedMasterSecret NS_SWIFT_NAME(TLSUseExtendedMasterSecret);

- (BOOL)TLSUseExtendedMasterSecret NS_SWIFT_NAME(TLSUseExtendedMasterSecret());
- (void)setTLSUseExtendedMasterSecret :(BOOL)newTLSUseExtendedMasterSecret NS_SWIFT_NAME(setTLSUseExtendedMasterSecret(_:));

@property (nonatomic,readwrite,assign,getter=TLSUseSessionResumption,setter=setTLSUseSessionResumption:) BOOL TLSUseSessionResumption NS_SWIFT_NAME(TLSUseSessionResumption);

- (BOOL)TLSUseSessionResumption NS_SWIFT_NAME(TLSUseSessionResumption());
- (void)setTLSUseSessionResumption :(BOOL)newTLSUseSessionResumption NS_SWIFT_NAME(setTLSUseSessionResumption(_:));

@property (nonatomic,readwrite,assign,getter=TLSVersions,setter=setTLSVersions:) int TLSVersions NS_SWIFT_NAME(TLSVersions);

- (int)TLSVersions NS_SWIFT_NAME(TLSVersions());
- (void)setTLSVersions :(int)newTLSVersions NS_SWIFT_NAME(setTLSVersions(_:));

  /* Methods */

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (void)reset NS_SWIFT_NAME(reset());

- (void)timestamp NS_SWIFT_NAME(timestamp());

@end

