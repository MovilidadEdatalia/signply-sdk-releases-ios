/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

//ASYNCSIGNMETHODS
#define ASMD_PKCS1                                         0

#define ASMD_PKCS7                                         1

//EXTERNALCRYPTOMODES
#define ECM_DEFAULT                                        0

#define ECM_DISABLED                                       1

#define ECM_GENERIC                                        2

#define ECM_DCAUTH                                         3

#define ECM_DCAUTH_JSON                                    4

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxCertificateManagerDelegate <NSObject>
@optional
- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onExternalSign:(NSString*)operationId :(NSString*)hashAlgorithm :(NSString*)pars :(NSString*)data :(NSString**)signedData NS_SWIFT_NAME(onExternalSign(_:_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onPasswordNeeded:(NSString**)password :(int*)cancel NS_SWIFT_NAME(onPasswordNeeded(_:_:));

@end

@interface SecureBlackboxCertificateManager : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxCertificateManagerDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasError;

  BOOL m_delegateHasExternalSign;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasPasswordNeeded;

}

+ (SecureBlackboxCertificateManager*)certificatemanager;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxCertificateManagerDelegate> delegate;
- (id <SecureBlackboxCertificateManagerDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxCertificateManagerDelegate>)anObject;

  /* Events */

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onExternalSign:(NSString*)operationId :(NSString*)hashAlgorithm :(NSString*)pars :(NSString*)data :(NSString**)signedData NS_SWIFT_NAME(onExternalSign(_:_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onPasswordNeeded:(NSString**)password :(int*)cancel NS_SWIFT_NAME(onPasswordNeeded(_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readonly,assign,getter=CACertBytes) NSData* CACertBytes NS_SWIFT_NAME(CACertBytes);

- (NSData*)CACertBytes NS_SWIFT_NAME(CACertBytes());

@property (nonatomic,readwrite,assign,getter=CACertCA,setter=setCACertCA:) BOOL CACertCA NS_SWIFT_NAME(CACertCA);

- (BOOL)CACertCA NS_SWIFT_NAME(CACertCA());
- (void)setCACertCA :(BOOL)newCACertCA NS_SWIFT_NAME(setCACertCA(_:));

@property (nonatomic,readonly,assign,getter=CACertCAKeyID) NSData* CACertCAKeyID NS_SWIFT_NAME(CACertCAKeyID);

- (NSData*)CACertCAKeyID NS_SWIFT_NAME(CACertCAKeyID());

@property (nonatomic,readonly,assign,getter=CACertCertType) int CACertCertType NS_SWIFT_NAME(CACertCertType);

- (int)CACertCertType NS_SWIFT_NAME(CACertCertType());

@property (nonatomic,readwrite,assign,getter=CACertCRLDistributionPoints,setter=setCACertCRLDistributionPoints:) NSString* CACertCRLDistributionPoints NS_SWIFT_NAME(CACertCRLDistributionPoints);

- (NSString*)CACertCRLDistributionPoints NS_SWIFT_NAME(CACertCRLDistributionPoints());
- (void)setCACertCRLDistributionPoints :(NSString*)newCACertCRLDistributionPoints NS_SWIFT_NAME(setCACertCRLDistributionPoints(_:));

@property (nonatomic,readwrite,assign,getter=CACertCurve,setter=setCACertCurve:) NSString* CACertCurve NS_SWIFT_NAME(CACertCurve);

- (NSString*)CACertCurve NS_SWIFT_NAME(CACertCurve());
- (void)setCACertCurve :(NSString*)newCACertCurve NS_SWIFT_NAME(setCACertCurve(_:));

@property (nonatomic,readonly,assign,getter=CACertFingerprint) NSString* CACertFingerprint NS_SWIFT_NAME(CACertFingerprint);

- (NSString*)CACertFingerprint NS_SWIFT_NAME(CACertFingerprint());

@property (nonatomic,readonly,assign,getter=CACertFriendlyName) NSString* CACertFriendlyName NS_SWIFT_NAME(CACertFriendlyName);

- (NSString*)CACertFriendlyName NS_SWIFT_NAME(CACertFriendlyName());

@property (nonatomic,readwrite,assign,getter=CACertHandle,setter=setCACertHandle:) long long CACertHandle NS_SWIFT_NAME(CACertHandle);

- (long long)CACertHandle NS_SWIFT_NAME(CACertHandle());
- (void)setCACertHandle :(long long)newCACertHandle NS_SWIFT_NAME(setCACertHandle(_:));

@property (nonatomic,readwrite,assign,getter=CACertHashAlgorithm,setter=setCACertHashAlgorithm:) NSString* CACertHashAlgorithm NS_SWIFT_NAME(CACertHashAlgorithm);

- (NSString*)CACertHashAlgorithm NS_SWIFT_NAME(CACertHashAlgorithm());
- (void)setCACertHashAlgorithm :(NSString*)newCACertHashAlgorithm NS_SWIFT_NAME(setCACertHashAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=CACertIssuer) NSString* CACertIssuer NS_SWIFT_NAME(CACertIssuer);

- (NSString*)CACertIssuer NS_SWIFT_NAME(CACertIssuer());

@property (nonatomic,readwrite,assign,getter=CACertIssuerRDN,setter=setCACertIssuerRDN:) NSString* CACertIssuerRDN NS_SWIFT_NAME(CACertIssuerRDN);

- (NSString*)CACertIssuerRDN NS_SWIFT_NAME(CACertIssuerRDN());
- (void)setCACertIssuerRDN :(NSString*)newCACertIssuerRDN NS_SWIFT_NAME(setCACertIssuerRDN(_:));

@property (nonatomic,readwrite,assign,getter=CACertKeyAlgorithm,setter=setCACertKeyAlgorithm:) NSString* CACertKeyAlgorithm NS_SWIFT_NAME(CACertKeyAlgorithm);

- (NSString*)CACertKeyAlgorithm NS_SWIFT_NAME(CACertKeyAlgorithm());
- (void)setCACertKeyAlgorithm :(NSString*)newCACertKeyAlgorithm NS_SWIFT_NAME(setCACertKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=CACertKeyBits) int CACertKeyBits NS_SWIFT_NAME(CACertKeyBits);

- (int)CACertKeyBits NS_SWIFT_NAME(CACertKeyBits());

@property (nonatomic,readonly,assign,getter=CACertKeyFingerprint) NSString* CACertKeyFingerprint NS_SWIFT_NAME(CACertKeyFingerprint);

- (NSString*)CACertKeyFingerprint NS_SWIFT_NAME(CACertKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=CACertKeyUsage,setter=setCACertKeyUsage:) int CACertKeyUsage NS_SWIFT_NAME(CACertKeyUsage);

- (int)CACertKeyUsage NS_SWIFT_NAME(CACertKeyUsage());
- (void)setCACertKeyUsage :(int)newCACertKeyUsage NS_SWIFT_NAME(setCACertKeyUsage(_:));

@property (nonatomic,readonly,assign,getter=CACertKeyValid) BOOL CACertKeyValid NS_SWIFT_NAME(CACertKeyValid);

- (BOOL)CACertKeyValid NS_SWIFT_NAME(CACertKeyValid());

@property (nonatomic,readwrite,assign,getter=CACertOCSPLocations,setter=setCACertOCSPLocations:) NSString* CACertOCSPLocations NS_SWIFT_NAME(CACertOCSPLocations);

- (NSString*)CACertOCSPLocations NS_SWIFT_NAME(CACertOCSPLocations());
- (void)setCACertOCSPLocations :(NSString*)newCACertOCSPLocations NS_SWIFT_NAME(setCACertOCSPLocations(_:));

@property (nonatomic,readwrite,assign,getter=CACertOCSPNoCheck,setter=setCACertOCSPNoCheck:) BOOL CACertOCSPNoCheck NS_SWIFT_NAME(CACertOCSPNoCheck);

- (BOOL)CACertOCSPNoCheck NS_SWIFT_NAME(CACertOCSPNoCheck());
- (void)setCACertOCSPNoCheck :(BOOL)newCACertOCSPNoCheck NS_SWIFT_NAME(setCACertOCSPNoCheck(_:));

@property (nonatomic,readonly,assign,getter=CACertOrigin) int CACertOrigin NS_SWIFT_NAME(CACertOrigin);

- (int)CACertOrigin NS_SWIFT_NAME(CACertOrigin());

@property (nonatomic,readwrite,assign,getter=CACertPolicyIDs,setter=setCACertPolicyIDs:) NSString* CACertPolicyIDs NS_SWIFT_NAME(CACertPolicyIDs);

- (NSString*)CACertPolicyIDs NS_SWIFT_NAME(CACertPolicyIDs());
- (void)setCACertPolicyIDs :(NSString*)newCACertPolicyIDs NS_SWIFT_NAME(setCACertPolicyIDs(_:));

@property (nonatomic,readonly,assign,getter=CACertPrivateKeyBytes) NSData* CACertPrivateKeyBytes NS_SWIFT_NAME(CACertPrivateKeyBytes);

- (NSData*)CACertPrivateKeyBytes NS_SWIFT_NAME(CACertPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=CACertPrivateKeyExists) BOOL CACertPrivateKeyExists NS_SWIFT_NAME(CACertPrivateKeyExists);

- (BOOL)CACertPrivateKeyExists NS_SWIFT_NAME(CACertPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=CACertPrivateKeyExtractable) BOOL CACertPrivateKeyExtractable NS_SWIFT_NAME(CACertPrivateKeyExtractable);

- (BOOL)CACertPrivateKeyExtractable NS_SWIFT_NAME(CACertPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=CACertPublicKeyBytes) NSData* CACertPublicKeyBytes NS_SWIFT_NAME(CACertPublicKeyBytes);

- (NSData*)CACertPublicKeyBytes NS_SWIFT_NAME(CACertPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=CACertQualified) BOOL CACertQualified NS_SWIFT_NAME(CACertQualified);

- (BOOL)CACertQualified NS_SWIFT_NAME(CACertQualified());

@property (nonatomic,readwrite,assign,getter=CACertQualifiedStatements,setter=setCACertQualifiedStatements:) int CACertQualifiedStatements NS_SWIFT_NAME(CACertQualifiedStatements);

- (int)CACertQualifiedStatements NS_SWIFT_NAME(CACertQualifiedStatements());
- (void)setCACertQualifiedStatements :(int)newCACertQualifiedStatements NS_SWIFT_NAME(setCACertQualifiedStatements(_:));

@property (nonatomic,readonly,assign,getter=CACertQualifiers) NSString* CACertQualifiers NS_SWIFT_NAME(CACertQualifiers);

- (NSString*)CACertQualifiers NS_SWIFT_NAME(CACertQualifiers());

@property (nonatomic,readonly,assign,getter=CACertSelfSigned) BOOL CACertSelfSigned NS_SWIFT_NAME(CACertSelfSigned);

- (BOOL)CACertSelfSigned NS_SWIFT_NAME(CACertSelfSigned());

@property (nonatomic,readwrite,assign,getter=CACertSerialNumber,setter=setCACertSerialNumber:) NSData* CACertSerialNumber NS_SWIFT_NAME(CACertSerialNumber);

- (NSData*)CACertSerialNumber NS_SWIFT_NAME(CACertSerialNumber());
- (void)setCACertSerialNumber :(NSData*)newCACertSerialNumber NS_SWIFT_NAME(setCACertSerialNumber(_:));

@property (nonatomic,readonly,assign,getter=CACertSigAlgorithm) NSString* CACertSigAlgorithm NS_SWIFT_NAME(CACertSigAlgorithm);

- (NSString*)CACertSigAlgorithm NS_SWIFT_NAME(CACertSigAlgorithm());

@property (nonatomic,readonly,assign,getter=CACertSource) int CACertSource NS_SWIFT_NAME(CACertSource);

- (int)CACertSource NS_SWIFT_NAME(CACertSource());

@property (nonatomic,readonly,assign,getter=CACertSubject) NSString* CACertSubject NS_SWIFT_NAME(CACertSubject);

- (NSString*)CACertSubject NS_SWIFT_NAME(CACertSubject());

@property (nonatomic,readwrite,assign,getter=CACertSubjectAlternativeName,setter=setCACertSubjectAlternativeName:) NSString* CACertSubjectAlternativeName NS_SWIFT_NAME(CACertSubjectAlternativeName);

- (NSString*)CACertSubjectAlternativeName NS_SWIFT_NAME(CACertSubjectAlternativeName());
- (void)setCACertSubjectAlternativeName :(NSString*)newCACertSubjectAlternativeName NS_SWIFT_NAME(setCACertSubjectAlternativeName(_:));

@property (nonatomic,readwrite,assign,getter=CACertSubjectKeyID,setter=setCACertSubjectKeyID:) NSData* CACertSubjectKeyID NS_SWIFT_NAME(CACertSubjectKeyID);

- (NSData*)CACertSubjectKeyID NS_SWIFT_NAME(CACertSubjectKeyID());
- (void)setCACertSubjectKeyID :(NSData*)newCACertSubjectKeyID NS_SWIFT_NAME(setCACertSubjectKeyID(_:));

@property (nonatomic,readwrite,assign,getter=CACertSubjectRDN,setter=setCACertSubjectRDN:) NSString* CACertSubjectRDN NS_SWIFT_NAME(CACertSubjectRDN);

- (NSString*)CACertSubjectRDN NS_SWIFT_NAME(CACertSubjectRDN());
- (void)setCACertSubjectRDN :(NSString*)newCACertSubjectRDN NS_SWIFT_NAME(setCACertSubjectRDN(_:));

@property (nonatomic,readonly,assign,getter=CACertValid) BOOL CACertValid NS_SWIFT_NAME(CACertValid);

- (BOOL)CACertValid NS_SWIFT_NAME(CACertValid());

@property (nonatomic,readwrite,assign,getter=CACertValidFrom,setter=setCACertValidFrom:) NSString* CACertValidFrom NS_SWIFT_NAME(CACertValidFrom);

- (NSString*)CACertValidFrom NS_SWIFT_NAME(CACertValidFrom());
- (void)setCACertValidFrom :(NSString*)newCACertValidFrom NS_SWIFT_NAME(setCACertValidFrom(_:));

@property (nonatomic,readwrite,assign,getter=CACertValidTo,setter=setCACertValidTo:) NSString* CACertValidTo NS_SWIFT_NAME(CACertValidTo);

- (NSString*)CACertValidTo NS_SWIFT_NAME(CACertValidTo());
- (void)setCACertValidTo :(NSString*)newCACertValidTo NS_SWIFT_NAME(setCACertValidTo(_:));

@property (nonatomic,readonly,assign,getter=certBytes) NSData* certBytes NS_SWIFT_NAME(certBytes);

- (NSData*)certBytes NS_SWIFT_NAME(certBytes());

@property (nonatomic,readwrite,assign,getter=certCA,setter=setCertCA:) BOOL certCA NS_SWIFT_NAME(certCA);

- (BOOL)certCA NS_SWIFT_NAME(certCA());
- (void)setCertCA :(BOOL)newCertCA NS_SWIFT_NAME(setCertCA(_:));

@property (nonatomic,readonly,assign,getter=certCAKeyID) NSData* certCAKeyID NS_SWIFT_NAME(certCAKeyID);

- (NSData*)certCAKeyID NS_SWIFT_NAME(certCAKeyID());

@property (nonatomic,readonly,assign,getter=certCertType) int certCertType NS_SWIFT_NAME(certCertType);

- (int)certCertType NS_SWIFT_NAME(certCertType());

@property (nonatomic,readwrite,assign,getter=certCRLDistributionPoints,setter=setCertCRLDistributionPoints:) NSString* certCRLDistributionPoints NS_SWIFT_NAME(certCRLDistributionPoints);

- (NSString*)certCRLDistributionPoints NS_SWIFT_NAME(certCRLDistributionPoints());
- (void)setCertCRLDistributionPoints :(NSString*)newCertCRLDistributionPoints NS_SWIFT_NAME(setCertCRLDistributionPoints(_:));

@property (nonatomic,readwrite,assign,getter=certCurve,setter=setCertCurve:) NSString* certCurve NS_SWIFT_NAME(certCurve);

- (NSString*)certCurve NS_SWIFT_NAME(certCurve());
- (void)setCertCurve :(NSString*)newCertCurve NS_SWIFT_NAME(setCertCurve(_:));

@property (nonatomic,readonly,assign,getter=certFingerprint) NSString* certFingerprint NS_SWIFT_NAME(certFingerprint);

- (NSString*)certFingerprint NS_SWIFT_NAME(certFingerprint());

@property (nonatomic,readonly,assign,getter=certFriendlyName) NSString* certFriendlyName NS_SWIFT_NAME(certFriendlyName);

- (NSString*)certFriendlyName NS_SWIFT_NAME(certFriendlyName());

@property (nonatomic,readwrite,assign,getter=certHandle,setter=setCertHandle:) long long certHandle NS_SWIFT_NAME(certHandle);

- (long long)certHandle NS_SWIFT_NAME(certHandle());
- (void)setCertHandle :(long long)newCertHandle NS_SWIFT_NAME(setCertHandle(_:));

@property (nonatomic,readwrite,assign,getter=certHashAlgorithm,setter=setCertHashAlgorithm:) NSString* certHashAlgorithm NS_SWIFT_NAME(certHashAlgorithm);

- (NSString*)certHashAlgorithm NS_SWIFT_NAME(certHashAlgorithm());
- (void)setCertHashAlgorithm :(NSString*)newCertHashAlgorithm NS_SWIFT_NAME(setCertHashAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=certIssuer) NSString* certIssuer NS_SWIFT_NAME(certIssuer);

- (NSString*)certIssuer NS_SWIFT_NAME(certIssuer());

@property (nonatomic,readwrite,assign,getter=certIssuerRDN,setter=setCertIssuerRDN:) NSString* certIssuerRDN NS_SWIFT_NAME(certIssuerRDN);

- (NSString*)certIssuerRDN NS_SWIFT_NAME(certIssuerRDN());
- (void)setCertIssuerRDN :(NSString*)newCertIssuerRDN NS_SWIFT_NAME(setCertIssuerRDN(_:));

@property (nonatomic,readwrite,assign,getter=certKeyAlgorithm,setter=setCertKeyAlgorithm:) NSString* certKeyAlgorithm NS_SWIFT_NAME(certKeyAlgorithm);

- (NSString*)certKeyAlgorithm NS_SWIFT_NAME(certKeyAlgorithm());
- (void)setCertKeyAlgorithm :(NSString*)newCertKeyAlgorithm NS_SWIFT_NAME(setCertKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=certKeyBits) int certKeyBits NS_SWIFT_NAME(certKeyBits);

- (int)certKeyBits NS_SWIFT_NAME(certKeyBits());

@property (nonatomic,readonly,assign,getter=certKeyFingerprint) NSString* certKeyFingerprint NS_SWIFT_NAME(certKeyFingerprint);

- (NSString*)certKeyFingerprint NS_SWIFT_NAME(certKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=certKeyUsage,setter=setCertKeyUsage:) int certKeyUsage NS_SWIFT_NAME(certKeyUsage);

- (int)certKeyUsage NS_SWIFT_NAME(certKeyUsage());
- (void)setCertKeyUsage :(int)newCertKeyUsage NS_SWIFT_NAME(setCertKeyUsage(_:));

@property (nonatomic,readonly,assign,getter=certKeyValid) BOOL certKeyValid NS_SWIFT_NAME(certKeyValid);

- (BOOL)certKeyValid NS_SWIFT_NAME(certKeyValid());

@property (nonatomic,readwrite,assign,getter=certOCSPLocations,setter=setCertOCSPLocations:) NSString* certOCSPLocations NS_SWIFT_NAME(certOCSPLocations);

- (NSString*)certOCSPLocations NS_SWIFT_NAME(certOCSPLocations());
- (void)setCertOCSPLocations :(NSString*)newCertOCSPLocations NS_SWIFT_NAME(setCertOCSPLocations(_:));

@property (nonatomic,readwrite,assign,getter=certOCSPNoCheck,setter=setCertOCSPNoCheck:) BOOL certOCSPNoCheck NS_SWIFT_NAME(certOCSPNoCheck);

- (BOOL)certOCSPNoCheck NS_SWIFT_NAME(certOCSPNoCheck());
- (void)setCertOCSPNoCheck :(BOOL)newCertOCSPNoCheck NS_SWIFT_NAME(setCertOCSPNoCheck(_:));

@property (nonatomic,readonly,assign,getter=certOrigin) int certOrigin NS_SWIFT_NAME(certOrigin);

- (int)certOrigin NS_SWIFT_NAME(certOrigin());

@property (nonatomic,readwrite,assign,getter=certPolicyIDs,setter=setCertPolicyIDs:) NSString* certPolicyIDs NS_SWIFT_NAME(certPolicyIDs);

- (NSString*)certPolicyIDs NS_SWIFT_NAME(certPolicyIDs());
- (void)setCertPolicyIDs :(NSString*)newCertPolicyIDs NS_SWIFT_NAME(setCertPolicyIDs(_:));

@property (nonatomic,readonly,assign,getter=certPrivateKeyBytes) NSData* certPrivateKeyBytes NS_SWIFT_NAME(certPrivateKeyBytes);

- (NSData*)certPrivateKeyBytes NS_SWIFT_NAME(certPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=certPrivateKeyExists) BOOL certPrivateKeyExists NS_SWIFT_NAME(certPrivateKeyExists);

- (BOOL)certPrivateKeyExists NS_SWIFT_NAME(certPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=certPrivateKeyExtractable) BOOL certPrivateKeyExtractable NS_SWIFT_NAME(certPrivateKeyExtractable);

- (BOOL)certPrivateKeyExtractable NS_SWIFT_NAME(certPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=certPublicKeyBytes) NSData* certPublicKeyBytes NS_SWIFT_NAME(certPublicKeyBytes);

- (NSData*)certPublicKeyBytes NS_SWIFT_NAME(certPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=certQualified) BOOL certQualified NS_SWIFT_NAME(certQualified);

- (BOOL)certQualified NS_SWIFT_NAME(certQualified());

@property (nonatomic,readwrite,assign,getter=certQualifiedStatements,setter=setCertQualifiedStatements:) int certQualifiedStatements NS_SWIFT_NAME(certQualifiedStatements);

- (int)certQualifiedStatements NS_SWIFT_NAME(certQualifiedStatements());
- (void)setCertQualifiedStatements :(int)newCertQualifiedStatements NS_SWIFT_NAME(setCertQualifiedStatements(_:));

@property (nonatomic,readonly,assign,getter=certQualifiers) NSString* certQualifiers NS_SWIFT_NAME(certQualifiers);

- (NSString*)certQualifiers NS_SWIFT_NAME(certQualifiers());

@property (nonatomic,readonly,assign,getter=certSelfSigned) BOOL certSelfSigned NS_SWIFT_NAME(certSelfSigned);

- (BOOL)certSelfSigned NS_SWIFT_NAME(certSelfSigned());

@property (nonatomic,readwrite,assign,getter=certSerialNumber,setter=setCertSerialNumber:) NSData* certSerialNumber NS_SWIFT_NAME(certSerialNumber);

- (NSData*)certSerialNumber NS_SWIFT_NAME(certSerialNumber());
- (void)setCertSerialNumber :(NSData*)newCertSerialNumber NS_SWIFT_NAME(setCertSerialNumber(_:));

@property (nonatomic,readonly,assign,getter=certSigAlgorithm) NSString* certSigAlgorithm NS_SWIFT_NAME(certSigAlgorithm);

- (NSString*)certSigAlgorithm NS_SWIFT_NAME(certSigAlgorithm());

@property (nonatomic,readonly,assign,getter=certSource) int certSource NS_SWIFT_NAME(certSource);

- (int)certSource NS_SWIFT_NAME(certSource());

@property (nonatomic,readonly,assign,getter=certSubject) NSString* certSubject NS_SWIFT_NAME(certSubject);

- (NSString*)certSubject NS_SWIFT_NAME(certSubject());

@property (nonatomic,readwrite,assign,getter=certSubjectAlternativeName,setter=setCertSubjectAlternativeName:) NSString* certSubjectAlternativeName NS_SWIFT_NAME(certSubjectAlternativeName);

- (NSString*)certSubjectAlternativeName NS_SWIFT_NAME(certSubjectAlternativeName());
- (void)setCertSubjectAlternativeName :(NSString*)newCertSubjectAlternativeName NS_SWIFT_NAME(setCertSubjectAlternativeName(_:));

@property (nonatomic,readwrite,assign,getter=certSubjectKeyID,setter=setCertSubjectKeyID:) NSData* certSubjectKeyID NS_SWIFT_NAME(certSubjectKeyID);

- (NSData*)certSubjectKeyID NS_SWIFT_NAME(certSubjectKeyID());
- (void)setCertSubjectKeyID :(NSData*)newCertSubjectKeyID NS_SWIFT_NAME(setCertSubjectKeyID(_:));

@property (nonatomic,readwrite,assign,getter=certSubjectRDN,setter=setCertSubjectRDN:) NSString* certSubjectRDN NS_SWIFT_NAME(certSubjectRDN);

- (NSString*)certSubjectRDN NS_SWIFT_NAME(certSubjectRDN());
- (void)setCertSubjectRDN :(NSString*)newCertSubjectRDN NS_SWIFT_NAME(setCertSubjectRDN(_:));

@property (nonatomic,readonly,assign,getter=certValid) BOOL certValid NS_SWIFT_NAME(certValid);

- (BOOL)certValid NS_SWIFT_NAME(certValid());

@property (nonatomic,readwrite,assign,getter=certValidFrom,setter=setCertValidFrom:) NSString* certValidFrom NS_SWIFT_NAME(certValidFrom);

- (NSString*)certValidFrom NS_SWIFT_NAME(certValidFrom());
- (void)setCertValidFrom :(NSString*)newCertValidFrom NS_SWIFT_NAME(setCertValidFrom(_:));

@property (nonatomic,readwrite,assign,getter=certValidTo,setter=setCertValidTo:) NSString* certValidTo NS_SWIFT_NAME(certValidTo);

- (NSString*)certValidTo NS_SWIFT_NAME(certValidTo());
- (void)setCertValidTo :(NSString*)newCertValidTo NS_SWIFT_NAME(setCertValidTo(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoAsyncDocumentID,setter=setExternalCryptoAsyncDocumentID:) NSString* externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID);

- (NSString*)externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID());
- (void)setExternalCryptoAsyncDocumentID :(NSString*)newExternalCryptoAsyncDocumentID NS_SWIFT_NAME(setExternalCryptoAsyncDocumentID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoCustomParams,setter=setExternalCryptoCustomParams:) NSString* externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams);

- (NSString*)externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams());
- (void)setExternalCryptoCustomParams :(NSString*)newExternalCryptoCustomParams NS_SWIFT_NAME(setExternalCryptoCustomParams(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoData,setter=setExternalCryptoData:) NSString* externalCryptoData NS_SWIFT_NAME(externalCryptoData);

- (NSString*)externalCryptoData NS_SWIFT_NAME(externalCryptoData());
- (void)setExternalCryptoData :(NSString*)newExternalCryptoData NS_SWIFT_NAME(setExternalCryptoData(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoExternalHashCalculation,setter=setExternalCryptoExternalHashCalculation:) BOOL externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation);

- (BOOL)externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation());
- (void)setExternalCryptoExternalHashCalculation :(BOOL)newExternalCryptoExternalHashCalculation NS_SWIFT_NAME(setExternalCryptoExternalHashCalculation(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoHashAlgorithm,setter=setExternalCryptoHashAlgorithm:) NSString* externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm);

- (NSString*)externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm());
- (void)setExternalCryptoHashAlgorithm :(NSString*)newExternalCryptoHashAlgorithm NS_SWIFT_NAME(setExternalCryptoHashAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeyID,setter=setExternalCryptoKeyID:) NSString* externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID);

- (NSString*)externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID());
- (void)setExternalCryptoKeyID :(NSString*)newExternalCryptoKeyID NS_SWIFT_NAME(setExternalCryptoKeyID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeySecret,setter=setExternalCryptoKeySecret:) NSString* externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret);

- (NSString*)externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret());
- (void)setExternalCryptoKeySecret :(NSString*)newExternalCryptoKeySecret NS_SWIFT_NAME(setExternalCryptoKeySecret(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMethod,setter=setExternalCryptoMethod:) int externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod);

- (int)externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod());
- (void)setExternalCryptoMethod :(int)newExternalCryptoMethod NS_SWIFT_NAME(setExternalCryptoMethod(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMode,setter=setExternalCryptoMode:) int externalCryptoMode NS_SWIFT_NAME(externalCryptoMode);

- (int)externalCryptoMode NS_SWIFT_NAME(externalCryptoMode());
- (void)setExternalCryptoMode :(int)newExternalCryptoMode NS_SWIFT_NAME(setExternalCryptoMode(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoPublicKeyAlgorithm,setter=setExternalCryptoPublicKeyAlgorithm:) NSString* externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm);

- (NSString*)externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm());
- (void)setExternalCryptoPublicKeyAlgorithm :(NSString*)newExternalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(setExternalCryptoPublicKeyAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

  /* Methods */

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (void)createNew:(int)certType :(NSString*)purpose :(NSString*)subject NS_SWIFT_NAME(createNew(_:_:_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (NSData*)exportBytes:(int)format :(BOOL)exportKey :(NSString*)password NS_SWIFT_NAME(exportBytes(_:_:_:));

- (NSData*)exportKey:(int)format :(NSString*)password NS_SWIFT_NAME(exportKey(_:_:));

- (void)exportKeyToFile:(NSString*)keyFile :(int)format :(NSString*)password NS_SWIFT_NAME(exportKeyToFile(_:_:_:));

- (void)exportToFile:(NSString*)fileName :(int)format :(BOOL)exportKey :(NSString*)password NS_SWIFT_NAME(exportToFile(_:_:_:_:));

- (void)generate:(int)keyBits NS_SWIFT_NAME(generate(_:));

- (NSString*)generateAsyncBegin:(int)keyBits NS_SWIFT_NAME(generateAsyncBegin(_:));

- (void)generateAsyncEnd:(NSString*)asyncReply NS_SWIFT_NAME(generateAsyncEnd(_:));

- (void)generateExternal:(NSData*)keyBytes :(NSString*)keyPassword NS_SWIFT_NAME(generateExternal(_:_:));

- (NSData*)getExtensionData:(NSString*)OID NS_SWIFT_NAME(getExtensionData(_:));

- (int)getExtensionState:(NSString*)OID NS_SWIFT_NAME(getExtensionState(_:));

- (void)importBytes:(NSData*)certBytes :(NSString*)password NS_SWIFT_NAME(importBytes(_:_:));

- (void)importFromFile:(NSString*)path :(NSString*)password NS_SWIFT_NAME(importFromFile(_:_:));

- (void)importFromObject:(long long)srcObj NS_SWIFT_NAME(importFromObject(_:));

- (void)importKey:(NSData*)key :(NSString*)password NS_SWIFT_NAME(importKey(_:_:));

- (void)importKeyFromFile:(NSString*)path :(NSString*)password NS_SWIFT_NAME(importKeyFromFile(_:_:));

- (NSString*)listExtensions NS_SWIFT_NAME(listExtensions());

- (void)reset NS_SWIFT_NAME(reset());

- (void)setExtensionData:(NSString*)OID :(NSData*)value NS_SWIFT_NAME(setExtensionData(_:_:));

- (void)setExtensionState:(NSString*)OID :(int)state NS_SWIFT_NAME(setExtensionState(_:_:));

- (void)update NS_SWIFT_NAME(update());

- (int)validate NS_SWIFT_NAME(validate());

@end

