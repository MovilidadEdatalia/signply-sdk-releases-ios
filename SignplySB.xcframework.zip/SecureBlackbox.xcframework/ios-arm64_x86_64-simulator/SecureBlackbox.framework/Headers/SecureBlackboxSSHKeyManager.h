/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

//SSHKEYFORMATS
#define CKF_OPEN_SSH                                       0

#define CKF_OPEN_SSH2                                      1

#define CKF_IETF                                           2

#define CKF_PU_TTY                                         3

#define CKF_X509                                           4

#define CKF_BINARY                                         5

#define CKF_SSH1                                           6

#define CKF_PGP                                            7

#define CKF_PKCS8                                          8

#define CKF_PU_TTY3                                        9

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxSSHKeyManagerDelegate <NSObject>
@optional
- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

@end

@interface SecureBlackboxSSHKeyManager : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxSSHKeyManagerDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasError;

  BOOL m_delegateHasNotification;

}

+ (SecureBlackboxSSHKeyManager*)sshkeymanager;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxSSHKeyManagerDelegate> delegate;
- (id <SecureBlackboxSSHKeyManagerDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxSSHKeyManagerDelegate>)anObject;

  /* Events */

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readonly,assign,getter=certBytes) NSData* certBytes NS_SWIFT_NAME(certBytes);

- (NSData*)certBytes NS_SWIFT_NAME(certBytes());

@property (nonatomic,readwrite,assign,getter=certCA,setter=setCertCA:) BOOL certCA NS_SWIFT_NAME(certCA);

- (BOOL)certCA NS_SWIFT_NAME(certCA());
- (void)setCertCA :(BOOL)newCertCA NS_SWIFT_NAME(setCertCA(_:));

@property (nonatomic,readonly,assign,getter=certCAKeyID) NSData* certCAKeyID NS_SWIFT_NAME(certCAKeyID);

- (NSData*)certCAKeyID NS_SWIFT_NAME(certCAKeyID());

@property (nonatomic,readonly,assign,getter=certCertType) int certCertType NS_SWIFT_NAME(certCertType);

- (int)certCertType NS_SWIFT_NAME(certCertType());

@property (nonatomic,readwrite,assign,getter=certCRLDistributionPoints,setter=setCertCRLDistributionPoints:) NSString* certCRLDistributionPoints NS_SWIFT_NAME(certCRLDistributionPoints);

- (NSString*)certCRLDistributionPoints NS_SWIFT_NAME(certCRLDistributionPoints());
- (void)setCertCRLDistributionPoints :(NSString*)newCertCRLDistributionPoints NS_SWIFT_NAME(setCertCRLDistributionPoints(_:));

@property (nonatomic,readwrite,assign,getter=certCurve,setter=setCertCurve:) NSString* certCurve NS_SWIFT_NAME(certCurve);

- (NSString*)certCurve NS_SWIFT_NAME(certCurve());
- (void)setCertCurve :(NSString*)newCertCurve NS_SWIFT_NAME(setCertCurve(_:));

@property (nonatomic,readonly,assign,getter=certFingerprint) NSString* certFingerprint NS_SWIFT_NAME(certFingerprint);

- (NSString*)certFingerprint NS_SWIFT_NAME(certFingerprint());

@property (nonatomic,readonly,assign,getter=certFriendlyName) NSString* certFriendlyName NS_SWIFT_NAME(certFriendlyName);

- (NSString*)certFriendlyName NS_SWIFT_NAME(certFriendlyName());

@property (nonatomic,readwrite,assign,getter=certHandle,setter=setCertHandle:) long long certHandle NS_SWIFT_NAME(certHandle);

- (long long)certHandle NS_SWIFT_NAME(certHandle());
- (void)setCertHandle :(long long)newCertHandle NS_SWIFT_NAME(setCertHandle(_:));

@property (nonatomic,readwrite,assign,getter=certHashAlgorithm,setter=setCertHashAlgorithm:) NSString* certHashAlgorithm NS_SWIFT_NAME(certHashAlgorithm);

- (NSString*)certHashAlgorithm NS_SWIFT_NAME(certHashAlgorithm());
- (void)setCertHashAlgorithm :(NSString*)newCertHashAlgorithm NS_SWIFT_NAME(setCertHashAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=certIssuer) NSString* certIssuer NS_SWIFT_NAME(certIssuer);

- (NSString*)certIssuer NS_SWIFT_NAME(certIssuer());

@property (nonatomic,readwrite,assign,getter=certIssuerRDN,setter=setCertIssuerRDN:) NSString* certIssuerRDN NS_SWIFT_NAME(certIssuerRDN);

- (NSString*)certIssuerRDN NS_SWIFT_NAME(certIssuerRDN());
- (void)setCertIssuerRDN :(NSString*)newCertIssuerRDN NS_SWIFT_NAME(setCertIssuerRDN(_:));

@property (nonatomic,readwrite,assign,getter=certKeyAlgorithm,setter=setCertKeyAlgorithm:) NSString* certKeyAlgorithm NS_SWIFT_NAME(certKeyAlgorithm);

- (NSString*)certKeyAlgorithm NS_SWIFT_NAME(certKeyAlgorithm());
- (void)setCertKeyAlgorithm :(NSString*)newCertKeyAlgorithm NS_SWIFT_NAME(setCertKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=certKeyBits) int certKeyBits NS_SWIFT_NAME(certKeyBits);

- (int)certKeyBits NS_SWIFT_NAME(certKeyBits());

@property (nonatomic,readonly,assign,getter=certKeyFingerprint) NSString* certKeyFingerprint NS_SWIFT_NAME(certKeyFingerprint);

- (NSString*)certKeyFingerprint NS_SWIFT_NAME(certKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=certKeyUsage,setter=setCertKeyUsage:) int certKeyUsage NS_SWIFT_NAME(certKeyUsage);

- (int)certKeyUsage NS_SWIFT_NAME(certKeyUsage());
- (void)setCertKeyUsage :(int)newCertKeyUsage NS_SWIFT_NAME(setCertKeyUsage(_:));

@property (nonatomic,readonly,assign,getter=certKeyValid) BOOL certKeyValid NS_SWIFT_NAME(certKeyValid);

- (BOOL)certKeyValid NS_SWIFT_NAME(certKeyValid());

@property (nonatomic,readwrite,assign,getter=certOCSPLocations,setter=setCertOCSPLocations:) NSString* certOCSPLocations NS_SWIFT_NAME(certOCSPLocations);

- (NSString*)certOCSPLocations NS_SWIFT_NAME(certOCSPLocations());
- (void)setCertOCSPLocations :(NSString*)newCertOCSPLocations NS_SWIFT_NAME(setCertOCSPLocations(_:));

@property (nonatomic,readwrite,assign,getter=certOCSPNoCheck,setter=setCertOCSPNoCheck:) BOOL certOCSPNoCheck NS_SWIFT_NAME(certOCSPNoCheck);

- (BOOL)certOCSPNoCheck NS_SWIFT_NAME(certOCSPNoCheck());
- (void)setCertOCSPNoCheck :(BOOL)newCertOCSPNoCheck NS_SWIFT_NAME(setCertOCSPNoCheck(_:));

@property (nonatomic,readonly,assign,getter=certOrigin) int certOrigin NS_SWIFT_NAME(certOrigin);

- (int)certOrigin NS_SWIFT_NAME(certOrigin());

@property (nonatomic,readwrite,assign,getter=certPolicyIDs,setter=setCertPolicyIDs:) NSString* certPolicyIDs NS_SWIFT_NAME(certPolicyIDs);

- (NSString*)certPolicyIDs NS_SWIFT_NAME(certPolicyIDs());
- (void)setCertPolicyIDs :(NSString*)newCertPolicyIDs NS_SWIFT_NAME(setCertPolicyIDs(_:));

@property (nonatomic,readonly,assign,getter=certPrivateKeyBytes) NSData* certPrivateKeyBytes NS_SWIFT_NAME(certPrivateKeyBytes);

- (NSData*)certPrivateKeyBytes NS_SWIFT_NAME(certPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=certPrivateKeyExists) BOOL certPrivateKeyExists NS_SWIFT_NAME(certPrivateKeyExists);

- (BOOL)certPrivateKeyExists NS_SWIFT_NAME(certPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=certPrivateKeyExtractable) BOOL certPrivateKeyExtractable NS_SWIFT_NAME(certPrivateKeyExtractable);

- (BOOL)certPrivateKeyExtractable NS_SWIFT_NAME(certPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=certPublicKeyBytes) NSData* certPublicKeyBytes NS_SWIFT_NAME(certPublicKeyBytes);

- (NSData*)certPublicKeyBytes NS_SWIFT_NAME(certPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=certQualified) BOOL certQualified NS_SWIFT_NAME(certQualified);

- (BOOL)certQualified NS_SWIFT_NAME(certQualified());

@property (nonatomic,readwrite,assign,getter=certQualifiedStatements,setter=setCertQualifiedStatements:) int certQualifiedStatements NS_SWIFT_NAME(certQualifiedStatements);

- (int)certQualifiedStatements NS_SWIFT_NAME(certQualifiedStatements());
- (void)setCertQualifiedStatements :(int)newCertQualifiedStatements NS_SWIFT_NAME(setCertQualifiedStatements(_:));

@property (nonatomic,readonly,assign,getter=certQualifiers) NSString* certQualifiers NS_SWIFT_NAME(certQualifiers);

- (NSString*)certQualifiers NS_SWIFT_NAME(certQualifiers());

@property (nonatomic,readonly,assign,getter=certSelfSigned) BOOL certSelfSigned NS_SWIFT_NAME(certSelfSigned);

- (BOOL)certSelfSigned NS_SWIFT_NAME(certSelfSigned());

@property (nonatomic,readwrite,assign,getter=certSerialNumber,setter=setCertSerialNumber:) NSData* certSerialNumber NS_SWIFT_NAME(certSerialNumber);

- (NSData*)certSerialNumber NS_SWIFT_NAME(certSerialNumber());
- (void)setCertSerialNumber :(NSData*)newCertSerialNumber NS_SWIFT_NAME(setCertSerialNumber(_:));

@property (nonatomic,readonly,assign,getter=certSigAlgorithm) NSString* certSigAlgorithm NS_SWIFT_NAME(certSigAlgorithm);

- (NSString*)certSigAlgorithm NS_SWIFT_NAME(certSigAlgorithm());

@property (nonatomic,readonly,assign,getter=certSource) int certSource NS_SWIFT_NAME(certSource);

- (int)certSource NS_SWIFT_NAME(certSource());

@property (nonatomic,readonly,assign,getter=certSubject) NSString* certSubject NS_SWIFT_NAME(certSubject);

- (NSString*)certSubject NS_SWIFT_NAME(certSubject());

@property (nonatomic,readwrite,assign,getter=certSubjectAlternativeName,setter=setCertSubjectAlternativeName:) NSString* certSubjectAlternativeName NS_SWIFT_NAME(certSubjectAlternativeName);

- (NSString*)certSubjectAlternativeName NS_SWIFT_NAME(certSubjectAlternativeName());
- (void)setCertSubjectAlternativeName :(NSString*)newCertSubjectAlternativeName NS_SWIFT_NAME(setCertSubjectAlternativeName(_:));

@property (nonatomic,readwrite,assign,getter=certSubjectKeyID,setter=setCertSubjectKeyID:) NSData* certSubjectKeyID NS_SWIFT_NAME(certSubjectKeyID);

- (NSData*)certSubjectKeyID NS_SWIFT_NAME(certSubjectKeyID());
- (void)setCertSubjectKeyID :(NSData*)newCertSubjectKeyID NS_SWIFT_NAME(setCertSubjectKeyID(_:));

@property (nonatomic,readwrite,assign,getter=certSubjectRDN,setter=setCertSubjectRDN:) NSString* certSubjectRDN NS_SWIFT_NAME(certSubjectRDN);

- (NSString*)certSubjectRDN NS_SWIFT_NAME(certSubjectRDN());
- (void)setCertSubjectRDN :(NSString*)newCertSubjectRDN NS_SWIFT_NAME(setCertSubjectRDN(_:));

@property (nonatomic,readonly,assign,getter=certValid) BOOL certValid NS_SWIFT_NAME(certValid);

- (BOOL)certValid NS_SWIFT_NAME(certValid());

@property (nonatomic,readwrite,assign,getter=certValidFrom,setter=setCertValidFrom:) NSString* certValidFrom NS_SWIFT_NAME(certValidFrom);

- (NSString*)certValidFrom NS_SWIFT_NAME(certValidFrom());
- (void)setCertValidFrom :(NSString*)newCertValidFrom NS_SWIFT_NAME(setCertValidFrom(_:));

@property (nonatomic,readwrite,assign,getter=certValidTo,setter=setCertValidTo:) NSString* certValidTo NS_SWIFT_NAME(certValidTo);

- (NSString*)certValidTo NS_SWIFT_NAME(certValidTo());
- (void)setCertValidTo :(NSString*)newCertValidTo NS_SWIFT_NAME(setCertValidTo(_:));

@property (nonatomic,readwrite,assign,getter=cryptoKeyAlgorithm,setter=setCryptoKeyAlgorithm:) NSString* cryptoKeyAlgorithm NS_SWIFT_NAME(cryptoKeyAlgorithm);

- (NSString*)cryptoKeyAlgorithm NS_SWIFT_NAME(cryptoKeyAlgorithm());
- (void)setCryptoKeyAlgorithm :(NSString*)newCryptoKeyAlgorithm NS_SWIFT_NAME(setCryptoKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=cryptoKeyBits) int cryptoKeyBits NS_SWIFT_NAME(cryptoKeyBits);

- (int)cryptoKeyBits NS_SWIFT_NAME(cryptoKeyBits());

@property (nonatomic,readwrite,assign,getter=cryptoKeyCurve,setter=setCryptoKeyCurve:) NSString* cryptoKeyCurve NS_SWIFT_NAME(cryptoKeyCurve);

- (NSString*)cryptoKeyCurve NS_SWIFT_NAME(cryptoKeyCurve());
- (void)setCryptoKeyCurve :(NSString*)newCryptoKeyCurve NS_SWIFT_NAME(setCryptoKeyCurve(_:));

@property (nonatomic,readonly,assign,getter=cryptoKeyExportable) BOOL cryptoKeyExportable NS_SWIFT_NAME(cryptoKeyExportable);

- (BOOL)cryptoKeyExportable NS_SWIFT_NAME(cryptoKeyExportable());

@property (nonatomic,readonly,assign,getter=cryptoKeyFingerprint) NSString* cryptoKeyFingerprint NS_SWIFT_NAME(cryptoKeyFingerprint);

- (NSString*)cryptoKeyFingerprint NS_SWIFT_NAME(cryptoKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=cryptoKeyHandle,setter=setCryptoKeyHandle:) long long cryptoKeyHandle NS_SWIFT_NAME(cryptoKeyHandle);

- (long long)cryptoKeyHandle NS_SWIFT_NAME(cryptoKeyHandle());
- (void)setCryptoKeyHandle :(long long)newCryptoKeyHandle NS_SWIFT_NAME(setCryptoKeyHandle(_:));

@property (nonatomic,readwrite,assign,getter=cryptoKeyID,setter=setCryptoKeyID:) NSData* cryptoKeyID NS_SWIFT_NAME(cryptoKeyID);

- (NSData*)cryptoKeyID NS_SWIFT_NAME(cryptoKeyID());
- (void)setCryptoKeyID :(NSData*)newCryptoKeyID NS_SWIFT_NAME(setCryptoKeyID(_:));

@property (nonatomic,readwrite,assign,getter=cryptoKeyIV,setter=setCryptoKeyIV:) NSData* cryptoKeyIV NS_SWIFT_NAME(cryptoKeyIV);

- (NSData*)cryptoKeyIV NS_SWIFT_NAME(cryptoKeyIV());
- (void)setCryptoKeyIV :(NSData*)newCryptoKeyIV NS_SWIFT_NAME(setCryptoKeyIV(_:));

@property (nonatomic,readonly,assign,getter=cryptoKeyKey) NSData* cryptoKeyKey NS_SWIFT_NAME(cryptoKeyKey);

- (NSData*)cryptoKeyKey NS_SWIFT_NAME(cryptoKeyKey());

@property (nonatomic,readwrite,assign,getter=cryptoKeyNonce,setter=setCryptoKeyNonce:) NSData* cryptoKeyNonce NS_SWIFT_NAME(cryptoKeyNonce);

- (NSData*)cryptoKeyNonce NS_SWIFT_NAME(cryptoKeyNonce());
- (void)setCryptoKeyNonce :(NSData*)newCryptoKeyNonce NS_SWIFT_NAME(setCryptoKeyNonce(_:));

@property (nonatomic,readonly,assign,getter=cryptoKeyPrivate) BOOL cryptoKeyPrivate NS_SWIFT_NAME(cryptoKeyPrivate);

- (BOOL)cryptoKeyPrivate NS_SWIFT_NAME(cryptoKeyPrivate());

@property (nonatomic,readonly,assign,getter=cryptoKeyPublic) BOOL cryptoKeyPublic NS_SWIFT_NAME(cryptoKeyPublic);

- (BOOL)cryptoKeyPublic NS_SWIFT_NAME(cryptoKeyPublic());

@property (nonatomic,readwrite,assign,getter=cryptoKeySubject,setter=setCryptoKeySubject:) NSData* cryptoKeySubject NS_SWIFT_NAME(cryptoKeySubject);

- (NSData*)cryptoKeySubject NS_SWIFT_NAME(cryptoKeySubject());
- (void)setCryptoKeySubject :(NSData*)newCryptoKeySubject NS_SWIFT_NAME(setCryptoKeySubject(_:));

@property (nonatomic,readonly,assign,getter=cryptoKeySymmetric) BOOL cryptoKeySymmetric NS_SWIFT_NAME(cryptoKeySymmetric);

- (BOOL)cryptoKeySymmetric NS_SWIFT_NAME(cryptoKeySymmetric());

@property (nonatomic,readonly,assign,getter=cryptoKeyValid) BOOL cryptoKeyValid NS_SWIFT_NAME(cryptoKeyValid);

- (BOOL)cryptoKeyValid NS_SWIFT_NAME(cryptoKeyValid());

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readonly,assign,getter=keyAlgorithm) NSString* keyAlgorithm NS_SWIFT_NAME(keyAlgorithm);

- (NSString*)keyAlgorithm NS_SWIFT_NAME(keyAlgorithm());

@property (nonatomic,readonly,assign,getter=keyBits) int keyBits NS_SWIFT_NAME(keyBits);

- (int)keyBits NS_SWIFT_NAME(keyBits());

@property (nonatomic,readwrite,assign,getter=keyComment,setter=setKeyComment:) NSString* keyComment NS_SWIFT_NAME(keyComment);

- (NSString*)keyComment NS_SWIFT_NAME(keyComment());
- (void)setKeyComment :(NSString*)newKeyComment NS_SWIFT_NAME(setKeyComment(_:));

@property (nonatomic,readonly,assign,getter=keyCurve) NSString* keyCurve NS_SWIFT_NAME(keyCurve);

- (NSString*)keyCurve NS_SWIFT_NAME(keyCurve());

@property (nonatomic,readonly,assign,getter=keyDSSG) NSData* keyDSSG NS_SWIFT_NAME(keyDSSG);

- (NSData*)keyDSSG NS_SWIFT_NAME(keyDSSG());

@property (nonatomic,readonly,assign,getter=keyDSSP) NSData* keyDSSP NS_SWIFT_NAME(keyDSSP);

- (NSData*)keyDSSP NS_SWIFT_NAME(keyDSSP());

@property (nonatomic,readonly,assign,getter=keyDSSQ) NSData* keyDSSQ NS_SWIFT_NAME(keyDSSQ);

- (NSData*)keyDSSQ NS_SWIFT_NAME(keyDSSQ());

@property (nonatomic,readonly,assign,getter=keyDSSX) NSData* keyDSSX NS_SWIFT_NAME(keyDSSX);

- (NSData*)keyDSSX NS_SWIFT_NAME(keyDSSX());

@property (nonatomic,readonly,assign,getter=keyDSSY) NSData* keyDSSY NS_SWIFT_NAME(keyDSSY);

- (NSData*)keyDSSY NS_SWIFT_NAME(keyDSSY());

@property (nonatomic,readonly,assign,getter=keyECCD) NSData* keyECCD NS_SWIFT_NAME(keyECCD);

- (NSData*)keyECCD NS_SWIFT_NAME(keyECCD());

@property (nonatomic,readonly,assign,getter=keyECCQX) NSData* keyECCQX NS_SWIFT_NAME(keyECCQX);

- (NSData*)keyECCQX NS_SWIFT_NAME(keyECCQX());

@property (nonatomic,readonly,assign,getter=keyECCQY) NSData* keyECCQY NS_SWIFT_NAME(keyECCQY);

- (NSData*)keyECCQY NS_SWIFT_NAME(keyECCQY());

@property (nonatomic,readonly,assign,getter=keyEdPrivate) NSData* keyEdPrivate NS_SWIFT_NAME(keyEdPrivate);

- (NSData*)keyEdPrivate NS_SWIFT_NAME(keyEdPrivate());

@property (nonatomic,readonly,assign,getter=keyEdPublic) NSData* keyEdPublic NS_SWIFT_NAME(keyEdPublic);

- (NSData*)keyEdPublic NS_SWIFT_NAME(keyEdPublic());

@property (nonatomic,readonly,assign,getter=keyFingerprintMD5) NSString* keyFingerprintMD5 NS_SWIFT_NAME(keyFingerprintMD5);

- (NSString*)keyFingerprintMD5 NS_SWIFT_NAME(keyFingerprintMD5());

@property (nonatomic,readonly,assign,getter=keyFingerprintSHA1) NSString* keyFingerprintSHA1 NS_SWIFT_NAME(keyFingerprintSHA1);

- (NSString*)keyFingerprintSHA1 NS_SWIFT_NAME(keyFingerprintSHA1());

@property (nonatomic,readonly,assign,getter=keyFingerprintSHA256) NSString* keyFingerprintSHA256 NS_SWIFT_NAME(keyFingerprintSHA256);

- (NSString*)keyFingerprintSHA256 NS_SWIFT_NAME(keyFingerprintSHA256());

@property (nonatomic,readwrite,assign,getter=keyHandle,setter=setKeyHandle:) long long keyHandle NS_SWIFT_NAME(keyHandle);

- (long long)keyHandle NS_SWIFT_NAME(keyHandle());
- (void)setKeyHandle :(long long)newKeyHandle NS_SWIFT_NAME(setKeyHandle(_:));

@property (nonatomic,readonly,assign,getter=keyIsExtractable) BOOL keyIsExtractable NS_SWIFT_NAME(keyIsExtractable);

- (BOOL)keyIsExtractable NS_SWIFT_NAME(keyIsExtractable());

@property (nonatomic,readonly,assign,getter=keyIsPrivate) BOOL keyIsPrivate NS_SWIFT_NAME(keyIsPrivate);

- (BOOL)keyIsPrivate NS_SWIFT_NAME(keyIsPrivate());

@property (nonatomic,readonly,assign,getter=keyIsPublic) BOOL keyIsPublic NS_SWIFT_NAME(keyIsPublic);

- (BOOL)keyIsPublic NS_SWIFT_NAME(keyIsPublic());

@property (nonatomic,readonly,assign,getter=keyKDFRounds) int keyKDFRounds NS_SWIFT_NAME(keyKDFRounds);

- (int)keyKDFRounds NS_SWIFT_NAME(keyKDFRounds());

@property (nonatomic,readonly,assign,getter=keyKDFSalt) NSData* keyKDFSalt NS_SWIFT_NAME(keyKDFSalt);

- (NSData*)keyKDFSalt NS_SWIFT_NAME(keyKDFSalt());

@property (nonatomic,readonly,assign,getter=keyKeyFormat) int keyKeyFormat NS_SWIFT_NAME(keyKeyFormat);

- (int)keyKeyFormat NS_SWIFT_NAME(keyKeyFormat());

@property (nonatomic,readonly,assign,getter=keyKeyProtectionAlgorithm) NSString* keyKeyProtectionAlgorithm NS_SWIFT_NAME(keyKeyProtectionAlgorithm);

- (NSString*)keyKeyProtectionAlgorithm NS_SWIFT_NAME(keyKeyProtectionAlgorithm());

@property (nonatomic,readonly,assign,getter=keyRSAExponent) NSData* keyRSAExponent NS_SWIFT_NAME(keyRSAExponent);

- (NSData*)keyRSAExponent NS_SWIFT_NAME(keyRSAExponent());

@property (nonatomic,readonly,assign,getter=keyRSAIQMP) NSData* keyRSAIQMP NS_SWIFT_NAME(keyRSAIQMP);

- (NSData*)keyRSAIQMP NS_SWIFT_NAME(keyRSAIQMP());

@property (nonatomic,readonly,assign,getter=keyRSAModulus) NSData* keyRSAModulus NS_SWIFT_NAME(keyRSAModulus);

- (NSData*)keyRSAModulus NS_SWIFT_NAME(keyRSAModulus());

@property (nonatomic,readonly,assign,getter=keyRSAP) NSData* keyRSAP NS_SWIFT_NAME(keyRSAP);

- (NSData*)keyRSAP NS_SWIFT_NAME(keyRSAP());

@property (nonatomic,readonly,assign,getter=keyRSAPrivateExponent) NSData* keyRSAPrivateExponent NS_SWIFT_NAME(keyRSAPrivateExponent);

- (NSData*)keyRSAPrivateExponent NS_SWIFT_NAME(keyRSAPrivateExponent());

@property (nonatomic,readonly,assign,getter=keyRSAQ) NSData* keyRSAQ NS_SWIFT_NAME(keyRSAQ);

- (NSData*)keyRSAQ NS_SWIFT_NAME(keyRSAQ());

@property (nonatomic,readwrite,assign,getter=keySubject,setter=setKeySubject:) NSString* keySubject NS_SWIFT_NAME(keySubject);

- (NSString*)keySubject NS_SWIFT_NAME(keySubject());
- (void)setKeySubject :(NSString*)newKeySubject NS_SWIFT_NAME(setKeySubject(_:));

  /* Methods */

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (void)createNew NS_SWIFT_NAME(createNew());

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (NSData*)exportBytes:(int)format :(BOOL)privateKey :(NSString*)password NS_SWIFT_NAME(exportBytes(_:_:_:));

- (void)exportToCert NS_SWIFT_NAME(exportToCert());

- (void)exportToCryptoKey NS_SWIFT_NAME(exportToCryptoKey());

- (void)exportToFile:(NSString*)fileName :(int)format :(BOOL)privateKey :(NSString*)password NS_SWIFT_NAME(exportToFile(_:_:_:_:));

- (void)generate:(NSString*)keyAlgorithm :(NSString*)scheme :(NSString*)schemeParams :(int)keyBits NS_SWIFT_NAME(generate(_:_:_:_:));

- (NSData*)getKeyParam:(NSString*)name NS_SWIFT_NAME(getKeyParam(_:));

- (NSString*)getKeyParamStr:(NSString*)name NS_SWIFT_NAME(getKeyParamStr(_:));

- (void)importBytes:(NSData*)bytes :(NSString*)password NS_SWIFT_NAME(importBytes(_:_:));

- (void)importFromCert NS_SWIFT_NAME(importFromCert());

- (void)importFromCryptoKey NS_SWIFT_NAME(importFromCryptoKey());

- (void)importFromFile:(NSString*)path :(NSString*)password NS_SWIFT_NAME(importFromFile(_:_:));

- (void)reset NS_SWIFT_NAME(reset());

- (void)setKeyParam:(NSString*)name :(NSData*)value NS_SWIFT_NAME(setKeyParam(_:_:));

- (void)setKeyParamStr:(NSString*)name :(NSString*)valueStr NS_SWIFT_NAME(setKeyParamStr(_:_:));

@end

