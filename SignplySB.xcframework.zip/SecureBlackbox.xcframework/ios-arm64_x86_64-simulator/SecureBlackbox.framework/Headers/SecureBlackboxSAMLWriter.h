/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//SAMLASSERTIONTYPES
#define CSAT_ASSERTION_IDREF                               0

#define CSAT_ASSERTION_URIREF                              1

#define CSAT_ASSERTION                                     2

#define CSAT_ENCRYPTED_ASSERTION                           3

//SIGNATUREVALIDITIES
#define SVT_VALID                                          0

#define SVT_UNKNOWN                                        1

#define SVT_CORRUPTED                                      2

#define SVT_SIGNER_NOT_FOUND                               3

#define SVT_FAILURE                                        4

#define SVT_REFERENCE_CORRUPTED                            5

//SAMLAUTHNCONTEXTCOMPARISONS
#define CACCT_NONE                                         0

#define CACCT_EXACT                                        1

#define CACCT_MINIMUM                                      2

#define CACCT_MAXIMUM                                      3

#define CACCT_BETTER                                       4

//SAMLAUTHNREFTYPES
#define CACRT_UNKNOWN                                      0

#define CACRT_CLASS                                        1

#define CACRT_DECL                                         2

//SAMLBINDINGTYPES
#define CSBT_NONE                                          0

#define CSBT_SOAP                                          1

#define CSBT_PAOS                                          2

#define CSBT_REDIRECT                                      3

#define CSBT_POST                                          4

#define CSBT_ARTIFACT                                      5

//SAMLPOSTBINDINGMODES
#define CSPM_CLIENT                                        0

#define CSPM_SERVER                                        1

//SAMLCONDITIONTYPES
#define CSCT_AUDIENCE_RESTRICTION                          0

#define CSCT_ONE_TIME_USE                                  1

#define CSCT_PROXY_RESTRICTION                             2

#define CSCT_NOT_BEFORE                                    3

#define CSCT_NOT_ON_OR_AFTER                               4

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

//SAMLCONTENTTYPES
#define CSTY_NONE                                          0

#define CSTY_ASSERTION_IDREQUEST                           1

#define CSTY_SUBJECT_QUERY                                 2

#define CSTY_AUTHN_QUERY                                   3

#define CSTY_ATTRIBUTE_QUERY                               4

#define CSTY_AUTHZ_DECISION_QUERY                          5

#define CSTY_AUTHN_REQUEST                                 6

#define CSTY_MANAGE_NAME_IDREQUEST                         7

#define CSTY_LOGOUT_REQUEST                                8

#define CSTY_NAME_IDMAPPING_REQUEST                        9

#define CSTY_ARTIFACT_RESOLVE                              10

#define CSTY_RESPONSE                                      11

#define CSTY_ASSERTION                                     12

//SAMLRESPONSETYPES
#define CSRT_RESPONSE                                      0

#define CSRT_ARTIFACT_RESPONSE                             1

#define CSRT_NAME_IDMAPPING_RESPONSE                       2

//SAMLSIGNATUREPOLICIES
#define SSP_AUTO                                           0

#define SSP_VALIDATE                                       1

#define SSP_REQUIRE                                        2

#define SSP_IGNORE                                         3

//SAMLDECISIONS
#define CSADN_PERMIT                                       0

#define CSADN_DENY                                         1

#define CSADN_INDETERMINATE                                2

//SAMLASSERTIONSTATEMENTTYPES
#define CSAST_AUTHN                                        0

#define CSAST_ATTRIBUTE                                    1

#define CSAST_AUTHZ_DECISION                               2

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxSAMLWriterDelegate <NSObject>
@optional
- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

@end

@interface SecureBlackboxSAMLWriter : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxSAMLWriterDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasError;

  BOOL m_delegateHasNotification;

}

+ (SecureBlackboxSAMLWriter*)samlwriter;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxSAMLWriterDelegate> delegate;
- (id <SecureBlackboxSAMLWriterDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxSAMLWriterDelegate>)anObject;

  /* Events */

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readwrite,assign,getter=artifactEndpointIndex,setter=setArtifactEndpointIndex:) int artifactEndpointIndex NS_SWIFT_NAME(artifactEndpointIndex);

- (int)artifactEndpointIndex NS_SWIFT_NAME(artifactEndpointIndex());
- (void)setArtifactEndpointIndex :(int)newArtifactEndpointIndex NS_SWIFT_NAME(setArtifactEndpointIndex(_:));

@property (nonatomic,readwrite,assign,getter=artifactMessageHandle,setter=setArtifactMessageHandle:) NSData* artifactMessageHandle NS_SWIFT_NAME(artifactMessageHandle);

- (NSData*)artifactMessageHandle NS_SWIFT_NAME(artifactMessageHandle());
- (void)setArtifactMessageHandle :(NSData*)newArtifactMessageHandle NS_SWIFT_NAME(setArtifactMessageHandle(_:));

@property (nonatomic,readonly,assign,getter=artifactRemainingArtifact) NSData* artifactRemainingArtifact NS_SWIFT_NAME(artifactRemainingArtifact);

- (NSData*)artifactRemainingArtifact NS_SWIFT_NAME(artifactRemainingArtifact());

@property (nonatomic,readwrite,assign,getter=artifactSourceID,setter=setArtifactSourceID:) NSData* artifactSourceID NS_SWIFT_NAME(artifactSourceID);

- (NSData*)artifactSourceID NS_SWIFT_NAME(artifactSourceID());
- (void)setArtifactSourceID :(NSData*)newArtifactSourceID NS_SWIFT_NAME(setArtifactSourceID(_:));

@property (nonatomic,readwrite,assign,getter=artifactTypeCode,setter=setArtifactTypeCode:) int artifactTypeCode NS_SWIFT_NAME(artifactTypeCode);

- (int)artifactTypeCode NS_SWIFT_NAME(artifactTypeCode());
- (void)setArtifactTypeCode :(int)newArtifactTypeCode NS_SWIFT_NAME(setArtifactTypeCode(_:));

@property (nonatomic,readwrite,assign,getter=artifactURI,setter=setArtifactURI:) NSString* artifactURI NS_SWIFT_NAME(artifactURI);

- (NSString*)artifactURI NS_SWIFT_NAME(artifactURI());
- (void)setArtifactURI :(NSString*)newArtifactURI NS_SWIFT_NAME(setArtifactURI(_:));

@property (nonatomic,readwrite,assign,getter=artifactResolveQuery,setter=setArtifactResolveQuery:) NSString* artifactResolveQuery NS_SWIFT_NAME(artifactResolveQuery);

- (NSString*)artifactResolveQuery NS_SWIFT_NAME(artifactResolveQuery());
- (void)setArtifactResolveQuery :(NSString*)newArtifactResolveQuery NS_SWIFT_NAME(setArtifactResolveQuery(_:));

@property (nonatomic,readwrite,assign,getter=assertionAssertionType,setter=setAssertionAssertionType:) int assertionAssertionType NS_SWIFT_NAME(assertionAssertionType);

- (int)assertionAssertionType NS_SWIFT_NAME(assertionAssertionType());
- (void)setAssertionAssertionType :(int)newAssertionAssertionType NS_SWIFT_NAME(setAssertionAssertionType(_:));

@property (nonatomic,readwrite,assign,getter=assertionEncryptedContent,setter=setAssertionEncryptedContent:) NSString* assertionEncryptedContent NS_SWIFT_NAME(assertionEncryptedContent);

- (NSString*)assertionEncryptedContent NS_SWIFT_NAME(assertionEncryptedContent());
- (void)setAssertionEncryptedContent :(NSString*)newAssertionEncryptedContent NS_SWIFT_NAME(setAssertionEncryptedContent(_:));

@property (nonatomic,readwrite,assign,getter=assertionID,setter=setAssertionID:) NSString* assertionID NS_SWIFT_NAME(assertionID);

- (NSString*)assertionID NS_SWIFT_NAME(assertionID());
- (void)setAssertionID :(NSString*)newAssertionID NS_SWIFT_NAME(setAssertionID(_:));

@property (nonatomic,readwrite,assign,getter=assertionIDRef,setter=setAssertionIDRef:) NSString* assertionIDRef NS_SWIFT_NAME(assertionIDRef);

- (NSString*)assertionIDRef NS_SWIFT_NAME(assertionIDRef());
- (void)setAssertionIDRef :(NSString*)newAssertionIDRef NS_SWIFT_NAME(setAssertionIDRef(_:));

@property (nonatomic,readwrite,assign,getter=assertionIssueInstant,setter=setAssertionIssueInstant:) NSString* assertionIssueInstant NS_SWIFT_NAME(assertionIssueInstant);

- (NSString*)assertionIssueInstant NS_SWIFT_NAME(assertionIssueInstant());
- (void)setAssertionIssueInstant :(NSString*)newAssertionIssueInstant NS_SWIFT_NAME(setAssertionIssueInstant(_:));

@property (nonatomic,readwrite,assign,getter=assertionIssuer,setter=setAssertionIssuer:) NSString* assertionIssuer NS_SWIFT_NAME(assertionIssuer);

- (NSString*)assertionIssuer NS_SWIFT_NAME(assertionIssuer());
- (void)setAssertionIssuer :(NSString*)newAssertionIssuer NS_SWIFT_NAME(setAssertionIssuer(_:));

@property (nonatomic,readwrite,assign,getter=assertionParentAssertion,setter=setAssertionParentAssertion:) int assertionParentAssertion NS_SWIFT_NAME(assertionParentAssertion);

- (int)assertionParentAssertion NS_SWIFT_NAME(assertionParentAssertion());
- (void)setAssertionParentAssertion :(int)newAssertionParentAssertion NS_SWIFT_NAME(setAssertionParentAssertion(_:));

@property (nonatomic,readonly,assign,getter=assertionSignatureValidationResult) int assertionSignatureValidationResult NS_SWIFT_NAME(assertionSignatureValidationResult);

- (int)assertionSignatureValidationResult NS_SWIFT_NAME(assertionSignatureValidationResult());

@property (nonatomic,readwrite,assign,getter=assertionSigned,setter=setAssertionSigned:) BOOL assertionSigned NS_SWIFT_NAME(assertionSigned);

- (BOOL)assertionSigned NS_SWIFT_NAME(assertionSigned());
- (void)setAssertionSigned :(BOOL)newAssertionSigned NS_SWIFT_NAME(setAssertionSigned(_:));

@property (nonatomic,readwrite,assign,getter=assertionSubject,setter=setAssertionSubject:) NSString* assertionSubject NS_SWIFT_NAME(assertionSubject);

- (NSString*)assertionSubject NS_SWIFT_NAME(assertionSubject());
- (void)setAssertionSubject :(NSString*)newAssertionSubject NS_SWIFT_NAME(setAssertionSubject(_:));

@property (nonatomic,readwrite,assign,getter=assertionURIRef,setter=setAssertionURIRef:) NSString* assertionURIRef NS_SWIFT_NAME(assertionURIRef);

- (NSString*)assertionURIRef NS_SWIFT_NAME(assertionURIRef());
- (void)setAssertionURIRef :(NSString*)newAssertionURIRef NS_SWIFT_NAME(setAssertionURIRef(_:));

@property (nonatomic,readwrite,assign,getter=assertionVersion,setter=setAssertionVersion:) NSString* assertionVersion NS_SWIFT_NAME(assertionVersion);

- (NSString*)assertionVersion NS_SWIFT_NAME(assertionVersion());
- (void)setAssertionVersion :(NSString*)newAssertionVersion NS_SWIFT_NAME(setAssertionVersion(_:));

@property (nonatomic,readonly,assign,getter=assertionCount) int assertionCount NS_SWIFT_NAME(assertionCount);

- (int)assertionCount NS_SWIFT_NAME(assertionCount());

@property (nonatomic,readwrite,assign,getter=attributeCount,setter=setAttributeCount:) int attributeCount NS_SWIFT_NAME(attributeCount);

- (int)attributeCount NS_SWIFT_NAME(attributeCount());
- (void)setAttributeCount :(int)newAttributeCount NS_SWIFT_NAME(setAttributeCount(_:));

- (NSString*)attributeFriendlyName:(int)attributeIndex NS_SWIFT_NAME(attributeFriendlyName(_:));
- (void)setAttributeFriendlyName:(int)attributeIndex :(NSString*)newAttributeFriendlyName NS_SWIFT_NAME(setAttributeFriendlyName(_:_:));

- (NSString*)attributeName:(int)attributeIndex NS_SWIFT_NAME(attributeName(_:));
- (void)setAttributeName:(int)attributeIndex :(NSString*)newAttributeName NS_SWIFT_NAME(setAttributeName(_:_:));

- (NSString*)attributeNameFormat:(int)attributeIndex NS_SWIFT_NAME(attributeNameFormat(_:));
- (void)setAttributeNameFormat:(int)attributeIndex :(NSString*)newAttributeNameFormat NS_SWIFT_NAME(setAttributeNameFormat(_:_:));

- (int)attributeStatementIndex:(int)attributeIndex NS_SWIFT_NAME(attributeStatementIndex(_:));
- (void)setAttributeStatementIndex:(int)attributeIndex :(int)newAttributeStatementIndex NS_SWIFT_NAME(setAttributeStatementIndex(_:_:));

- (NSString*)attributeValues:(int)attributeIndex NS_SWIFT_NAME(attributeValues(_:));
- (void)setAttributeValues:(int)attributeIndex :(NSString*)newAttributeValues NS_SWIFT_NAME(setAttributeValues(_:_:));

@property (nonatomic,readwrite,assign,getter=authnQueryComparison,setter=setAuthnQueryComparison:) int authnQueryComparison NS_SWIFT_NAME(authnQueryComparison);

- (int)authnQueryComparison NS_SWIFT_NAME(authnQueryComparison());
- (void)setAuthnQueryComparison :(int)newAuthnQueryComparison NS_SWIFT_NAME(setAuthnQueryComparison(_:));

@property (nonatomic,readwrite,assign,getter=authnQueryContextClassRefs,setter=setAuthnQueryContextClassRefs:) NSString* authnQueryContextClassRefs NS_SWIFT_NAME(authnQueryContextClassRefs);

- (NSString*)authnQueryContextClassRefs NS_SWIFT_NAME(authnQueryContextClassRefs());
- (void)setAuthnQueryContextClassRefs :(NSString*)newAuthnQueryContextClassRefs NS_SWIFT_NAME(setAuthnQueryContextClassRefs(_:));

@property (nonatomic,readwrite,assign,getter=authnQueryRefType,setter=setAuthnQueryRefType:) int authnQueryRefType NS_SWIFT_NAME(authnQueryRefType);

- (int)authnQueryRefType NS_SWIFT_NAME(authnQueryRefType());
- (void)setAuthnQueryRefType :(int)newAuthnQueryRefType NS_SWIFT_NAME(setAuthnQueryRefType(_:));

@property (nonatomic,readwrite,assign,getter=authnQuerySessionIndex,setter=setAuthnQuerySessionIndex:) NSString* authnQuerySessionIndex NS_SWIFT_NAME(authnQuerySessionIndex);

- (NSString*)authnQuerySessionIndex NS_SWIFT_NAME(authnQuerySessionIndex());
- (void)setAuthnQuerySessionIndex :(NSString*)newAuthnQuerySessionIndex NS_SWIFT_NAME(setAuthnQuerySessionIndex(_:));

@property (nonatomic,readwrite,assign,getter=authnRequestAssertionConsumerServiceIndex,setter=setAuthnRequestAssertionConsumerServiceIndex:) int authnRequestAssertionConsumerServiceIndex NS_SWIFT_NAME(authnRequestAssertionConsumerServiceIndex);

- (int)authnRequestAssertionConsumerServiceIndex NS_SWIFT_NAME(authnRequestAssertionConsumerServiceIndex());
- (void)setAuthnRequestAssertionConsumerServiceIndex :(int)newAuthnRequestAssertionConsumerServiceIndex NS_SWIFT_NAME(setAuthnRequestAssertionConsumerServiceIndex(_:));

@property (nonatomic,readwrite,assign,getter=authnRequestAssertionConsumerServiceURL,setter=setAuthnRequestAssertionConsumerServiceURL:) NSString* authnRequestAssertionConsumerServiceURL NS_SWIFT_NAME(authnRequestAssertionConsumerServiceURL);

- (NSString*)authnRequestAssertionConsumerServiceURL NS_SWIFT_NAME(authnRequestAssertionConsumerServiceURL());
- (void)setAuthnRequestAssertionConsumerServiceURL :(NSString*)newAuthnRequestAssertionConsumerServiceURL NS_SWIFT_NAME(setAuthnRequestAssertionConsumerServiceURL(_:));

@property (nonatomic,readwrite,assign,getter=authnRequestAttributeConsumingServiceIndex,setter=setAuthnRequestAttributeConsumingServiceIndex:) int authnRequestAttributeConsumingServiceIndex NS_SWIFT_NAME(authnRequestAttributeConsumingServiceIndex);

- (int)authnRequestAttributeConsumingServiceIndex NS_SWIFT_NAME(authnRequestAttributeConsumingServiceIndex());
- (void)setAuthnRequestAttributeConsumingServiceIndex :(int)newAuthnRequestAttributeConsumingServiceIndex NS_SWIFT_NAME(setAuthnRequestAttributeConsumingServiceIndex(_:));

@property (nonatomic,readwrite,assign,getter=authnRequestContextClassRefs,setter=setAuthnRequestContextClassRefs:) NSString* authnRequestContextClassRefs NS_SWIFT_NAME(authnRequestContextClassRefs);

- (NSString*)authnRequestContextClassRefs NS_SWIFT_NAME(authnRequestContextClassRefs());
- (void)setAuthnRequestContextClassRefs :(NSString*)newAuthnRequestContextClassRefs NS_SWIFT_NAME(setAuthnRequestContextClassRefs(_:));

@property (nonatomic,readwrite,assign,getter=authnRequestContextComparison,setter=setAuthnRequestContextComparison:) int authnRequestContextComparison NS_SWIFT_NAME(authnRequestContextComparison);

- (int)authnRequestContextComparison NS_SWIFT_NAME(authnRequestContextComparison());
- (void)setAuthnRequestContextComparison :(int)newAuthnRequestContextComparison NS_SWIFT_NAME(setAuthnRequestContextComparison(_:));

@property (nonatomic,readwrite,assign,getter=authnRequestContextRefType,setter=setAuthnRequestContextRefType:) int authnRequestContextRefType NS_SWIFT_NAME(authnRequestContextRefType);

- (int)authnRequestContextRefType NS_SWIFT_NAME(authnRequestContextRefType());
- (void)setAuthnRequestContextRefType :(int)newAuthnRequestContextRefType NS_SWIFT_NAME(setAuthnRequestContextRefType(_:));

@property (nonatomic,readwrite,assign,getter=authnRequestFlags,setter=setAuthnRequestFlags:) int authnRequestFlags NS_SWIFT_NAME(authnRequestFlags);

- (int)authnRequestFlags NS_SWIFT_NAME(authnRequestFlags());
- (void)setAuthnRequestFlags :(int)newAuthnRequestFlags NS_SWIFT_NAME(setAuthnRequestFlags(_:));

@property (nonatomic,readwrite,assign,getter=authnRequestForceAuthn,setter=setAuthnRequestForceAuthn:) BOOL authnRequestForceAuthn NS_SWIFT_NAME(authnRequestForceAuthn);

- (BOOL)authnRequestForceAuthn NS_SWIFT_NAME(authnRequestForceAuthn());
- (void)setAuthnRequestForceAuthn :(BOOL)newAuthnRequestForceAuthn NS_SWIFT_NAME(setAuthnRequestForceAuthn(_:));

@property (nonatomic,readwrite,assign,getter=authnRequestIsPassive,setter=setAuthnRequestIsPassive:) BOOL authnRequestIsPassive NS_SWIFT_NAME(authnRequestIsPassive);

- (BOOL)authnRequestIsPassive NS_SWIFT_NAME(authnRequestIsPassive());
- (void)setAuthnRequestIsPassive :(BOOL)newAuthnRequestIsPassive NS_SWIFT_NAME(setAuthnRequestIsPassive(_:));

@property (nonatomic,readwrite,assign,getter=authnRequestNameIDPolicyAllowCreate,setter=setAuthnRequestNameIDPolicyAllowCreate:) BOOL authnRequestNameIDPolicyAllowCreate NS_SWIFT_NAME(authnRequestNameIDPolicyAllowCreate);

- (BOOL)authnRequestNameIDPolicyAllowCreate NS_SWIFT_NAME(authnRequestNameIDPolicyAllowCreate());
- (void)setAuthnRequestNameIDPolicyAllowCreate :(BOOL)newAuthnRequestNameIDPolicyAllowCreate NS_SWIFT_NAME(setAuthnRequestNameIDPolicyAllowCreate(_:));

@property (nonatomic,readwrite,assign,getter=authnRequestNameIDPolicyFormat,setter=setAuthnRequestNameIDPolicyFormat:) NSString* authnRequestNameIDPolicyFormat NS_SWIFT_NAME(authnRequestNameIDPolicyFormat);

- (NSString*)authnRequestNameIDPolicyFormat NS_SWIFT_NAME(authnRequestNameIDPolicyFormat());
- (void)setAuthnRequestNameIDPolicyFormat :(NSString*)newAuthnRequestNameIDPolicyFormat NS_SWIFT_NAME(setAuthnRequestNameIDPolicyFormat(_:));

@property (nonatomic,readwrite,assign,getter=authnRequestNameIDPolicySPNameQualifier,setter=setAuthnRequestNameIDPolicySPNameQualifier:) NSString* authnRequestNameIDPolicySPNameQualifier NS_SWIFT_NAME(authnRequestNameIDPolicySPNameQualifier);

- (NSString*)authnRequestNameIDPolicySPNameQualifier NS_SWIFT_NAME(authnRequestNameIDPolicySPNameQualifier());
- (void)setAuthnRequestNameIDPolicySPNameQualifier :(NSString*)newAuthnRequestNameIDPolicySPNameQualifier NS_SWIFT_NAME(setAuthnRequestNameIDPolicySPNameQualifier(_:));

@property (nonatomic,readwrite,assign,getter=authnRequestProtocolBinding,setter=setAuthnRequestProtocolBinding:) NSString* authnRequestProtocolBinding NS_SWIFT_NAME(authnRequestProtocolBinding);

- (NSString*)authnRequestProtocolBinding NS_SWIFT_NAME(authnRequestProtocolBinding());
- (void)setAuthnRequestProtocolBinding :(NSString*)newAuthnRequestProtocolBinding NS_SWIFT_NAME(setAuthnRequestProtocolBinding(_:));

@property (nonatomic,readwrite,assign,getter=authnRequestProviderName,setter=setAuthnRequestProviderName:) NSString* authnRequestProviderName NS_SWIFT_NAME(authnRequestProviderName);

- (NSString*)authnRequestProviderName NS_SWIFT_NAME(authnRequestProviderName());
- (void)setAuthnRequestProviderName :(NSString*)newAuthnRequestProviderName NS_SWIFT_NAME(setAuthnRequestProviderName(_:));

@property (nonatomic,readwrite,assign,getter=authnRequestScopingGetComplete,setter=setAuthnRequestScopingGetComplete:) NSString* authnRequestScopingGetComplete NS_SWIFT_NAME(authnRequestScopingGetComplete);

- (NSString*)authnRequestScopingGetComplete NS_SWIFT_NAME(authnRequestScopingGetComplete());
- (void)setAuthnRequestScopingGetComplete :(NSString*)newAuthnRequestScopingGetComplete NS_SWIFT_NAME(setAuthnRequestScopingGetComplete(_:));

@property (nonatomic,readwrite,assign,getter=authnRequestScopingProxyCount,setter=setAuthnRequestScopingProxyCount:) int authnRequestScopingProxyCount NS_SWIFT_NAME(authnRequestScopingProxyCount);

- (int)authnRequestScopingProxyCount NS_SWIFT_NAME(authnRequestScopingProxyCount());
- (void)setAuthnRequestScopingProxyCount :(int)newAuthnRequestScopingProxyCount NS_SWIFT_NAME(setAuthnRequestScopingProxyCount(_:));

@property (nonatomic,readwrite,assign,getter=authnRequestScopingRequesterIDs,setter=setAuthnRequestScopingRequesterIDs:) NSString* authnRequestScopingRequesterIDs NS_SWIFT_NAME(authnRequestScopingRequesterIDs);

- (NSString*)authnRequestScopingRequesterIDs NS_SWIFT_NAME(authnRequestScopingRequesterIDs());
- (void)setAuthnRequestScopingRequesterIDs :(NSString*)newAuthnRequestScopingRequesterIDs NS_SWIFT_NAME(setAuthnRequestScopingRequesterIDs(_:));

@property (nonatomic,readwrite,assign,getter=authzDecisionQueryActions,setter=setAuthzDecisionQueryActions:) NSString* authzDecisionQueryActions NS_SWIFT_NAME(authzDecisionQueryActions);

- (NSString*)authzDecisionQueryActions NS_SWIFT_NAME(authzDecisionQueryActions());
- (void)setAuthzDecisionQueryActions :(NSString*)newAuthzDecisionQueryActions NS_SWIFT_NAME(setAuthzDecisionQueryActions(_:));

@property (nonatomic,readwrite,assign,getter=authzDecisionQueryResource,setter=setAuthzDecisionQueryResource:) NSString* authzDecisionQueryResource NS_SWIFT_NAME(authzDecisionQueryResource);

- (NSString*)authzDecisionQueryResource NS_SWIFT_NAME(authzDecisionQueryResource());
- (void)setAuthzDecisionQueryResource :(NSString*)newAuthzDecisionQueryResource NS_SWIFT_NAME(setAuthzDecisionQueryResource(_:));

@property (nonatomic,readwrite,assign,getter=bindingBindingType,setter=setBindingBindingType:) int bindingBindingType NS_SWIFT_NAME(bindingBindingType);

- (int)bindingBindingType NS_SWIFT_NAME(bindingBindingType());
- (void)setBindingBindingType :(int)newBindingBindingType NS_SWIFT_NAME(setBindingBindingType(_:));

@property (nonatomic,readwrite,assign,getter=bindingBody,setter=setBindingBody:) NSString* bindingBody NS_SWIFT_NAME(bindingBody);

- (NSString*)bindingBody NS_SWIFT_NAME(bindingBody());
- (void)setBindingBody :(NSString*)newBindingBody NS_SWIFT_NAME(setBindingBody(_:));

@property (nonatomic,readwrite,assign,getter=bindingEncoding,setter=setBindingEncoding:) NSString* bindingEncoding NS_SWIFT_NAME(bindingEncoding);

- (NSString*)bindingEncoding NS_SWIFT_NAME(bindingEncoding());
- (void)setBindingEncoding :(NSString*)newBindingEncoding NS_SWIFT_NAME(setBindingEncoding(_:));

@property (nonatomic,readwrite,assign,getter=bindingForceSign,setter=setBindingForceSign:) BOOL bindingForceSign NS_SWIFT_NAME(bindingForceSign);

- (BOOL)bindingForceSign NS_SWIFT_NAME(bindingForceSign());
- (void)setBindingForceSign :(BOOL)newBindingForceSign NS_SWIFT_NAME(setBindingForceSign(_:));

@property (nonatomic,readwrite,assign,getter=bindingFormTemplate,setter=setBindingFormTemplate:) NSString* bindingFormTemplate NS_SWIFT_NAME(bindingFormTemplate);

- (NSString*)bindingFormTemplate NS_SWIFT_NAME(bindingFormTemplate());
- (void)setBindingFormTemplate :(NSString*)newBindingFormTemplate NS_SWIFT_NAME(setBindingFormTemplate(_:));

@property (nonatomic,readwrite,assign,getter=bindingPOSTMode,setter=setBindingPOSTMode:) int bindingPOSTMode NS_SWIFT_NAME(bindingPOSTMode);

- (int)bindingPOSTMode NS_SWIFT_NAME(bindingPOSTMode());
- (void)setBindingPOSTMode :(int)newBindingPOSTMode NS_SWIFT_NAME(setBindingPOSTMode(_:));

@property (nonatomic,readwrite,assign,getter=bindingRelayState,setter=setBindingRelayState:) NSString* bindingRelayState NS_SWIFT_NAME(bindingRelayState);

- (NSString*)bindingRelayState NS_SWIFT_NAME(bindingRelayState());
- (void)setBindingRelayState :(NSString*)newBindingRelayState NS_SWIFT_NAME(setBindingRelayState(_:));

@property (nonatomic,readwrite,assign,getter=bindingSignatureAlgorithm,setter=setBindingSignatureAlgorithm:) NSString* bindingSignatureAlgorithm NS_SWIFT_NAME(bindingSignatureAlgorithm);

- (NSString*)bindingSignatureAlgorithm NS_SWIFT_NAME(bindingSignatureAlgorithm());
- (void)setBindingSignatureAlgorithm :(NSString*)newBindingSignatureAlgorithm NS_SWIFT_NAME(setBindingSignatureAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=bindingSignatureValidationResult) int bindingSignatureValidationResult NS_SWIFT_NAME(bindingSignatureValidationResult);

- (int)bindingSignatureValidationResult NS_SWIFT_NAME(bindingSignatureValidationResult());

@property (nonatomic,readwrite,assign,getter=bindingSigned,setter=setBindingSigned:) BOOL bindingSigned NS_SWIFT_NAME(bindingSigned);

- (BOOL)bindingSigned NS_SWIFT_NAME(bindingSigned());
- (void)setBindingSigned :(BOOL)newBindingSigned NS_SWIFT_NAME(setBindingSigned(_:));

@property (nonatomic,readwrite,assign,getter=bindingURL,setter=setBindingURL:) NSString* bindingURL NS_SWIFT_NAME(bindingURL);

- (NSString*)bindingURL NS_SWIFT_NAME(bindingURL());
- (void)setBindingURL :(NSString*)newBindingURL NS_SWIFT_NAME(setBindingURL(_:));

@property (nonatomic,readwrite,assign,getter=bindingVerifySignatures,setter=setBindingVerifySignatures:) BOOL bindingVerifySignatures NS_SWIFT_NAME(bindingVerifySignatures);

- (BOOL)bindingVerifySignatures NS_SWIFT_NAME(bindingVerifySignatures());
- (void)setBindingVerifySignatures :(BOOL)newBindingVerifySignatures NS_SWIFT_NAME(setBindingVerifySignatures(_:));

@property (nonatomic,readwrite,assign,getter=bindingKeyAlgorithm,setter=setBindingKeyAlgorithm:) NSString* bindingKeyAlgorithm NS_SWIFT_NAME(bindingKeyAlgorithm);

- (NSString*)bindingKeyAlgorithm NS_SWIFT_NAME(bindingKeyAlgorithm());
- (void)setBindingKeyAlgorithm :(NSString*)newBindingKeyAlgorithm NS_SWIFT_NAME(setBindingKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=bindingKeyBits) int bindingKeyBits NS_SWIFT_NAME(bindingKeyBits);

- (int)bindingKeyBits NS_SWIFT_NAME(bindingKeyBits());

@property (nonatomic,readwrite,assign,getter=bindingKeyCurve,setter=setBindingKeyCurve:) NSString* bindingKeyCurve NS_SWIFT_NAME(bindingKeyCurve);

- (NSString*)bindingKeyCurve NS_SWIFT_NAME(bindingKeyCurve());
- (void)setBindingKeyCurve :(NSString*)newBindingKeyCurve NS_SWIFT_NAME(setBindingKeyCurve(_:));

@property (nonatomic,readonly,assign,getter=bindingKeyExportable) BOOL bindingKeyExportable NS_SWIFT_NAME(bindingKeyExportable);

- (BOOL)bindingKeyExportable NS_SWIFT_NAME(bindingKeyExportable());

@property (nonatomic,readonly,assign,getter=bindingKeyFingerprint) NSString* bindingKeyFingerprint NS_SWIFT_NAME(bindingKeyFingerprint);

- (NSString*)bindingKeyFingerprint NS_SWIFT_NAME(bindingKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=bindingKeyHandle,setter=setBindingKeyHandle:) long long bindingKeyHandle NS_SWIFT_NAME(bindingKeyHandle);

- (long long)bindingKeyHandle NS_SWIFT_NAME(bindingKeyHandle());
- (void)setBindingKeyHandle :(long long)newBindingKeyHandle NS_SWIFT_NAME(setBindingKeyHandle(_:));

@property (nonatomic,readwrite,assign,getter=bindingKeyID,setter=setBindingKeyID:) NSData* bindingKeyID NS_SWIFT_NAME(bindingKeyID);

- (NSData*)bindingKeyID NS_SWIFT_NAME(bindingKeyID());
- (void)setBindingKeyID :(NSData*)newBindingKeyID NS_SWIFT_NAME(setBindingKeyID(_:));

@property (nonatomic,readwrite,assign,getter=bindingKeyIV,setter=setBindingKeyIV:) NSData* bindingKeyIV NS_SWIFT_NAME(bindingKeyIV);

- (NSData*)bindingKeyIV NS_SWIFT_NAME(bindingKeyIV());
- (void)setBindingKeyIV :(NSData*)newBindingKeyIV NS_SWIFT_NAME(setBindingKeyIV(_:));

@property (nonatomic,readonly,assign,getter=bindingKeyKey) NSData* bindingKeyKey NS_SWIFT_NAME(bindingKeyKey);

- (NSData*)bindingKeyKey NS_SWIFT_NAME(bindingKeyKey());

@property (nonatomic,readwrite,assign,getter=bindingKeyNonce,setter=setBindingKeyNonce:) NSData* bindingKeyNonce NS_SWIFT_NAME(bindingKeyNonce);

- (NSData*)bindingKeyNonce NS_SWIFT_NAME(bindingKeyNonce());
- (void)setBindingKeyNonce :(NSData*)newBindingKeyNonce NS_SWIFT_NAME(setBindingKeyNonce(_:));

@property (nonatomic,readonly,assign,getter=bindingKeyPrivate) BOOL bindingKeyPrivate NS_SWIFT_NAME(bindingKeyPrivate);

- (BOOL)bindingKeyPrivate NS_SWIFT_NAME(bindingKeyPrivate());

@property (nonatomic,readonly,assign,getter=bindingKeyPublic) BOOL bindingKeyPublic NS_SWIFT_NAME(bindingKeyPublic);

- (BOOL)bindingKeyPublic NS_SWIFT_NAME(bindingKeyPublic());

@property (nonatomic,readwrite,assign,getter=bindingKeySubject,setter=setBindingKeySubject:) NSData* bindingKeySubject NS_SWIFT_NAME(bindingKeySubject);

- (NSData*)bindingKeySubject NS_SWIFT_NAME(bindingKeySubject());
- (void)setBindingKeySubject :(NSData*)newBindingKeySubject NS_SWIFT_NAME(setBindingKeySubject(_:));

@property (nonatomic,readonly,assign,getter=bindingKeySymmetric) BOOL bindingKeySymmetric NS_SWIFT_NAME(bindingKeySymmetric);

- (BOOL)bindingKeySymmetric NS_SWIFT_NAME(bindingKeySymmetric());

@property (nonatomic,readonly,assign,getter=bindingKeyValid) BOOL bindingKeyValid NS_SWIFT_NAME(bindingKeyValid);

- (BOOL)bindingKeyValid NS_SWIFT_NAME(bindingKeyValid());

@property (nonatomic,readwrite,assign,getter=conditionCount,setter=setConditionCount:) int conditionCount NS_SWIFT_NAME(conditionCount);

- (int)conditionCount NS_SWIFT_NAME(conditionCount());
- (void)setConditionCount :(int)newConditionCount NS_SWIFT_NAME(setConditionCount(_:));

- (NSString*)conditionCondition:(int)conditionIndex NS_SWIFT_NAME(conditionCondition(_:));
- (void)setConditionCondition:(int)conditionIndex :(NSString*)newConditionCondition NS_SWIFT_NAME(setConditionCondition(_:_:));

- (int)conditionConditionType:(int)conditionIndex NS_SWIFT_NAME(conditionConditionType(_:));
- (void)setConditionConditionType:(int)conditionIndex :(int)newConditionConditionType NS_SWIFT_NAME(setConditionConditionType(_:_:));

@property (nonatomic,readonly,assign,getter=encryptionCertBytes) NSData* encryptionCertBytes NS_SWIFT_NAME(encryptionCertBytes);

- (NSData*)encryptionCertBytes NS_SWIFT_NAME(encryptionCertBytes());

@property (nonatomic,readwrite,assign,getter=encryptionCertCA,setter=setEncryptionCertCA:) BOOL encryptionCertCA NS_SWIFT_NAME(encryptionCertCA);

- (BOOL)encryptionCertCA NS_SWIFT_NAME(encryptionCertCA());
- (void)setEncryptionCertCA :(BOOL)newEncryptionCertCA NS_SWIFT_NAME(setEncryptionCertCA(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertCAKeyID) NSData* encryptionCertCAKeyID NS_SWIFT_NAME(encryptionCertCAKeyID);

- (NSData*)encryptionCertCAKeyID NS_SWIFT_NAME(encryptionCertCAKeyID());

@property (nonatomic,readonly,assign,getter=encryptionCertCertType) int encryptionCertCertType NS_SWIFT_NAME(encryptionCertCertType);

- (int)encryptionCertCertType NS_SWIFT_NAME(encryptionCertCertType());

@property (nonatomic,readwrite,assign,getter=encryptionCertCRLDistributionPoints,setter=setEncryptionCertCRLDistributionPoints:) NSString* encryptionCertCRLDistributionPoints NS_SWIFT_NAME(encryptionCertCRLDistributionPoints);

- (NSString*)encryptionCertCRLDistributionPoints NS_SWIFT_NAME(encryptionCertCRLDistributionPoints());
- (void)setEncryptionCertCRLDistributionPoints :(NSString*)newEncryptionCertCRLDistributionPoints NS_SWIFT_NAME(setEncryptionCertCRLDistributionPoints(_:));

@property (nonatomic,readwrite,assign,getter=encryptionCertCurve,setter=setEncryptionCertCurve:) NSString* encryptionCertCurve NS_SWIFT_NAME(encryptionCertCurve);

- (NSString*)encryptionCertCurve NS_SWIFT_NAME(encryptionCertCurve());
- (void)setEncryptionCertCurve :(NSString*)newEncryptionCertCurve NS_SWIFT_NAME(setEncryptionCertCurve(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertFingerprint) NSString* encryptionCertFingerprint NS_SWIFT_NAME(encryptionCertFingerprint);

- (NSString*)encryptionCertFingerprint NS_SWIFT_NAME(encryptionCertFingerprint());

@property (nonatomic,readonly,assign,getter=encryptionCertFriendlyName) NSString* encryptionCertFriendlyName NS_SWIFT_NAME(encryptionCertFriendlyName);

- (NSString*)encryptionCertFriendlyName NS_SWIFT_NAME(encryptionCertFriendlyName());

@property (nonatomic,readwrite,assign,getter=encryptionCertHandle,setter=setEncryptionCertHandle:) long long encryptionCertHandle NS_SWIFT_NAME(encryptionCertHandle);

- (long long)encryptionCertHandle NS_SWIFT_NAME(encryptionCertHandle());
- (void)setEncryptionCertHandle :(long long)newEncryptionCertHandle NS_SWIFT_NAME(setEncryptionCertHandle(_:));

@property (nonatomic,readwrite,assign,getter=encryptionCertHashAlgorithm,setter=setEncryptionCertHashAlgorithm:) NSString* encryptionCertHashAlgorithm NS_SWIFT_NAME(encryptionCertHashAlgorithm);

- (NSString*)encryptionCertHashAlgorithm NS_SWIFT_NAME(encryptionCertHashAlgorithm());
- (void)setEncryptionCertHashAlgorithm :(NSString*)newEncryptionCertHashAlgorithm NS_SWIFT_NAME(setEncryptionCertHashAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertIssuer) NSString* encryptionCertIssuer NS_SWIFT_NAME(encryptionCertIssuer);

- (NSString*)encryptionCertIssuer NS_SWIFT_NAME(encryptionCertIssuer());

@property (nonatomic,readwrite,assign,getter=encryptionCertIssuerRDN,setter=setEncryptionCertIssuerRDN:) NSString* encryptionCertIssuerRDN NS_SWIFT_NAME(encryptionCertIssuerRDN);

- (NSString*)encryptionCertIssuerRDN NS_SWIFT_NAME(encryptionCertIssuerRDN());
- (void)setEncryptionCertIssuerRDN :(NSString*)newEncryptionCertIssuerRDN NS_SWIFT_NAME(setEncryptionCertIssuerRDN(_:));

@property (nonatomic,readwrite,assign,getter=encryptionCertKeyAlgorithm,setter=setEncryptionCertKeyAlgorithm:) NSString* encryptionCertKeyAlgorithm NS_SWIFT_NAME(encryptionCertKeyAlgorithm);

- (NSString*)encryptionCertKeyAlgorithm NS_SWIFT_NAME(encryptionCertKeyAlgorithm());
- (void)setEncryptionCertKeyAlgorithm :(NSString*)newEncryptionCertKeyAlgorithm NS_SWIFT_NAME(setEncryptionCertKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertKeyBits) int encryptionCertKeyBits NS_SWIFT_NAME(encryptionCertKeyBits);

- (int)encryptionCertKeyBits NS_SWIFT_NAME(encryptionCertKeyBits());

@property (nonatomic,readonly,assign,getter=encryptionCertKeyFingerprint) NSString* encryptionCertKeyFingerprint NS_SWIFT_NAME(encryptionCertKeyFingerprint);

- (NSString*)encryptionCertKeyFingerprint NS_SWIFT_NAME(encryptionCertKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=encryptionCertKeyUsage,setter=setEncryptionCertKeyUsage:) int encryptionCertKeyUsage NS_SWIFT_NAME(encryptionCertKeyUsage);

- (int)encryptionCertKeyUsage NS_SWIFT_NAME(encryptionCertKeyUsage());
- (void)setEncryptionCertKeyUsage :(int)newEncryptionCertKeyUsage NS_SWIFT_NAME(setEncryptionCertKeyUsage(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertKeyValid) BOOL encryptionCertKeyValid NS_SWIFT_NAME(encryptionCertKeyValid);

- (BOOL)encryptionCertKeyValid NS_SWIFT_NAME(encryptionCertKeyValid());

@property (nonatomic,readwrite,assign,getter=encryptionCertOCSPLocations,setter=setEncryptionCertOCSPLocations:) NSString* encryptionCertOCSPLocations NS_SWIFT_NAME(encryptionCertOCSPLocations);

- (NSString*)encryptionCertOCSPLocations NS_SWIFT_NAME(encryptionCertOCSPLocations());
- (void)setEncryptionCertOCSPLocations :(NSString*)newEncryptionCertOCSPLocations NS_SWIFT_NAME(setEncryptionCertOCSPLocations(_:));

@property (nonatomic,readwrite,assign,getter=encryptionCertOCSPNoCheck,setter=setEncryptionCertOCSPNoCheck:) BOOL encryptionCertOCSPNoCheck NS_SWIFT_NAME(encryptionCertOCSPNoCheck);

- (BOOL)encryptionCertOCSPNoCheck NS_SWIFT_NAME(encryptionCertOCSPNoCheck());
- (void)setEncryptionCertOCSPNoCheck :(BOOL)newEncryptionCertOCSPNoCheck NS_SWIFT_NAME(setEncryptionCertOCSPNoCheck(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertOrigin) int encryptionCertOrigin NS_SWIFT_NAME(encryptionCertOrigin);

- (int)encryptionCertOrigin NS_SWIFT_NAME(encryptionCertOrigin());

@property (nonatomic,readwrite,assign,getter=encryptionCertPolicyIDs,setter=setEncryptionCertPolicyIDs:) NSString* encryptionCertPolicyIDs NS_SWIFT_NAME(encryptionCertPolicyIDs);

- (NSString*)encryptionCertPolicyIDs NS_SWIFT_NAME(encryptionCertPolicyIDs());
- (void)setEncryptionCertPolicyIDs :(NSString*)newEncryptionCertPolicyIDs NS_SWIFT_NAME(setEncryptionCertPolicyIDs(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertPrivateKeyBytes) NSData* encryptionCertPrivateKeyBytes NS_SWIFT_NAME(encryptionCertPrivateKeyBytes);

- (NSData*)encryptionCertPrivateKeyBytes NS_SWIFT_NAME(encryptionCertPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=encryptionCertPrivateKeyExists) BOOL encryptionCertPrivateKeyExists NS_SWIFT_NAME(encryptionCertPrivateKeyExists);

- (BOOL)encryptionCertPrivateKeyExists NS_SWIFT_NAME(encryptionCertPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=encryptionCertPrivateKeyExtractable) BOOL encryptionCertPrivateKeyExtractable NS_SWIFT_NAME(encryptionCertPrivateKeyExtractable);

- (BOOL)encryptionCertPrivateKeyExtractable NS_SWIFT_NAME(encryptionCertPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=encryptionCertPublicKeyBytes) NSData* encryptionCertPublicKeyBytes NS_SWIFT_NAME(encryptionCertPublicKeyBytes);

- (NSData*)encryptionCertPublicKeyBytes NS_SWIFT_NAME(encryptionCertPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=encryptionCertQualified) BOOL encryptionCertQualified NS_SWIFT_NAME(encryptionCertQualified);

- (BOOL)encryptionCertQualified NS_SWIFT_NAME(encryptionCertQualified());

@property (nonatomic,readwrite,assign,getter=encryptionCertQualifiedStatements,setter=setEncryptionCertQualifiedStatements:) int encryptionCertQualifiedStatements NS_SWIFT_NAME(encryptionCertQualifiedStatements);

- (int)encryptionCertQualifiedStatements NS_SWIFT_NAME(encryptionCertQualifiedStatements());
- (void)setEncryptionCertQualifiedStatements :(int)newEncryptionCertQualifiedStatements NS_SWIFT_NAME(setEncryptionCertQualifiedStatements(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertQualifiers) NSString* encryptionCertQualifiers NS_SWIFT_NAME(encryptionCertQualifiers);

- (NSString*)encryptionCertQualifiers NS_SWIFT_NAME(encryptionCertQualifiers());

@property (nonatomic,readonly,assign,getter=encryptionCertSelfSigned) BOOL encryptionCertSelfSigned NS_SWIFT_NAME(encryptionCertSelfSigned);

- (BOOL)encryptionCertSelfSigned NS_SWIFT_NAME(encryptionCertSelfSigned());

@property (nonatomic,readwrite,assign,getter=encryptionCertSerialNumber,setter=setEncryptionCertSerialNumber:) NSData* encryptionCertSerialNumber NS_SWIFT_NAME(encryptionCertSerialNumber);

- (NSData*)encryptionCertSerialNumber NS_SWIFT_NAME(encryptionCertSerialNumber());
- (void)setEncryptionCertSerialNumber :(NSData*)newEncryptionCertSerialNumber NS_SWIFT_NAME(setEncryptionCertSerialNumber(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertSigAlgorithm) NSString* encryptionCertSigAlgorithm NS_SWIFT_NAME(encryptionCertSigAlgorithm);

- (NSString*)encryptionCertSigAlgorithm NS_SWIFT_NAME(encryptionCertSigAlgorithm());

@property (nonatomic,readonly,assign,getter=encryptionCertSource) int encryptionCertSource NS_SWIFT_NAME(encryptionCertSource);

- (int)encryptionCertSource NS_SWIFT_NAME(encryptionCertSource());

@property (nonatomic,readonly,assign,getter=encryptionCertSubject) NSString* encryptionCertSubject NS_SWIFT_NAME(encryptionCertSubject);

- (NSString*)encryptionCertSubject NS_SWIFT_NAME(encryptionCertSubject());

@property (nonatomic,readwrite,assign,getter=encryptionCertSubjectAlternativeName,setter=setEncryptionCertSubjectAlternativeName:) NSString* encryptionCertSubjectAlternativeName NS_SWIFT_NAME(encryptionCertSubjectAlternativeName);

- (NSString*)encryptionCertSubjectAlternativeName NS_SWIFT_NAME(encryptionCertSubjectAlternativeName());
- (void)setEncryptionCertSubjectAlternativeName :(NSString*)newEncryptionCertSubjectAlternativeName NS_SWIFT_NAME(setEncryptionCertSubjectAlternativeName(_:));

@property (nonatomic,readwrite,assign,getter=encryptionCertSubjectKeyID,setter=setEncryptionCertSubjectKeyID:) NSData* encryptionCertSubjectKeyID NS_SWIFT_NAME(encryptionCertSubjectKeyID);

- (NSData*)encryptionCertSubjectKeyID NS_SWIFT_NAME(encryptionCertSubjectKeyID());
- (void)setEncryptionCertSubjectKeyID :(NSData*)newEncryptionCertSubjectKeyID NS_SWIFT_NAME(setEncryptionCertSubjectKeyID(_:));

@property (nonatomic,readwrite,assign,getter=encryptionCertSubjectRDN,setter=setEncryptionCertSubjectRDN:) NSString* encryptionCertSubjectRDN NS_SWIFT_NAME(encryptionCertSubjectRDN);

- (NSString*)encryptionCertSubjectRDN NS_SWIFT_NAME(encryptionCertSubjectRDN());
- (void)setEncryptionCertSubjectRDN :(NSString*)newEncryptionCertSubjectRDN NS_SWIFT_NAME(setEncryptionCertSubjectRDN(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertValid) BOOL encryptionCertValid NS_SWIFT_NAME(encryptionCertValid);

- (BOOL)encryptionCertValid NS_SWIFT_NAME(encryptionCertValid());

@property (nonatomic,readwrite,assign,getter=encryptionCertValidFrom,setter=setEncryptionCertValidFrom:) NSString* encryptionCertValidFrom NS_SWIFT_NAME(encryptionCertValidFrom);

- (NSString*)encryptionCertValidFrom NS_SWIFT_NAME(encryptionCertValidFrom());
- (void)setEncryptionCertValidFrom :(NSString*)newEncryptionCertValidFrom NS_SWIFT_NAME(setEncryptionCertValidFrom(_:));

@property (nonatomic,readwrite,assign,getter=encryptionCertValidTo,setter=setEncryptionCertValidTo:) NSString* encryptionCertValidTo NS_SWIFT_NAME(encryptionCertValidTo);

- (NSString*)encryptionCertValidTo NS_SWIFT_NAME(encryptionCertValidTo());
- (void)setEncryptionCertValidTo :(NSString*)newEncryptionCertValidTo NS_SWIFT_NAME(setEncryptionCertValidTo(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=logoutRequestNameID,setter=setLogoutRequestNameID:) NSString* logoutRequestNameID NS_SWIFT_NAME(logoutRequestNameID);

- (NSString*)logoutRequestNameID NS_SWIFT_NAME(logoutRequestNameID());
- (void)setLogoutRequestNameID :(NSString*)newLogoutRequestNameID NS_SWIFT_NAME(setLogoutRequestNameID(_:));

@property (nonatomic,readwrite,assign,getter=logoutRequestNotOnOrAfter,setter=setLogoutRequestNotOnOrAfter:) NSString* logoutRequestNotOnOrAfter NS_SWIFT_NAME(logoutRequestNotOnOrAfter);

- (NSString*)logoutRequestNotOnOrAfter NS_SWIFT_NAME(logoutRequestNotOnOrAfter());
- (void)setLogoutRequestNotOnOrAfter :(NSString*)newLogoutRequestNotOnOrAfter NS_SWIFT_NAME(setLogoutRequestNotOnOrAfter(_:));

@property (nonatomic,readwrite,assign,getter=logoutRequestReason,setter=setLogoutRequestReason:) NSString* logoutRequestReason NS_SWIFT_NAME(logoutRequestReason);

- (NSString*)logoutRequestReason NS_SWIFT_NAME(logoutRequestReason());
- (void)setLogoutRequestReason :(NSString*)newLogoutRequestReason NS_SWIFT_NAME(setLogoutRequestReason(_:));

@property (nonatomic,readwrite,assign,getter=logoutRequestSessionIndexes,setter=setLogoutRequestSessionIndexes:) NSString* logoutRequestSessionIndexes NS_SWIFT_NAME(logoutRequestSessionIndexes);

- (NSString*)logoutRequestSessionIndexes NS_SWIFT_NAME(logoutRequestSessionIndexes());
- (void)setLogoutRequestSessionIndexes :(NSString*)newLogoutRequestSessionIndexes NS_SWIFT_NAME(setLogoutRequestSessionIndexes(_:));

@property (nonatomic,readwrite,assign,getter=manageNameIDRequestNameID,setter=setManageNameIDRequestNameID:) NSString* manageNameIDRequestNameID NS_SWIFT_NAME(manageNameIDRequestNameID);

- (NSString*)manageNameIDRequestNameID NS_SWIFT_NAME(manageNameIDRequestNameID());
- (void)setManageNameIDRequestNameID :(NSString*)newManageNameIDRequestNameID NS_SWIFT_NAME(setManageNameIDRequestNameID(_:));

@property (nonatomic,readwrite,assign,getter=manageNameIDRequestNewEncryptedID,setter=setManageNameIDRequestNewEncryptedID:) NSString* manageNameIDRequestNewEncryptedID NS_SWIFT_NAME(manageNameIDRequestNewEncryptedID);

- (NSString*)manageNameIDRequestNewEncryptedID NS_SWIFT_NAME(manageNameIDRequestNewEncryptedID());
- (void)setManageNameIDRequestNewEncryptedID :(NSString*)newManageNameIDRequestNewEncryptedID NS_SWIFT_NAME(setManageNameIDRequestNewEncryptedID(_:));

@property (nonatomic,readwrite,assign,getter=manageNameIDRequestNewID,setter=setManageNameIDRequestNewID:) NSString* manageNameIDRequestNewID NS_SWIFT_NAME(manageNameIDRequestNewID);

- (NSString*)manageNameIDRequestNewID NS_SWIFT_NAME(manageNameIDRequestNewID());
- (void)setManageNameIDRequestNewID :(NSString*)newManageNameIDRequestNewID NS_SWIFT_NAME(setManageNameIDRequestNewID(_:));

@property (nonatomic,readwrite,assign,getter=manageNameIDRequestTerminate,setter=setManageNameIDRequestTerminate:) NSString* manageNameIDRequestTerminate NS_SWIFT_NAME(manageNameIDRequestTerminate);

- (NSString*)manageNameIDRequestTerminate NS_SWIFT_NAME(manageNameIDRequestTerminate());
- (void)setManageNameIDRequestTerminate :(NSString*)newManageNameIDRequestTerminate NS_SWIFT_NAME(setManageNameIDRequestTerminate(_:));

@property (nonatomic,readwrite,assign,getter=messageConsent,setter=setMessageConsent:) NSString* messageConsent NS_SWIFT_NAME(messageConsent);

- (NSString*)messageConsent NS_SWIFT_NAME(messageConsent());
- (void)setMessageConsent :(NSString*)newMessageConsent NS_SWIFT_NAME(setMessageConsent(_:));

@property (nonatomic,readonly,assign,getter=messageContentType) int messageContentType NS_SWIFT_NAME(messageContentType);

- (int)messageContentType NS_SWIFT_NAME(messageContentType());

@property (nonatomic,readonly,assign,getter=messageContentTypeString) NSString* messageContentTypeString NS_SWIFT_NAME(messageContentTypeString);

- (NSString*)messageContentTypeString NS_SWIFT_NAME(messageContentTypeString());

@property (nonatomic,readwrite,assign,getter=messageDestination,setter=setMessageDestination:) NSString* messageDestination NS_SWIFT_NAME(messageDestination);

- (NSString*)messageDestination NS_SWIFT_NAME(messageDestination());
- (void)setMessageDestination :(NSString*)newMessageDestination NS_SWIFT_NAME(setMessageDestination(_:));

@property (nonatomic,readwrite,assign,getter=messageID,setter=setMessageID:) NSString* messageID NS_SWIFT_NAME(messageID);

- (NSString*)messageID NS_SWIFT_NAME(messageID());
- (void)setMessageID :(NSString*)newMessageID NS_SWIFT_NAME(setMessageID(_:));

@property (nonatomic,readwrite,assign,getter=messageInResponseTo,setter=setMessageInResponseTo:) NSString* messageInResponseTo NS_SWIFT_NAME(messageInResponseTo);

- (NSString*)messageInResponseTo NS_SWIFT_NAME(messageInResponseTo());
- (void)setMessageInResponseTo :(NSString*)newMessageInResponseTo NS_SWIFT_NAME(setMessageInResponseTo(_:));

@property (nonatomic,readwrite,assign,getter=messageIssueInstant,setter=setMessageIssueInstant:) NSString* messageIssueInstant NS_SWIFT_NAME(messageIssueInstant);

- (NSString*)messageIssueInstant NS_SWIFT_NAME(messageIssueInstant());
- (void)setMessageIssueInstant :(NSString*)newMessageIssueInstant NS_SWIFT_NAME(setMessageIssueInstant(_:));

@property (nonatomic,readwrite,assign,getter=messageIssuer,setter=setMessageIssuer:) NSString* messageIssuer NS_SWIFT_NAME(messageIssuer);

- (NSString*)messageIssuer NS_SWIFT_NAME(messageIssuer());
- (void)setMessageIssuer :(NSString*)newMessageIssuer NS_SWIFT_NAME(setMessageIssuer(_:));

@property (nonatomic,readonly,assign,getter=messageSignatureValidationResult) int messageSignatureValidationResult NS_SWIFT_NAME(messageSignatureValidationResult);

- (int)messageSignatureValidationResult NS_SWIFT_NAME(messageSignatureValidationResult());

@property (nonatomic,readwrite,assign,getter=messageSigned,setter=setMessageSigned:) BOOL messageSigned NS_SWIFT_NAME(messageSigned);

- (BOOL)messageSigned NS_SWIFT_NAME(messageSigned());
- (void)setMessageSigned :(BOOL)newMessageSigned NS_SWIFT_NAME(setMessageSigned(_:));

@property (nonatomic,readwrite,assign,getter=messageSubject,setter=setMessageSubject:) NSString* messageSubject NS_SWIFT_NAME(messageSubject);

- (NSString*)messageSubject NS_SWIFT_NAME(messageSubject());
- (void)setMessageSubject :(NSString*)newMessageSubject NS_SWIFT_NAME(setMessageSubject(_:));

@property (nonatomic,readwrite,assign,getter=messageVersion,setter=setMessageVersion:) NSString* messageVersion NS_SWIFT_NAME(messageVersion);

- (NSString*)messageVersion NS_SWIFT_NAME(messageVersion());
- (void)setMessageVersion :(NSString*)newMessageVersion NS_SWIFT_NAME(setMessageVersion(_:));

@property (nonatomic,readwrite,assign,getter=messageXMLHeader,setter=setMessageXMLHeader:) BOOL messageXMLHeader NS_SWIFT_NAME(messageXMLHeader);

- (BOOL)messageXMLHeader NS_SWIFT_NAME(messageXMLHeader());
- (void)setMessageXMLHeader :(BOOL)newMessageXMLHeader NS_SWIFT_NAME(setMessageXMLHeader(_:));

@property (nonatomic,readwrite,assign,getter=nameIDMappingRequestNameID,setter=setNameIDMappingRequestNameID:) NSString* nameIDMappingRequestNameID NS_SWIFT_NAME(nameIDMappingRequestNameID);

- (NSString*)nameIDMappingRequestNameID NS_SWIFT_NAME(nameIDMappingRequestNameID());
- (void)setNameIDMappingRequestNameID :(NSString*)newNameIDMappingRequestNameID NS_SWIFT_NAME(setNameIDMappingRequestNameID(_:));

@property (nonatomic,readwrite,assign,getter=nameIDMappingRequestNameIDPolicyAllowCreate,setter=setNameIDMappingRequestNameIDPolicyAllowCreate:) BOOL nameIDMappingRequestNameIDPolicyAllowCreate NS_SWIFT_NAME(nameIDMappingRequestNameIDPolicyAllowCreate);

- (BOOL)nameIDMappingRequestNameIDPolicyAllowCreate NS_SWIFT_NAME(nameIDMappingRequestNameIDPolicyAllowCreate());
- (void)setNameIDMappingRequestNameIDPolicyAllowCreate :(BOOL)newNameIDMappingRequestNameIDPolicyAllowCreate NS_SWIFT_NAME(setNameIDMappingRequestNameIDPolicyAllowCreate(_:));

@property (nonatomic,readwrite,assign,getter=nameIDMappingRequestNameIDPolicyFormat,setter=setNameIDMappingRequestNameIDPolicyFormat:) NSString* nameIDMappingRequestNameIDPolicyFormat NS_SWIFT_NAME(nameIDMappingRequestNameIDPolicyFormat);

- (NSString*)nameIDMappingRequestNameIDPolicyFormat NS_SWIFT_NAME(nameIDMappingRequestNameIDPolicyFormat());
- (void)setNameIDMappingRequestNameIDPolicyFormat :(NSString*)newNameIDMappingRequestNameIDPolicyFormat NS_SWIFT_NAME(setNameIDMappingRequestNameIDPolicyFormat(_:));

@property (nonatomic,readwrite,assign,getter=nameIDMappingRequestNameIDPolicySPNameQualifier,setter=setNameIDMappingRequestNameIDPolicySPNameQualifier:) NSString* nameIDMappingRequestNameIDPolicySPNameQualifier NS_SWIFT_NAME(nameIDMappingRequestNameIDPolicySPNameQualifier);

- (NSString*)nameIDMappingRequestNameIDPolicySPNameQualifier NS_SWIFT_NAME(nameIDMappingRequestNameIDPolicySPNameQualifier());
- (void)setNameIDMappingRequestNameIDPolicySPNameQualifier :(NSString*)newNameIDMappingRequestNameIDPolicySPNameQualifier NS_SWIFT_NAME(setNameIDMappingRequestNameIDPolicySPNameQualifier(_:));

@property (nonatomic,readwrite,assign,getter=nameIDMappingRequestNameIDPolicyUseAllowCreate,setter=setNameIDMappingRequestNameIDPolicyUseAllowCreate:) BOOL nameIDMappingRequestNameIDPolicyUseAllowCreate NS_SWIFT_NAME(nameIDMappingRequestNameIDPolicyUseAllowCreate);

- (BOOL)nameIDMappingRequestNameIDPolicyUseAllowCreate NS_SWIFT_NAME(nameIDMappingRequestNameIDPolicyUseAllowCreate());
- (void)setNameIDMappingRequestNameIDPolicyUseAllowCreate :(BOOL)newNameIDMappingRequestNameIDPolicyUseAllowCreate NS_SWIFT_NAME(setNameIDMappingRequestNameIDPolicyUseAllowCreate(_:));

@property (nonatomic,readwrite,assign,getter=profile,setter=setProfile:) NSString* profile NS_SWIFT_NAME(profile);

- (NSString*)profile NS_SWIFT_NAME(profile());
- (void)setProfile :(NSString*)newProfile NS_SWIFT_NAME(setProfile(_:));

@property (nonatomic,readwrite,assign,getter=references,setter=setReferences:) NSString* references NS_SWIFT_NAME(references);

- (NSString*)references NS_SWIFT_NAME(references());
- (void)setReferences :(NSString*)newReferences NS_SWIFT_NAME(setReferences(_:));

@property (nonatomic,readwrite,assign,getter=responseNameID,setter=setResponseNameID:) NSString* responseNameID NS_SWIFT_NAME(responseNameID);

- (NSString*)responseNameID NS_SWIFT_NAME(responseNameID());
- (void)setResponseNameID :(NSString*)newResponseNameID NS_SWIFT_NAME(setResponseNameID(_:));

@property (nonatomic,readwrite,assign,getter=responseOptionalElement,setter=setResponseOptionalElement:) NSString* responseOptionalElement NS_SWIFT_NAME(responseOptionalElement);

- (NSString*)responseOptionalElement NS_SWIFT_NAME(responseOptionalElement());
- (void)setResponseOptionalElement :(NSString*)newResponseOptionalElement NS_SWIFT_NAME(setResponseOptionalElement(_:));

@property (nonatomic,readwrite,assign,getter=responseResponseType,setter=setResponseResponseType:) int responseResponseType NS_SWIFT_NAME(responseResponseType);

- (int)responseResponseType NS_SWIFT_NAME(responseResponseType());
- (void)setResponseResponseType :(int)newResponseResponseType NS_SWIFT_NAME(setResponseResponseType(_:));

@property (nonatomic,readwrite,assign,getter=responseStatus,setter=setResponseStatus:) int responseStatus NS_SWIFT_NAME(responseStatus);

- (int)responseStatus NS_SWIFT_NAME(responseStatus());
- (void)setResponseStatus :(int)newResponseStatus NS_SWIFT_NAME(setResponseStatus(_:));

@property (nonatomic,readwrite,assign,getter=responseStatusCodeSubValue,setter=setResponseStatusCodeSubValue:) NSString* responseStatusCodeSubValue NS_SWIFT_NAME(responseStatusCodeSubValue);

- (NSString*)responseStatusCodeSubValue NS_SWIFT_NAME(responseStatusCodeSubValue());
- (void)setResponseStatusCodeSubValue :(NSString*)newResponseStatusCodeSubValue NS_SWIFT_NAME(setResponseStatusCodeSubValue(_:));

@property (nonatomic,readwrite,assign,getter=responseStatusCodeValue,setter=setResponseStatusCodeValue:) NSString* responseStatusCodeValue NS_SWIFT_NAME(responseStatusCodeValue);

- (NSString*)responseStatusCodeValue NS_SWIFT_NAME(responseStatusCodeValue());
- (void)setResponseStatusCodeValue :(NSString*)newResponseStatusCodeValue NS_SWIFT_NAME(setResponseStatusCodeValue(_:));

@property (nonatomic,readwrite,assign,getter=responseStatusDetail,setter=setResponseStatusDetail:) NSString* responseStatusDetail NS_SWIFT_NAME(responseStatusDetail);

- (NSString*)responseStatusDetail NS_SWIFT_NAME(responseStatusDetail());
- (void)setResponseStatusDetail :(NSString*)newResponseStatusDetail NS_SWIFT_NAME(setResponseStatusDetail(_:));

@property (nonatomic,readwrite,assign,getter=responseStatusMessage,setter=setResponseStatusMessage:) NSString* responseStatusMessage NS_SWIFT_NAME(responseStatusMessage);

- (NSString*)responseStatusMessage NS_SWIFT_NAME(responseStatusMessage());
- (void)setResponseStatusMessage :(NSString*)newResponseStatusMessage NS_SWIFT_NAME(setResponseStatusMessage(_:));

@property (nonatomic,readwrite,assign,getter=scopingIDPCount,setter=setScopingIDPCount:) int scopingIDPCount NS_SWIFT_NAME(scopingIDPCount);

- (int)scopingIDPCount NS_SWIFT_NAME(scopingIDPCount());
- (void)setScopingIDPCount :(int)newScopingIDPCount NS_SWIFT_NAME(setScopingIDPCount(_:));

- (NSString*)scopingIDPLoc:(int)scopingIDPIndex NS_SWIFT_NAME(scopingIDPLoc(_:));
- (void)setScopingIDPLoc:(int)scopingIDPIndex :(NSString*)newScopingIDPLoc NS_SWIFT_NAME(setScopingIDPLoc(_:_:));

- (NSString*)scopingIDPName:(int)scopingIDPIndex NS_SWIFT_NAME(scopingIDPName(_:));
- (void)setScopingIDPName:(int)scopingIDPIndex :(NSString*)newScopingIDPName NS_SWIFT_NAME(setScopingIDPName(_:_:));

- (NSString*)scopingIDPProviderID:(int)scopingIDPIndex NS_SWIFT_NAME(scopingIDPProviderID(_:));
- (void)setScopingIDPProviderID:(int)scopingIDPIndex :(NSString*)newScopingIDPProviderID NS_SWIFT_NAME(setScopingIDPProviderID(_:_:));

@property (nonatomic,readwrite,assign,getter=securityCanonicalizationMethod,setter=setSecurityCanonicalizationMethod:) NSString* securityCanonicalizationMethod NS_SWIFT_NAME(securityCanonicalizationMethod);

- (NSString*)securityCanonicalizationMethod NS_SWIFT_NAME(securityCanonicalizationMethod());
- (void)setSecurityCanonicalizationMethod :(NSString*)newSecurityCanonicalizationMethod NS_SWIFT_NAME(setSecurityCanonicalizationMethod(_:));

@property (nonatomic,readwrite,assign,getter=securityDigestMethod,setter=setSecurityDigestMethod:) NSString* securityDigestMethod NS_SWIFT_NAME(securityDigestMethod);

- (NSString*)securityDigestMethod NS_SWIFT_NAME(securityDigestMethod());
- (void)setSecurityDigestMethod :(NSString*)newSecurityDigestMethod NS_SWIFT_NAME(setSecurityDigestMethod(_:));

@property (nonatomic,readwrite,assign,getter=securityEncryptionMethod,setter=setSecurityEncryptionMethod:) NSString* securityEncryptionMethod NS_SWIFT_NAME(securityEncryptionMethod);

- (NSString*)securityEncryptionMethod NS_SWIFT_NAME(securityEncryptionMethod());
- (void)setSecurityEncryptionMethod :(NSString*)newSecurityEncryptionMethod NS_SWIFT_NAME(setSecurityEncryptionMethod(_:));

@property (nonatomic,readwrite,assign,getter=securityFlags,setter=setSecurityFlags:) int securityFlags NS_SWIFT_NAME(securityFlags);

- (int)securityFlags NS_SWIFT_NAME(securityFlags());
- (void)setSecurityFlags :(int)newSecurityFlags NS_SWIFT_NAME(setSecurityFlags(_:));

@property (nonatomic,readwrite,assign,getter=securitySigMethod,setter=setSecuritySigMethod:) NSString* securitySigMethod NS_SWIFT_NAME(securitySigMethod);

- (NSString*)securitySigMethod NS_SWIFT_NAME(securitySigMethod());
- (void)setSecuritySigMethod :(NSString*)newSecuritySigMethod NS_SWIFT_NAME(setSecuritySigMethod(_:));

@property (nonatomic,readwrite,assign,getter=securitySignaturePolicy,setter=setSecuritySignaturePolicy:) int securitySignaturePolicy NS_SWIFT_NAME(securitySignaturePolicy);

- (int)securitySignaturePolicy NS_SWIFT_NAME(securitySignaturePolicy());
- (void)setSecuritySignaturePolicy :(int)newSecuritySignaturePolicy NS_SWIFT_NAME(setSecuritySignaturePolicy(_:));

@property (nonatomic,readonly,assign,getter=signingCertBytes) NSData* signingCertBytes NS_SWIFT_NAME(signingCertBytes);

- (NSData*)signingCertBytes NS_SWIFT_NAME(signingCertBytes());

@property (nonatomic,readwrite,assign,getter=signingCertCA,setter=setSigningCertCA:) BOOL signingCertCA NS_SWIFT_NAME(signingCertCA);

- (BOOL)signingCertCA NS_SWIFT_NAME(signingCertCA());
- (void)setSigningCertCA :(BOOL)newSigningCertCA NS_SWIFT_NAME(setSigningCertCA(_:));

@property (nonatomic,readonly,assign,getter=signingCertCAKeyID) NSData* signingCertCAKeyID NS_SWIFT_NAME(signingCertCAKeyID);

- (NSData*)signingCertCAKeyID NS_SWIFT_NAME(signingCertCAKeyID());

@property (nonatomic,readonly,assign,getter=signingCertCertType) int signingCertCertType NS_SWIFT_NAME(signingCertCertType);

- (int)signingCertCertType NS_SWIFT_NAME(signingCertCertType());

@property (nonatomic,readwrite,assign,getter=signingCertCRLDistributionPoints,setter=setSigningCertCRLDistributionPoints:) NSString* signingCertCRLDistributionPoints NS_SWIFT_NAME(signingCertCRLDistributionPoints);

- (NSString*)signingCertCRLDistributionPoints NS_SWIFT_NAME(signingCertCRLDistributionPoints());
- (void)setSigningCertCRLDistributionPoints :(NSString*)newSigningCertCRLDistributionPoints NS_SWIFT_NAME(setSigningCertCRLDistributionPoints(_:));

@property (nonatomic,readwrite,assign,getter=signingCertCurve,setter=setSigningCertCurve:) NSString* signingCertCurve NS_SWIFT_NAME(signingCertCurve);

- (NSString*)signingCertCurve NS_SWIFT_NAME(signingCertCurve());
- (void)setSigningCertCurve :(NSString*)newSigningCertCurve NS_SWIFT_NAME(setSigningCertCurve(_:));

@property (nonatomic,readonly,assign,getter=signingCertFingerprint) NSString* signingCertFingerprint NS_SWIFT_NAME(signingCertFingerprint);

- (NSString*)signingCertFingerprint NS_SWIFT_NAME(signingCertFingerprint());

@property (nonatomic,readonly,assign,getter=signingCertFriendlyName) NSString* signingCertFriendlyName NS_SWIFT_NAME(signingCertFriendlyName);

- (NSString*)signingCertFriendlyName NS_SWIFT_NAME(signingCertFriendlyName());

@property (nonatomic,readwrite,assign,getter=signingCertHandle,setter=setSigningCertHandle:) long long signingCertHandle NS_SWIFT_NAME(signingCertHandle);

- (long long)signingCertHandle NS_SWIFT_NAME(signingCertHandle());
- (void)setSigningCertHandle :(long long)newSigningCertHandle NS_SWIFT_NAME(setSigningCertHandle(_:));

@property (nonatomic,readwrite,assign,getter=signingCertHashAlgorithm,setter=setSigningCertHashAlgorithm:) NSString* signingCertHashAlgorithm NS_SWIFT_NAME(signingCertHashAlgorithm);

- (NSString*)signingCertHashAlgorithm NS_SWIFT_NAME(signingCertHashAlgorithm());
- (void)setSigningCertHashAlgorithm :(NSString*)newSigningCertHashAlgorithm NS_SWIFT_NAME(setSigningCertHashAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=signingCertIssuer) NSString* signingCertIssuer NS_SWIFT_NAME(signingCertIssuer);

- (NSString*)signingCertIssuer NS_SWIFT_NAME(signingCertIssuer());

@property (nonatomic,readwrite,assign,getter=signingCertIssuerRDN,setter=setSigningCertIssuerRDN:) NSString* signingCertIssuerRDN NS_SWIFT_NAME(signingCertIssuerRDN);

- (NSString*)signingCertIssuerRDN NS_SWIFT_NAME(signingCertIssuerRDN());
- (void)setSigningCertIssuerRDN :(NSString*)newSigningCertIssuerRDN NS_SWIFT_NAME(setSigningCertIssuerRDN(_:));

@property (nonatomic,readwrite,assign,getter=signingCertKeyAlgorithm,setter=setSigningCertKeyAlgorithm:) NSString* signingCertKeyAlgorithm NS_SWIFT_NAME(signingCertKeyAlgorithm);

- (NSString*)signingCertKeyAlgorithm NS_SWIFT_NAME(signingCertKeyAlgorithm());
- (void)setSigningCertKeyAlgorithm :(NSString*)newSigningCertKeyAlgorithm NS_SWIFT_NAME(setSigningCertKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=signingCertKeyBits) int signingCertKeyBits NS_SWIFT_NAME(signingCertKeyBits);

- (int)signingCertKeyBits NS_SWIFT_NAME(signingCertKeyBits());

@property (nonatomic,readonly,assign,getter=signingCertKeyFingerprint) NSString* signingCertKeyFingerprint NS_SWIFT_NAME(signingCertKeyFingerprint);

- (NSString*)signingCertKeyFingerprint NS_SWIFT_NAME(signingCertKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=signingCertKeyUsage,setter=setSigningCertKeyUsage:) int signingCertKeyUsage NS_SWIFT_NAME(signingCertKeyUsage);

- (int)signingCertKeyUsage NS_SWIFT_NAME(signingCertKeyUsage());
- (void)setSigningCertKeyUsage :(int)newSigningCertKeyUsage NS_SWIFT_NAME(setSigningCertKeyUsage(_:));

@property (nonatomic,readonly,assign,getter=signingCertKeyValid) BOOL signingCertKeyValid NS_SWIFT_NAME(signingCertKeyValid);

- (BOOL)signingCertKeyValid NS_SWIFT_NAME(signingCertKeyValid());

@property (nonatomic,readwrite,assign,getter=signingCertOCSPLocations,setter=setSigningCertOCSPLocations:) NSString* signingCertOCSPLocations NS_SWIFT_NAME(signingCertOCSPLocations);

- (NSString*)signingCertOCSPLocations NS_SWIFT_NAME(signingCertOCSPLocations());
- (void)setSigningCertOCSPLocations :(NSString*)newSigningCertOCSPLocations NS_SWIFT_NAME(setSigningCertOCSPLocations(_:));

@property (nonatomic,readwrite,assign,getter=signingCertOCSPNoCheck,setter=setSigningCertOCSPNoCheck:) BOOL signingCertOCSPNoCheck NS_SWIFT_NAME(signingCertOCSPNoCheck);

- (BOOL)signingCertOCSPNoCheck NS_SWIFT_NAME(signingCertOCSPNoCheck());
- (void)setSigningCertOCSPNoCheck :(BOOL)newSigningCertOCSPNoCheck NS_SWIFT_NAME(setSigningCertOCSPNoCheck(_:));

@property (nonatomic,readonly,assign,getter=signingCertOrigin) int signingCertOrigin NS_SWIFT_NAME(signingCertOrigin);

- (int)signingCertOrigin NS_SWIFT_NAME(signingCertOrigin());

@property (nonatomic,readwrite,assign,getter=signingCertPolicyIDs,setter=setSigningCertPolicyIDs:) NSString* signingCertPolicyIDs NS_SWIFT_NAME(signingCertPolicyIDs);

- (NSString*)signingCertPolicyIDs NS_SWIFT_NAME(signingCertPolicyIDs());
- (void)setSigningCertPolicyIDs :(NSString*)newSigningCertPolicyIDs NS_SWIFT_NAME(setSigningCertPolicyIDs(_:));

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyBytes) NSData* signingCertPrivateKeyBytes NS_SWIFT_NAME(signingCertPrivateKeyBytes);

- (NSData*)signingCertPrivateKeyBytes NS_SWIFT_NAME(signingCertPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyExists) BOOL signingCertPrivateKeyExists NS_SWIFT_NAME(signingCertPrivateKeyExists);

- (BOOL)signingCertPrivateKeyExists NS_SWIFT_NAME(signingCertPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyExtractable) BOOL signingCertPrivateKeyExtractable NS_SWIFT_NAME(signingCertPrivateKeyExtractable);

- (BOOL)signingCertPrivateKeyExtractable NS_SWIFT_NAME(signingCertPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=signingCertPublicKeyBytes) NSData* signingCertPublicKeyBytes NS_SWIFT_NAME(signingCertPublicKeyBytes);

- (NSData*)signingCertPublicKeyBytes NS_SWIFT_NAME(signingCertPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=signingCertQualified) BOOL signingCertQualified NS_SWIFT_NAME(signingCertQualified);

- (BOOL)signingCertQualified NS_SWIFT_NAME(signingCertQualified());

@property (nonatomic,readwrite,assign,getter=signingCertQualifiedStatements,setter=setSigningCertQualifiedStatements:) int signingCertQualifiedStatements NS_SWIFT_NAME(signingCertQualifiedStatements);

- (int)signingCertQualifiedStatements NS_SWIFT_NAME(signingCertQualifiedStatements());
- (void)setSigningCertQualifiedStatements :(int)newSigningCertQualifiedStatements NS_SWIFT_NAME(setSigningCertQualifiedStatements(_:));

@property (nonatomic,readonly,assign,getter=signingCertQualifiers) NSString* signingCertQualifiers NS_SWIFT_NAME(signingCertQualifiers);

- (NSString*)signingCertQualifiers NS_SWIFT_NAME(signingCertQualifiers());

@property (nonatomic,readonly,assign,getter=signingCertSelfSigned) BOOL signingCertSelfSigned NS_SWIFT_NAME(signingCertSelfSigned);

- (BOOL)signingCertSelfSigned NS_SWIFT_NAME(signingCertSelfSigned());

@property (nonatomic,readwrite,assign,getter=signingCertSerialNumber,setter=setSigningCertSerialNumber:) NSData* signingCertSerialNumber NS_SWIFT_NAME(signingCertSerialNumber);

- (NSData*)signingCertSerialNumber NS_SWIFT_NAME(signingCertSerialNumber());
- (void)setSigningCertSerialNumber :(NSData*)newSigningCertSerialNumber NS_SWIFT_NAME(setSigningCertSerialNumber(_:));

@property (nonatomic,readonly,assign,getter=signingCertSigAlgorithm) NSString* signingCertSigAlgorithm NS_SWIFT_NAME(signingCertSigAlgorithm);

- (NSString*)signingCertSigAlgorithm NS_SWIFT_NAME(signingCertSigAlgorithm());

@property (nonatomic,readonly,assign,getter=signingCertSource) int signingCertSource NS_SWIFT_NAME(signingCertSource);

- (int)signingCertSource NS_SWIFT_NAME(signingCertSource());

@property (nonatomic,readonly,assign,getter=signingCertSubject) NSString* signingCertSubject NS_SWIFT_NAME(signingCertSubject);

- (NSString*)signingCertSubject NS_SWIFT_NAME(signingCertSubject());

@property (nonatomic,readwrite,assign,getter=signingCertSubjectAlternativeName,setter=setSigningCertSubjectAlternativeName:) NSString* signingCertSubjectAlternativeName NS_SWIFT_NAME(signingCertSubjectAlternativeName);

- (NSString*)signingCertSubjectAlternativeName NS_SWIFT_NAME(signingCertSubjectAlternativeName());
- (void)setSigningCertSubjectAlternativeName :(NSString*)newSigningCertSubjectAlternativeName NS_SWIFT_NAME(setSigningCertSubjectAlternativeName(_:));

@property (nonatomic,readwrite,assign,getter=signingCertSubjectKeyID,setter=setSigningCertSubjectKeyID:) NSData* signingCertSubjectKeyID NS_SWIFT_NAME(signingCertSubjectKeyID);

- (NSData*)signingCertSubjectKeyID NS_SWIFT_NAME(signingCertSubjectKeyID());
- (void)setSigningCertSubjectKeyID :(NSData*)newSigningCertSubjectKeyID NS_SWIFT_NAME(setSigningCertSubjectKeyID(_:));

@property (nonatomic,readwrite,assign,getter=signingCertSubjectRDN,setter=setSigningCertSubjectRDN:) NSString* signingCertSubjectRDN NS_SWIFT_NAME(signingCertSubjectRDN);

- (NSString*)signingCertSubjectRDN NS_SWIFT_NAME(signingCertSubjectRDN());
- (void)setSigningCertSubjectRDN :(NSString*)newSigningCertSubjectRDN NS_SWIFT_NAME(setSigningCertSubjectRDN(_:));

@property (nonatomic,readonly,assign,getter=signingCertValid) BOOL signingCertValid NS_SWIFT_NAME(signingCertValid);

- (BOOL)signingCertValid NS_SWIFT_NAME(signingCertValid());

@property (nonatomic,readwrite,assign,getter=signingCertValidFrom,setter=setSigningCertValidFrom:) NSString* signingCertValidFrom NS_SWIFT_NAME(signingCertValidFrom);

- (NSString*)signingCertValidFrom NS_SWIFT_NAME(signingCertValidFrom());
- (void)setSigningCertValidFrom :(NSString*)newSigningCertValidFrom NS_SWIFT_NAME(setSigningCertValidFrom(_:));

@property (nonatomic,readwrite,assign,getter=signingCertValidTo,setter=setSigningCertValidTo:) NSString* signingCertValidTo NS_SWIFT_NAME(signingCertValidTo);

- (NSString*)signingCertValidTo NS_SWIFT_NAME(signingCertValidTo());
- (void)setSigningCertValidTo :(NSString*)newSigningCertValidTo NS_SWIFT_NAME(setSigningCertValidTo(_:));

@property (nonatomic,readwrite,assign,getter=signingChainCount,setter=setSigningChainCount:) int signingChainCount NS_SWIFT_NAME(signingChainCount);

- (int)signingChainCount NS_SWIFT_NAME(signingChainCount());
- (void)setSigningChainCount :(int)newSigningChainCount NS_SWIFT_NAME(setSigningChainCount(_:));

- (NSData*)signingChainBytes:(int)signingChainIndex NS_SWIFT_NAME(signingChainBytes(_:));

- (BOOL)signingChainCA:(int)signingChainIndex NS_SWIFT_NAME(signingChainCA(_:));
- (void)setSigningChainCA:(int)signingChainIndex :(BOOL)newSigningChainCA NS_SWIFT_NAME(setSigningChainCA(_:_:));

- (NSData*)signingChainCAKeyID:(int)signingChainIndex NS_SWIFT_NAME(signingChainCAKeyID(_:));

- (int)signingChainCertType:(int)signingChainIndex NS_SWIFT_NAME(signingChainCertType(_:));

- (NSString*)signingChainCRLDistributionPoints:(int)signingChainIndex NS_SWIFT_NAME(signingChainCRLDistributionPoints(_:));
- (void)setSigningChainCRLDistributionPoints:(int)signingChainIndex :(NSString*)newSigningChainCRLDistributionPoints NS_SWIFT_NAME(setSigningChainCRLDistributionPoints(_:_:));

- (NSString*)signingChainCurve:(int)signingChainIndex NS_SWIFT_NAME(signingChainCurve(_:));
- (void)setSigningChainCurve:(int)signingChainIndex :(NSString*)newSigningChainCurve NS_SWIFT_NAME(setSigningChainCurve(_:_:));

- (NSString*)signingChainFingerprint:(int)signingChainIndex NS_SWIFT_NAME(signingChainFingerprint(_:));

- (NSString*)signingChainFriendlyName:(int)signingChainIndex NS_SWIFT_NAME(signingChainFriendlyName(_:));

- (long long)signingChainHandle:(int)signingChainIndex NS_SWIFT_NAME(signingChainHandle(_:));
- (void)setSigningChainHandle:(int)signingChainIndex :(long long)newSigningChainHandle NS_SWIFT_NAME(setSigningChainHandle(_:_:));

- (NSString*)signingChainHashAlgorithm:(int)signingChainIndex NS_SWIFT_NAME(signingChainHashAlgorithm(_:));
- (void)setSigningChainHashAlgorithm:(int)signingChainIndex :(NSString*)newSigningChainHashAlgorithm NS_SWIFT_NAME(setSigningChainHashAlgorithm(_:_:));

- (NSString*)signingChainIssuer:(int)signingChainIndex NS_SWIFT_NAME(signingChainIssuer(_:));

- (NSString*)signingChainIssuerRDN:(int)signingChainIndex NS_SWIFT_NAME(signingChainIssuerRDN(_:));
- (void)setSigningChainIssuerRDN:(int)signingChainIndex :(NSString*)newSigningChainIssuerRDN NS_SWIFT_NAME(setSigningChainIssuerRDN(_:_:));

- (NSString*)signingChainKeyAlgorithm:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyAlgorithm(_:));
- (void)setSigningChainKeyAlgorithm:(int)signingChainIndex :(NSString*)newSigningChainKeyAlgorithm NS_SWIFT_NAME(setSigningChainKeyAlgorithm(_:_:));

- (int)signingChainKeyBits:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyBits(_:));

- (NSString*)signingChainKeyFingerprint:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyFingerprint(_:));

- (int)signingChainKeyUsage:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyUsage(_:));
- (void)setSigningChainKeyUsage:(int)signingChainIndex :(int)newSigningChainKeyUsage NS_SWIFT_NAME(setSigningChainKeyUsage(_:_:));

- (BOOL)signingChainKeyValid:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyValid(_:));

- (NSString*)signingChainOCSPLocations:(int)signingChainIndex NS_SWIFT_NAME(signingChainOCSPLocations(_:));
- (void)setSigningChainOCSPLocations:(int)signingChainIndex :(NSString*)newSigningChainOCSPLocations NS_SWIFT_NAME(setSigningChainOCSPLocations(_:_:));

- (BOOL)signingChainOCSPNoCheck:(int)signingChainIndex NS_SWIFT_NAME(signingChainOCSPNoCheck(_:));
- (void)setSigningChainOCSPNoCheck:(int)signingChainIndex :(BOOL)newSigningChainOCSPNoCheck NS_SWIFT_NAME(setSigningChainOCSPNoCheck(_:_:));

- (int)signingChainOrigin:(int)signingChainIndex NS_SWIFT_NAME(signingChainOrigin(_:));

- (NSString*)signingChainPolicyIDs:(int)signingChainIndex NS_SWIFT_NAME(signingChainPolicyIDs(_:));
- (void)setSigningChainPolicyIDs:(int)signingChainIndex :(NSString*)newSigningChainPolicyIDs NS_SWIFT_NAME(setSigningChainPolicyIDs(_:_:));

- (NSData*)signingChainPrivateKeyBytes:(int)signingChainIndex NS_SWIFT_NAME(signingChainPrivateKeyBytes(_:));

- (BOOL)signingChainPrivateKeyExists:(int)signingChainIndex NS_SWIFT_NAME(signingChainPrivateKeyExists(_:));

- (BOOL)signingChainPrivateKeyExtractable:(int)signingChainIndex NS_SWIFT_NAME(signingChainPrivateKeyExtractable(_:));

- (NSData*)signingChainPublicKeyBytes:(int)signingChainIndex NS_SWIFT_NAME(signingChainPublicKeyBytes(_:));

- (BOOL)signingChainQualified:(int)signingChainIndex NS_SWIFT_NAME(signingChainQualified(_:));

- (int)signingChainQualifiedStatements:(int)signingChainIndex NS_SWIFT_NAME(signingChainQualifiedStatements(_:));
- (void)setSigningChainQualifiedStatements:(int)signingChainIndex :(int)newSigningChainQualifiedStatements NS_SWIFT_NAME(setSigningChainQualifiedStatements(_:_:));

- (NSString*)signingChainQualifiers:(int)signingChainIndex NS_SWIFT_NAME(signingChainQualifiers(_:));

- (BOOL)signingChainSelfSigned:(int)signingChainIndex NS_SWIFT_NAME(signingChainSelfSigned(_:));

- (NSData*)signingChainSerialNumber:(int)signingChainIndex NS_SWIFT_NAME(signingChainSerialNumber(_:));
- (void)setSigningChainSerialNumber:(int)signingChainIndex :(NSData*)newSigningChainSerialNumber NS_SWIFT_NAME(setSigningChainSerialNumber(_:_:));

- (NSString*)signingChainSigAlgorithm:(int)signingChainIndex NS_SWIFT_NAME(signingChainSigAlgorithm(_:));

- (int)signingChainSource:(int)signingChainIndex NS_SWIFT_NAME(signingChainSource(_:));

- (NSString*)signingChainSubject:(int)signingChainIndex NS_SWIFT_NAME(signingChainSubject(_:));

- (NSString*)signingChainSubjectAlternativeName:(int)signingChainIndex NS_SWIFT_NAME(signingChainSubjectAlternativeName(_:));
- (void)setSigningChainSubjectAlternativeName:(int)signingChainIndex :(NSString*)newSigningChainSubjectAlternativeName NS_SWIFT_NAME(setSigningChainSubjectAlternativeName(_:_:));

- (NSData*)signingChainSubjectKeyID:(int)signingChainIndex NS_SWIFT_NAME(signingChainSubjectKeyID(_:));
- (void)setSigningChainSubjectKeyID:(int)signingChainIndex :(NSData*)newSigningChainSubjectKeyID NS_SWIFT_NAME(setSigningChainSubjectKeyID(_:_:));

- (NSString*)signingChainSubjectRDN:(int)signingChainIndex NS_SWIFT_NAME(signingChainSubjectRDN(_:));
- (void)setSigningChainSubjectRDN:(int)signingChainIndex :(NSString*)newSigningChainSubjectRDN NS_SWIFT_NAME(setSigningChainSubjectRDN(_:_:));

- (BOOL)signingChainValid:(int)signingChainIndex NS_SWIFT_NAME(signingChainValid(_:));

- (NSString*)signingChainValidFrom:(int)signingChainIndex NS_SWIFT_NAME(signingChainValidFrom(_:));
- (void)setSigningChainValidFrom:(int)signingChainIndex :(NSString*)newSigningChainValidFrom NS_SWIFT_NAME(setSigningChainValidFrom(_:_:));

- (NSString*)signingChainValidTo:(int)signingChainIndex NS_SWIFT_NAME(signingChainValidTo(_:));
- (void)setSigningChainValidTo:(int)signingChainIndex :(NSString*)newSigningChainValidTo NS_SWIFT_NAME(setSigningChainValidTo(_:_:));

@property (nonatomic,readwrite,assign,getter=statementCount,setter=setStatementCount:) int statementCount NS_SWIFT_NAME(statementCount);

- (int)statementCount NS_SWIFT_NAME(statementCount());
- (void)setStatementCount :(int)newStatementCount NS_SWIFT_NAME(setStatementCount(_:));

- (NSString*)statementAuthnContextAuthenticatingAuthorities:(int)statementIndex NS_SWIFT_NAME(statementAuthnContextAuthenticatingAuthorities(_:));
- (void)setStatementAuthnContextAuthenticatingAuthorities:(int)statementIndex :(NSString*)newStatementAuthnContextAuthenticatingAuthorities NS_SWIFT_NAME(setStatementAuthnContextAuthenticatingAuthorities(_:_:));

- (NSString*)statementAuthnContextChoice:(int)statementIndex NS_SWIFT_NAME(statementAuthnContextChoice(_:));
- (void)setStatementAuthnContextChoice:(int)statementIndex :(NSString*)newStatementAuthnContextChoice NS_SWIFT_NAME(setStatementAuthnContextChoice(_:_:));

- (NSString*)statementAuthnContextClassRef:(int)statementIndex NS_SWIFT_NAME(statementAuthnContextClassRef(_:));
- (void)setStatementAuthnContextClassRef:(int)statementIndex :(NSString*)newStatementAuthnContextClassRef NS_SWIFT_NAME(setStatementAuthnContextClassRef(_:_:));

- (NSString*)statementAuthnContextDecl:(int)statementIndex NS_SWIFT_NAME(statementAuthnContextDecl(_:));
- (void)setStatementAuthnContextDecl:(int)statementIndex :(NSString*)newStatementAuthnContextDecl NS_SWIFT_NAME(setStatementAuthnContextDecl(_:_:));

- (NSString*)statementAuthnContextDeclRef:(int)statementIndex NS_SWIFT_NAME(statementAuthnContextDeclRef(_:));
- (void)setStatementAuthnContextDeclRef:(int)statementIndex :(NSString*)newStatementAuthnContextDeclRef NS_SWIFT_NAME(setStatementAuthnContextDeclRef(_:_:));

- (NSString*)statementAuthnInstant:(int)statementIndex NS_SWIFT_NAME(statementAuthnInstant(_:));
- (void)setStatementAuthnInstant:(int)statementIndex :(NSString*)newStatementAuthnInstant NS_SWIFT_NAME(setStatementAuthnInstant(_:_:));

- (NSString*)statementAuthnSessionIndex:(int)statementIndex NS_SWIFT_NAME(statementAuthnSessionIndex(_:));
- (void)setStatementAuthnSessionIndex:(int)statementIndex :(NSString*)newStatementAuthnSessionIndex NS_SWIFT_NAME(setStatementAuthnSessionIndex(_:_:));

- (NSString*)statementAuthnSessionNotOnOrAfter:(int)statementIndex NS_SWIFT_NAME(statementAuthnSessionNotOnOrAfter(_:));
- (void)setStatementAuthnSessionNotOnOrAfter:(int)statementIndex :(NSString*)newStatementAuthnSessionNotOnOrAfter NS_SWIFT_NAME(setStatementAuthnSessionNotOnOrAfter(_:_:));

- (NSString*)statementAuthnSubjectLocalityAddress:(int)statementIndex NS_SWIFT_NAME(statementAuthnSubjectLocalityAddress(_:));
- (void)setStatementAuthnSubjectLocalityAddress:(int)statementIndex :(NSString*)newStatementAuthnSubjectLocalityAddress NS_SWIFT_NAME(setStatementAuthnSubjectLocalityAddress(_:_:));

- (NSString*)statementAuthnSubjectLocalityDNSName:(int)statementIndex NS_SWIFT_NAME(statementAuthnSubjectLocalityDNSName(_:));
- (void)setStatementAuthnSubjectLocalityDNSName:(int)statementIndex :(NSString*)newStatementAuthnSubjectLocalityDNSName NS_SWIFT_NAME(setStatementAuthnSubjectLocalityDNSName(_:_:));

- (NSString*)statementAuthzActions:(int)statementIndex NS_SWIFT_NAME(statementAuthzActions(_:));
- (void)setStatementAuthzActions:(int)statementIndex :(NSString*)newStatementAuthzActions NS_SWIFT_NAME(setStatementAuthzActions(_:_:));

- (int)statementAuthzDecision:(int)statementIndex NS_SWIFT_NAME(statementAuthzDecision(_:));
- (void)setStatementAuthzDecision:(int)statementIndex :(int)newStatementAuthzDecision NS_SWIFT_NAME(setStatementAuthzDecision(_:_:));

- (NSString*)statementAuthzDecisionEvidence:(int)statementIndex NS_SWIFT_NAME(statementAuthzDecisionEvidence(_:));
- (void)setStatementAuthzDecisionEvidence:(int)statementIndex :(NSString*)newStatementAuthzDecisionEvidence NS_SWIFT_NAME(setStatementAuthzDecisionEvidence(_:_:));

- (NSString*)statementAuthzDecisionResource:(int)statementIndex NS_SWIFT_NAME(statementAuthzDecisionResource(_:));
- (void)setStatementAuthzDecisionResource:(int)statementIndex :(NSString*)newStatementAuthzDecisionResource NS_SWIFT_NAME(setStatementAuthzDecisionResource(_:_:));

- (int)statementStatementType:(int)statementIndex NS_SWIFT_NAME(statementStatementType(_:));
- (void)setStatementStatementType:(int)statementIndex :(int)newStatementStatementType NS_SWIFT_NAME(setStatementStatementType(_:_:));

@property (nonatomic,readwrite,assign,getter=subjectConfirmationCount,setter=setSubjectConfirmationCount:) int subjectConfirmationCount NS_SWIFT_NAME(subjectConfirmationCount);

- (int)subjectConfirmationCount NS_SWIFT_NAME(subjectConfirmationCount());
- (void)setSubjectConfirmationCount :(int)newSubjectConfirmationCount NS_SWIFT_NAME(setSubjectConfirmationCount(_:));

- (NSString*)subjectConfirmationAddress:(int)subjectConfirmationIndex NS_SWIFT_NAME(subjectConfirmationAddress(_:));
- (void)setSubjectConfirmationAddress:(int)subjectConfirmationIndex :(NSString*)newSubjectConfirmationAddress NS_SWIFT_NAME(setSubjectConfirmationAddress(_:_:));

- (NSString*)subjectConfirmationData:(int)subjectConfirmationIndex NS_SWIFT_NAME(subjectConfirmationData(_:));
- (void)setSubjectConfirmationData:(int)subjectConfirmationIndex :(NSString*)newSubjectConfirmationData NS_SWIFT_NAME(setSubjectConfirmationData(_:_:));

- (NSString*)subjectConfirmationDataType:(int)subjectConfirmationIndex NS_SWIFT_NAME(subjectConfirmationDataType(_:));
- (void)setSubjectConfirmationDataType:(int)subjectConfirmationIndex :(NSString*)newSubjectConfirmationDataType NS_SWIFT_NAME(setSubjectConfirmationDataType(_:_:));

- (NSString*)subjectConfirmationID:(int)subjectConfirmationIndex NS_SWIFT_NAME(subjectConfirmationID(_:));
- (void)setSubjectConfirmationID:(int)subjectConfirmationIndex :(NSString*)newSubjectConfirmationID NS_SWIFT_NAME(setSubjectConfirmationID(_:_:));

- (NSString*)subjectConfirmationInResponseTo:(int)subjectConfirmationIndex NS_SWIFT_NAME(subjectConfirmationInResponseTo(_:));
- (void)setSubjectConfirmationInResponseTo:(int)subjectConfirmationIndex :(NSString*)newSubjectConfirmationInResponseTo NS_SWIFT_NAME(setSubjectConfirmationInResponseTo(_:_:));

- (NSString*)subjectConfirmationMethod:(int)subjectConfirmationIndex NS_SWIFT_NAME(subjectConfirmationMethod(_:));
- (void)setSubjectConfirmationMethod:(int)subjectConfirmationIndex :(NSString*)newSubjectConfirmationMethod NS_SWIFT_NAME(setSubjectConfirmationMethod(_:_:));

- (NSString*)subjectConfirmationNotBefore:(int)subjectConfirmationIndex NS_SWIFT_NAME(subjectConfirmationNotBefore(_:));
- (void)setSubjectConfirmationNotBefore:(int)subjectConfirmationIndex :(NSString*)newSubjectConfirmationNotBefore NS_SWIFT_NAME(setSubjectConfirmationNotBefore(_:_:));

- (NSString*)subjectConfirmationNotOnOrAfter:(int)subjectConfirmationIndex NS_SWIFT_NAME(subjectConfirmationNotOnOrAfter(_:));
- (void)setSubjectConfirmationNotOnOrAfter:(int)subjectConfirmationIndex :(NSString*)newSubjectConfirmationNotOnOrAfter NS_SWIFT_NAME(setSubjectConfirmationNotOnOrAfter(_:_:));

- (NSString*)subjectConfirmationRecipient:(int)subjectConfirmationIndex NS_SWIFT_NAME(subjectConfirmationRecipient(_:));
- (void)setSubjectConfirmationRecipient:(int)subjectConfirmationIndex :(NSString*)newSubjectConfirmationRecipient NS_SWIFT_NAME(setSubjectConfirmationRecipient(_:_:));

  /* Methods */

- (int)addAttribute:(NSString*)attributeName :(NSString*)attributeValue :(NSString*)nameFormat :(NSString*)contentType :(int)statementIndex NS_SWIFT_NAME(addAttribute(_:_:_:_:_:));

- (int)addAttributeStatement NS_SWIFT_NAME(addAttributeStatement());

- (int)addAuthnStatement:(NSString*)authnInstant :(NSString*)sessionIndex :(NSString*)notOnOrAfter :(NSString*)classRef NS_SWIFT_NAME(addAuthnStatement(_:_:_:_:));

- (int)addAuthzDecisionStatement:(int)decision :(NSString*)evidence :(NSString*)resource :(NSString*)actions NS_SWIFT_NAME(addAuthzDecisionStatement(_:_:_:_:));

- (int)addCondition:(int)conditionType :(NSString*)conditionValue NS_SWIFT_NAME(addCondition(_:_:));

- (int)addScopingIDP:(NSString*)name :(NSString*)providerID :(NSString*)loc NS_SWIFT_NAME(addScopingIDP(_:_:_:));

- (int)addSubjectConfirmation:(NSString*)method :(NSString*)address :(NSString*)recipient :(NSString*)inResponseTo :(NSString*)notBefore :(NSString*)notOnOrAfter :(NSString*)ID :(NSString*)dataType :(NSString*)data NS_SWIFT_NAME(addSubjectConfirmation(_:_:_:_:_:_:_:_:_:));

- (void)beginAssertion NS_SWIFT_NAME(beginAssertion());

- (int)completeAssertion NS_SWIFT_NAME(completeAssertion());

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (void)createNew:(int)contentType NS_SWIFT_NAME(createNew(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (NSString*)formatID:(NSString*)value :(NSString*)IDType :(NSString*)format :(NSString*)nameQualifier :(NSString*)SPNameQualifier :(NSString*)SPProvidedID NS_SWIFT_NAME(formatID(_:_:_:_:_:_:));

- (void)reset NS_SWIFT_NAME(reset());

- (NSString*)save NS_SWIFT_NAME(save());

- (NSData*)saveBytes NS_SWIFT_NAME(saveBytes());

- (void)saveFile:(NSString*)fileName NS_SWIFT_NAME(saveFile(_:));

@end

