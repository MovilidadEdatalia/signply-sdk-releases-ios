/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//OFFICEDOCUMENTFORMATS
#define ODF_UNKNOWN                                        0

#define ODF_BINARY                                         1

#define ODF_OPEN_XML                                       2

#define ODF_OPEN_XPS                                       3

#define ODF_OPEN_DOCUMENT                                  4

//OFFICEENCRYPTIONTYPES
#define OET_DEFAULT                                        0

#define OET_BINARY_RC4                                     1

#define OET_BINARY_RC4CRYPTO_API                           2

#define OET_OPEN_XMLSTANDARD                               3

#define OET_OPEN_XMLAGILE                                  4

#define OET_OPEN_DOCUMENT                                  5

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxOfficeEncryptorDelegate <NSObject>
@optional
- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

@end

@interface SecureBlackboxOfficeEncryptor : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxOfficeEncryptorDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasError;

  BOOL m_delegateHasNotification;

}

+ (SecureBlackboxOfficeEncryptor*)officeencryptor;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxOfficeEncryptorDelegate> delegate;
- (id <SecureBlackboxOfficeEncryptorDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxOfficeEncryptorDelegate>)anObject;

  /* Events */

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readonly,assign,getter=documentFormat) int documentFormat NS_SWIFT_NAME(documentFormat);

- (int)documentFormat NS_SWIFT_NAME(documentFormat());

@property (nonatomic,readonly,assign,getter=documentType) NSString* documentType NS_SWIFT_NAME(documentType);

- (NSString*)documentType NS_SWIFT_NAME(documentType());

@property (nonatomic,readwrite,assign,getter=encryptionAlgorithm,setter=setEncryptionAlgorithm:) NSString* encryptionAlgorithm NS_SWIFT_NAME(encryptionAlgorithm);

- (NSString*)encryptionAlgorithm NS_SWIFT_NAME(encryptionAlgorithm());
- (void)setEncryptionAlgorithm :(NSString*)newEncryptionAlgorithm NS_SWIFT_NAME(setEncryptionAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=encryptionType,setter=setEncryptionType:) int encryptionType NS_SWIFT_NAME(encryptionType);

- (int)encryptionType NS_SWIFT_NAME(encryptionType());
- (void)setEncryptionType :(int)newEncryptionType NS_SWIFT_NAME(setEncryptionType(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=inputBytes,setter=setInputBytes:) NSData* inputBytes NS_SWIFT_NAME(inputBytes);

- (NSData*)inputBytes NS_SWIFT_NAME(inputBytes());
- (void)setInputBytes :(NSData*)newInputBytes NS_SWIFT_NAME(setInputBytes(_:));

@property (nonatomic,readwrite,assign,getter=inputFile,setter=setInputFile:) NSString* inputFile NS_SWIFT_NAME(inputFile);

- (NSString*)inputFile NS_SWIFT_NAME(inputFile());
- (void)setInputFile :(NSString*)newInputFile NS_SWIFT_NAME(setInputFile(_:));

@property (nonatomic,readonly,assign,getter=outputBytes) NSData* outputBytes NS_SWIFT_NAME(outputBytes);

- (NSData*)outputBytes NS_SWIFT_NAME(outputBytes());

@property (nonatomic,readwrite,assign,getter=outputFile,setter=setOutputFile:) NSString* outputFile NS_SWIFT_NAME(outputFile);

- (NSString*)outputFile NS_SWIFT_NAME(outputFile());
- (void)setOutputFile :(NSString*)newOutputFile NS_SWIFT_NAME(setOutputFile(_:));

@property (nonatomic,readwrite,assign,getter=password,setter=setPassword:) NSString* password NS_SWIFT_NAME(password);

- (NSString*)password NS_SWIFT_NAME(password());
- (void)setPassword :(NSString*)newPassword NS_SWIFT_NAME(setPassword(_:));

  /* Methods */

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (void)encrypt NS_SWIFT_NAME(encrypt());

- (void)reset NS_SWIFT_NAME(reset());

@end

