/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//MAILENCODINGS
#define ME_AUTO                                            0

#define ME_8BIT                                            1

#define ME_BASE_64                                         2

#define ME_QUOTED_PRINTABLE                                3

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

//ASYNCSIGNMETHODS
#define ASMD_PKCS1                                         0

#define ASMD_PKCS7                                         1

//EXTERNALCRYPTOMODES
#define ECM_DEFAULT                                        0

#define ECM_DISABLED                                       1

#define ECM_GENERIC                                        2

#define ECM_DCAUTH                                         3

#define ECM_DCAUTH_JSON                                    4

//MAILPRIORITIES
#define MP_LOWEST                                          0

#define MP_LOW                                             1

#define MP_NORMAL                                          2

#define MP_HIGH                                            3

#define MP_HIGHEST                                         4

//MAILSIGNATUREFORMATS
#define MS_MULTIPART_SIGNED                                0

#define MS_SIGNED_DATA                                     1

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxMailWriterDelegate <NSObject>
@optional
- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onExternalSign:(NSString*)operationId :(NSString*)hashAlgorithm :(NSString*)pars :(NSString*)data :(NSString**)signedData NS_SWIFT_NAME(onExternalSign(_:_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

@end

@interface SecureBlackboxMailWriter : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxMailWriterDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasError;

  BOOL m_delegateHasExternalSign;

  BOOL m_delegateHasNotification;

}

+ (SecureBlackboxMailWriter*)mailwriter;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxMailWriterDelegate> delegate;
- (id <SecureBlackboxMailWriterDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxMailWriterDelegate>)anObject;

  /* Events */

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onExternalSign:(NSString*)operationId :(NSString*)hashAlgorithm :(NSString*)pars :(NSString*)data :(NSString**)signedData NS_SWIFT_NAME(onExternalSign(_:_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readwrite,assign,getter=attachEncoding,setter=setAttachEncoding:) int attachEncoding NS_SWIFT_NAME(attachEncoding);

- (int)attachEncoding NS_SWIFT_NAME(attachEncoding());
- (void)setAttachEncoding :(int)newAttachEncoding NS_SWIFT_NAME(setAttachEncoding(_:));

@property (nonatomic,readwrite,assign,getter=attachCount,setter=setAttachCount:) int attachCount NS_SWIFT_NAME(attachCount);

- (int)attachCount NS_SWIFT_NAME(attachCount());
- (void)setAttachCount :(int)newAttachCount NS_SWIFT_NAME(setAttachCount(_:));

- (NSString*)attachContentSubtype:(int)attachIndex NS_SWIFT_NAME(attachContentSubtype(_:));
- (void)setAttachContentSubtype:(int)attachIndex :(NSString*)newAttachContentSubtype NS_SWIFT_NAME(setAttachContentSubtype(_:_:));

- (NSString*)attachContentType:(int)attachIndex NS_SWIFT_NAME(attachContentType(_:));
- (void)setAttachContentType:(int)attachIndex :(NSString*)newAttachContentType NS_SWIFT_NAME(setAttachContentType(_:_:));

- (NSString*)attachCreationDate:(int)attachIndex NS_SWIFT_NAME(attachCreationDate(_:));
- (void)setAttachCreationDate:(int)attachIndex :(NSString*)newAttachCreationDate NS_SWIFT_NAME(setAttachCreationDate(_:_:));

- (NSData*)attachData:(int)attachIndex NS_SWIFT_NAME(attachData(_:));
- (void)setAttachData:(int)attachIndex :(NSData*)newAttachData NS_SWIFT_NAME(setAttachData(_:_:));

- (NSString*)attachDescription:(int)attachIndex NS_SWIFT_NAME(attachDescription(_:));
- (void)setAttachDescription:(int)attachIndex :(NSString*)newAttachDescription NS_SWIFT_NAME(setAttachDescription(_:_:));

- (NSString*)attachFileName:(int)attachIndex NS_SWIFT_NAME(attachFileName(_:));
- (void)setAttachFileName:(int)attachIndex :(NSString*)newAttachFileName NS_SWIFT_NAME(setAttachFileName(_:_:));

- (long long)attachHandle:(int)attachIndex NS_SWIFT_NAME(attachHandle(_:));
- (void)setAttachHandle:(int)attachIndex :(long long)newAttachHandle NS_SWIFT_NAME(setAttachHandle(_:_:));

- (NSString*)attachID:(int)attachIndex NS_SWIFT_NAME(attachID(_:));
- (void)setAttachID:(int)attachIndex :(NSString*)newAttachID NS_SWIFT_NAME(setAttachID(_:_:));

- (NSString*)attachModificationDate:(int)attachIndex NS_SWIFT_NAME(attachModificationDate(_:));
- (void)setAttachModificationDate:(int)attachIndex :(NSString*)newAttachModificationDate NS_SWIFT_NAME(setAttachModificationDate(_:_:));

- (NSString*)attachReadDate:(int)attachIndex NS_SWIFT_NAME(attachReadDate(_:));
- (void)setAttachReadDate:(int)attachIndex :(NSString*)newAttachReadDate NS_SWIFT_NAME(setAttachReadDate(_:_:));

- (long long)attachSize:(int)attachIndex NS_SWIFT_NAME(attachSize(_:));
- (void)setAttachSize:(int)attachIndex :(long long)newAttachSize NS_SWIFT_NAME(setAttachSize(_:_:));

@property (nonatomic,readwrite,assign,getter=bccAddrCount,setter=setBccAddrCount:) int bccAddrCount NS_SWIFT_NAME(bccAddrCount);

- (int)bccAddrCount NS_SWIFT_NAME(bccAddrCount());
- (void)setBccAddrCount :(int)newBccAddrCount NS_SWIFT_NAME(setBccAddrCount(_:));

- (NSString*)bccAddrAddress:(int)bccAddrIndex NS_SWIFT_NAME(bccAddrAddress(_:));
- (void)setBccAddrAddress:(int)bccAddrIndex :(NSString*)newBccAddrAddress NS_SWIFT_NAME(setBccAddrAddress(_:_:));

- (NSString*)bccAddrDisplayName:(int)bccAddrIndex NS_SWIFT_NAME(bccAddrDisplayName(_:));
- (void)setBccAddrDisplayName:(int)bccAddrIndex :(NSString*)newBccAddrDisplayName NS_SWIFT_NAME(setBccAddrDisplayName(_:_:));

- (NSString*)bccAddrGroupName:(int)bccAddrIndex NS_SWIFT_NAME(bccAddrGroupName(_:));
- (void)setBccAddrGroupName:(int)bccAddrIndex :(NSString*)newBccAddrGroupName NS_SWIFT_NAME(setBccAddrGroupName(_:_:));

@property (nonatomic,readwrite,assign,getter=ccAddrCount,setter=setCcAddrCount:) int ccAddrCount NS_SWIFT_NAME(ccAddrCount);

- (int)ccAddrCount NS_SWIFT_NAME(ccAddrCount());
- (void)setCcAddrCount :(int)newCcAddrCount NS_SWIFT_NAME(setCcAddrCount(_:));

- (NSString*)ccAddrAddress:(int)ccAddrIndex NS_SWIFT_NAME(ccAddrAddress(_:));
- (void)setCcAddrAddress:(int)ccAddrIndex :(NSString*)newCcAddrAddress NS_SWIFT_NAME(setCcAddrAddress(_:_:));

- (NSString*)ccAddrDisplayName:(int)ccAddrIndex NS_SWIFT_NAME(ccAddrDisplayName(_:));
- (void)setCcAddrDisplayName:(int)ccAddrIndex :(NSString*)newCcAddrDisplayName NS_SWIFT_NAME(setCcAddrDisplayName(_:_:));

- (NSString*)ccAddrGroupName:(int)ccAddrIndex NS_SWIFT_NAME(ccAddrGroupName(_:));
- (void)setCcAddrGroupName:(int)ccAddrIndex :(NSString*)newCcAddrGroupName NS_SWIFT_NAME(setCcAddrGroupName(_:_:));

@property (nonatomic,readwrite,assign,getter=charset,setter=setCharset:) NSString* charset NS_SWIFT_NAME(charset);

- (NSString*)charset NS_SWIFT_NAME(charset());
- (void)setCharset :(NSString*)newCharset NS_SWIFT_NAME(setCharset(_:));

@property (nonatomic,readwrite,assign,getter=encryptionCertCount,setter=setEncryptionCertCount:) int encryptionCertCount NS_SWIFT_NAME(encryptionCertCount);

- (int)encryptionCertCount NS_SWIFT_NAME(encryptionCertCount());
- (void)setEncryptionCertCount :(int)newEncryptionCertCount NS_SWIFT_NAME(setEncryptionCertCount(_:));

- (NSData*)encryptionCertBytes:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertBytes(_:));

- (BOOL)encryptionCertCA:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertCA(_:));
- (void)setEncryptionCertCA:(int)encryptionCertIndex :(BOOL)newEncryptionCertCA NS_SWIFT_NAME(setEncryptionCertCA(_:_:));

- (NSData*)encryptionCertCAKeyID:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertCAKeyID(_:));

- (int)encryptionCertCertType:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertCertType(_:));

- (NSString*)encryptionCertCRLDistributionPoints:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertCRLDistributionPoints(_:));
- (void)setEncryptionCertCRLDistributionPoints:(int)encryptionCertIndex :(NSString*)newEncryptionCertCRLDistributionPoints NS_SWIFT_NAME(setEncryptionCertCRLDistributionPoints(_:_:));

- (NSString*)encryptionCertCurve:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertCurve(_:));
- (void)setEncryptionCertCurve:(int)encryptionCertIndex :(NSString*)newEncryptionCertCurve NS_SWIFT_NAME(setEncryptionCertCurve(_:_:));

- (NSString*)encryptionCertFingerprint:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertFingerprint(_:));

- (NSString*)encryptionCertFriendlyName:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertFriendlyName(_:));

- (long long)encryptionCertHandle:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertHandle(_:));
- (void)setEncryptionCertHandle:(int)encryptionCertIndex :(long long)newEncryptionCertHandle NS_SWIFT_NAME(setEncryptionCertHandle(_:_:));

- (NSString*)encryptionCertHashAlgorithm:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertHashAlgorithm(_:));
- (void)setEncryptionCertHashAlgorithm:(int)encryptionCertIndex :(NSString*)newEncryptionCertHashAlgorithm NS_SWIFT_NAME(setEncryptionCertHashAlgorithm(_:_:));

- (NSString*)encryptionCertIssuer:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertIssuer(_:));

- (NSString*)encryptionCertIssuerRDN:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertIssuerRDN(_:));
- (void)setEncryptionCertIssuerRDN:(int)encryptionCertIndex :(NSString*)newEncryptionCertIssuerRDN NS_SWIFT_NAME(setEncryptionCertIssuerRDN(_:_:));

- (NSString*)encryptionCertKeyAlgorithm:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertKeyAlgorithm(_:));
- (void)setEncryptionCertKeyAlgorithm:(int)encryptionCertIndex :(NSString*)newEncryptionCertKeyAlgorithm NS_SWIFT_NAME(setEncryptionCertKeyAlgorithm(_:_:));

- (int)encryptionCertKeyBits:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertKeyBits(_:));

- (NSString*)encryptionCertKeyFingerprint:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertKeyFingerprint(_:));

- (int)encryptionCertKeyUsage:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertKeyUsage(_:));
- (void)setEncryptionCertKeyUsage:(int)encryptionCertIndex :(int)newEncryptionCertKeyUsage NS_SWIFT_NAME(setEncryptionCertKeyUsage(_:_:));

- (BOOL)encryptionCertKeyValid:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertKeyValid(_:));

- (NSString*)encryptionCertOCSPLocations:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertOCSPLocations(_:));
- (void)setEncryptionCertOCSPLocations:(int)encryptionCertIndex :(NSString*)newEncryptionCertOCSPLocations NS_SWIFT_NAME(setEncryptionCertOCSPLocations(_:_:));

- (BOOL)encryptionCertOCSPNoCheck:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertOCSPNoCheck(_:));
- (void)setEncryptionCertOCSPNoCheck:(int)encryptionCertIndex :(BOOL)newEncryptionCertOCSPNoCheck NS_SWIFT_NAME(setEncryptionCertOCSPNoCheck(_:_:));

- (int)encryptionCertOrigin:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertOrigin(_:));

- (NSString*)encryptionCertPolicyIDs:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertPolicyIDs(_:));
- (void)setEncryptionCertPolicyIDs:(int)encryptionCertIndex :(NSString*)newEncryptionCertPolicyIDs NS_SWIFT_NAME(setEncryptionCertPolicyIDs(_:_:));

- (NSData*)encryptionCertPrivateKeyBytes:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertPrivateKeyBytes(_:));

- (BOOL)encryptionCertPrivateKeyExists:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertPrivateKeyExists(_:));

- (BOOL)encryptionCertPrivateKeyExtractable:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertPrivateKeyExtractable(_:));

- (NSData*)encryptionCertPublicKeyBytes:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertPublicKeyBytes(_:));

- (BOOL)encryptionCertQualified:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertQualified(_:));

- (int)encryptionCertQualifiedStatements:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertQualifiedStatements(_:));
- (void)setEncryptionCertQualifiedStatements:(int)encryptionCertIndex :(int)newEncryptionCertQualifiedStatements NS_SWIFT_NAME(setEncryptionCertQualifiedStatements(_:_:));

- (NSString*)encryptionCertQualifiers:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertQualifiers(_:));

- (BOOL)encryptionCertSelfSigned:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertSelfSigned(_:));

- (NSData*)encryptionCertSerialNumber:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertSerialNumber(_:));
- (void)setEncryptionCertSerialNumber:(int)encryptionCertIndex :(NSData*)newEncryptionCertSerialNumber NS_SWIFT_NAME(setEncryptionCertSerialNumber(_:_:));

- (NSString*)encryptionCertSigAlgorithm:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertSigAlgorithm(_:));

- (int)encryptionCertSource:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertSource(_:));

- (NSString*)encryptionCertSubject:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertSubject(_:));

- (NSString*)encryptionCertSubjectAlternativeName:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertSubjectAlternativeName(_:));
- (void)setEncryptionCertSubjectAlternativeName:(int)encryptionCertIndex :(NSString*)newEncryptionCertSubjectAlternativeName NS_SWIFT_NAME(setEncryptionCertSubjectAlternativeName(_:_:));

- (NSData*)encryptionCertSubjectKeyID:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertSubjectKeyID(_:));
- (void)setEncryptionCertSubjectKeyID:(int)encryptionCertIndex :(NSData*)newEncryptionCertSubjectKeyID NS_SWIFT_NAME(setEncryptionCertSubjectKeyID(_:_:));

- (NSString*)encryptionCertSubjectRDN:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertSubjectRDN(_:));
- (void)setEncryptionCertSubjectRDN:(int)encryptionCertIndex :(NSString*)newEncryptionCertSubjectRDN NS_SWIFT_NAME(setEncryptionCertSubjectRDN(_:_:));

- (BOOL)encryptionCertValid:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertValid(_:));

- (NSString*)encryptionCertValidFrom:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertValidFrom(_:));
- (void)setEncryptionCertValidFrom:(int)encryptionCertIndex :(NSString*)newEncryptionCertValidFrom NS_SWIFT_NAME(setEncryptionCertValidFrom(_:_:));

- (NSString*)encryptionCertValidTo:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertValidTo(_:));
- (void)setEncryptionCertValidTo:(int)encryptionCertIndex :(NSString*)newEncryptionCertValidTo NS_SWIFT_NAME(setEncryptionCertValidTo(_:_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoAsyncDocumentID,setter=setExternalCryptoAsyncDocumentID:) NSString* externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID);

- (NSString*)externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID());
- (void)setExternalCryptoAsyncDocumentID :(NSString*)newExternalCryptoAsyncDocumentID NS_SWIFT_NAME(setExternalCryptoAsyncDocumentID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoCustomParams,setter=setExternalCryptoCustomParams:) NSString* externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams);

- (NSString*)externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams());
- (void)setExternalCryptoCustomParams :(NSString*)newExternalCryptoCustomParams NS_SWIFT_NAME(setExternalCryptoCustomParams(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoData,setter=setExternalCryptoData:) NSString* externalCryptoData NS_SWIFT_NAME(externalCryptoData);

- (NSString*)externalCryptoData NS_SWIFT_NAME(externalCryptoData());
- (void)setExternalCryptoData :(NSString*)newExternalCryptoData NS_SWIFT_NAME(setExternalCryptoData(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoExternalHashCalculation,setter=setExternalCryptoExternalHashCalculation:) BOOL externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation);

- (BOOL)externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation());
- (void)setExternalCryptoExternalHashCalculation :(BOOL)newExternalCryptoExternalHashCalculation NS_SWIFT_NAME(setExternalCryptoExternalHashCalculation(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoHashAlgorithm,setter=setExternalCryptoHashAlgorithm:) NSString* externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm);

- (NSString*)externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm());
- (void)setExternalCryptoHashAlgorithm :(NSString*)newExternalCryptoHashAlgorithm NS_SWIFT_NAME(setExternalCryptoHashAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeyID,setter=setExternalCryptoKeyID:) NSString* externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID);

- (NSString*)externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID());
- (void)setExternalCryptoKeyID :(NSString*)newExternalCryptoKeyID NS_SWIFT_NAME(setExternalCryptoKeyID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeySecret,setter=setExternalCryptoKeySecret:) NSString* externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret);

- (NSString*)externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret());
- (void)setExternalCryptoKeySecret :(NSString*)newExternalCryptoKeySecret NS_SWIFT_NAME(setExternalCryptoKeySecret(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMethod,setter=setExternalCryptoMethod:) int externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod);

- (int)externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod());
- (void)setExternalCryptoMethod :(int)newExternalCryptoMethod NS_SWIFT_NAME(setExternalCryptoMethod(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMode,setter=setExternalCryptoMode:) int externalCryptoMode NS_SWIFT_NAME(externalCryptoMode);

- (int)externalCryptoMode NS_SWIFT_NAME(externalCryptoMode());
- (void)setExternalCryptoMode :(int)newExternalCryptoMode NS_SWIFT_NAME(setExternalCryptoMode(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoPublicKeyAlgorithm,setter=setExternalCryptoPublicKeyAlgorithm:) NSString* externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm);

- (NSString*)externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm());
- (void)setExternalCryptoPublicKeyAlgorithm :(NSString*)newExternalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(setExternalCryptoPublicKeyAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=fromAddrCount,setter=setFromAddrCount:) int fromAddrCount NS_SWIFT_NAME(fromAddrCount);

- (int)fromAddrCount NS_SWIFT_NAME(fromAddrCount());
- (void)setFromAddrCount :(int)newFromAddrCount NS_SWIFT_NAME(setFromAddrCount(_:));

- (NSString*)fromAddrAddress:(int)fromAddrIndex NS_SWIFT_NAME(fromAddrAddress(_:));
- (void)setFromAddrAddress:(int)fromAddrIndex :(NSString*)newFromAddrAddress NS_SWIFT_NAME(setFromAddrAddress(_:_:));

- (NSString*)fromAddrDisplayName:(int)fromAddrIndex NS_SWIFT_NAME(fromAddrDisplayName(_:));
- (void)setFromAddrDisplayName:(int)fromAddrIndex :(NSString*)newFromAddrDisplayName NS_SWIFT_NAME(setFromAddrDisplayName(_:_:));

- (NSString*)fromAddrGroupName:(int)fromAddrIndex NS_SWIFT_NAME(fromAddrGroupName(_:));
- (void)setFromAddrGroupName:(int)fromAddrIndex :(NSString*)newFromAddrGroupName NS_SWIFT_NAME(setFromAddrGroupName(_:_:));

@property (nonatomic,readwrite,assign,getter=headerEncoding,setter=setHeaderEncoding:) int headerEncoding NS_SWIFT_NAME(headerEncoding);

- (int)headerEncoding NS_SWIFT_NAME(headerEncoding());
- (void)setHeaderEncoding :(int)newHeaderEncoding NS_SWIFT_NAME(setHeaderEncoding(_:));

@property (nonatomic,readwrite,assign,getter=mailer,setter=setMailer:) NSString* mailer NS_SWIFT_NAME(mailer);

- (NSString*)mailer NS_SWIFT_NAME(mailer());
- (void)setMailer :(NSString*)newMailer NS_SWIFT_NAME(setMailer(_:));

@property (nonatomic,readonly,assign,getter=msgAttachmentCount) int msgAttachmentCount NS_SWIFT_NAME(msgAttachmentCount);

- (int)msgAttachmentCount NS_SWIFT_NAME(msgAttachmentCount());

@property (nonatomic,readwrite,assign,getter=msgBcc,setter=setMsgBcc:) NSString* msgBcc NS_SWIFT_NAME(msgBcc);

- (NSString*)msgBcc NS_SWIFT_NAME(msgBcc());
- (void)setMsgBcc :(NSString*)newMsgBcc NS_SWIFT_NAME(setMsgBcc(_:));

@property (nonatomic,readwrite,assign,getter=msgCc,setter=setMsgCc:) NSString* msgCc NS_SWIFT_NAME(msgCc);

- (NSString*)msgCc NS_SWIFT_NAME(msgCc());
- (void)setMsgCc :(NSString*)newMsgCc NS_SWIFT_NAME(setMsgCc(_:));

@property (nonatomic,readwrite,assign,getter=msgComments,setter=setMsgComments:) NSString* msgComments NS_SWIFT_NAME(msgComments);

- (NSString*)msgComments NS_SWIFT_NAME(msgComments());
- (void)setMsgComments :(NSString*)newMsgComments NS_SWIFT_NAME(setMsgComments(_:));

@property (nonatomic,readwrite,assign,getter=msgDate,setter=setMsgDate:) NSString* msgDate NS_SWIFT_NAME(msgDate);

- (NSString*)msgDate NS_SWIFT_NAME(msgDate());
- (void)setMsgDate :(NSString*)newMsgDate NS_SWIFT_NAME(setMsgDate(_:));

@property (nonatomic,readwrite,assign,getter=msgDeliveryReceipt,setter=setMsgDeliveryReceipt:) BOOL msgDeliveryReceipt NS_SWIFT_NAME(msgDeliveryReceipt);

- (BOOL)msgDeliveryReceipt NS_SWIFT_NAME(msgDeliveryReceipt());
- (void)setMsgDeliveryReceipt :(BOOL)newMsgDeliveryReceipt NS_SWIFT_NAME(setMsgDeliveryReceipt(_:));

@property (nonatomic,readwrite,assign,getter=msgFrom,setter=setMsgFrom:) NSString* msgFrom NS_SWIFT_NAME(msgFrom);

- (NSString*)msgFrom NS_SWIFT_NAME(msgFrom());
- (void)setMsgFrom :(NSString*)newMsgFrom NS_SWIFT_NAME(setMsgFrom(_:));

@property (nonatomic,readwrite,assign,getter=msgHandle,setter=setMsgHandle:) long long msgHandle NS_SWIFT_NAME(msgHandle);

- (long long)msgHandle NS_SWIFT_NAME(msgHandle());
- (void)setMsgHandle :(long long)newMsgHandle NS_SWIFT_NAME(setMsgHandle(_:));

@property (nonatomic,readwrite,assign,getter=msgHtmlText,setter=setMsgHtmlText:) NSString* msgHtmlText NS_SWIFT_NAME(msgHtmlText);

- (NSString*)msgHtmlText NS_SWIFT_NAME(msgHtmlText());
- (void)setMsgHtmlText :(NSString*)newMsgHtmlText NS_SWIFT_NAME(setMsgHtmlText(_:));

@property (nonatomic,readwrite,assign,getter=msgID,setter=setMsgID:) NSString* msgID NS_SWIFT_NAME(msgID);

- (NSString*)msgID NS_SWIFT_NAME(msgID());
- (void)setMsgID :(NSString*)newMsgID NS_SWIFT_NAME(setMsgID(_:));

@property (nonatomic,readwrite,assign,getter=msgInReplyTo,setter=setMsgInReplyTo:) NSString* msgInReplyTo NS_SWIFT_NAME(msgInReplyTo);

- (NSString*)msgInReplyTo NS_SWIFT_NAME(msgInReplyTo());
- (void)setMsgInReplyTo :(NSString*)newMsgInReplyTo NS_SWIFT_NAME(setMsgInReplyTo(_:));

@property (nonatomic,readwrite,assign,getter=msgKeywords,setter=setMsgKeywords:) NSString* msgKeywords NS_SWIFT_NAME(msgKeywords);

- (NSString*)msgKeywords NS_SWIFT_NAME(msgKeywords());
- (void)setMsgKeywords :(NSString*)newMsgKeywords NS_SWIFT_NAME(setMsgKeywords(_:));

@property (nonatomic,readonly,assign,getter=msgMailer) NSString* msgMailer NS_SWIFT_NAME(msgMailer);

- (NSString*)msgMailer NS_SWIFT_NAME(msgMailer());

@property (nonatomic,readwrite,assign,getter=msgPlainText,setter=setMsgPlainText:) NSString* msgPlainText NS_SWIFT_NAME(msgPlainText);

- (NSString*)msgPlainText NS_SWIFT_NAME(msgPlainText());
- (void)setMsgPlainText :(NSString*)newMsgPlainText NS_SWIFT_NAME(setMsgPlainText(_:));

@property (nonatomic,readwrite,assign,getter=msgPriority,setter=setMsgPriority:) int msgPriority NS_SWIFT_NAME(msgPriority);

- (int)msgPriority NS_SWIFT_NAME(msgPriority());
- (void)setMsgPriority :(int)newMsgPriority NS_SWIFT_NAME(setMsgPriority(_:));

@property (nonatomic,readwrite,assign,getter=msgReadReceipt,setter=setMsgReadReceipt:) BOOL msgReadReceipt NS_SWIFT_NAME(msgReadReceipt);

- (BOOL)msgReadReceipt NS_SWIFT_NAME(msgReadReceipt());
- (void)setMsgReadReceipt :(BOOL)newMsgReadReceipt NS_SWIFT_NAME(setMsgReadReceipt(_:));

@property (nonatomic,readwrite,assign,getter=msgReferences,setter=setMsgReferences:) NSString* msgReferences NS_SWIFT_NAME(msgReferences);

- (NSString*)msgReferences NS_SWIFT_NAME(msgReferences());
- (void)setMsgReferences :(NSString*)newMsgReferences NS_SWIFT_NAME(setMsgReferences(_:));

@property (nonatomic,readwrite,assign,getter=msgReplyTo,setter=setMsgReplyTo:) NSString* msgReplyTo NS_SWIFT_NAME(msgReplyTo);

- (NSString*)msgReplyTo NS_SWIFT_NAME(msgReplyTo());
- (void)setMsgReplyTo :(NSString*)newMsgReplyTo NS_SWIFT_NAME(setMsgReplyTo(_:));

@property (nonatomic,readwrite,assign,getter=msgReturnPath,setter=setMsgReturnPath:) NSString* msgReturnPath NS_SWIFT_NAME(msgReturnPath);

- (NSString*)msgReturnPath NS_SWIFT_NAME(msgReturnPath());
- (void)setMsgReturnPath :(NSString*)newMsgReturnPath NS_SWIFT_NAME(setMsgReturnPath(_:));

@property (nonatomic,readwrite,assign,getter=msgSender,setter=setMsgSender:) NSString* msgSender NS_SWIFT_NAME(msgSender);

- (NSString*)msgSender NS_SWIFT_NAME(msgSender());
- (void)setMsgSender :(NSString*)newMsgSender NS_SWIFT_NAME(setMsgSender(_:));

@property (nonatomic,readwrite,assign,getter=msgSendTo,setter=setMsgSendTo:) NSString* msgSendTo NS_SWIFT_NAME(msgSendTo);

- (NSString*)msgSendTo NS_SWIFT_NAME(msgSendTo());
- (void)setMsgSendTo :(NSString*)newMsgSendTo NS_SWIFT_NAME(setMsgSendTo(_:));

@property (nonatomic,readwrite,assign,getter=msgSubject,setter=setMsgSubject:) NSString* msgSubject NS_SWIFT_NAME(msgSubject);

- (NSString*)msgSubject NS_SWIFT_NAME(msgSubject());
- (void)setMsgSubject :(NSString*)newMsgSubject NS_SWIFT_NAME(setMsgSubject(_:));

@property (nonatomic,readwrite,assign,getter=headerFieldCount,setter=setHeaderFieldCount:) int headerFieldCount NS_SWIFT_NAME(headerFieldCount);

- (int)headerFieldCount NS_SWIFT_NAME(headerFieldCount());
- (void)setHeaderFieldCount :(int)newHeaderFieldCount NS_SWIFT_NAME(setHeaderFieldCount(_:));

- (NSString*)headerFieldCategory:(int)headerFieldIndex NS_SWIFT_NAME(headerFieldCategory(_:));
- (void)setHeaderFieldCategory:(int)headerFieldIndex :(NSString*)newHeaderFieldCategory NS_SWIFT_NAME(setHeaderFieldCategory(_:_:));

- (int)headerFieldFormat:(int)headerFieldIndex NS_SWIFT_NAME(headerFieldFormat(_:));
- (void)setHeaderFieldFormat:(int)headerFieldIndex :(int)newHeaderFieldFormat NS_SWIFT_NAME(setHeaderFieldFormat(_:_:));

- (NSString*)headerFieldName:(int)headerFieldIndex NS_SWIFT_NAME(headerFieldName(_:));
- (void)setHeaderFieldName:(int)headerFieldIndex :(NSString*)newHeaderFieldName NS_SWIFT_NAME(setHeaderFieldName(_:_:));

- (NSString*)headerFieldValue:(int)headerFieldIndex NS_SWIFT_NAME(headerFieldValue(_:));
- (void)setHeaderFieldValue:(int)headerFieldIndex :(NSString*)newHeaderFieldValue NS_SWIFT_NAME(setHeaderFieldValue(_:_:));

@property (nonatomic,readwrite,assign,getter=profile,setter=setProfile:) NSString* profile NS_SWIFT_NAME(profile);

- (NSString*)profile NS_SWIFT_NAME(profile());
- (void)setProfile :(NSString*)newProfile NS_SWIFT_NAME(setProfile(_:));

@property (nonatomic,readwrite,assign,getter=replyToAddrCount,setter=setReplyToAddrCount:) int replyToAddrCount NS_SWIFT_NAME(replyToAddrCount);

- (int)replyToAddrCount NS_SWIFT_NAME(replyToAddrCount());
- (void)setReplyToAddrCount :(int)newReplyToAddrCount NS_SWIFT_NAME(setReplyToAddrCount(_:));

- (NSString*)replyToAddrAddress:(int)replyToAddrIndex NS_SWIFT_NAME(replyToAddrAddress(_:));
- (void)setReplyToAddrAddress:(int)replyToAddrIndex :(NSString*)newReplyToAddrAddress NS_SWIFT_NAME(setReplyToAddrAddress(_:_:));

- (NSString*)replyToAddrDisplayName:(int)replyToAddrIndex NS_SWIFT_NAME(replyToAddrDisplayName(_:));
- (void)setReplyToAddrDisplayName:(int)replyToAddrIndex :(NSString*)newReplyToAddrDisplayName NS_SWIFT_NAME(setReplyToAddrDisplayName(_:_:));

- (NSString*)replyToAddrGroupName:(int)replyToAddrIndex NS_SWIFT_NAME(replyToAddrGroupName(_:));
- (void)setReplyToAddrGroupName:(int)replyToAddrIndex :(NSString*)newReplyToAddrGroupName NS_SWIFT_NAME(setReplyToAddrGroupName(_:_:));

@property (nonatomic,readwrite,assign,getter=secSettingsClaimedSigningTime,setter=setSecSettingsClaimedSigningTime:) NSString* secSettingsClaimedSigningTime NS_SWIFT_NAME(secSettingsClaimedSigningTime);

- (NSString*)secSettingsClaimedSigningTime NS_SWIFT_NAME(secSettingsClaimedSigningTime());
- (void)setSecSettingsClaimedSigningTime :(NSString*)newSecSettingsClaimedSigningTime NS_SWIFT_NAME(setSecSettingsClaimedSigningTime(_:));

@property (nonatomic,readwrite,assign,getter=secSettingsEncrypt,setter=setSecSettingsEncrypt:) BOOL secSettingsEncrypt NS_SWIFT_NAME(secSettingsEncrypt);

- (BOOL)secSettingsEncrypt NS_SWIFT_NAME(secSettingsEncrypt());
- (void)setSecSettingsEncrypt :(BOOL)newSecSettingsEncrypt NS_SWIFT_NAME(setSecSettingsEncrypt(_:));

@property (nonatomic,readwrite,assign,getter=secSettingsEncryptionAlgorithm,setter=setSecSettingsEncryptionAlgorithm:) NSString* secSettingsEncryptionAlgorithm NS_SWIFT_NAME(secSettingsEncryptionAlgorithm);

- (NSString*)secSettingsEncryptionAlgorithm NS_SWIFT_NAME(secSettingsEncryptionAlgorithm());
- (void)setSecSettingsEncryptionAlgorithm :(NSString*)newSecSettingsEncryptionAlgorithm NS_SWIFT_NAME(setSecSettingsEncryptionAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=secSettingsHashAlgorithm,setter=setSecSettingsHashAlgorithm:) NSString* secSettingsHashAlgorithm NS_SWIFT_NAME(secSettingsHashAlgorithm);

- (NSString*)secSettingsHashAlgorithm NS_SWIFT_NAME(secSettingsHashAlgorithm());
- (void)setSecSettingsHashAlgorithm :(NSString*)newSecSettingsHashAlgorithm NS_SWIFT_NAME(setSecSettingsHashAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=secSettingsSign,setter=setSecSettingsSign:) BOOL secSettingsSign NS_SWIFT_NAME(secSettingsSign);

- (BOOL)secSettingsSign NS_SWIFT_NAME(secSettingsSign());
- (void)setSecSettingsSign :(BOOL)newSecSettingsSign NS_SWIFT_NAME(setSecSettingsSign(_:));

@property (nonatomic,readwrite,assign,getter=secSettingsSignatureFormat,setter=setSecSettingsSignatureFormat:) int secSettingsSignatureFormat NS_SWIFT_NAME(secSettingsSignatureFormat);

- (int)secSettingsSignatureFormat NS_SWIFT_NAME(secSettingsSignatureFormat());
- (void)setSecSettingsSignatureFormat :(int)newSecSettingsSignatureFormat NS_SWIFT_NAME(setSecSettingsSignatureFormat(_:));

@property (nonatomic,readwrite,assign,getter=secSettingsSignBeforeEncrypt,setter=setSecSettingsSignBeforeEncrypt:) BOOL secSettingsSignBeforeEncrypt NS_SWIFT_NAME(secSettingsSignBeforeEncrypt);

- (BOOL)secSettingsSignBeforeEncrypt NS_SWIFT_NAME(secSettingsSignBeforeEncrypt());
- (void)setSecSettingsSignBeforeEncrypt :(BOOL)newSecSettingsSignBeforeEncrypt NS_SWIFT_NAME(setSecSettingsSignBeforeEncrypt(_:));

@property (nonatomic,readwrite,assign,getter=secSettingsSignMessageHeader,setter=setSecSettingsSignMessageHeader:) BOOL secSettingsSignMessageHeader NS_SWIFT_NAME(secSettingsSignMessageHeader);

- (BOOL)secSettingsSignMessageHeader NS_SWIFT_NAME(secSettingsSignMessageHeader());
- (void)setSecSettingsSignMessageHeader :(BOOL)newSecSettingsSignMessageHeader NS_SWIFT_NAME(setSecSettingsSignMessageHeader(_:));

@property (nonatomic,readwrite,assign,getter=senderAddrAddress,setter=setSenderAddrAddress:) NSString* senderAddrAddress NS_SWIFT_NAME(senderAddrAddress);

- (NSString*)senderAddrAddress NS_SWIFT_NAME(senderAddrAddress());
- (void)setSenderAddrAddress :(NSString*)newSenderAddrAddress NS_SWIFT_NAME(setSenderAddrAddress(_:));

@property (nonatomic,readwrite,assign,getter=senderAddrDisplayName,setter=setSenderAddrDisplayName:) NSString* senderAddrDisplayName NS_SWIFT_NAME(senderAddrDisplayName);

- (NSString*)senderAddrDisplayName NS_SWIFT_NAME(senderAddrDisplayName());
- (void)setSenderAddrDisplayName :(NSString*)newSenderAddrDisplayName NS_SWIFT_NAME(setSenderAddrDisplayName(_:));

@property (nonatomic,readwrite,assign,getter=senderAddrGroupName,setter=setSenderAddrGroupName:) NSString* senderAddrGroupName NS_SWIFT_NAME(senderAddrGroupName);

- (NSString*)senderAddrGroupName NS_SWIFT_NAME(senderAddrGroupName());
- (void)setSenderAddrGroupName :(NSString*)newSenderAddrGroupName NS_SWIFT_NAME(setSenderAddrGroupName(_:));

@property (nonatomic,readwrite,assign,getter=sendToAddrCount,setter=setSendToAddrCount:) int sendToAddrCount NS_SWIFT_NAME(sendToAddrCount);

- (int)sendToAddrCount NS_SWIFT_NAME(sendToAddrCount());
- (void)setSendToAddrCount :(int)newSendToAddrCount NS_SWIFT_NAME(setSendToAddrCount(_:));

- (NSString*)sendToAddrAddress:(int)sendToAddrIndex NS_SWIFT_NAME(sendToAddrAddress(_:));
- (void)setSendToAddrAddress:(int)sendToAddrIndex :(NSString*)newSendToAddrAddress NS_SWIFT_NAME(setSendToAddrAddress(_:_:));

- (NSString*)sendToAddrDisplayName:(int)sendToAddrIndex NS_SWIFT_NAME(sendToAddrDisplayName(_:));
- (void)setSendToAddrDisplayName:(int)sendToAddrIndex :(NSString*)newSendToAddrDisplayName NS_SWIFT_NAME(setSendToAddrDisplayName(_:_:));

- (NSString*)sendToAddrGroupName:(int)sendToAddrIndex NS_SWIFT_NAME(sendToAddrGroupName(_:));
- (void)setSendToAddrGroupName:(int)sendToAddrIndex :(NSString*)newSendToAddrGroupName NS_SWIFT_NAME(setSendToAddrGroupName(_:_:));

@property (nonatomic,readonly,assign,getter=signingCertBytes) NSData* signingCertBytes NS_SWIFT_NAME(signingCertBytes);

- (NSData*)signingCertBytes NS_SWIFT_NAME(signingCertBytes());

@property (nonatomic,readwrite,assign,getter=signingCertCA,setter=setSigningCertCA:) BOOL signingCertCA NS_SWIFT_NAME(signingCertCA);

- (BOOL)signingCertCA NS_SWIFT_NAME(signingCertCA());
- (void)setSigningCertCA :(BOOL)newSigningCertCA NS_SWIFT_NAME(setSigningCertCA(_:));

@property (nonatomic,readonly,assign,getter=signingCertCAKeyID) NSData* signingCertCAKeyID NS_SWIFT_NAME(signingCertCAKeyID);

- (NSData*)signingCertCAKeyID NS_SWIFT_NAME(signingCertCAKeyID());

@property (nonatomic,readonly,assign,getter=signingCertCertType) int signingCertCertType NS_SWIFT_NAME(signingCertCertType);

- (int)signingCertCertType NS_SWIFT_NAME(signingCertCertType());

@property (nonatomic,readwrite,assign,getter=signingCertCRLDistributionPoints,setter=setSigningCertCRLDistributionPoints:) NSString* signingCertCRLDistributionPoints NS_SWIFT_NAME(signingCertCRLDistributionPoints);

- (NSString*)signingCertCRLDistributionPoints NS_SWIFT_NAME(signingCertCRLDistributionPoints());
- (void)setSigningCertCRLDistributionPoints :(NSString*)newSigningCertCRLDistributionPoints NS_SWIFT_NAME(setSigningCertCRLDistributionPoints(_:));

@property (nonatomic,readwrite,assign,getter=signingCertCurve,setter=setSigningCertCurve:) NSString* signingCertCurve NS_SWIFT_NAME(signingCertCurve);

- (NSString*)signingCertCurve NS_SWIFT_NAME(signingCertCurve());
- (void)setSigningCertCurve :(NSString*)newSigningCertCurve NS_SWIFT_NAME(setSigningCertCurve(_:));

@property (nonatomic,readonly,assign,getter=signingCertFingerprint) NSString* signingCertFingerprint NS_SWIFT_NAME(signingCertFingerprint);

- (NSString*)signingCertFingerprint NS_SWIFT_NAME(signingCertFingerprint());

@property (nonatomic,readonly,assign,getter=signingCertFriendlyName) NSString* signingCertFriendlyName NS_SWIFT_NAME(signingCertFriendlyName);

- (NSString*)signingCertFriendlyName NS_SWIFT_NAME(signingCertFriendlyName());

@property (nonatomic,readwrite,assign,getter=signingCertHandle,setter=setSigningCertHandle:) long long signingCertHandle NS_SWIFT_NAME(signingCertHandle);

- (long long)signingCertHandle NS_SWIFT_NAME(signingCertHandle());
- (void)setSigningCertHandle :(long long)newSigningCertHandle NS_SWIFT_NAME(setSigningCertHandle(_:));

@property (nonatomic,readwrite,assign,getter=signingCertHashAlgorithm,setter=setSigningCertHashAlgorithm:) NSString* signingCertHashAlgorithm NS_SWIFT_NAME(signingCertHashAlgorithm);

- (NSString*)signingCertHashAlgorithm NS_SWIFT_NAME(signingCertHashAlgorithm());
- (void)setSigningCertHashAlgorithm :(NSString*)newSigningCertHashAlgorithm NS_SWIFT_NAME(setSigningCertHashAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=signingCertIssuer) NSString* signingCertIssuer NS_SWIFT_NAME(signingCertIssuer);

- (NSString*)signingCertIssuer NS_SWIFT_NAME(signingCertIssuer());

@property (nonatomic,readwrite,assign,getter=signingCertIssuerRDN,setter=setSigningCertIssuerRDN:) NSString* signingCertIssuerRDN NS_SWIFT_NAME(signingCertIssuerRDN);

- (NSString*)signingCertIssuerRDN NS_SWIFT_NAME(signingCertIssuerRDN());
- (void)setSigningCertIssuerRDN :(NSString*)newSigningCertIssuerRDN NS_SWIFT_NAME(setSigningCertIssuerRDN(_:));

@property (nonatomic,readwrite,assign,getter=signingCertKeyAlgorithm,setter=setSigningCertKeyAlgorithm:) NSString* signingCertKeyAlgorithm NS_SWIFT_NAME(signingCertKeyAlgorithm);

- (NSString*)signingCertKeyAlgorithm NS_SWIFT_NAME(signingCertKeyAlgorithm());
- (void)setSigningCertKeyAlgorithm :(NSString*)newSigningCertKeyAlgorithm NS_SWIFT_NAME(setSigningCertKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=signingCertKeyBits) int signingCertKeyBits NS_SWIFT_NAME(signingCertKeyBits);

- (int)signingCertKeyBits NS_SWIFT_NAME(signingCertKeyBits());

@property (nonatomic,readonly,assign,getter=signingCertKeyFingerprint) NSString* signingCertKeyFingerprint NS_SWIFT_NAME(signingCertKeyFingerprint);

- (NSString*)signingCertKeyFingerprint NS_SWIFT_NAME(signingCertKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=signingCertKeyUsage,setter=setSigningCertKeyUsage:) int signingCertKeyUsage NS_SWIFT_NAME(signingCertKeyUsage);

- (int)signingCertKeyUsage NS_SWIFT_NAME(signingCertKeyUsage());
- (void)setSigningCertKeyUsage :(int)newSigningCertKeyUsage NS_SWIFT_NAME(setSigningCertKeyUsage(_:));

@property (nonatomic,readonly,assign,getter=signingCertKeyValid) BOOL signingCertKeyValid NS_SWIFT_NAME(signingCertKeyValid);

- (BOOL)signingCertKeyValid NS_SWIFT_NAME(signingCertKeyValid());

@property (nonatomic,readwrite,assign,getter=signingCertOCSPLocations,setter=setSigningCertOCSPLocations:) NSString* signingCertOCSPLocations NS_SWIFT_NAME(signingCertOCSPLocations);

- (NSString*)signingCertOCSPLocations NS_SWIFT_NAME(signingCertOCSPLocations());
- (void)setSigningCertOCSPLocations :(NSString*)newSigningCertOCSPLocations NS_SWIFT_NAME(setSigningCertOCSPLocations(_:));

@property (nonatomic,readwrite,assign,getter=signingCertOCSPNoCheck,setter=setSigningCertOCSPNoCheck:) BOOL signingCertOCSPNoCheck NS_SWIFT_NAME(signingCertOCSPNoCheck);

- (BOOL)signingCertOCSPNoCheck NS_SWIFT_NAME(signingCertOCSPNoCheck());
- (void)setSigningCertOCSPNoCheck :(BOOL)newSigningCertOCSPNoCheck NS_SWIFT_NAME(setSigningCertOCSPNoCheck(_:));

@property (nonatomic,readonly,assign,getter=signingCertOrigin) int signingCertOrigin NS_SWIFT_NAME(signingCertOrigin);

- (int)signingCertOrigin NS_SWIFT_NAME(signingCertOrigin());

@property (nonatomic,readwrite,assign,getter=signingCertPolicyIDs,setter=setSigningCertPolicyIDs:) NSString* signingCertPolicyIDs NS_SWIFT_NAME(signingCertPolicyIDs);

- (NSString*)signingCertPolicyIDs NS_SWIFT_NAME(signingCertPolicyIDs());
- (void)setSigningCertPolicyIDs :(NSString*)newSigningCertPolicyIDs NS_SWIFT_NAME(setSigningCertPolicyIDs(_:));

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyBytes) NSData* signingCertPrivateKeyBytes NS_SWIFT_NAME(signingCertPrivateKeyBytes);

- (NSData*)signingCertPrivateKeyBytes NS_SWIFT_NAME(signingCertPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyExists) BOOL signingCertPrivateKeyExists NS_SWIFT_NAME(signingCertPrivateKeyExists);

- (BOOL)signingCertPrivateKeyExists NS_SWIFT_NAME(signingCertPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyExtractable) BOOL signingCertPrivateKeyExtractable NS_SWIFT_NAME(signingCertPrivateKeyExtractable);

- (BOOL)signingCertPrivateKeyExtractable NS_SWIFT_NAME(signingCertPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=signingCertPublicKeyBytes) NSData* signingCertPublicKeyBytes NS_SWIFT_NAME(signingCertPublicKeyBytes);

- (NSData*)signingCertPublicKeyBytes NS_SWIFT_NAME(signingCertPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=signingCertQualified) BOOL signingCertQualified NS_SWIFT_NAME(signingCertQualified);

- (BOOL)signingCertQualified NS_SWIFT_NAME(signingCertQualified());

@property (nonatomic,readwrite,assign,getter=signingCertQualifiedStatements,setter=setSigningCertQualifiedStatements:) int signingCertQualifiedStatements NS_SWIFT_NAME(signingCertQualifiedStatements);

- (int)signingCertQualifiedStatements NS_SWIFT_NAME(signingCertQualifiedStatements());
- (void)setSigningCertQualifiedStatements :(int)newSigningCertQualifiedStatements NS_SWIFT_NAME(setSigningCertQualifiedStatements(_:));

@property (nonatomic,readonly,assign,getter=signingCertQualifiers) NSString* signingCertQualifiers NS_SWIFT_NAME(signingCertQualifiers);

- (NSString*)signingCertQualifiers NS_SWIFT_NAME(signingCertQualifiers());

@property (nonatomic,readonly,assign,getter=signingCertSelfSigned) BOOL signingCertSelfSigned NS_SWIFT_NAME(signingCertSelfSigned);

- (BOOL)signingCertSelfSigned NS_SWIFT_NAME(signingCertSelfSigned());

@property (nonatomic,readwrite,assign,getter=signingCertSerialNumber,setter=setSigningCertSerialNumber:) NSData* signingCertSerialNumber NS_SWIFT_NAME(signingCertSerialNumber);

- (NSData*)signingCertSerialNumber NS_SWIFT_NAME(signingCertSerialNumber());
- (void)setSigningCertSerialNumber :(NSData*)newSigningCertSerialNumber NS_SWIFT_NAME(setSigningCertSerialNumber(_:));

@property (nonatomic,readonly,assign,getter=signingCertSigAlgorithm) NSString* signingCertSigAlgorithm NS_SWIFT_NAME(signingCertSigAlgorithm);

- (NSString*)signingCertSigAlgorithm NS_SWIFT_NAME(signingCertSigAlgorithm());

@property (nonatomic,readonly,assign,getter=signingCertSource) int signingCertSource NS_SWIFT_NAME(signingCertSource);

- (int)signingCertSource NS_SWIFT_NAME(signingCertSource());

@property (nonatomic,readonly,assign,getter=signingCertSubject) NSString* signingCertSubject NS_SWIFT_NAME(signingCertSubject);

- (NSString*)signingCertSubject NS_SWIFT_NAME(signingCertSubject());

@property (nonatomic,readwrite,assign,getter=signingCertSubjectAlternativeName,setter=setSigningCertSubjectAlternativeName:) NSString* signingCertSubjectAlternativeName NS_SWIFT_NAME(signingCertSubjectAlternativeName);

- (NSString*)signingCertSubjectAlternativeName NS_SWIFT_NAME(signingCertSubjectAlternativeName());
- (void)setSigningCertSubjectAlternativeName :(NSString*)newSigningCertSubjectAlternativeName NS_SWIFT_NAME(setSigningCertSubjectAlternativeName(_:));

@property (nonatomic,readwrite,assign,getter=signingCertSubjectKeyID,setter=setSigningCertSubjectKeyID:) NSData* signingCertSubjectKeyID NS_SWIFT_NAME(signingCertSubjectKeyID);

- (NSData*)signingCertSubjectKeyID NS_SWIFT_NAME(signingCertSubjectKeyID());
- (void)setSigningCertSubjectKeyID :(NSData*)newSigningCertSubjectKeyID NS_SWIFT_NAME(setSigningCertSubjectKeyID(_:));

@property (nonatomic,readwrite,assign,getter=signingCertSubjectRDN,setter=setSigningCertSubjectRDN:) NSString* signingCertSubjectRDN NS_SWIFT_NAME(signingCertSubjectRDN);

- (NSString*)signingCertSubjectRDN NS_SWIFT_NAME(signingCertSubjectRDN());
- (void)setSigningCertSubjectRDN :(NSString*)newSigningCertSubjectRDN NS_SWIFT_NAME(setSigningCertSubjectRDN(_:));

@property (nonatomic,readonly,assign,getter=signingCertValid) BOOL signingCertValid NS_SWIFT_NAME(signingCertValid);

- (BOOL)signingCertValid NS_SWIFT_NAME(signingCertValid());

@property (nonatomic,readwrite,assign,getter=signingCertValidFrom,setter=setSigningCertValidFrom:) NSString* signingCertValidFrom NS_SWIFT_NAME(signingCertValidFrom);

- (NSString*)signingCertValidFrom NS_SWIFT_NAME(signingCertValidFrom());
- (void)setSigningCertValidFrom :(NSString*)newSigningCertValidFrom NS_SWIFT_NAME(setSigningCertValidFrom(_:));

@property (nonatomic,readwrite,assign,getter=signingCertValidTo,setter=setSigningCertValidTo:) NSString* signingCertValidTo NS_SWIFT_NAME(signingCertValidTo);

- (NSString*)signingCertValidTo NS_SWIFT_NAME(signingCertValidTo());
- (void)setSigningCertValidTo :(NSString*)newSigningCertValidTo NS_SWIFT_NAME(setSigningCertValidTo(_:));

@property (nonatomic,readwrite,assign,getter=signingChainCount,setter=setSigningChainCount:) int signingChainCount NS_SWIFT_NAME(signingChainCount);

- (int)signingChainCount NS_SWIFT_NAME(signingChainCount());
- (void)setSigningChainCount :(int)newSigningChainCount NS_SWIFT_NAME(setSigningChainCount(_:));

- (NSData*)signingChainBytes:(int)signingChainIndex NS_SWIFT_NAME(signingChainBytes(_:));

- (BOOL)signingChainCA:(int)signingChainIndex NS_SWIFT_NAME(signingChainCA(_:));
- (void)setSigningChainCA:(int)signingChainIndex :(BOOL)newSigningChainCA NS_SWIFT_NAME(setSigningChainCA(_:_:));

- (NSData*)signingChainCAKeyID:(int)signingChainIndex NS_SWIFT_NAME(signingChainCAKeyID(_:));

- (int)signingChainCertType:(int)signingChainIndex NS_SWIFT_NAME(signingChainCertType(_:));

- (NSString*)signingChainCRLDistributionPoints:(int)signingChainIndex NS_SWIFT_NAME(signingChainCRLDistributionPoints(_:));
- (void)setSigningChainCRLDistributionPoints:(int)signingChainIndex :(NSString*)newSigningChainCRLDistributionPoints NS_SWIFT_NAME(setSigningChainCRLDistributionPoints(_:_:));

- (NSString*)signingChainCurve:(int)signingChainIndex NS_SWIFT_NAME(signingChainCurve(_:));
- (void)setSigningChainCurve:(int)signingChainIndex :(NSString*)newSigningChainCurve NS_SWIFT_NAME(setSigningChainCurve(_:_:));

- (NSString*)signingChainFingerprint:(int)signingChainIndex NS_SWIFT_NAME(signingChainFingerprint(_:));

- (NSString*)signingChainFriendlyName:(int)signingChainIndex NS_SWIFT_NAME(signingChainFriendlyName(_:));

- (long long)signingChainHandle:(int)signingChainIndex NS_SWIFT_NAME(signingChainHandle(_:));
- (void)setSigningChainHandle:(int)signingChainIndex :(long long)newSigningChainHandle NS_SWIFT_NAME(setSigningChainHandle(_:_:));

- (NSString*)signingChainHashAlgorithm:(int)signingChainIndex NS_SWIFT_NAME(signingChainHashAlgorithm(_:));
- (void)setSigningChainHashAlgorithm:(int)signingChainIndex :(NSString*)newSigningChainHashAlgorithm NS_SWIFT_NAME(setSigningChainHashAlgorithm(_:_:));

- (NSString*)signingChainIssuer:(int)signingChainIndex NS_SWIFT_NAME(signingChainIssuer(_:));

- (NSString*)signingChainIssuerRDN:(int)signingChainIndex NS_SWIFT_NAME(signingChainIssuerRDN(_:));
- (void)setSigningChainIssuerRDN:(int)signingChainIndex :(NSString*)newSigningChainIssuerRDN NS_SWIFT_NAME(setSigningChainIssuerRDN(_:_:));

- (NSString*)signingChainKeyAlgorithm:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyAlgorithm(_:));
- (void)setSigningChainKeyAlgorithm:(int)signingChainIndex :(NSString*)newSigningChainKeyAlgorithm NS_SWIFT_NAME(setSigningChainKeyAlgorithm(_:_:));

- (int)signingChainKeyBits:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyBits(_:));

- (NSString*)signingChainKeyFingerprint:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyFingerprint(_:));

- (int)signingChainKeyUsage:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyUsage(_:));
- (void)setSigningChainKeyUsage:(int)signingChainIndex :(int)newSigningChainKeyUsage NS_SWIFT_NAME(setSigningChainKeyUsage(_:_:));

- (BOOL)signingChainKeyValid:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyValid(_:));

- (NSString*)signingChainOCSPLocations:(int)signingChainIndex NS_SWIFT_NAME(signingChainOCSPLocations(_:));
- (void)setSigningChainOCSPLocations:(int)signingChainIndex :(NSString*)newSigningChainOCSPLocations NS_SWIFT_NAME(setSigningChainOCSPLocations(_:_:));

- (BOOL)signingChainOCSPNoCheck:(int)signingChainIndex NS_SWIFT_NAME(signingChainOCSPNoCheck(_:));
- (void)setSigningChainOCSPNoCheck:(int)signingChainIndex :(BOOL)newSigningChainOCSPNoCheck NS_SWIFT_NAME(setSigningChainOCSPNoCheck(_:_:));

- (int)signingChainOrigin:(int)signingChainIndex NS_SWIFT_NAME(signingChainOrigin(_:));

- (NSString*)signingChainPolicyIDs:(int)signingChainIndex NS_SWIFT_NAME(signingChainPolicyIDs(_:));
- (void)setSigningChainPolicyIDs:(int)signingChainIndex :(NSString*)newSigningChainPolicyIDs NS_SWIFT_NAME(setSigningChainPolicyIDs(_:_:));

- (NSData*)signingChainPrivateKeyBytes:(int)signingChainIndex NS_SWIFT_NAME(signingChainPrivateKeyBytes(_:));

- (BOOL)signingChainPrivateKeyExists:(int)signingChainIndex NS_SWIFT_NAME(signingChainPrivateKeyExists(_:));

- (BOOL)signingChainPrivateKeyExtractable:(int)signingChainIndex NS_SWIFT_NAME(signingChainPrivateKeyExtractable(_:));

- (NSData*)signingChainPublicKeyBytes:(int)signingChainIndex NS_SWIFT_NAME(signingChainPublicKeyBytes(_:));

- (BOOL)signingChainQualified:(int)signingChainIndex NS_SWIFT_NAME(signingChainQualified(_:));

- (int)signingChainQualifiedStatements:(int)signingChainIndex NS_SWIFT_NAME(signingChainQualifiedStatements(_:));
- (void)setSigningChainQualifiedStatements:(int)signingChainIndex :(int)newSigningChainQualifiedStatements NS_SWIFT_NAME(setSigningChainQualifiedStatements(_:_:));

- (NSString*)signingChainQualifiers:(int)signingChainIndex NS_SWIFT_NAME(signingChainQualifiers(_:));

- (BOOL)signingChainSelfSigned:(int)signingChainIndex NS_SWIFT_NAME(signingChainSelfSigned(_:));

- (NSData*)signingChainSerialNumber:(int)signingChainIndex NS_SWIFT_NAME(signingChainSerialNumber(_:));
- (void)setSigningChainSerialNumber:(int)signingChainIndex :(NSData*)newSigningChainSerialNumber NS_SWIFT_NAME(setSigningChainSerialNumber(_:_:));

- (NSString*)signingChainSigAlgorithm:(int)signingChainIndex NS_SWIFT_NAME(signingChainSigAlgorithm(_:));

- (int)signingChainSource:(int)signingChainIndex NS_SWIFT_NAME(signingChainSource(_:));

- (NSString*)signingChainSubject:(int)signingChainIndex NS_SWIFT_NAME(signingChainSubject(_:));

- (NSString*)signingChainSubjectAlternativeName:(int)signingChainIndex NS_SWIFT_NAME(signingChainSubjectAlternativeName(_:));
- (void)setSigningChainSubjectAlternativeName:(int)signingChainIndex :(NSString*)newSigningChainSubjectAlternativeName NS_SWIFT_NAME(setSigningChainSubjectAlternativeName(_:_:));

- (NSData*)signingChainSubjectKeyID:(int)signingChainIndex NS_SWIFT_NAME(signingChainSubjectKeyID(_:));
- (void)setSigningChainSubjectKeyID:(int)signingChainIndex :(NSData*)newSigningChainSubjectKeyID NS_SWIFT_NAME(setSigningChainSubjectKeyID(_:_:));

- (NSString*)signingChainSubjectRDN:(int)signingChainIndex NS_SWIFT_NAME(signingChainSubjectRDN(_:));
- (void)setSigningChainSubjectRDN:(int)signingChainIndex :(NSString*)newSigningChainSubjectRDN NS_SWIFT_NAME(setSigningChainSubjectRDN(_:_:));

- (BOOL)signingChainValid:(int)signingChainIndex NS_SWIFT_NAME(signingChainValid(_:));

- (NSString*)signingChainValidFrom:(int)signingChainIndex NS_SWIFT_NAME(signingChainValidFrom(_:));
- (void)setSigningChainValidFrom:(int)signingChainIndex :(NSString*)newSigningChainValidFrom NS_SWIFT_NAME(setSigningChainValidFrom(_:_:));

- (NSString*)signingChainValidTo:(int)signingChainIndex NS_SWIFT_NAME(signingChainValidTo(_:));
- (void)setSigningChainValidTo:(int)signingChainIndex :(NSString*)newSigningChainValidTo NS_SWIFT_NAME(setSigningChainValidTo(_:_:));

@property (nonatomic,readwrite,assign,getter=textEncoding,setter=setTextEncoding:) int textEncoding NS_SWIFT_NAME(textEncoding);

- (int)textEncoding NS_SWIFT_NAME(textEncoding());
- (void)setTextEncoding :(int)newTextEncoding NS_SWIFT_NAME(setTextEncoding(_:));

  /* Methods */

- (int)attachBytes:(NSData*)data NS_SWIFT_NAME(attachBytes(_:));

- (int)attachFile:(NSString*)fileName NS_SWIFT_NAME(attachFile(_:));

- (int)attachImage:(NSString*)ID :(NSData*)data NS_SWIFT_NAME(attachImage(_:_:));

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (void)createNew NS_SWIFT_NAME(createNew());

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (void)reset NS_SWIFT_NAME(reset());

- (NSData*)saveToBytes NS_SWIFT_NAME(saveToBytes());

- (void)saveToFile:(NSString*)fileName NS_SWIFT_NAME(saveToFile(_:));

@end

