/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//CONFLICTRESOLUTIONMODES
#define CFTM_OVERWRITE                                     0

#define CFTM_SKIP                                          1

#define CFTM_APPEND_TO_END                                 2

#define CFTM_RESUME                                        3

#define CFTM_OVERWRITE_IF_DIFF_SIZE                        4

#define CFTM_SAVE_WITH_NEW_NAME                            5

#define CFTM_RENAME_EXISTING_TARGET                        6

//FTPFILEFORMATS
#define CFEF_UNKNOWN                                       0

#define CFEF_UNIX                                          1

#define CFEF_WINDOWS                                       2

#define CFEF_MLSD                                          3

//FTPFILETYPES
#define FET_UNKNOWN                                        0

#define FET_DIRECTORY                                      1

#define FET_FILE                                           2

#define FET_SYMLINK                                        3

#define FET_SPECIAL                                        4

#define FET_CURRENT_DIRECTORY                              5

#define FET_PARENT_DIRECTORY                               6

#define FET_SOCKET                                         7

#define FET_CHAR_DEVICE                                    8

#define FET_BLOCK_DEVICE                                   9

#define FET_FIFO                                           10

//ASYNCSIGNMETHODS
#define ASMD_PKCS1                                         0

#define ASMD_PKCS7                                         1

//EXTERNALCRYPTOMODES
#define ECM_DEFAULT                                        0

#define ECM_DISABLED                                       1

#define ECM_GENERIC                                        2

#define ECM_DCAUTH                                         3

#define ECM_DCAUTH_JSON                                    4

//SSHKEYFORMATS
#define CKF_OPEN_SSH                                       0

#define CKF_OPEN_SSH2                                      1

#define CKF_IETF                                           2

#define CKF_PU_TTY                                         3

#define CKF_X509                                           4

#define CKF_BINARY                                         5

#define CKF_SSH1                                           6

#define CKF_PGP                                            7

#define CKF_PKCS8                                          8

#define CKF_PU_TTY3                                        9

//PROXYAUTHTYPES
#define PAT_NO_AUTHENTICATION                              0

#define PAT_BASIC                                          1

#define PAT_DIGEST                                         2

#define PAT_NTLM                                           3

//PROXYTYPES
#define CPT_NONE                                           0

#define CPT_SOCKS_4                                        1

#define CPT_SOCKS_5                                        2

#define CPT_WEB_TUNNEL                                     3

#define CPT_HTTP                                           4

//DNSRESOLVEMODES
#define DM_AUTO                                            0

#define DM_PLATFORM                                        1

#define DM_OWN                                             2

#define DM_OWN_SECURE                                      3

//SECURETRANSPORTPREDEFINEDCONFIGURATIONS
#define STPC_DEFAULT                                       0

#define STPC_COMPATIBLE                                    1

#define STPC_COMPREHENSIVE_INSECURE                        2

#define STPC_HIGHLY_SECURE                                 3

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxSFTPClientDelegate <NSObject>
@optional
- (void)onAuthAttempt:(int)authType NS_SWIFT_NAME(onAuthAttempt(_:));

- (void)onAuthFailed:(int)authType NS_SWIFT_NAME(onAuthFailed(_:));

- (void)onAuthSucceeded NS_SWIFT_NAME(onAuthSucceeded());

- (void)onBanner:(NSData*)text :(NSData*)language NS_SWIFT_NAME(onBanner(_:_:));

- (void)onDisconnect:(int)closeReason NS_SWIFT_NAME(onDisconnect(_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onExternalSign:(NSString*)operationId :(NSString*)hashAlgorithm :(NSString*)pars :(NSString*)data :(NSString**)signedData NS_SWIFT_NAME(onExternalSign(_:_:_:_:_:));

- (void)onFileNameChangeNeeded:(NSString**)fileName :(int*)force NS_SWIFT_NAME(onFileNameChangeNeeded(_:_:));

- (void)onFileOperation:(int)operation :(NSString*)remotePath :(NSString*)localPath :(int*)skip :(int*)cancel NS_SWIFT_NAME(onFileOperation(_:_:_:_:_:));

- (void)onFileOperationResult:(int)operation :(NSString*)remotePath :(NSString*)localPath :(int)errorCode :(NSString*)comment :(int*)cancel NS_SWIFT_NAME(onFileOperationResult(_:_:_:_:_:_:));

- (void)onKnownKeyReceived:(NSString*)algorithm :(int)bits :(NSString*)fingerprintSHA256 NS_SWIFT_NAME(onKnownKeyReceived(_:_:_:));

- (void)onListEntry:(NSString*)fileName NS_SWIFT_NAME(onListEntry(_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onPasswordChangeRequest:(NSString*)prompt :(NSString**)newPassword :(int*)cancel NS_SWIFT_NAME(onPasswordChangeRequest(_:_:_:));

- (void)onPrivateKeyNeeded:(int*)skip NS_SWIFT_NAME(onPrivateKeyNeeded(_:));

- (void)onProgress:(long long)total :(long long)current :(int*)cancel NS_SWIFT_NAME(onProgress(_:_:_:));

- (void)onUnknownKeyReceived:(NSString*)algorithm :(int)bits :(NSString*)fingerprintSHA256 :(int*)action NS_SWIFT_NAME(onUnknownKeyReceived(_:_:_:_:));

@end

@interface SecureBlackboxSFTPClient : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxSFTPClientDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasAuthAttempt;

  BOOL m_delegateHasAuthFailed;

  BOOL m_delegateHasAuthSucceeded;

  BOOL m_delegateHasBanner;

  BOOL m_delegateHasDisconnect;

  BOOL m_delegateHasError;

  BOOL m_delegateHasExternalSign;

  BOOL m_delegateHasFileNameChangeNeeded;

  BOOL m_delegateHasFileOperation;

  BOOL m_delegateHasFileOperationResult;

  BOOL m_delegateHasKnownKeyReceived;

  BOOL m_delegateHasListEntry;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasPasswordChangeRequest;

  BOOL m_delegateHasPrivateKeyNeeded;

  BOOL m_delegateHasProgress;

  BOOL m_delegateHasUnknownKeyReceived;

}

+ (SecureBlackboxSFTPClient*)sftpclient;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxSFTPClientDelegate> delegate;
- (id <SecureBlackboxSFTPClientDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxSFTPClientDelegate>)anObject;

  /* Events */

- (void)onAuthAttempt:(int)authType NS_SWIFT_NAME(onAuthAttempt(_:));

- (void)onAuthFailed:(int)authType NS_SWIFT_NAME(onAuthFailed(_:));

- (void)onAuthSucceeded NS_SWIFT_NAME(onAuthSucceeded());

- (void)onBanner:(NSData*)text :(NSData*)language NS_SWIFT_NAME(onBanner(_:_:));

- (void)onDisconnect:(int)closeReason NS_SWIFT_NAME(onDisconnect(_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onExternalSign:(NSString*)operationId :(NSString*)hashAlgorithm :(NSString*)pars :(NSString*)data :(NSString**)signedData NS_SWIFT_NAME(onExternalSign(_:_:_:_:_:));

- (void)onFileNameChangeNeeded:(NSString**)fileName :(int*)force NS_SWIFT_NAME(onFileNameChangeNeeded(_:_:));

- (void)onFileOperation:(int)operation :(NSString*)remotePath :(NSString*)localPath :(int*)skip :(int*)cancel NS_SWIFT_NAME(onFileOperation(_:_:_:_:_:));

- (void)onFileOperationResult:(int)operation :(NSString*)remotePath :(NSString*)localPath :(int)errorCode :(NSString*)comment :(int*)cancel NS_SWIFT_NAME(onFileOperationResult(_:_:_:_:_:_:));

- (void)onKnownKeyReceived:(NSString*)algorithm :(int)bits :(NSString*)fingerprintSHA256 NS_SWIFT_NAME(onKnownKeyReceived(_:_:_:));

- (void)onListEntry:(NSString*)fileName NS_SWIFT_NAME(onListEntry(_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onPasswordChangeRequest:(NSString*)prompt :(NSString**)newPassword :(int*)cancel NS_SWIFT_NAME(onPasswordChangeRequest(_:_:_:));

- (void)onPrivateKeyNeeded:(int*)skip NS_SWIFT_NAME(onPrivateKeyNeeded(_:));

- (void)onProgress:(long long)total :(long long)current :(int*)cancel NS_SWIFT_NAME(onProgress(_:_:_:));

- (void)onUnknownKeyReceived:(NSString*)algorithm :(int)bits :(NSString*)fingerprintSHA256 :(int*)action NS_SWIFT_NAME(onUnknownKeyReceived(_:_:_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readwrite,assign,getter=authAttempts,setter=setAuthAttempts:) int authAttempts NS_SWIFT_NAME(authAttempts);

- (int)authAttempts NS_SWIFT_NAME(authAttempts());
- (void)setAuthAttempts :(int)newAuthAttempts NS_SWIFT_NAME(setAuthAttempts(_:));

@property (nonatomic,readwrite,assign,getter=autoAdjustTransferBlock,setter=setAutoAdjustTransferBlock:) BOOL autoAdjustTransferBlock NS_SWIFT_NAME(autoAdjustTransferBlock);

- (BOOL)autoAdjustTransferBlock NS_SWIFT_NAME(autoAdjustTransferBlock());
- (void)setAutoAdjustTransferBlock :(BOOL)newAutoAdjustTransferBlock NS_SWIFT_NAME(setAutoAdjustTransferBlock(_:));

@property (nonatomic,readwrite,assign,getter=conflictResolutionMode,setter=setConflictResolutionMode:) int conflictResolutionMode NS_SWIFT_NAME(conflictResolutionMode);

- (int)conflictResolutionMode NS_SWIFT_NAME(conflictResolutionMode());
- (void)setConflictResolutionMode :(int)newConflictResolutionMode NS_SWIFT_NAME(setConflictResolutionMode(_:));

@property (nonatomic,readonly,assign,getter=connected) BOOL connected NS_SWIFT_NAME(connected);

- (BOOL)connected NS_SWIFT_NAME(connected());

@property (nonatomic,readonly,assign,getter=connInfoClientKeyAlgorithm) NSString* connInfoClientKeyAlgorithm NS_SWIFT_NAME(connInfoClientKeyAlgorithm);

- (NSString*)connInfoClientKeyAlgorithm NS_SWIFT_NAME(connInfoClientKeyAlgorithm());

@property (nonatomic,readonly,assign,getter=connInfoClientKeyBits) int connInfoClientKeyBits NS_SWIFT_NAME(connInfoClientKeyBits);

- (int)connInfoClientKeyBits NS_SWIFT_NAME(connInfoClientKeyBits());

@property (nonatomic,readonly,assign,getter=connInfoClientKeyFingerprint) NSString* connInfoClientKeyFingerprint NS_SWIFT_NAME(connInfoClientKeyFingerprint);

- (NSString*)connInfoClientKeyFingerprint NS_SWIFT_NAME(connInfoClientKeyFingerprint());

@property (nonatomic,readonly,assign,getter=connInfoCloseReason) NSString* connInfoCloseReason NS_SWIFT_NAME(connInfoCloseReason);

- (NSString*)connInfoCloseReason NS_SWIFT_NAME(connInfoCloseReason());

@property (nonatomic,readonly,assign,getter=connInfoCompressionAlgorithmInbound) NSString* connInfoCompressionAlgorithmInbound NS_SWIFT_NAME(connInfoCompressionAlgorithmInbound);

- (NSString*)connInfoCompressionAlgorithmInbound NS_SWIFT_NAME(connInfoCompressionAlgorithmInbound());

@property (nonatomic,readonly,assign,getter=connInfoCompressionAlgorithmOutbound) NSString* connInfoCompressionAlgorithmOutbound NS_SWIFT_NAME(connInfoCompressionAlgorithmOutbound);

- (NSString*)connInfoCompressionAlgorithmOutbound NS_SWIFT_NAME(connInfoCompressionAlgorithmOutbound());

@property (nonatomic,readonly,assign,getter=connInfoEncryptionAlgorithmInbound) NSString* connInfoEncryptionAlgorithmInbound NS_SWIFT_NAME(connInfoEncryptionAlgorithmInbound);

- (NSString*)connInfoEncryptionAlgorithmInbound NS_SWIFT_NAME(connInfoEncryptionAlgorithmInbound());

@property (nonatomic,readonly,assign,getter=connInfoEncryptionAlgorithmOutbound) NSString* connInfoEncryptionAlgorithmOutbound NS_SWIFT_NAME(connInfoEncryptionAlgorithmOutbound);

- (NSString*)connInfoEncryptionAlgorithmOutbound NS_SWIFT_NAME(connInfoEncryptionAlgorithmOutbound());

@property (nonatomic,readonly,assign,getter=connInfoInboundEncryptionKeyBits) int connInfoInboundEncryptionKeyBits NS_SWIFT_NAME(connInfoInboundEncryptionKeyBits);

- (int)connInfoInboundEncryptionKeyBits NS_SWIFT_NAME(connInfoInboundEncryptionKeyBits());

@property (nonatomic,readonly,assign,getter=connInfoKexAlgorithm) NSString* connInfoKexAlgorithm NS_SWIFT_NAME(connInfoKexAlgorithm);

- (NSString*)connInfoKexAlgorithm NS_SWIFT_NAME(connInfoKexAlgorithm());

@property (nonatomic,readonly,assign,getter=connInfoKexBits) int connInfoKexBits NS_SWIFT_NAME(connInfoKexBits);

- (int)connInfoKexBits NS_SWIFT_NAME(connInfoKexBits());

@property (nonatomic,readonly,assign,getter=connInfoKexLines) NSString* connInfoKexLines NS_SWIFT_NAME(connInfoKexLines);

- (NSString*)connInfoKexLines NS_SWIFT_NAME(connInfoKexLines());

@property (nonatomic,readonly,assign,getter=connInfoMacAlgorithmInbound) NSString* connInfoMacAlgorithmInbound NS_SWIFT_NAME(connInfoMacAlgorithmInbound);

- (NSString*)connInfoMacAlgorithmInbound NS_SWIFT_NAME(connInfoMacAlgorithmInbound());

@property (nonatomic,readonly,assign,getter=connInfoMacAlgorithmOutbound) NSString* connInfoMacAlgorithmOutbound NS_SWIFT_NAME(connInfoMacAlgorithmOutbound);

- (NSString*)connInfoMacAlgorithmOutbound NS_SWIFT_NAME(connInfoMacAlgorithmOutbound());

@property (nonatomic,readonly,assign,getter=connInfoOutboundEncryptionKeyBits) int connInfoOutboundEncryptionKeyBits NS_SWIFT_NAME(connInfoOutboundEncryptionKeyBits);

- (int)connInfoOutboundEncryptionKeyBits NS_SWIFT_NAME(connInfoOutboundEncryptionKeyBits());

@property (nonatomic,readonly,assign,getter=connInfoPublicKeyAlgorithm) NSString* connInfoPublicKeyAlgorithm NS_SWIFT_NAME(connInfoPublicKeyAlgorithm);

- (NSString*)connInfoPublicKeyAlgorithm NS_SWIFT_NAME(connInfoPublicKeyAlgorithm());

@property (nonatomic,readonly,assign,getter=connInfoRemoteAddress) NSString* connInfoRemoteAddress NS_SWIFT_NAME(connInfoRemoteAddress);

- (NSString*)connInfoRemoteAddress NS_SWIFT_NAME(connInfoRemoteAddress());

@property (nonatomic,readonly,assign,getter=connInfoRemotePort) int connInfoRemotePort NS_SWIFT_NAME(connInfoRemotePort);

- (int)connInfoRemotePort NS_SWIFT_NAME(connInfoRemotePort());

@property (nonatomic,readonly,assign,getter=connInfoServerKeyAlgorithm) NSString* connInfoServerKeyAlgorithm NS_SWIFT_NAME(connInfoServerKeyAlgorithm);

- (NSString*)connInfoServerKeyAlgorithm NS_SWIFT_NAME(connInfoServerKeyAlgorithm());

@property (nonatomic,readonly,assign,getter=connInfoServerKeyBits) int connInfoServerKeyBits NS_SWIFT_NAME(connInfoServerKeyBits);

- (int)connInfoServerKeyBits NS_SWIFT_NAME(connInfoServerKeyBits());

@property (nonatomic,readonly,assign,getter=connInfoServerKeyFingerprint) NSString* connInfoServerKeyFingerprint NS_SWIFT_NAME(connInfoServerKeyFingerprint);

- (NSString*)connInfoServerKeyFingerprint NS_SWIFT_NAME(connInfoServerKeyFingerprint());

@property (nonatomic,readonly,assign,getter=connInfoServerSoftwareName) NSString* connInfoServerSoftwareName NS_SWIFT_NAME(connInfoServerSoftwareName);

- (NSString*)connInfoServerSoftwareName NS_SWIFT_NAME(connInfoServerSoftwareName());

@property (nonatomic,readonly,assign,getter=connInfoTotalBytesReceived) long long connInfoTotalBytesReceived NS_SWIFT_NAME(connInfoTotalBytesReceived);

- (long long)connInfoTotalBytesReceived NS_SWIFT_NAME(connInfoTotalBytesReceived());

@property (nonatomic,readonly,assign,getter=connInfoTotalBytesSent) long long connInfoTotalBytesSent NS_SWIFT_NAME(connInfoTotalBytesSent);

- (long long)connInfoTotalBytesSent NS_SWIFT_NAME(connInfoTotalBytesSent());

@property (nonatomic,readonly,assign,getter=connInfoVersion) int connInfoVersion NS_SWIFT_NAME(connInfoVersion);

- (int)connInfoVersion NS_SWIFT_NAME(connInfoVersion());

@property (nonatomic,readonly,assign,getter=currListEntryAccessTime) NSString* currListEntryAccessTime NS_SWIFT_NAME(currListEntryAccessTime);

- (NSString*)currListEntryAccessTime NS_SWIFT_NAME(currListEntryAccessTime());

@property (nonatomic,readonly,assign,getter=currListEntryCreationTime) NSString* currListEntryCreationTime NS_SWIFT_NAME(currListEntryCreationTime);

- (NSString*)currListEntryCreationTime NS_SWIFT_NAME(currListEntryCreationTime());

@property (nonatomic,readonly,assign,getter=currListEntryEntryFormat) int currListEntryEntryFormat NS_SWIFT_NAME(currListEntryEntryFormat);

- (int)currListEntryEntryFormat NS_SWIFT_NAME(currListEntryEntryFormat());

@property (nonatomic,readonly,assign,getter=currListEntryFileType) int currListEntryFileType NS_SWIFT_NAME(currListEntryFileType);

- (int)currListEntryFileType NS_SWIFT_NAME(currListEntryFileType());

@property (nonatomic,readonly,assign,getter=currListEntryHandle) long long currListEntryHandle NS_SWIFT_NAME(currListEntryHandle);

- (long long)currListEntryHandle NS_SWIFT_NAME(currListEntryHandle());

@property (nonatomic,readonly,assign,getter=currListEntryModificationTime) NSString* currListEntryModificationTime NS_SWIFT_NAME(currListEntryModificationTime);

- (NSString*)currListEntryModificationTime NS_SWIFT_NAME(currListEntryModificationTime());

@property (nonatomic,readonly,assign,getter=currListEntryName) NSString* currListEntryName NS_SWIFT_NAME(currListEntryName);

- (NSString*)currListEntryName NS_SWIFT_NAME(currListEntryName());

@property (nonatomic,readonly,assign,getter=currListEntryPath) NSString* currListEntryPath NS_SWIFT_NAME(currListEntryPath);

- (NSString*)currListEntryPath NS_SWIFT_NAME(currListEntryPath());

@property (nonatomic,readonly,assign,getter=currListEntryPrincipal) NSString* currListEntryPrincipal NS_SWIFT_NAME(currListEntryPrincipal);

- (NSString*)currListEntryPrincipal NS_SWIFT_NAME(currListEntryPrincipal());

@property (nonatomic,readonly,assign,getter=currListEntrySize) long long currListEntrySize NS_SWIFT_NAME(currListEntrySize);

- (long long)currListEntrySize NS_SWIFT_NAME(currListEntrySize());

@property (nonatomic,readonly,assign,getter=currListEntryUnixPerms) int currListEntryUnixPerms NS_SWIFT_NAME(currListEntryUnixPerms);

- (int)currListEntryUnixPerms NS_SWIFT_NAME(currListEntryUnixPerms());

@property (nonatomic,readonly,assign,getter=currListEntryUnparsedName) NSString* currListEntryUnparsedName NS_SWIFT_NAME(currListEntryUnparsedName);

- (NSString*)currListEntryUnparsedName NS_SWIFT_NAME(currListEntryUnparsedName());

@property (nonatomic,readwrite,assign,getter=downloadBlockSize,setter=setDownloadBlockSize:) int downloadBlockSize NS_SWIFT_NAME(downloadBlockSize);

- (int)downloadBlockSize NS_SWIFT_NAME(downloadBlockSize());
- (void)setDownloadBlockSize :(int)newDownloadBlockSize NS_SWIFT_NAME(setDownloadBlockSize(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoAsyncDocumentID,setter=setExternalCryptoAsyncDocumentID:) NSString* externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID);

- (NSString*)externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID());
- (void)setExternalCryptoAsyncDocumentID :(NSString*)newExternalCryptoAsyncDocumentID NS_SWIFT_NAME(setExternalCryptoAsyncDocumentID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoCustomParams,setter=setExternalCryptoCustomParams:) NSString* externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams);

- (NSString*)externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams());
- (void)setExternalCryptoCustomParams :(NSString*)newExternalCryptoCustomParams NS_SWIFT_NAME(setExternalCryptoCustomParams(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoData,setter=setExternalCryptoData:) NSString* externalCryptoData NS_SWIFT_NAME(externalCryptoData);

- (NSString*)externalCryptoData NS_SWIFT_NAME(externalCryptoData());
- (void)setExternalCryptoData :(NSString*)newExternalCryptoData NS_SWIFT_NAME(setExternalCryptoData(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoExternalHashCalculation,setter=setExternalCryptoExternalHashCalculation:) BOOL externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation);

- (BOOL)externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation());
- (void)setExternalCryptoExternalHashCalculation :(BOOL)newExternalCryptoExternalHashCalculation NS_SWIFT_NAME(setExternalCryptoExternalHashCalculation(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoHashAlgorithm,setter=setExternalCryptoHashAlgorithm:) NSString* externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm);

- (NSString*)externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm());
- (void)setExternalCryptoHashAlgorithm :(NSString*)newExternalCryptoHashAlgorithm NS_SWIFT_NAME(setExternalCryptoHashAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeyID,setter=setExternalCryptoKeyID:) NSString* externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID);

- (NSString*)externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID());
- (void)setExternalCryptoKeyID :(NSString*)newExternalCryptoKeyID NS_SWIFT_NAME(setExternalCryptoKeyID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeySecret,setter=setExternalCryptoKeySecret:) NSString* externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret);

- (NSString*)externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret());
- (void)setExternalCryptoKeySecret :(NSString*)newExternalCryptoKeySecret NS_SWIFT_NAME(setExternalCryptoKeySecret(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMethod,setter=setExternalCryptoMethod:) int externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod);

- (int)externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod());
- (void)setExternalCryptoMethod :(int)newExternalCryptoMethod NS_SWIFT_NAME(setExternalCryptoMethod(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMode,setter=setExternalCryptoMode:) int externalCryptoMode NS_SWIFT_NAME(externalCryptoMode);

- (int)externalCryptoMode NS_SWIFT_NAME(externalCryptoMode());
- (void)setExternalCryptoMode :(int)newExternalCryptoMode NS_SWIFT_NAME(setExternalCryptoMode(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoPublicKeyAlgorithm,setter=setExternalCryptoPublicKeyAlgorithm:) NSString* externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm);

- (NSString*)externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm());
- (void)setExternalCryptoPublicKeyAlgorithm :(NSString*)newExternalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(setExternalCryptoPublicKeyAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=forceCompression,setter=setForceCompression:) BOOL forceCompression NS_SWIFT_NAME(forceCompression);

- (BOOL)forceCompression NS_SWIFT_NAME(forceCompression());
- (void)setForceCompression :(BOOL)newForceCompression NS_SWIFT_NAME(setForceCompression(_:));

@property (nonatomic,readonly,assign,getter=keyAlgorithm) NSString* keyAlgorithm NS_SWIFT_NAME(keyAlgorithm);

- (NSString*)keyAlgorithm NS_SWIFT_NAME(keyAlgorithm());

@property (nonatomic,readonly,assign,getter=keyBits) int keyBits NS_SWIFT_NAME(keyBits);

- (int)keyBits NS_SWIFT_NAME(keyBits());

@property (nonatomic,readwrite,assign,getter=keyComment,setter=setKeyComment:) NSString* keyComment NS_SWIFT_NAME(keyComment);

- (NSString*)keyComment NS_SWIFT_NAME(keyComment());
- (void)setKeyComment :(NSString*)newKeyComment NS_SWIFT_NAME(setKeyComment(_:));

@property (nonatomic,readonly,assign,getter=keyCurve) NSString* keyCurve NS_SWIFT_NAME(keyCurve);

- (NSString*)keyCurve NS_SWIFT_NAME(keyCurve());

@property (nonatomic,readonly,assign,getter=keyDSSG) NSData* keyDSSG NS_SWIFT_NAME(keyDSSG);

- (NSData*)keyDSSG NS_SWIFT_NAME(keyDSSG());

@property (nonatomic,readonly,assign,getter=keyDSSP) NSData* keyDSSP NS_SWIFT_NAME(keyDSSP);

- (NSData*)keyDSSP NS_SWIFT_NAME(keyDSSP());

@property (nonatomic,readonly,assign,getter=keyDSSQ) NSData* keyDSSQ NS_SWIFT_NAME(keyDSSQ);

- (NSData*)keyDSSQ NS_SWIFT_NAME(keyDSSQ());

@property (nonatomic,readonly,assign,getter=keyDSSX) NSData* keyDSSX NS_SWIFT_NAME(keyDSSX);

- (NSData*)keyDSSX NS_SWIFT_NAME(keyDSSX());

@property (nonatomic,readonly,assign,getter=keyDSSY) NSData* keyDSSY NS_SWIFT_NAME(keyDSSY);

- (NSData*)keyDSSY NS_SWIFT_NAME(keyDSSY());

@property (nonatomic,readonly,assign,getter=keyECCD) NSData* keyECCD NS_SWIFT_NAME(keyECCD);

- (NSData*)keyECCD NS_SWIFT_NAME(keyECCD());

@property (nonatomic,readonly,assign,getter=keyECCQX) NSData* keyECCQX NS_SWIFT_NAME(keyECCQX);

- (NSData*)keyECCQX NS_SWIFT_NAME(keyECCQX());

@property (nonatomic,readonly,assign,getter=keyECCQY) NSData* keyECCQY NS_SWIFT_NAME(keyECCQY);

- (NSData*)keyECCQY NS_SWIFT_NAME(keyECCQY());

@property (nonatomic,readonly,assign,getter=keyEdPrivate) NSData* keyEdPrivate NS_SWIFT_NAME(keyEdPrivate);

- (NSData*)keyEdPrivate NS_SWIFT_NAME(keyEdPrivate());

@property (nonatomic,readonly,assign,getter=keyEdPublic) NSData* keyEdPublic NS_SWIFT_NAME(keyEdPublic);

- (NSData*)keyEdPublic NS_SWIFT_NAME(keyEdPublic());

@property (nonatomic,readonly,assign,getter=keyFingerprintMD5) NSString* keyFingerprintMD5 NS_SWIFT_NAME(keyFingerprintMD5);

- (NSString*)keyFingerprintMD5 NS_SWIFT_NAME(keyFingerprintMD5());

@property (nonatomic,readonly,assign,getter=keyFingerprintSHA1) NSString* keyFingerprintSHA1 NS_SWIFT_NAME(keyFingerprintSHA1);

- (NSString*)keyFingerprintSHA1 NS_SWIFT_NAME(keyFingerprintSHA1());

@property (nonatomic,readonly,assign,getter=keyFingerprintSHA256) NSString* keyFingerprintSHA256 NS_SWIFT_NAME(keyFingerprintSHA256);

- (NSString*)keyFingerprintSHA256 NS_SWIFT_NAME(keyFingerprintSHA256());

@property (nonatomic,readwrite,assign,getter=keyHandle,setter=setKeyHandle:) long long keyHandle NS_SWIFT_NAME(keyHandle);

- (long long)keyHandle NS_SWIFT_NAME(keyHandle());
- (void)setKeyHandle :(long long)newKeyHandle NS_SWIFT_NAME(setKeyHandle(_:));

@property (nonatomic,readonly,assign,getter=keyIsExtractable) BOOL keyIsExtractable NS_SWIFT_NAME(keyIsExtractable);

- (BOOL)keyIsExtractable NS_SWIFT_NAME(keyIsExtractable());

@property (nonatomic,readonly,assign,getter=keyIsPrivate) BOOL keyIsPrivate NS_SWIFT_NAME(keyIsPrivate);

- (BOOL)keyIsPrivate NS_SWIFT_NAME(keyIsPrivate());

@property (nonatomic,readonly,assign,getter=keyIsPublic) BOOL keyIsPublic NS_SWIFT_NAME(keyIsPublic);

- (BOOL)keyIsPublic NS_SWIFT_NAME(keyIsPublic());

@property (nonatomic,readonly,assign,getter=keyKDFRounds) int keyKDFRounds NS_SWIFT_NAME(keyKDFRounds);

- (int)keyKDFRounds NS_SWIFT_NAME(keyKDFRounds());

@property (nonatomic,readonly,assign,getter=keyKDFSalt) NSData* keyKDFSalt NS_SWIFT_NAME(keyKDFSalt);

- (NSData*)keyKDFSalt NS_SWIFT_NAME(keyKDFSalt());

@property (nonatomic,readonly,assign,getter=keyKeyFormat) int keyKeyFormat NS_SWIFT_NAME(keyKeyFormat);

- (int)keyKeyFormat NS_SWIFT_NAME(keyKeyFormat());

@property (nonatomic,readonly,assign,getter=keyKeyProtectionAlgorithm) NSString* keyKeyProtectionAlgorithm NS_SWIFT_NAME(keyKeyProtectionAlgorithm);

- (NSString*)keyKeyProtectionAlgorithm NS_SWIFT_NAME(keyKeyProtectionAlgorithm());

@property (nonatomic,readonly,assign,getter=keyRSAExponent) NSData* keyRSAExponent NS_SWIFT_NAME(keyRSAExponent);

- (NSData*)keyRSAExponent NS_SWIFT_NAME(keyRSAExponent());

@property (nonatomic,readonly,assign,getter=keyRSAIQMP) NSData* keyRSAIQMP NS_SWIFT_NAME(keyRSAIQMP);

- (NSData*)keyRSAIQMP NS_SWIFT_NAME(keyRSAIQMP());

@property (nonatomic,readonly,assign,getter=keyRSAModulus) NSData* keyRSAModulus NS_SWIFT_NAME(keyRSAModulus);

- (NSData*)keyRSAModulus NS_SWIFT_NAME(keyRSAModulus());

@property (nonatomic,readonly,assign,getter=keyRSAP) NSData* keyRSAP NS_SWIFT_NAME(keyRSAP);

- (NSData*)keyRSAP NS_SWIFT_NAME(keyRSAP());

@property (nonatomic,readonly,assign,getter=keyRSAPrivateExponent) NSData* keyRSAPrivateExponent NS_SWIFT_NAME(keyRSAPrivateExponent);

- (NSData*)keyRSAPrivateExponent NS_SWIFT_NAME(keyRSAPrivateExponent());

@property (nonatomic,readonly,assign,getter=keyRSAQ) NSData* keyRSAQ NS_SWIFT_NAME(keyRSAQ);

- (NSData*)keyRSAQ NS_SWIFT_NAME(keyRSAQ());

@property (nonatomic,readwrite,assign,getter=keySubject,setter=setKeySubject:) NSString* keySubject NS_SWIFT_NAME(keySubject);

- (NSString*)keySubject NS_SWIFT_NAME(keySubject());
- (void)setKeySubject :(NSString*)newKeySubject NS_SWIFT_NAME(setKeySubject(_:));

@property (nonatomic,readwrite,assign,getter=maxSFTPVersion,setter=setMaxSFTPVersion:) int maxSFTPVersion NS_SWIFT_NAME(maxSFTPVersion);

- (int)maxSFTPVersion NS_SWIFT_NAME(maxSFTPVersion());
- (void)setMaxSFTPVersion :(int)newMaxSFTPVersion NS_SWIFT_NAME(setMaxSFTPVersion(_:));

@property (nonatomic,readwrite,assign,getter=minSFTPVersion,setter=setMinSFTPVersion:) int minSFTPVersion NS_SWIFT_NAME(minSFTPVersion);

- (int)minSFTPVersion NS_SWIFT_NAME(minSFTPVersion());
- (void)setMinSFTPVersion :(int)newMinSFTPVersion NS_SWIFT_NAME(setMinSFTPVersion(_:));

@property (nonatomic,readwrite,assign,getter=password,setter=setPassword:) NSString* password NS_SWIFT_NAME(password);

- (NSString*)password NS_SWIFT_NAME(password());
- (void)setPassword :(NSString*)newPassword NS_SWIFT_NAME(setPassword(_:));

@property (nonatomic,readwrite,assign,getter=pipelineLength,setter=setPipelineLength:) int pipelineLength NS_SWIFT_NAME(pipelineLength);

- (int)pipelineLength NS_SWIFT_NAME(pipelineLength());
- (void)setPipelineLength :(int)newPipelineLength NS_SWIFT_NAME(setPipelineLength(_:));

@property (nonatomic,readwrite,assign,getter=proxyAddress,setter=setProxyAddress:) NSString* proxyAddress NS_SWIFT_NAME(proxyAddress);

- (NSString*)proxyAddress NS_SWIFT_NAME(proxyAddress());
- (void)setProxyAddress :(NSString*)newProxyAddress NS_SWIFT_NAME(setProxyAddress(_:));

@property (nonatomic,readwrite,assign,getter=proxyAuthentication,setter=setProxyAuthentication:) int proxyAuthentication NS_SWIFT_NAME(proxyAuthentication);

- (int)proxyAuthentication NS_SWIFT_NAME(proxyAuthentication());
- (void)setProxyAuthentication :(int)newProxyAuthentication NS_SWIFT_NAME(setProxyAuthentication(_:));

@property (nonatomic,readwrite,assign,getter=proxyPassword,setter=setProxyPassword:) NSString* proxyPassword NS_SWIFT_NAME(proxyPassword);

- (NSString*)proxyPassword NS_SWIFT_NAME(proxyPassword());
- (void)setProxyPassword :(NSString*)newProxyPassword NS_SWIFT_NAME(setProxyPassword(_:));

@property (nonatomic,readwrite,assign,getter=proxyPort,setter=setProxyPort:) int proxyPort NS_SWIFT_NAME(proxyPort);

- (int)proxyPort NS_SWIFT_NAME(proxyPort());
- (void)setProxyPort :(int)newProxyPort NS_SWIFT_NAME(setProxyPort(_:));

@property (nonatomic,readwrite,assign,getter=proxyProxyType,setter=setProxyProxyType:) int proxyProxyType NS_SWIFT_NAME(proxyProxyType);

- (int)proxyProxyType NS_SWIFT_NAME(proxyProxyType());
- (void)setProxyProxyType :(int)newProxyProxyType NS_SWIFT_NAME(setProxyProxyType(_:));

@property (nonatomic,readwrite,assign,getter=proxyRequestHeaders,setter=setProxyRequestHeaders:) NSString* proxyRequestHeaders NS_SWIFT_NAME(proxyRequestHeaders);

- (NSString*)proxyRequestHeaders NS_SWIFT_NAME(proxyRequestHeaders());
- (void)setProxyRequestHeaders :(NSString*)newProxyRequestHeaders NS_SWIFT_NAME(setProxyRequestHeaders(_:));

@property (nonatomic,readwrite,assign,getter=proxyResponseBody,setter=setProxyResponseBody:) NSString* proxyResponseBody NS_SWIFT_NAME(proxyResponseBody);

- (NSString*)proxyResponseBody NS_SWIFT_NAME(proxyResponseBody());
- (void)setProxyResponseBody :(NSString*)newProxyResponseBody NS_SWIFT_NAME(setProxyResponseBody(_:));

@property (nonatomic,readwrite,assign,getter=proxyResponseHeaders,setter=setProxyResponseHeaders:) NSString* proxyResponseHeaders NS_SWIFT_NAME(proxyResponseHeaders);

- (NSString*)proxyResponseHeaders NS_SWIFT_NAME(proxyResponseHeaders());
- (void)setProxyResponseHeaders :(NSString*)newProxyResponseHeaders NS_SWIFT_NAME(setProxyResponseHeaders(_:));

@property (nonatomic,readwrite,assign,getter=proxyUseIPv6,setter=setProxyUseIPv6:) BOOL proxyUseIPv6 NS_SWIFT_NAME(proxyUseIPv6);

- (BOOL)proxyUseIPv6 NS_SWIFT_NAME(proxyUseIPv6());
- (void)setProxyUseIPv6 :(BOOL)newProxyUseIPv6 NS_SWIFT_NAME(setProxyUseIPv6(_:));

@property (nonatomic,readwrite,assign,getter=proxyUsername,setter=setProxyUsername:) NSString* proxyUsername NS_SWIFT_NAME(proxyUsername);

- (NSString*)proxyUsername NS_SWIFT_NAME(proxyUsername());
- (void)setProxyUsername :(NSString*)newProxyUsername NS_SWIFT_NAME(setProxyUsername(_:));

@property (nonatomic,readonly,assign,getter=serverKeyAlgorithm) NSString* serverKeyAlgorithm NS_SWIFT_NAME(serverKeyAlgorithm);

- (NSString*)serverKeyAlgorithm NS_SWIFT_NAME(serverKeyAlgorithm());

@property (nonatomic,readonly,assign,getter=serverKeyBits) int serverKeyBits NS_SWIFT_NAME(serverKeyBits);

- (int)serverKeyBits NS_SWIFT_NAME(serverKeyBits());

@property (nonatomic,readonly,assign,getter=serverKeyComment) NSString* serverKeyComment NS_SWIFT_NAME(serverKeyComment);

- (NSString*)serverKeyComment NS_SWIFT_NAME(serverKeyComment());

@property (nonatomic,readonly,assign,getter=serverKeyCurve) NSString* serverKeyCurve NS_SWIFT_NAME(serverKeyCurve);

- (NSString*)serverKeyCurve NS_SWIFT_NAME(serverKeyCurve());

@property (nonatomic,readonly,assign,getter=serverKeyDSSG) NSData* serverKeyDSSG NS_SWIFT_NAME(serverKeyDSSG);

- (NSData*)serverKeyDSSG NS_SWIFT_NAME(serverKeyDSSG());

@property (nonatomic,readonly,assign,getter=serverKeyDSSP) NSData* serverKeyDSSP NS_SWIFT_NAME(serverKeyDSSP);

- (NSData*)serverKeyDSSP NS_SWIFT_NAME(serverKeyDSSP());

@property (nonatomic,readonly,assign,getter=serverKeyDSSQ) NSData* serverKeyDSSQ NS_SWIFT_NAME(serverKeyDSSQ);

- (NSData*)serverKeyDSSQ NS_SWIFT_NAME(serverKeyDSSQ());

@property (nonatomic,readonly,assign,getter=serverKeyDSSX) NSData* serverKeyDSSX NS_SWIFT_NAME(serverKeyDSSX);

- (NSData*)serverKeyDSSX NS_SWIFT_NAME(serverKeyDSSX());

@property (nonatomic,readonly,assign,getter=serverKeyDSSY) NSData* serverKeyDSSY NS_SWIFT_NAME(serverKeyDSSY);

- (NSData*)serverKeyDSSY NS_SWIFT_NAME(serverKeyDSSY());

@property (nonatomic,readonly,assign,getter=serverKeyECCD) NSData* serverKeyECCD NS_SWIFT_NAME(serverKeyECCD);

- (NSData*)serverKeyECCD NS_SWIFT_NAME(serverKeyECCD());

@property (nonatomic,readonly,assign,getter=serverKeyECCQX) NSData* serverKeyECCQX NS_SWIFT_NAME(serverKeyECCQX);

- (NSData*)serverKeyECCQX NS_SWIFT_NAME(serverKeyECCQX());

@property (nonatomic,readonly,assign,getter=serverKeyECCQY) NSData* serverKeyECCQY NS_SWIFT_NAME(serverKeyECCQY);

- (NSData*)serverKeyECCQY NS_SWIFT_NAME(serverKeyECCQY());

@property (nonatomic,readonly,assign,getter=serverKeyEdPrivate) NSData* serverKeyEdPrivate NS_SWIFT_NAME(serverKeyEdPrivate);

- (NSData*)serverKeyEdPrivate NS_SWIFT_NAME(serverKeyEdPrivate());

@property (nonatomic,readonly,assign,getter=serverKeyEdPublic) NSData* serverKeyEdPublic NS_SWIFT_NAME(serverKeyEdPublic);

- (NSData*)serverKeyEdPublic NS_SWIFT_NAME(serverKeyEdPublic());

@property (nonatomic,readonly,assign,getter=serverKeyFingerprintMD5) NSString* serverKeyFingerprintMD5 NS_SWIFT_NAME(serverKeyFingerprintMD5);

- (NSString*)serverKeyFingerprintMD5 NS_SWIFT_NAME(serverKeyFingerprintMD5());

@property (nonatomic,readonly,assign,getter=serverKeyFingerprintSHA1) NSString* serverKeyFingerprintSHA1 NS_SWIFT_NAME(serverKeyFingerprintSHA1);

- (NSString*)serverKeyFingerprintSHA1 NS_SWIFT_NAME(serverKeyFingerprintSHA1());

@property (nonatomic,readonly,assign,getter=serverKeyFingerprintSHA256) NSString* serverKeyFingerprintSHA256 NS_SWIFT_NAME(serverKeyFingerprintSHA256);

- (NSString*)serverKeyFingerprintSHA256 NS_SWIFT_NAME(serverKeyFingerprintSHA256());

@property (nonatomic,readonly,assign,getter=serverKeyHandle) long long serverKeyHandle NS_SWIFT_NAME(serverKeyHandle);

- (long long)serverKeyHandle NS_SWIFT_NAME(serverKeyHandle());

@property (nonatomic,readonly,assign,getter=serverKeyIsExtractable) BOOL serverKeyIsExtractable NS_SWIFT_NAME(serverKeyIsExtractable);

- (BOOL)serverKeyIsExtractable NS_SWIFT_NAME(serverKeyIsExtractable());

@property (nonatomic,readonly,assign,getter=serverKeyIsPrivate) BOOL serverKeyIsPrivate NS_SWIFT_NAME(serverKeyIsPrivate);

- (BOOL)serverKeyIsPrivate NS_SWIFT_NAME(serverKeyIsPrivate());

@property (nonatomic,readonly,assign,getter=serverKeyIsPublic) BOOL serverKeyIsPublic NS_SWIFT_NAME(serverKeyIsPublic);

- (BOOL)serverKeyIsPublic NS_SWIFT_NAME(serverKeyIsPublic());

@property (nonatomic,readonly,assign,getter=serverKeyKDFRounds) int serverKeyKDFRounds NS_SWIFT_NAME(serverKeyKDFRounds);

- (int)serverKeyKDFRounds NS_SWIFT_NAME(serverKeyKDFRounds());

@property (nonatomic,readonly,assign,getter=serverKeyKDFSalt) NSData* serverKeyKDFSalt NS_SWIFT_NAME(serverKeyKDFSalt);

- (NSData*)serverKeyKDFSalt NS_SWIFT_NAME(serverKeyKDFSalt());

@property (nonatomic,readonly,assign,getter=serverKeyKeyFormat) int serverKeyKeyFormat NS_SWIFT_NAME(serverKeyKeyFormat);

- (int)serverKeyKeyFormat NS_SWIFT_NAME(serverKeyKeyFormat());

@property (nonatomic,readonly,assign,getter=serverKeyKeyProtectionAlgorithm) NSString* serverKeyKeyProtectionAlgorithm NS_SWIFT_NAME(serverKeyKeyProtectionAlgorithm);

- (NSString*)serverKeyKeyProtectionAlgorithm NS_SWIFT_NAME(serverKeyKeyProtectionAlgorithm());

@property (nonatomic,readonly,assign,getter=serverKeyRSAExponent) NSData* serverKeyRSAExponent NS_SWIFT_NAME(serverKeyRSAExponent);

- (NSData*)serverKeyRSAExponent NS_SWIFT_NAME(serverKeyRSAExponent());

@property (nonatomic,readonly,assign,getter=serverKeyRSAIQMP) NSData* serverKeyRSAIQMP NS_SWIFT_NAME(serverKeyRSAIQMP);

- (NSData*)serverKeyRSAIQMP NS_SWIFT_NAME(serverKeyRSAIQMP());

@property (nonatomic,readonly,assign,getter=serverKeyRSAModulus) NSData* serverKeyRSAModulus NS_SWIFT_NAME(serverKeyRSAModulus);

- (NSData*)serverKeyRSAModulus NS_SWIFT_NAME(serverKeyRSAModulus());

@property (nonatomic,readonly,assign,getter=serverKeyRSAP) NSData* serverKeyRSAP NS_SWIFT_NAME(serverKeyRSAP);

- (NSData*)serverKeyRSAP NS_SWIFT_NAME(serverKeyRSAP());

@property (nonatomic,readonly,assign,getter=serverKeyRSAPrivateExponent) NSData* serverKeyRSAPrivateExponent NS_SWIFT_NAME(serverKeyRSAPrivateExponent);

- (NSData*)serverKeyRSAPrivateExponent NS_SWIFT_NAME(serverKeyRSAPrivateExponent());

@property (nonatomic,readonly,assign,getter=serverKeyRSAQ) NSData* serverKeyRSAQ NS_SWIFT_NAME(serverKeyRSAQ);

- (NSData*)serverKeyRSAQ NS_SWIFT_NAME(serverKeyRSAQ());

@property (nonatomic,readonly,assign,getter=serverKeySubject) NSString* serverKeySubject NS_SWIFT_NAME(serverKeySubject);

- (NSString*)serverKeySubject NS_SWIFT_NAME(serverKeySubject());

@property (nonatomic,readwrite,assign,getter=socketDNSMode,setter=setSocketDNSMode:) int socketDNSMode NS_SWIFT_NAME(socketDNSMode);

- (int)socketDNSMode NS_SWIFT_NAME(socketDNSMode());
- (void)setSocketDNSMode :(int)newSocketDNSMode NS_SWIFT_NAME(setSocketDNSMode(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSPort,setter=setSocketDNSPort:) int socketDNSPort NS_SWIFT_NAME(socketDNSPort);

- (int)socketDNSPort NS_SWIFT_NAME(socketDNSPort());
- (void)setSocketDNSPort :(int)newSocketDNSPort NS_SWIFT_NAME(setSocketDNSPort(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSQueryTimeout,setter=setSocketDNSQueryTimeout:) int socketDNSQueryTimeout NS_SWIFT_NAME(socketDNSQueryTimeout);

- (int)socketDNSQueryTimeout NS_SWIFT_NAME(socketDNSQueryTimeout());
- (void)setSocketDNSQueryTimeout :(int)newSocketDNSQueryTimeout NS_SWIFT_NAME(setSocketDNSQueryTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSServers,setter=setSocketDNSServers:) NSString* socketDNSServers NS_SWIFT_NAME(socketDNSServers);

- (NSString*)socketDNSServers NS_SWIFT_NAME(socketDNSServers());
- (void)setSocketDNSServers :(NSString*)newSocketDNSServers NS_SWIFT_NAME(setSocketDNSServers(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSTotalTimeout,setter=setSocketDNSTotalTimeout:) int socketDNSTotalTimeout NS_SWIFT_NAME(socketDNSTotalTimeout);

- (int)socketDNSTotalTimeout NS_SWIFT_NAME(socketDNSTotalTimeout());
- (void)setSocketDNSTotalTimeout :(int)newSocketDNSTotalTimeout NS_SWIFT_NAME(setSocketDNSTotalTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketIncomingSpeedLimit,setter=setSocketIncomingSpeedLimit:) int socketIncomingSpeedLimit NS_SWIFT_NAME(socketIncomingSpeedLimit);

- (int)socketIncomingSpeedLimit NS_SWIFT_NAME(socketIncomingSpeedLimit());
- (void)setSocketIncomingSpeedLimit :(int)newSocketIncomingSpeedLimit NS_SWIFT_NAME(setSocketIncomingSpeedLimit(_:));

@property (nonatomic,readwrite,assign,getter=socketLocalAddress,setter=setSocketLocalAddress:) NSString* socketLocalAddress NS_SWIFT_NAME(socketLocalAddress);

- (NSString*)socketLocalAddress NS_SWIFT_NAME(socketLocalAddress());
- (void)setSocketLocalAddress :(NSString*)newSocketLocalAddress NS_SWIFT_NAME(setSocketLocalAddress(_:));

@property (nonatomic,readwrite,assign,getter=socketLocalPort,setter=setSocketLocalPort:) int socketLocalPort NS_SWIFT_NAME(socketLocalPort);

- (int)socketLocalPort NS_SWIFT_NAME(socketLocalPort());
- (void)setSocketLocalPort :(int)newSocketLocalPort NS_SWIFT_NAME(setSocketLocalPort(_:));

@property (nonatomic,readwrite,assign,getter=socketOutgoingSpeedLimit,setter=setSocketOutgoingSpeedLimit:) int socketOutgoingSpeedLimit NS_SWIFT_NAME(socketOutgoingSpeedLimit);

- (int)socketOutgoingSpeedLimit NS_SWIFT_NAME(socketOutgoingSpeedLimit());
- (void)setSocketOutgoingSpeedLimit :(int)newSocketOutgoingSpeedLimit NS_SWIFT_NAME(setSocketOutgoingSpeedLimit(_:));

@property (nonatomic,readwrite,assign,getter=socketTimeout,setter=setSocketTimeout:) int socketTimeout NS_SWIFT_NAME(socketTimeout);

- (int)socketTimeout NS_SWIFT_NAME(socketTimeout());
- (void)setSocketTimeout :(int)newSocketTimeout NS_SWIFT_NAME(setSocketTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketUseIPv6,setter=setSocketUseIPv6:) BOOL socketUseIPv6 NS_SWIFT_NAME(socketUseIPv6);

- (BOOL)socketUseIPv6 NS_SWIFT_NAME(socketUseIPv6());
- (void)setSocketUseIPv6 :(BOOL)newSocketUseIPv6 NS_SWIFT_NAME(setSocketUseIPv6(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsAutoAdjustCiphers,setter=setSSHSettingsAutoAdjustCiphers:) BOOL SSHSettingsAutoAdjustCiphers NS_SWIFT_NAME(SSHSettingsAutoAdjustCiphers);

- (BOOL)SSHSettingsAutoAdjustCiphers NS_SWIFT_NAME(SSHSettingsAutoAdjustCiphers());
- (void)setSSHSettingsAutoAdjustCiphers :(BOOL)newSSHSettingsAutoAdjustCiphers NS_SWIFT_NAME(setSSHSettingsAutoAdjustCiphers(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsBaseConfiguration,setter=setSSHSettingsBaseConfiguration:) int SSHSettingsBaseConfiguration NS_SWIFT_NAME(SSHSettingsBaseConfiguration);

- (int)SSHSettingsBaseConfiguration NS_SWIFT_NAME(SSHSettingsBaseConfiguration());
- (void)setSSHSettingsBaseConfiguration :(int)newSSHSettingsBaseConfiguration NS_SWIFT_NAME(setSSHSettingsBaseConfiguration(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsCompressionAlgorithms,setter=setSSHSettingsCompressionAlgorithms:) NSString* SSHSettingsCompressionAlgorithms NS_SWIFT_NAME(SSHSettingsCompressionAlgorithms);

- (NSString*)SSHSettingsCompressionAlgorithms NS_SWIFT_NAME(SSHSettingsCompressionAlgorithms());
- (void)setSSHSettingsCompressionAlgorithms :(NSString*)newSSHSettingsCompressionAlgorithms NS_SWIFT_NAME(setSSHSettingsCompressionAlgorithms(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsCompressionLevel,setter=setSSHSettingsCompressionLevel:) int SSHSettingsCompressionLevel NS_SWIFT_NAME(SSHSettingsCompressionLevel);

- (int)SSHSettingsCompressionLevel NS_SWIFT_NAME(SSHSettingsCompressionLevel());
- (void)setSSHSettingsCompressionLevel :(int)newSSHSettingsCompressionLevel NS_SWIFT_NAME(setSSHSettingsCompressionLevel(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsDefaultWindowSize,setter=setSSHSettingsDefaultWindowSize:) int SSHSettingsDefaultWindowSize NS_SWIFT_NAME(SSHSettingsDefaultWindowSize);

- (int)SSHSettingsDefaultWindowSize NS_SWIFT_NAME(SSHSettingsDefaultWindowSize());
- (void)setSSHSettingsDefaultWindowSize :(int)newSSHSettingsDefaultWindowSize NS_SWIFT_NAME(setSSHSettingsDefaultWindowSize(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsEncryptionAlgorithms,setter=setSSHSettingsEncryptionAlgorithms:) NSString* SSHSettingsEncryptionAlgorithms NS_SWIFT_NAME(SSHSettingsEncryptionAlgorithms);

- (NSString*)SSHSettingsEncryptionAlgorithms NS_SWIFT_NAME(SSHSettingsEncryptionAlgorithms());
- (void)setSSHSettingsEncryptionAlgorithms :(NSString*)newSSHSettingsEncryptionAlgorithms NS_SWIFT_NAME(setSSHSettingsEncryptionAlgorithms(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsForceCompression,setter=setSSHSettingsForceCompression:) BOOL SSHSettingsForceCompression NS_SWIFT_NAME(SSHSettingsForceCompression);

- (BOOL)SSHSettingsForceCompression NS_SWIFT_NAME(SSHSettingsForceCompression());
- (void)setSSHSettingsForceCompression :(BOOL)newSSHSettingsForceCompression NS_SWIFT_NAME(setSSHSettingsForceCompression(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsForwardAuthAgent,setter=setSSHSettingsForwardAuthAgent:) BOOL SSHSettingsForwardAuthAgent NS_SWIFT_NAME(SSHSettingsForwardAuthAgent);

- (BOOL)SSHSettingsForwardAuthAgent NS_SWIFT_NAME(SSHSettingsForwardAuthAgent());
- (void)setSSHSettingsForwardAuthAgent :(BOOL)newSSHSettingsForwardAuthAgent NS_SWIFT_NAME(setSSHSettingsForwardAuthAgent(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsGSSAuthTypes,setter=setSSHSettingsGSSAuthTypes:) NSString* SSHSettingsGSSAuthTypes NS_SWIFT_NAME(SSHSettingsGSSAuthTypes);

- (NSString*)SSHSettingsGSSAuthTypes NS_SWIFT_NAME(SSHSettingsGSSAuthTypes());
- (void)setSSHSettingsGSSAuthTypes :(NSString*)newSSHSettingsGSSAuthTypes NS_SWIFT_NAME(setSSHSettingsGSSAuthTypes(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsGSSDelegateCreds,setter=setSSHSettingsGSSDelegateCreds:) BOOL SSHSettingsGSSDelegateCreds NS_SWIFT_NAME(SSHSettingsGSSDelegateCreds);

- (BOOL)SSHSettingsGSSDelegateCreds NS_SWIFT_NAME(SSHSettingsGSSDelegateCreds());
- (void)setSSHSettingsGSSDelegateCreds :(BOOL)newSSHSettingsGSSDelegateCreds NS_SWIFT_NAME(setSSHSettingsGSSDelegateCreds(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsGSSHostname,setter=setSSHSettingsGSSHostname:) NSString* SSHSettingsGSSHostname NS_SWIFT_NAME(SSHSettingsGSSHostname);

- (NSString*)SSHSettingsGSSHostname NS_SWIFT_NAME(SSHSettingsGSSHostname());
- (void)setSSHSettingsGSSHostname :(NSString*)newSSHSettingsGSSHostname NS_SWIFT_NAME(setSSHSettingsGSSHostname(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsGSSLib,setter=setSSHSettingsGSSLib:) NSString* SSHSettingsGSSLib NS_SWIFT_NAME(SSHSettingsGSSLib);

- (NSString*)SSHSettingsGSSLib NS_SWIFT_NAME(SSHSettingsGSSLib());
- (void)setSSHSettingsGSSLib :(NSString*)newSSHSettingsGSSLib NS_SWIFT_NAME(setSSHSettingsGSSLib(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsGSSMechanisms,setter=setSSHSettingsGSSMechanisms:) NSString* SSHSettingsGSSMechanisms NS_SWIFT_NAME(SSHSettingsGSSMechanisms);

- (NSString*)SSHSettingsGSSMechanisms NS_SWIFT_NAME(SSHSettingsGSSMechanisms());
- (void)setSSHSettingsGSSMechanisms :(NSString*)newSSHSettingsGSSMechanisms NS_SWIFT_NAME(setSSHSettingsGSSMechanisms(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsGSSProtocols,setter=setSSHSettingsGSSProtocols:) NSString* SSHSettingsGSSProtocols NS_SWIFT_NAME(SSHSettingsGSSProtocols);

- (NSString*)SSHSettingsGSSProtocols NS_SWIFT_NAME(SSHSettingsGSSProtocols());
- (void)setSSHSettingsGSSProtocols :(NSString*)newSSHSettingsGSSProtocols NS_SWIFT_NAME(setSSHSettingsGSSProtocols(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsHandshakeTimeout,setter=setSSHSettingsHandshakeTimeout:) int SSHSettingsHandshakeTimeout NS_SWIFT_NAME(SSHSettingsHandshakeTimeout);

- (int)SSHSettingsHandshakeTimeout NS_SWIFT_NAME(SSHSettingsHandshakeTimeout());
- (void)setSSHSettingsHandshakeTimeout :(int)newSSHSettingsHandshakeTimeout NS_SWIFT_NAME(setSSHSettingsHandshakeTimeout(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsKexAlgorithms,setter=setSSHSettingsKexAlgorithms:) NSString* SSHSettingsKexAlgorithms NS_SWIFT_NAME(SSHSettingsKexAlgorithms);

- (NSString*)SSHSettingsKexAlgorithms NS_SWIFT_NAME(SSHSettingsKexAlgorithms());
- (void)setSSHSettingsKexAlgorithms :(NSString*)newSSHSettingsKexAlgorithms NS_SWIFT_NAME(setSSHSettingsKexAlgorithms(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsMacAlgorithms,setter=setSSHSettingsMacAlgorithms:) NSString* SSHSettingsMacAlgorithms NS_SWIFT_NAME(SSHSettingsMacAlgorithms);

- (NSString*)SSHSettingsMacAlgorithms NS_SWIFT_NAME(SSHSettingsMacAlgorithms());
- (void)setSSHSettingsMacAlgorithms :(NSString*)newSSHSettingsMacAlgorithms NS_SWIFT_NAME(setSSHSettingsMacAlgorithms(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsMaxSSHPacketSize,setter=setSSHSettingsMaxSSHPacketSize:) int SSHSettingsMaxSSHPacketSize NS_SWIFT_NAME(SSHSettingsMaxSSHPacketSize);

- (int)SSHSettingsMaxSSHPacketSize NS_SWIFT_NAME(SSHSettingsMaxSSHPacketSize());
- (void)setSSHSettingsMaxSSHPacketSize :(int)newSSHSettingsMaxSSHPacketSize NS_SWIFT_NAME(setSSHSettingsMaxSSHPacketSize(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsMinWindowSize,setter=setSSHSettingsMinWindowSize:) int SSHSettingsMinWindowSize NS_SWIFT_NAME(SSHSettingsMinWindowSize);

- (int)SSHSettingsMinWindowSize NS_SWIFT_NAME(SSHSettingsMinWindowSize());
- (void)setSSHSettingsMinWindowSize :(int)newSSHSettingsMinWindowSize NS_SWIFT_NAME(setSSHSettingsMinWindowSize(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsObfuscateHandshake,setter=setSSHSettingsObfuscateHandshake:) BOOL SSHSettingsObfuscateHandshake NS_SWIFT_NAME(SSHSettingsObfuscateHandshake);

- (BOOL)SSHSettingsObfuscateHandshake NS_SWIFT_NAME(SSHSettingsObfuscateHandshake());
- (void)setSSHSettingsObfuscateHandshake :(BOOL)newSSHSettingsObfuscateHandshake NS_SWIFT_NAME(setSSHSettingsObfuscateHandshake(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsObfuscationPassword,setter=setSSHSettingsObfuscationPassword:) NSString* SSHSettingsObfuscationPassword NS_SWIFT_NAME(SSHSettingsObfuscationPassword);

- (NSString*)SSHSettingsObfuscationPassword NS_SWIFT_NAME(SSHSettingsObfuscationPassword());
- (void)setSSHSettingsObfuscationPassword :(NSString*)newSSHSettingsObfuscationPassword NS_SWIFT_NAME(setSSHSettingsObfuscationPassword(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsPublicKeyAlgorithms,setter=setSSHSettingsPublicKeyAlgorithms:) NSString* SSHSettingsPublicKeyAlgorithms NS_SWIFT_NAME(SSHSettingsPublicKeyAlgorithms);

- (NSString*)SSHSettingsPublicKeyAlgorithms NS_SWIFT_NAME(SSHSettingsPublicKeyAlgorithms());
- (void)setSSHSettingsPublicKeyAlgorithms :(NSString*)newSSHSettingsPublicKeyAlgorithms NS_SWIFT_NAME(setSSHSettingsPublicKeyAlgorithms(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsRequestPasswordChange,setter=setSSHSettingsRequestPasswordChange:) BOOL SSHSettingsRequestPasswordChange NS_SWIFT_NAME(SSHSettingsRequestPasswordChange);

- (BOOL)SSHSettingsRequestPasswordChange NS_SWIFT_NAME(SSHSettingsRequestPasswordChange());
- (void)setSSHSettingsRequestPasswordChange :(BOOL)newSSHSettingsRequestPasswordChange NS_SWIFT_NAME(setSSHSettingsRequestPasswordChange(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsSoftwareName,setter=setSSHSettingsSoftwareName:) NSString* SSHSettingsSoftwareName NS_SWIFT_NAME(SSHSettingsSoftwareName);

- (NSString*)SSHSettingsSoftwareName NS_SWIFT_NAME(SSHSettingsSoftwareName());
- (void)setSSHSettingsSoftwareName :(NSString*)newSSHSettingsSoftwareName NS_SWIFT_NAME(setSSHSettingsSoftwareName(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsTrustAllKeys,setter=setSSHSettingsTrustAllKeys:) BOOL SSHSettingsTrustAllKeys NS_SWIFT_NAME(SSHSettingsTrustAllKeys);

- (BOOL)SSHSettingsTrustAllKeys NS_SWIFT_NAME(SSHSettingsTrustAllKeys());
- (void)setSSHSettingsTrustAllKeys :(BOOL)newSSHSettingsTrustAllKeys NS_SWIFT_NAME(setSSHSettingsTrustAllKeys(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsUseAuthAgent,setter=setSSHSettingsUseAuthAgent:) BOOL SSHSettingsUseAuthAgent NS_SWIFT_NAME(SSHSettingsUseAuthAgent);

- (BOOL)SSHSettingsUseAuthAgent NS_SWIFT_NAME(SSHSettingsUseAuthAgent());
- (void)setSSHSettingsUseAuthAgent :(BOOL)newSSHSettingsUseAuthAgent NS_SWIFT_NAME(setSSHSettingsUseAuthAgent(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsVersions,setter=setSSHSettingsVersions:) int SSHSettingsVersions NS_SWIFT_NAME(SSHSettingsVersions);

- (int)SSHSettingsVersions NS_SWIFT_NAME(SSHSettingsVersions());
- (void)setSSHSettingsVersions :(int)newSSHSettingsVersions NS_SWIFT_NAME(setSSHSettingsVersions(_:));

@property (nonatomic,readwrite,assign,getter=trustedKeysFile,setter=setTrustedKeysFile:) NSString* trustedKeysFile NS_SWIFT_NAME(trustedKeysFile);

- (NSString*)trustedKeysFile NS_SWIFT_NAME(trustedKeysFile());
- (void)setTrustedKeysFile :(NSString*)newTrustedKeysFile NS_SWIFT_NAME(setTrustedKeysFile(_:));

@property (nonatomic,readwrite,assign,getter=uploadBlockSize,setter=setUploadBlockSize:) int uploadBlockSize NS_SWIFT_NAME(uploadBlockSize);

- (int)uploadBlockSize NS_SWIFT_NAME(uploadBlockSize());
- (void)setUploadBlockSize :(int)newUploadBlockSize NS_SWIFT_NAME(setUploadBlockSize(_:));

@property (nonatomic,readwrite,assign,getter=username,setter=setUsername:) NSString* username NS_SWIFT_NAME(username);

- (NSString*)username NS_SWIFT_NAME(username());
- (void)setUsername :(NSString*)newUsername NS_SWIFT_NAME(setUsername(_:));

@property (nonatomic,readwrite,assign,getter=useUTF8,setter=setUseUTF8:) BOOL useUTF8 NS_SWIFT_NAME(useUTF8);

- (BOOL)useUTF8 NS_SWIFT_NAME(useUTF8());
- (void)setUseUTF8 :(BOOL)newUseUTF8 NS_SWIFT_NAME(setUseUTF8(_:));

@property (nonatomic,readonly,assign,getter=version) int version NS_SWIFT_NAME(version);

- (int)version NS_SWIFT_NAME(version());

  /* Methods */

- (NSString*)absolutePath:(NSString*)remotePath NS_SWIFT_NAME(absolutePath(_:));

- (void)changeDir:(NSString*)remoteDir NS_SWIFT_NAME(changeDir(_:));

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (void)connect:(NSString*)address :(int)port NS_SWIFT_NAME(connect(_:_:));

- (void)createLink:(NSString*)linkPath :(NSString*)targetPath :(BOOL)hardLink NS_SWIFT_NAME(createLink(_:_:_:));

- (void)deleteDir:(NSString*)remoteDir NS_SWIFT_NAME(deleteDir(_:));

- (void)deleteFile:(NSString*)remoteFile NS_SWIFT_NAME(deleteFile(_:));

- (void)deleteFiles:(NSString*)remotePath :(NSString*)mask :(BOOL)caseSensitive :(BOOL)recursive :(int)errorHandling NS_SWIFT_NAME(deleteFiles(_:_:_:_:_:));

- (BOOL)dirExists:(NSString*)remoteDir NS_SWIFT_NAME(dirExists(_:));

- (void)disconnect NS_SWIFT_NAME(disconnect());

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (NSData*)downloadBytes:(NSString*)remoteFile NS_SWIFT_NAME(downloadBytes(_:));

- (void)downloadFile:(NSString*)remoteFile :(NSString*)localFile NS_SWIFT_NAME(downloadFile(_:_:));

- (void)downloadFiles:(NSString*)remotePath :(NSString*)localDir :(BOOL)recursive :(int)errorHandling NS_SWIFT_NAME(downloadFiles(_:_:_:_:));

- (NSData*)executeSSHCommand:(NSString*)command NS_SWIFT_NAME(executeSSHCommand(_:));

- (NSData*)extensionCmd:(NSString*)extn :(NSData*)dataBuffer NS_SWIFT_NAME(extensionCmd(_:_:));

- (BOOL)fileExists:(NSString*)remoteFile NS_SWIFT_NAME(fileExists(_:));

- (NSString*)getCurrentDir NS_SWIFT_NAME(getCurrentDir());

- (long long)getFileSize:(NSString*)remoteFile NS_SWIFT_NAME(getFileSize(_:));

- (NSString*)listDir:(BOOL)includeFiles :(BOOL)includeDirectories NS_SWIFT_NAME(listDir(_:_:));

- (void)makeDir:(NSString*)remoteDir NS_SWIFT_NAME(makeDir(_:));

- (void)renameFile:(NSString*)sourceFile :(NSString*)destFile NS_SWIFT_NAME(renameFile(_:_:));

- (NSString*)requestAttributes:(NSString*)remotePath :(BOOL)followSymLinks NS_SWIFT_NAME(requestAttributes(_:_:));

- (void)reset NS_SWIFT_NAME(reset());

- (void)setAttributes:(NSString*)remotePath :(NSString*)attributes NS_SWIFT_NAME(setAttributes(_:_:));

- (void)uploadBytes:(NSData*)bytes :(NSString*)remoteFile NS_SWIFT_NAME(uploadBytes(_:_:));

- (void)uploadFile:(NSString*)localFile :(NSString*)remoteFile NS_SWIFT_NAME(uploadFile(_:_:));

- (void)uploadFiles:(NSString*)localPath :(NSString*)remoteDir :(BOOL)recursive :(int)errorHandling NS_SWIFT_NAME(uploadFiles(_:_:_:_:));

@end

