/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//FTPFILEFORMATS
#define CFEF_UNKNOWN                                       0

#define CFEF_UNIX                                          1

#define CFEF_WINDOWS                                       2

#define CFEF_MLSD                                          3

//FTPFILETYPES
#define FET_UNKNOWN                                        0

#define FET_DIRECTORY                                      1

#define FET_FILE                                           2

#define FET_SYMLINK                                        3

#define FET_SPECIAL                                        4

#define FET_CURRENT_DIRECTORY                              5

#define FET_PARENT_DIRECTORY                               6

#define FET_SOCKET                                         7

#define FET_CHAR_DEVICE                                    8

#define FET_BLOCK_DEVICE                                   9

#define FET_FIFO                                           10

//ASYNCSIGNMETHODS
#define ASMD_PKCS1                                         0

#define ASMD_PKCS7                                         1

//EXTERNALCRYPTOMODES
#define ECM_DEFAULT                                        0

#define ECM_DISABLED                                       1

#define ECM_GENERIC                                        2

#define ECM_DCAUTH                                         3

#define ECM_DCAUTH_JSON                                    4

//SSHKEYFORMATS
#define CKF_OPEN_SSH                                       0

#define CKF_OPEN_SSH2                                      1

#define CKF_IETF                                           2

#define CKF_PU_TTY                                         3

#define CKF_X509                                           4

#define CKF_BINARY                                         5

#define CKF_SSH1                                           6

#define CKF_PGP                                            7

#define CKF_PKCS8                                          8

#define CKF_PU_TTY3                                        9

//DNSRESOLVEMODES
#define DM_AUTO                                            0

#define DM_PLATFORM                                        1

#define DM_OWN                                             2

#define DM_OWN_SECURE                                      3

//SECURETRANSPORTPREDEFINEDCONFIGURATIONS
#define STPC_DEFAULT                                       0

#define STPC_COMPATIBLE                                    1

#define STPC_COMPREHENSIVE_INSECURE                        2

#define STPC_HIGHLY_SECURE                                 3

//OTPALGORITHMS
#define OA_NONE                                            0

#define OA_HMAC                                            1

#define OA_TIME                                            2

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxSFTPServerDelegate <NSObject>
@optional
- (void)onAccept:(NSString*)remoteAddress :(int)remotePort :(int*)accept NS_SWIFT_NAME(onAccept(_:_:_:));

- (void)onAfterCreateDirectory:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterCreateDirectory(_:_:_:));

- (void)onAfterRemove:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterRemove(_:_:_:));

- (void)onAfterRenameFile:(long long)connectionID :(NSString*)oldPath :(NSString*)newPath :(int*)operationStatus NS_SWIFT_NAME(onAfterRenameFile(_:_:_:_:));

- (void)onAfterRequestAttributes:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterRequestAttributes(_:_:_:));

- (void)onAfterSetAttributes:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterSetAttributes(_:_:_:));

- (void)onAuthAttempt:(long long)connectionID :(NSString*)username :(int)authType :(int*)accept NS_SWIFT_NAME(onAuthAttempt(_:_:_:_:));

- (void)onAuthFailed:(long long)connectionID :(NSString*)username :(int)authType NS_SWIFT_NAME(onAuthFailed(_:_:_:));

- (void)onAuthPassword:(long long)connectionID :(NSString*)username :(NSString*)password :(int*)accept :(int*)forceChangePassword NS_SWIFT_NAME(onAuthPassword(_:_:_:_:_:));

- (void)onAuthPublicKey:(long long)connectionID :(NSString*)username :(int*)accept NS_SWIFT_NAME(onAuthPublicKey(_:_:_:));

- (void)onAuthSucceeded:(long long)connectionID :(NSString*)username :(int)authType NS_SWIFT_NAME(onAuthSucceeded(_:_:_:));

- (void)onBeforeCreateDirectory:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeCreateDirectory(_:_:_:));

- (void)onBeforeDownloadFile:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeDownloadFile(_:_:_:));

- (void)onBeforeFind:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeFind(_:_:_:));

- (void)onBeforeOpenClientForwarding:(long long)connectionID :(NSString**)destHost :(int*)destPort :(NSString*)srcHost :(int)srcPort :(int*)action NS_SWIFT_NAME(onBeforeOpenClientForwarding(_:_:_:_:_:_:));

- (void)onBeforeOpenCommand:(long long)connectionID :(NSString**)command :(int*)action NS_SWIFT_NAME(onBeforeOpenCommand(_:_:_:));

- (void)onBeforeOpenServerForwarding:(long long)connectionID :(NSString*)localHost :(int)localPort :(NSString*)srcHost :(int)srcPort :(int*)action NS_SWIFT_NAME(onBeforeOpenServerForwarding(_:_:_:_:_:_:));

- (void)onBeforeOpenShell:(long long)connectionID :(int*)action NS_SWIFT_NAME(onBeforeOpenShell(_:_:));

- (void)onBeforeRemove:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeRemove(_:_:_:));

- (void)onBeforeRenameFile:(long long)connectionID :(NSString*)oldPath :(NSString*)newPath :(int*)action NS_SWIFT_NAME(onBeforeRenameFile(_:_:_:_:));

- (void)onBeforeRequestAttributes:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeRequestAttributes(_:_:_:));

- (void)onBeforeSetAttributes:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeSetAttributes(_:_:_:));

- (void)onBeforeUploadFile:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeUploadFile(_:_:_:));

- (void)onCloseClientForwarding:(long long)connectionID :(NSString*)destHost :(int)destPort :(NSString*)srcHost :(int)srcPort NS_SWIFT_NAME(onCloseClientForwarding(_:_:_:_:_:));

- (void)onCloseCommand:(long long)connectionID :(NSString*)command NS_SWIFT_NAME(onCloseCommand(_:_:));

- (void)onCloseFile:(long long)connectionID :(NSString*)handle :(int*)operationStatus NS_SWIFT_NAME(onCloseFile(_:_:_:));

- (void)onCloseServerForwarding:(long long)connectionID :(NSString*)localHost :(int)localPort :(NSString*)srcHost :(int)srcPort NS_SWIFT_NAME(onCloseServerForwarding(_:_:_:_:_:));

- (void)onCloseShell:(long long)connectionID NS_SWIFT_NAME(onCloseShell(_:));

- (void)onConnect:(long long)connectionID :(NSString*)remoteAddress :(int)remotePort NS_SWIFT_NAME(onConnect(_:_:_:));

- (void)onCreateDirectory:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onCreateDirectory(_:_:_:));

- (void)onDisconnect:(long long)connectionID NS_SWIFT_NAME(onDisconnect(_:));

- (void)onError:(long long)connectionID :(int)errorCode :(BOOL)fatal :(BOOL)remote :(NSString*)description NS_SWIFT_NAME(onError(_:_:_:_:_:));

- (void)onExternalSign:(long long)connectionID :(NSString*)operationId :(NSString*)hashAlgorithm :(NSString*)pars :(NSString*)data :(NSString**)signedData NS_SWIFT_NAME(onExternalSign(_:_:_:_:_:_:));

- (void)onFindClose:(long long)connectionID :(NSString*)handle :(int*)operationStatus NS_SWIFT_NAME(onFindClose(_:_:_:));

- (void)onFindFirst:(long long)connectionID :(NSString*)path :(int*)operationStatus :(NSString**)handle NS_SWIFT_NAME(onFindFirst(_:_:_:_:));

- (void)onFindNext:(long long)connectionID :(NSString*)handle :(int*)operationStatus NS_SWIFT_NAME(onFindNext(_:_:_:));

- (void)onListeningStarted:(NSString*)host :(int)port NS_SWIFT_NAME(onListeningStarted(_:_:));

- (void)onListeningStopped:(NSString*)host :(int)port NS_SWIFT_NAME(onListeningStopped(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onOpenClientForwarding:(long long)connectionID :(NSString*)destHost :(int)destPort :(NSString*)srcHost :(int)srcPort NS_SWIFT_NAME(onOpenClientForwarding(_:_:_:_:_:));

- (void)onOpenCommand:(long long)connectionID :(NSString*)command NS_SWIFT_NAME(onOpenCommand(_:_:));

- (void)onOpenFile:(long long)connectionID :(NSString*)path :(int)modes :(int)access :(int*)operationStatus :(NSString**)handle NS_SWIFT_NAME(onOpenFile(_:_:_:_:_:_:));

- (void)onOpenServerForwarding:(long long)connectionID :(NSString*)localHost :(int)localPort :(NSString*)srcHost :(int)srcPort NS_SWIFT_NAME(onOpenServerForwarding(_:_:_:_:_:));

- (void)onOpenShell:(long long)connectionID NS_SWIFT_NAME(onOpenShell(_:));

- (void)onReadFile:(long long)connectionID :(NSString*)handle :(long long)offset :(int)size :(int*)operationStatus NS_SWIFT_NAME(onReadFile(_:_:_:_:_:));

- (void)onRemove:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onRemove(_:_:_:));

- (void)onRenameFile:(long long)connectionID :(NSString*)oldPath :(NSString*)newPath :(int*)operationStatus NS_SWIFT_NAME(onRenameFile(_:_:_:_:));

- (void)onRequestAttributes:(long long)connectionID :(NSString*)path :(NSString*)handle :(int*)operationStatus NS_SWIFT_NAME(onRequestAttributes(_:_:_:_:));

- (void)onServerForwardingCancel:(long long)connectionID :(NSString*)localHost :(int)localPort NS_SWIFT_NAME(onServerForwardingCancel(_:_:_:));

- (void)onServerForwardingOpenFailed:(long long)connectionID :(NSString*)localHost :(int)localPort :(NSString*)srcHost :(int)srcPort NS_SWIFT_NAME(onServerForwardingOpenFailed(_:_:_:_:_:));

- (void)onServerForwardingRequest:(long long)connectionID :(NSString*)localHost :(int*)localPort :(int*)action NS_SWIFT_NAME(onServerForwardingRequest(_:_:_:_:));

- (void)onSessionClosed:(long long)connectionID NS_SWIFT_NAME(onSessionClosed(_:));

- (void)onSessionEstablished:(long long)connectionID NS_SWIFT_NAME(onSessionEstablished(_:));

- (void)onSetAttributes:(long long)connectionID :(NSString*)path :(NSString*)handle :(int*)operationStatus NS_SWIFT_NAME(onSetAttributes(_:_:_:_:));

- (void)onTranslatePath:(long long)connectionID :(NSString*)path :(NSString**)absolutePath :(int*)action NS_SWIFT_NAME(onTranslatePath(_:_:_:_:));

- (void)onWriteFile:(long long)connectionID :(NSString*)handle :(long long)offset :(int*)operationStatus NS_SWIFT_NAME(onWriteFile(_:_:_:_:));

@end

@interface SecureBlackboxSFTPServer : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxSFTPServerDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasAccept;

  BOOL m_delegateHasAfterCreateDirectory;

  BOOL m_delegateHasAfterRemove;

  BOOL m_delegateHasAfterRenameFile;

  BOOL m_delegateHasAfterRequestAttributes;

  BOOL m_delegateHasAfterSetAttributes;

  BOOL m_delegateHasAuthAttempt;

  BOOL m_delegateHasAuthFailed;

  BOOL m_delegateHasAuthPassword;

  BOOL m_delegateHasAuthPublicKey;

  BOOL m_delegateHasAuthSucceeded;

  BOOL m_delegateHasBeforeCreateDirectory;

  BOOL m_delegateHasBeforeDownloadFile;

  BOOL m_delegateHasBeforeFind;

  BOOL m_delegateHasBeforeOpenClientForwarding;

  BOOL m_delegateHasBeforeOpenCommand;

  BOOL m_delegateHasBeforeOpenServerForwarding;

  BOOL m_delegateHasBeforeOpenShell;

  BOOL m_delegateHasBeforeRemove;

  BOOL m_delegateHasBeforeRenameFile;

  BOOL m_delegateHasBeforeRequestAttributes;

  BOOL m_delegateHasBeforeSetAttributes;

  BOOL m_delegateHasBeforeUploadFile;

  BOOL m_delegateHasCloseClientForwarding;

  BOOL m_delegateHasCloseCommand;

  BOOL m_delegateHasCloseFile;

  BOOL m_delegateHasCloseServerForwarding;

  BOOL m_delegateHasCloseShell;

  BOOL m_delegateHasConnect;

  BOOL m_delegateHasCreateDirectory;

  BOOL m_delegateHasDisconnect;

  BOOL m_delegateHasError;

  BOOL m_delegateHasExternalSign;

  BOOL m_delegateHasFindClose;

  BOOL m_delegateHasFindFirst;

  BOOL m_delegateHasFindNext;

  BOOL m_delegateHasListeningStarted;

  BOOL m_delegateHasListeningStopped;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasOpenClientForwarding;

  BOOL m_delegateHasOpenCommand;

  BOOL m_delegateHasOpenFile;

  BOOL m_delegateHasOpenServerForwarding;

  BOOL m_delegateHasOpenShell;

  BOOL m_delegateHasReadFile;

  BOOL m_delegateHasRemove;

  BOOL m_delegateHasRenameFile;

  BOOL m_delegateHasRequestAttributes;

  BOOL m_delegateHasServerForwardingCancel;

  BOOL m_delegateHasServerForwardingOpenFailed;

  BOOL m_delegateHasServerForwardingRequest;

  BOOL m_delegateHasSessionClosed;

  BOOL m_delegateHasSessionEstablished;

  BOOL m_delegateHasSetAttributes;

  BOOL m_delegateHasTranslatePath;

  BOOL m_delegateHasWriteFile;

}

+ (SecureBlackboxSFTPServer*)sftpserver;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxSFTPServerDelegate> delegate;
- (id <SecureBlackboxSFTPServerDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxSFTPServerDelegate>)anObject;

  /* Events */

- (void)onAccept:(NSString*)remoteAddress :(int)remotePort :(int*)accept NS_SWIFT_NAME(onAccept(_:_:_:));

- (void)onAfterCreateDirectory:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterCreateDirectory(_:_:_:));

- (void)onAfterRemove:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterRemove(_:_:_:));

- (void)onAfterRenameFile:(long long)connectionID :(NSString*)oldPath :(NSString*)newPath :(int*)operationStatus NS_SWIFT_NAME(onAfterRenameFile(_:_:_:_:));

- (void)onAfterRequestAttributes:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterRequestAttributes(_:_:_:));

- (void)onAfterSetAttributes:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterSetAttributes(_:_:_:));

- (void)onAuthAttempt:(long long)connectionID :(NSString*)username :(int)authType :(int*)accept NS_SWIFT_NAME(onAuthAttempt(_:_:_:_:));

- (void)onAuthFailed:(long long)connectionID :(NSString*)username :(int)authType NS_SWIFT_NAME(onAuthFailed(_:_:_:));

- (void)onAuthPassword:(long long)connectionID :(NSString*)username :(NSString*)password :(int*)accept :(int*)forceChangePassword NS_SWIFT_NAME(onAuthPassword(_:_:_:_:_:));

- (void)onAuthPublicKey:(long long)connectionID :(NSString*)username :(int*)accept NS_SWIFT_NAME(onAuthPublicKey(_:_:_:));

- (void)onAuthSucceeded:(long long)connectionID :(NSString*)username :(int)authType NS_SWIFT_NAME(onAuthSucceeded(_:_:_:));

- (void)onBeforeCreateDirectory:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeCreateDirectory(_:_:_:));

- (void)onBeforeDownloadFile:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeDownloadFile(_:_:_:));

- (void)onBeforeFind:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeFind(_:_:_:));

- (void)onBeforeOpenClientForwarding:(long long)connectionID :(NSString**)destHost :(int*)destPort :(NSString*)srcHost :(int)srcPort :(int*)action NS_SWIFT_NAME(onBeforeOpenClientForwarding(_:_:_:_:_:_:));

- (void)onBeforeOpenCommand:(long long)connectionID :(NSString**)command :(int*)action NS_SWIFT_NAME(onBeforeOpenCommand(_:_:_:));

- (void)onBeforeOpenServerForwarding:(long long)connectionID :(NSString*)localHost :(int)localPort :(NSString*)srcHost :(int)srcPort :(int*)action NS_SWIFT_NAME(onBeforeOpenServerForwarding(_:_:_:_:_:_:));

- (void)onBeforeOpenShell:(long long)connectionID :(int*)action NS_SWIFT_NAME(onBeforeOpenShell(_:_:));

- (void)onBeforeRemove:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeRemove(_:_:_:));

- (void)onBeforeRenameFile:(long long)connectionID :(NSString*)oldPath :(NSString*)newPath :(int*)action NS_SWIFT_NAME(onBeforeRenameFile(_:_:_:_:));

- (void)onBeforeRequestAttributes:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeRequestAttributes(_:_:_:));

- (void)onBeforeSetAttributes:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeSetAttributes(_:_:_:));

- (void)onBeforeUploadFile:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeUploadFile(_:_:_:));

- (void)onCloseClientForwarding:(long long)connectionID :(NSString*)destHost :(int)destPort :(NSString*)srcHost :(int)srcPort NS_SWIFT_NAME(onCloseClientForwarding(_:_:_:_:_:));

- (void)onCloseCommand:(long long)connectionID :(NSString*)command NS_SWIFT_NAME(onCloseCommand(_:_:));

- (void)onCloseFile:(long long)connectionID :(NSString*)handle :(int*)operationStatus NS_SWIFT_NAME(onCloseFile(_:_:_:));

- (void)onCloseServerForwarding:(long long)connectionID :(NSString*)localHost :(int)localPort :(NSString*)srcHost :(int)srcPort NS_SWIFT_NAME(onCloseServerForwarding(_:_:_:_:_:));

- (void)onCloseShell:(long long)connectionID NS_SWIFT_NAME(onCloseShell(_:));

- (void)onConnect:(long long)connectionID :(NSString*)remoteAddress :(int)remotePort NS_SWIFT_NAME(onConnect(_:_:_:));

- (void)onCreateDirectory:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onCreateDirectory(_:_:_:));

- (void)onDisconnect:(long long)connectionID NS_SWIFT_NAME(onDisconnect(_:));

- (void)onError:(long long)connectionID :(int)errorCode :(BOOL)fatal :(BOOL)remote :(NSString*)description NS_SWIFT_NAME(onError(_:_:_:_:_:));

- (void)onExternalSign:(long long)connectionID :(NSString*)operationId :(NSString*)hashAlgorithm :(NSString*)pars :(NSString*)data :(NSString**)signedData NS_SWIFT_NAME(onExternalSign(_:_:_:_:_:_:));

- (void)onFindClose:(long long)connectionID :(NSString*)handle :(int*)operationStatus NS_SWIFT_NAME(onFindClose(_:_:_:));

- (void)onFindFirst:(long long)connectionID :(NSString*)path :(int*)operationStatus :(NSString**)handle NS_SWIFT_NAME(onFindFirst(_:_:_:_:));

- (void)onFindNext:(long long)connectionID :(NSString*)handle :(int*)operationStatus NS_SWIFT_NAME(onFindNext(_:_:_:));

- (void)onListeningStarted:(NSString*)host :(int)port NS_SWIFT_NAME(onListeningStarted(_:_:));

- (void)onListeningStopped:(NSString*)host :(int)port NS_SWIFT_NAME(onListeningStopped(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onOpenClientForwarding:(long long)connectionID :(NSString*)destHost :(int)destPort :(NSString*)srcHost :(int)srcPort NS_SWIFT_NAME(onOpenClientForwarding(_:_:_:_:_:));

- (void)onOpenCommand:(long long)connectionID :(NSString*)command NS_SWIFT_NAME(onOpenCommand(_:_:));

- (void)onOpenFile:(long long)connectionID :(NSString*)path :(int)modes :(int)access :(int*)operationStatus :(NSString**)handle NS_SWIFT_NAME(onOpenFile(_:_:_:_:_:_:));

- (void)onOpenServerForwarding:(long long)connectionID :(NSString*)localHost :(int)localPort :(NSString*)srcHost :(int)srcPort NS_SWIFT_NAME(onOpenServerForwarding(_:_:_:_:_:));

- (void)onOpenShell:(long long)connectionID NS_SWIFT_NAME(onOpenShell(_:));

- (void)onReadFile:(long long)connectionID :(NSString*)handle :(long long)offset :(int)size :(int*)operationStatus NS_SWIFT_NAME(onReadFile(_:_:_:_:_:));

- (void)onRemove:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onRemove(_:_:_:));

- (void)onRenameFile:(long long)connectionID :(NSString*)oldPath :(NSString*)newPath :(int*)operationStatus NS_SWIFT_NAME(onRenameFile(_:_:_:_:));

- (void)onRequestAttributes:(long long)connectionID :(NSString*)path :(NSString*)handle :(int*)operationStatus NS_SWIFT_NAME(onRequestAttributes(_:_:_:_:));

- (void)onServerForwardingCancel:(long long)connectionID :(NSString*)localHost :(int)localPort NS_SWIFT_NAME(onServerForwardingCancel(_:_:_:));

- (void)onServerForwardingOpenFailed:(long long)connectionID :(NSString*)localHost :(int)localPort :(NSString*)srcHost :(int)srcPort NS_SWIFT_NAME(onServerForwardingOpenFailed(_:_:_:_:_:));

- (void)onServerForwardingRequest:(long long)connectionID :(NSString*)localHost :(int*)localPort :(int*)action NS_SWIFT_NAME(onServerForwardingRequest(_:_:_:_:));

- (void)onSessionClosed:(long long)connectionID NS_SWIFT_NAME(onSessionClosed(_:));

- (void)onSessionEstablished:(long long)connectionID NS_SWIFT_NAME(onSessionEstablished(_:));

- (void)onSetAttributes:(long long)connectionID :(NSString*)path :(NSString*)handle :(int*)operationStatus NS_SWIFT_NAME(onSetAttributes(_:_:_:_:));

- (void)onTranslatePath:(long long)connectionID :(NSString*)path :(NSString**)absolutePath :(int*)action NS_SWIFT_NAME(onTranslatePath(_:_:_:_:));

- (void)onWriteFile:(long long)connectionID :(NSString*)handle :(long long)offset :(int*)operationStatus NS_SWIFT_NAME(onWriteFile(_:_:_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readonly,assign,getter=active) BOOL active NS_SWIFT_NAME(active);

- (BOOL)active NS_SWIFT_NAME(active());

@property (nonatomic,readwrite,assign,getter=authTypes,setter=setAuthTypes:) int authTypes NS_SWIFT_NAME(authTypes);

- (int)authTypes NS_SWIFT_NAME(authTypes());
- (void)setAuthTypes :(int)newAuthTypes NS_SWIFT_NAME(setAuthTypes(_:));

@property (nonatomic,readwrite,assign,getter=baseDir,setter=setBaseDir:) NSString* baseDir NS_SWIFT_NAME(baseDir);

- (NSString*)baseDir NS_SWIFT_NAME(baseDir());
- (void)setBaseDir :(NSString*)newBaseDir NS_SWIFT_NAME(setBaseDir(_:));

@property (nonatomic,readwrite,assign,getter=capabilities,setter=setCapabilities:) int capabilities NS_SWIFT_NAME(capabilities);

- (int)capabilities NS_SWIFT_NAME(capabilities());
- (void)setCapabilities :(int)newCapabilities NS_SWIFT_NAME(setCapabilities(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntryAccessTime,setter=setClientFileEntryAccessTime:) NSString* clientFileEntryAccessTime NS_SWIFT_NAME(clientFileEntryAccessTime);

- (NSString*)clientFileEntryAccessTime NS_SWIFT_NAME(clientFileEntryAccessTime());
- (void)setClientFileEntryAccessTime :(NSString*)newClientFileEntryAccessTime NS_SWIFT_NAME(setClientFileEntryAccessTime(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntryCreationTime,setter=setClientFileEntryCreationTime:) NSString* clientFileEntryCreationTime NS_SWIFT_NAME(clientFileEntryCreationTime);

- (NSString*)clientFileEntryCreationTime NS_SWIFT_NAME(clientFileEntryCreationTime());
- (void)setClientFileEntryCreationTime :(NSString*)newClientFileEntryCreationTime NS_SWIFT_NAME(setClientFileEntryCreationTime(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntryEntryFormat,setter=setClientFileEntryEntryFormat:) int clientFileEntryEntryFormat NS_SWIFT_NAME(clientFileEntryEntryFormat);

- (int)clientFileEntryEntryFormat NS_SWIFT_NAME(clientFileEntryEntryFormat());
- (void)setClientFileEntryEntryFormat :(int)newClientFileEntryEntryFormat NS_SWIFT_NAME(setClientFileEntryEntryFormat(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntryFileType,setter=setClientFileEntryFileType:) int clientFileEntryFileType NS_SWIFT_NAME(clientFileEntryFileType);

- (int)clientFileEntryFileType NS_SWIFT_NAME(clientFileEntryFileType());
- (void)setClientFileEntryFileType :(int)newClientFileEntryFileType NS_SWIFT_NAME(setClientFileEntryFileType(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntryHandle,setter=setClientFileEntryHandle:) long long clientFileEntryHandle NS_SWIFT_NAME(clientFileEntryHandle);

- (long long)clientFileEntryHandle NS_SWIFT_NAME(clientFileEntryHandle());
- (void)setClientFileEntryHandle :(long long)newClientFileEntryHandle NS_SWIFT_NAME(setClientFileEntryHandle(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntryModificationTime,setter=setClientFileEntryModificationTime:) NSString* clientFileEntryModificationTime NS_SWIFT_NAME(clientFileEntryModificationTime);

- (NSString*)clientFileEntryModificationTime NS_SWIFT_NAME(clientFileEntryModificationTime());
- (void)setClientFileEntryModificationTime :(NSString*)newClientFileEntryModificationTime NS_SWIFT_NAME(setClientFileEntryModificationTime(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntryName,setter=setClientFileEntryName:) NSString* clientFileEntryName NS_SWIFT_NAME(clientFileEntryName);

- (NSString*)clientFileEntryName NS_SWIFT_NAME(clientFileEntryName());
- (void)setClientFileEntryName :(NSString*)newClientFileEntryName NS_SWIFT_NAME(setClientFileEntryName(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntryPath,setter=setClientFileEntryPath:) NSString* clientFileEntryPath NS_SWIFT_NAME(clientFileEntryPath);

- (NSString*)clientFileEntryPath NS_SWIFT_NAME(clientFileEntryPath());
- (void)setClientFileEntryPath :(NSString*)newClientFileEntryPath NS_SWIFT_NAME(setClientFileEntryPath(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntryPrincipal,setter=setClientFileEntryPrincipal:) NSString* clientFileEntryPrincipal NS_SWIFT_NAME(clientFileEntryPrincipal);

- (NSString*)clientFileEntryPrincipal NS_SWIFT_NAME(clientFileEntryPrincipal());
- (void)setClientFileEntryPrincipal :(NSString*)newClientFileEntryPrincipal NS_SWIFT_NAME(setClientFileEntryPrincipal(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntrySize,setter=setClientFileEntrySize:) long long clientFileEntrySize NS_SWIFT_NAME(clientFileEntrySize);

- (long long)clientFileEntrySize NS_SWIFT_NAME(clientFileEntrySize());
- (void)setClientFileEntrySize :(long long)newClientFileEntrySize NS_SWIFT_NAME(setClientFileEntrySize(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntryUnixPerms,setter=setClientFileEntryUnixPerms:) int clientFileEntryUnixPerms NS_SWIFT_NAME(clientFileEntryUnixPerms);

- (int)clientFileEntryUnixPerms NS_SWIFT_NAME(clientFileEntryUnixPerms());
- (void)setClientFileEntryUnixPerms :(int)newClientFileEntryUnixPerms NS_SWIFT_NAME(setClientFileEntryUnixPerms(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntryUnparsedName,setter=setClientFileEntryUnparsedName:) NSString* clientFileEntryUnparsedName NS_SWIFT_NAME(clientFileEntryUnparsedName);

- (NSString*)clientFileEntryUnparsedName NS_SWIFT_NAME(clientFileEntryUnparsedName());
- (void)setClientFileEntryUnparsedName :(NSString*)newClientFileEntryUnparsedName NS_SWIFT_NAME(setClientFileEntryUnparsedName(_:));

@property (nonatomic,readwrite,assign,getter=compressionLevel,setter=setCompressionLevel:) int compressionLevel NS_SWIFT_NAME(compressionLevel);

- (int)compressionLevel NS_SWIFT_NAME(compressionLevel());
- (void)setCompressionLevel :(int)newCompressionLevel NS_SWIFT_NAME(setCompressionLevel(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoAsyncDocumentID,setter=setExternalCryptoAsyncDocumentID:) NSString* externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID);

- (NSString*)externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID());
- (void)setExternalCryptoAsyncDocumentID :(NSString*)newExternalCryptoAsyncDocumentID NS_SWIFT_NAME(setExternalCryptoAsyncDocumentID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoCustomParams,setter=setExternalCryptoCustomParams:) NSString* externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams);

- (NSString*)externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams());
- (void)setExternalCryptoCustomParams :(NSString*)newExternalCryptoCustomParams NS_SWIFT_NAME(setExternalCryptoCustomParams(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoData,setter=setExternalCryptoData:) NSString* externalCryptoData NS_SWIFT_NAME(externalCryptoData);

- (NSString*)externalCryptoData NS_SWIFT_NAME(externalCryptoData());
- (void)setExternalCryptoData :(NSString*)newExternalCryptoData NS_SWIFT_NAME(setExternalCryptoData(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoExternalHashCalculation,setter=setExternalCryptoExternalHashCalculation:) BOOL externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation);

- (BOOL)externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation());
- (void)setExternalCryptoExternalHashCalculation :(BOOL)newExternalCryptoExternalHashCalculation NS_SWIFT_NAME(setExternalCryptoExternalHashCalculation(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoHashAlgorithm,setter=setExternalCryptoHashAlgorithm:) NSString* externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm);

- (NSString*)externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm());
- (void)setExternalCryptoHashAlgorithm :(NSString*)newExternalCryptoHashAlgorithm NS_SWIFT_NAME(setExternalCryptoHashAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeyID,setter=setExternalCryptoKeyID:) NSString* externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID);

- (NSString*)externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID());
- (void)setExternalCryptoKeyID :(NSString*)newExternalCryptoKeyID NS_SWIFT_NAME(setExternalCryptoKeyID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeySecret,setter=setExternalCryptoKeySecret:) NSString* externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret);

- (NSString*)externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret());
- (void)setExternalCryptoKeySecret :(NSString*)newExternalCryptoKeySecret NS_SWIFT_NAME(setExternalCryptoKeySecret(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMethod,setter=setExternalCryptoMethod:) int externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod);

- (int)externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod());
- (void)setExternalCryptoMethod :(int)newExternalCryptoMethod NS_SWIFT_NAME(setExternalCryptoMethod(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMode,setter=setExternalCryptoMode:) int externalCryptoMode NS_SWIFT_NAME(externalCryptoMode);

- (int)externalCryptoMode NS_SWIFT_NAME(externalCryptoMode());
- (void)setExternalCryptoMode :(int)newExternalCryptoMode NS_SWIFT_NAME(setExternalCryptoMode(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoPublicKeyAlgorithm,setter=setExternalCryptoPublicKeyAlgorithm:) NSString* externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm);

- (NSString*)externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm());
- (void)setExternalCryptoPublicKeyAlgorithm :(NSString*)newExternalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(setExternalCryptoPublicKeyAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=forceCompression,setter=setForceCompression:) BOOL forceCompression NS_SWIFT_NAME(forceCompression);

- (BOOL)forceCompression NS_SWIFT_NAME(forceCompression());
- (void)setForceCompression :(BOOL)newForceCompression NS_SWIFT_NAME(setForceCompression(_:));

@property (nonatomic,readwrite,assign,getter=host,setter=setHost:) NSString* host NS_SWIFT_NAME(host);

- (NSString*)host NS_SWIFT_NAME(host());
- (void)setHost :(NSString*)newHost NS_SWIFT_NAME(setHost(_:));

@property (nonatomic,readonly,assign,getter=keyAlgorithm) NSString* keyAlgorithm NS_SWIFT_NAME(keyAlgorithm);

- (NSString*)keyAlgorithm NS_SWIFT_NAME(keyAlgorithm());

@property (nonatomic,readonly,assign,getter=keyBits) int keyBits NS_SWIFT_NAME(keyBits);

- (int)keyBits NS_SWIFT_NAME(keyBits());

@property (nonatomic,readonly,assign,getter=keyComment) NSString* keyComment NS_SWIFT_NAME(keyComment);

- (NSString*)keyComment NS_SWIFT_NAME(keyComment());

@property (nonatomic,readonly,assign,getter=keyCurve) NSString* keyCurve NS_SWIFT_NAME(keyCurve);

- (NSString*)keyCurve NS_SWIFT_NAME(keyCurve());

@property (nonatomic,readonly,assign,getter=keyDSSG) NSData* keyDSSG NS_SWIFT_NAME(keyDSSG);

- (NSData*)keyDSSG NS_SWIFT_NAME(keyDSSG());

@property (nonatomic,readonly,assign,getter=keyDSSP) NSData* keyDSSP NS_SWIFT_NAME(keyDSSP);

- (NSData*)keyDSSP NS_SWIFT_NAME(keyDSSP());

@property (nonatomic,readonly,assign,getter=keyDSSQ) NSData* keyDSSQ NS_SWIFT_NAME(keyDSSQ);

- (NSData*)keyDSSQ NS_SWIFT_NAME(keyDSSQ());

@property (nonatomic,readonly,assign,getter=keyDSSX) NSData* keyDSSX NS_SWIFT_NAME(keyDSSX);

- (NSData*)keyDSSX NS_SWIFT_NAME(keyDSSX());

@property (nonatomic,readonly,assign,getter=keyDSSY) NSData* keyDSSY NS_SWIFT_NAME(keyDSSY);

- (NSData*)keyDSSY NS_SWIFT_NAME(keyDSSY());

@property (nonatomic,readonly,assign,getter=keyECCD) NSData* keyECCD NS_SWIFT_NAME(keyECCD);

- (NSData*)keyECCD NS_SWIFT_NAME(keyECCD());

@property (nonatomic,readonly,assign,getter=keyECCQX) NSData* keyECCQX NS_SWIFT_NAME(keyECCQX);

- (NSData*)keyECCQX NS_SWIFT_NAME(keyECCQX());

@property (nonatomic,readonly,assign,getter=keyECCQY) NSData* keyECCQY NS_SWIFT_NAME(keyECCQY);

- (NSData*)keyECCQY NS_SWIFT_NAME(keyECCQY());

@property (nonatomic,readonly,assign,getter=keyEdPrivate) NSData* keyEdPrivate NS_SWIFT_NAME(keyEdPrivate);

- (NSData*)keyEdPrivate NS_SWIFT_NAME(keyEdPrivate());

@property (nonatomic,readonly,assign,getter=keyEdPublic) NSData* keyEdPublic NS_SWIFT_NAME(keyEdPublic);

- (NSData*)keyEdPublic NS_SWIFT_NAME(keyEdPublic());

@property (nonatomic,readonly,assign,getter=keyFingerprintMD5) NSString* keyFingerprintMD5 NS_SWIFT_NAME(keyFingerprintMD5);

- (NSString*)keyFingerprintMD5 NS_SWIFT_NAME(keyFingerprintMD5());

@property (nonatomic,readonly,assign,getter=keyFingerprintSHA1) NSString* keyFingerprintSHA1 NS_SWIFT_NAME(keyFingerprintSHA1);

- (NSString*)keyFingerprintSHA1 NS_SWIFT_NAME(keyFingerprintSHA1());

@property (nonatomic,readonly,assign,getter=keyFingerprintSHA256) NSString* keyFingerprintSHA256 NS_SWIFT_NAME(keyFingerprintSHA256);

- (NSString*)keyFingerprintSHA256 NS_SWIFT_NAME(keyFingerprintSHA256());

@property (nonatomic,readonly,assign,getter=keyHandle) long long keyHandle NS_SWIFT_NAME(keyHandle);

- (long long)keyHandle NS_SWIFT_NAME(keyHandle());

@property (nonatomic,readonly,assign,getter=keyIsExtractable) BOOL keyIsExtractable NS_SWIFT_NAME(keyIsExtractable);

- (BOOL)keyIsExtractable NS_SWIFT_NAME(keyIsExtractable());

@property (nonatomic,readonly,assign,getter=keyIsPrivate) BOOL keyIsPrivate NS_SWIFT_NAME(keyIsPrivate);

- (BOOL)keyIsPrivate NS_SWIFT_NAME(keyIsPrivate());

@property (nonatomic,readonly,assign,getter=keyIsPublic) BOOL keyIsPublic NS_SWIFT_NAME(keyIsPublic);

- (BOOL)keyIsPublic NS_SWIFT_NAME(keyIsPublic());

@property (nonatomic,readonly,assign,getter=keyKDFRounds) int keyKDFRounds NS_SWIFT_NAME(keyKDFRounds);

- (int)keyKDFRounds NS_SWIFT_NAME(keyKDFRounds());

@property (nonatomic,readonly,assign,getter=keyKDFSalt) NSData* keyKDFSalt NS_SWIFT_NAME(keyKDFSalt);

- (NSData*)keyKDFSalt NS_SWIFT_NAME(keyKDFSalt());

@property (nonatomic,readonly,assign,getter=keyKeyFormat) int keyKeyFormat NS_SWIFT_NAME(keyKeyFormat);

- (int)keyKeyFormat NS_SWIFT_NAME(keyKeyFormat());

@property (nonatomic,readonly,assign,getter=keyKeyProtectionAlgorithm) NSString* keyKeyProtectionAlgorithm NS_SWIFT_NAME(keyKeyProtectionAlgorithm);

- (NSString*)keyKeyProtectionAlgorithm NS_SWIFT_NAME(keyKeyProtectionAlgorithm());

@property (nonatomic,readonly,assign,getter=keyRSAExponent) NSData* keyRSAExponent NS_SWIFT_NAME(keyRSAExponent);

- (NSData*)keyRSAExponent NS_SWIFT_NAME(keyRSAExponent());

@property (nonatomic,readonly,assign,getter=keyRSAIQMP) NSData* keyRSAIQMP NS_SWIFT_NAME(keyRSAIQMP);

- (NSData*)keyRSAIQMP NS_SWIFT_NAME(keyRSAIQMP());

@property (nonatomic,readonly,assign,getter=keyRSAModulus) NSData* keyRSAModulus NS_SWIFT_NAME(keyRSAModulus);

- (NSData*)keyRSAModulus NS_SWIFT_NAME(keyRSAModulus());

@property (nonatomic,readonly,assign,getter=keyRSAP) NSData* keyRSAP NS_SWIFT_NAME(keyRSAP);

- (NSData*)keyRSAP NS_SWIFT_NAME(keyRSAP());

@property (nonatomic,readonly,assign,getter=keyRSAPrivateExponent) NSData* keyRSAPrivateExponent NS_SWIFT_NAME(keyRSAPrivateExponent);

- (NSData*)keyRSAPrivateExponent NS_SWIFT_NAME(keyRSAPrivateExponent());

@property (nonatomic,readonly,assign,getter=keyRSAQ) NSData* keyRSAQ NS_SWIFT_NAME(keyRSAQ);

- (NSData*)keyRSAQ NS_SWIFT_NAME(keyRSAQ());

@property (nonatomic,readonly,assign,getter=keySubject) NSString* keySubject NS_SWIFT_NAME(keySubject);

- (NSString*)keySubject NS_SWIFT_NAME(keySubject());

@property (nonatomic,readwrite,assign,getter=maxSFTPVersion,setter=setMaxSFTPVersion:) int maxSFTPVersion NS_SWIFT_NAME(maxSFTPVersion);

- (int)maxSFTPVersion NS_SWIFT_NAME(maxSFTPVersion());
- (void)setMaxSFTPVersion :(int)newMaxSFTPVersion NS_SWIFT_NAME(setMaxSFTPVersion(_:));

@property (nonatomic,readwrite,assign,getter=minSFTPVersion,setter=setMinSFTPVersion:) int minSFTPVersion NS_SWIFT_NAME(minSFTPVersion);

- (int)minSFTPVersion NS_SWIFT_NAME(minSFTPVersion());
- (void)setMinSFTPVersion :(int)newMinSFTPVersion NS_SWIFT_NAME(setMinSFTPVersion(_:));

@property (nonatomic,readonly,assign,getter=pinnedClientClientKeyAlgorithm) NSString* pinnedClientClientKeyAlgorithm NS_SWIFT_NAME(pinnedClientClientKeyAlgorithm);

- (NSString*)pinnedClientClientKeyAlgorithm NS_SWIFT_NAME(pinnedClientClientKeyAlgorithm());

@property (nonatomic,readonly,assign,getter=pinnedClientClientKeyBits) int pinnedClientClientKeyBits NS_SWIFT_NAME(pinnedClientClientKeyBits);

- (int)pinnedClientClientKeyBits NS_SWIFT_NAME(pinnedClientClientKeyBits());

@property (nonatomic,readonly,assign,getter=pinnedClientClientKeyFingerprint) NSString* pinnedClientClientKeyFingerprint NS_SWIFT_NAME(pinnedClientClientKeyFingerprint);

- (NSString*)pinnedClientClientKeyFingerprint NS_SWIFT_NAME(pinnedClientClientKeyFingerprint());

@property (nonatomic,readonly,assign,getter=pinnedClientCloseReason) NSString* pinnedClientCloseReason NS_SWIFT_NAME(pinnedClientCloseReason);

- (NSString*)pinnedClientCloseReason NS_SWIFT_NAME(pinnedClientCloseReason());

@property (nonatomic,readonly,assign,getter=pinnedClientCompressionAlgorithmInbound) NSString* pinnedClientCompressionAlgorithmInbound NS_SWIFT_NAME(pinnedClientCompressionAlgorithmInbound);

- (NSString*)pinnedClientCompressionAlgorithmInbound NS_SWIFT_NAME(pinnedClientCompressionAlgorithmInbound());

@property (nonatomic,readonly,assign,getter=pinnedClientCompressionAlgorithmOutbound) NSString* pinnedClientCompressionAlgorithmOutbound NS_SWIFT_NAME(pinnedClientCompressionAlgorithmOutbound);

- (NSString*)pinnedClientCompressionAlgorithmOutbound NS_SWIFT_NAME(pinnedClientCompressionAlgorithmOutbound());

@property (nonatomic,readonly,assign,getter=pinnedClientEncryptionAlgorithmInbound) NSString* pinnedClientEncryptionAlgorithmInbound NS_SWIFT_NAME(pinnedClientEncryptionAlgorithmInbound);

- (NSString*)pinnedClientEncryptionAlgorithmInbound NS_SWIFT_NAME(pinnedClientEncryptionAlgorithmInbound());

@property (nonatomic,readonly,assign,getter=pinnedClientEncryptionAlgorithmOutbound) NSString* pinnedClientEncryptionAlgorithmOutbound NS_SWIFT_NAME(pinnedClientEncryptionAlgorithmOutbound);

- (NSString*)pinnedClientEncryptionAlgorithmOutbound NS_SWIFT_NAME(pinnedClientEncryptionAlgorithmOutbound());

@property (nonatomic,readonly,assign,getter=pinnedClientInboundEncryptionKeyBits) int pinnedClientInboundEncryptionKeyBits NS_SWIFT_NAME(pinnedClientInboundEncryptionKeyBits);

- (int)pinnedClientInboundEncryptionKeyBits NS_SWIFT_NAME(pinnedClientInboundEncryptionKeyBits());

@property (nonatomic,readonly,assign,getter=pinnedClientKexAlgorithm) NSString* pinnedClientKexAlgorithm NS_SWIFT_NAME(pinnedClientKexAlgorithm);

- (NSString*)pinnedClientKexAlgorithm NS_SWIFT_NAME(pinnedClientKexAlgorithm());

@property (nonatomic,readonly,assign,getter=pinnedClientKexBits) int pinnedClientKexBits NS_SWIFT_NAME(pinnedClientKexBits);

- (int)pinnedClientKexBits NS_SWIFT_NAME(pinnedClientKexBits());

@property (nonatomic,readonly,assign,getter=pinnedClientKexLines) NSString* pinnedClientKexLines NS_SWIFT_NAME(pinnedClientKexLines);

- (NSString*)pinnedClientKexLines NS_SWIFT_NAME(pinnedClientKexLines());

@property (nonatomic,readonly,assign,getter=pinnedClientMacAlgorithmInbound) NSString* pinnedClientMacAlgorithmInbound NS_SWIFT_NAME(pinnedClientMacAlgorithmInbound);

- (NSString*)pinnedClientMacAlgorithmInbound NS_SWIFT_NAME(pinnedClientMacAlgorithmInbound());

@property (nonatomic,readonly,assign,getter=pinnedClientMacAlgorithmOutbound) NSString* pinnedClientMacAlgorithmOutbound NS_SWIFT_NAME(pinnedClientMacAlgorithmOutbound);

- (NSString*)pinnedClientMacAlgorithmOutbound NS_SWIFT_NAME(pinnedClientMacAlgorithmOutbound());

@property (nonatomic,readonly,assign,getter=pinnedClientOutboundEncryptionKeyBits) int pinnedClientOutboundEncryptionKeyBits NS_SWIFT_NAME(pinnedClientOutboundEncryptionKeyBits);

- (int)pinnedClientOutboundEncryptionKeyBits NS_SWIFT_NAME(pinnedClientOutboundEncryptionKeyBits());

@property (nonatomic,readonly,assign,getter=pinnedClientPublicKeyAlgorithm) NSString* pinnedClientPublicKeyAlgorithm NS_SWIFT_NAME(pinnedClientPublicKeyAlgorithm);

- (NSString*)pinnedClientPublicKeyAlgorithm NS_SWIFT_NAME(pinnedClientPublicKeyAlgorithm());

@property (nonatomic,readonly,assign,getter=pinnedClientRemoteAddress) NSString* pinnedClientRemoteAddress NS_SWIFT_NAME(pinnedClientRemoteAddress);

- (NSString*)pinnedClientRemoteAddress NS_SWIFT_NAME(pinnedClientRemoteAddress());

@property (nonatomic,readonly,assign,getter=pinnedClientRemotePort) int pinnedClientRemotePort NS_SWIFT_NAME(pinnedClientRemotePort);

- (int)pinnedClientRemotePort NS_SWIFT_NAME(pinnedClientRemotePort());

@property (nonatomic,readonly,assign,getter=pinnedClientServerKeyAlgorithm) NSString* pinnedClientServerKeyAlgorithm NS_SWIFT_NAME(pinnedClientServerKeyAlgorithm);

- (NSString*)pinnedClientServerKeyAlgorithm NS_SWIFT_NAME(pinnedClientServerKeyAlgorithm());

@property (nonatomic,readonly,assign,getter=pinnedClientServerKeyBits) int pinnedClientServerKeyBits NS_SWIFT_NAME(pinnedClientServerKeyBits);

- (int)pinnedClientServerKeyBits NS_SWIFT_NAME(pinnedClientServerKeyBits());

@property (nonatomic,readonly,assign,getter=pinnedClientServerKeyFingerprint) NSString* pinnedClientServerKeyFingerprint NS_SWIFT_NAME(pinnedClientServerKeyFingerprint);

- (NSString*)pinnedClientServerKeyFingerprint NS_SWIFT_NAME(pinnedClientServerKeyFingerprint());

@property (nonatomic,readonly,assign,getter=pinnedClientServerSoftwareName) NSString* pinnedClientServerSoftwareName NS_SWIFT_NAME(pinnedClientServerSoftwareName);

- (NSString*)pinnedClientServerSoftwareName NS_SWIFT_NAME(pinnedClientServerSoftwareName());

@property (nonatomic,readonly,assign,getter=pinnedClientTotalBytesReceived) long long pinnedClientTotalBytesReceived NS_SWIFT_NAME(pinnedClientTotalBytesReceived);

- (long long)pinnedClientTotalBytesReceived NS_SWIFT_NAME(pinnedClientTotalBytesReceived());

@property (nonatomic,readonly,assign,getter=pinnedClientTotalBytesSent) long long pinnedClientTotalBytesSent NS_SWIFT_NAME(pinnedClientTotalBytesSent);

- (long long)pinnedClientTotalBytesSent NS_SWIFT_NAME(pinnedClientTotalBytesSent());

@property (nonatomic,readonly,assign,getter=pinnedClientVersion) int pinnedClientVersion NS_SWIFT_NAME(pinnedClientVersion);

- (int)pinnedClientVersion NS_SWIFT_NAME(pinnedClientVersion());

@property (nonatomic,readwrite,assign,getter=port,setter=setPort:) int port NS_SWIFT_NAME(port);

- (int)port NS_SWIFT_NAME(port());
- (void)setPort :(int)newPort NS_SWIFT_NAME(setPort(_:));

@property (nonatomic,readwrite,assign,getter=readOnly,setter=setReadOnly:) BOOL readOnly NS_SWIFT_NAME(readOnly);

- (BOOL)readOnly NS_SWIFT_NAME(readOnly());
- (void)setReadOnly :(BOOL)newReadOnly NS_SWIFT_NAME(setReadOnly(_:));

@property (nonatomic,readwrite,assign,getter=serverKeyCount,setter=setServerKeyCount:) int serverKeyCount NS_SWIFT_NAME(serverKeyCount);

- (int)serverKeyCount NS_SWIFT_NAME(serverKeyCount());
- (void)setServerKeyCount :(int)newServerKeyCount NS_SWIFT_NAME(setServerKeyCount(_:));

- (NSString*)serverKeyAlgorithm:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyAlgorithm(_:));

- (int)serverKeyBits:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyBits(_:));

- (NSString*)serverKeyComment:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyComment(_:));
- (void)setServerKeyComment:(int)serverKeyIndex :(NSString*)newServerKeyComment NS_SWIFT_NAME(setServerKeyComment(_:_:));

- (NSString*)serverKeyCurve:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyCurve(_:));

- (NSData*)serverKeyDSSG:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyDSSG(_:));

- (NSData*)serverKeyDSSP:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyDSSP(_:));

- (NSData*)serverKeyDSSQ:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyDSSQ(_:));

- (NSData*)serverKeyDSSX:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyDSSX(_:));

- (NSData*)serverKeyDSSY:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyDSSY(_:));

- (NSData*)serverKeyECCD:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyECCD(_:));

- (NSData*)serverKeyECCQX:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyECCQX(_:));

- (NSData*)serverKeyECCQY:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyECCQY(_:));

- (NSData*)serverKeyEdPrivate:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyEdPrivate(_:));

- (NSData*)serverKeyEdPublic:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyEdPublic(_:));

- (NSString*)serverKeyFingerprintMD5:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyFingerprintMD5(_:));

- (NSString*)serverKeyFingerprintSHA1:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyFingerprintSHA1(_:));

- (NSString*)serverKeyFingerprintSHA256:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyFingerprintSHA256(_:));

- (long long)serverKeyHandle:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyHandle(_:));
- (void)setServerKeyHandle:(int)serverKeyIndex :(long long)newServerKeyHandle NS_SWIFT_NAME(setServerKeyHandle(_:_:));

- (BOOL)serverKeyIsExtractable:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyIsExtractable(_:));

- (BOOL)serverKeyIsPrivate:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyIsPrivate(_:));

- (BOOL)serverKeyIsPublic:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyIsPublic(_:));

- (int)serverKeyKDFRounds:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyKDFRounds(_:));

- (NSData*)serverKeyKDFSalt:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyKDFSalt(_:));

- (int)serverKeyKeyFormat:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyKeyFormat(_:));

- (NSString*)serverKeyKeyProtectionAlgorithm:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyKeyProtectionAlgorithm(_:));

- (NSData*)serverKeyRSAExponent:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyRSAExponent(_:));

- (NSData*)serverKeyRSAIQMP:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyRSAIQMP(_:));

- (NSData*)serverKeyRSAModulus:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyRSAModulus(_:));

- (NSData*)serverKeyRSAP:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyRSAP(_:));

- (NSData*)serverKeyRSAPrivateExponent:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyRSAPrivateExponent(_:));

- (NSData*)serverKeyRSAQ:(int)serverKeyIndex NS_SWIFT_NAME(serverKeyRSAQ(_:));

- (NSString*)serverKeySubject:(int)serverKeyIndex NS_SWIFT_NAME(serverKeySubject(_:));
- (void)setServerKeySubject:(int)serverKeyIndex :(NSString*)newServerKeySubject NS_SWIFT_NAME(setServerKeySubject(_:_:));

@property (nonatomic,readwrite,assign,getter=socketDNSMode,setter=setSocketDNSMode:) int socketDNSMode NS_SWIFT_NAME(socketDNSMode);

- (int)socketDNSMode NS_SWIFT_NAME(socketDNSMode());
- (void)setSocketDNSMode :(int)newSocketDNSMode NS_SWIFT_NAME(setSocketDNSMode(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSPort,setter=setSocketDNSPort:) int socketDNSPort NS_SWIFT_NAME(socketDNSPort);

- (int)socketDNSPort NS_SWIFT_NAME(socketDNSPort());
- (void)setSocketDNSPort :(int)newSocketDNSPort NS_SWIFT_NAME(setSocketDNSPort(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSQueryTimeout,setter=setSocketDNSQueryTimeout:) int socketDNSQueryTimeout NS_SWIFT_NAME(socketDNSQueryTimeout);

- (int)socketDNSQueryTimeout NS_SWIFT_NAME(socketDNSQueryTimeout());
- (void)setSocketDNSQueryTimeout :(int)newSocketDNSQueryTimeout NS_SWIFT_NAME(setSocketDNSQueryTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSServers,setter=setSocketDNSServers:) NSString* socketDNSServers NS_SWIFT_NAME(socketDNSServers);

- (NSString*)socketDNSServers NS_SWIFT_NAME(socketDNSServers());
- (void)setSocketDNSServers :(NSString*)newSocketDNSServers NS_SWIFT_NAME(setSocketDNSServers(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSTotalTimeout,setter=setSocketDNSTotalTimeout:) int socketDNSTotalTimeout NS_SWIFT_NAME(socketDNSTotalTimeout);

- (int)socketDNSTotalTimeout NS_SWIFT_NAME(socketDNSTotalTimeout());
- (void)setSocketDNSTotalTimeout :(int)newSocketDNSTotalTimeout NS_SWIFT_NAME(setSocketDNSTotalTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketIncomingSpeedLimit,setter=setSocketIncomingSpeedLimit:) int socketIncomingSpeedLimit NS_SWIFT_NAME(socketIncomingSpeedLimit);

- (int)socketIncomingSpeedLimit NS_SWIFT_NAME(socketIncomingSpeedLimit());
- (void)setSocketIncomingSpeedLimit :(int)newSocketIncomingSpeedLimit NS_SWIFT_NAME(setSocketIncomingSpeedLimit(_:));

@property (nonatomic,readwrite,assign,getter=socketLocalAddress,setter=setSocketLocalAddress:) NSString* socketLocalAddress NS_SWIFT_NAME(socketLocalAddress);

- (NSString*)socketLocalAddress NS_SWIFT_NAME(socketLocalAddress());
- (void)setSocketLocalAddress :(NSString*)newSocketLocalAddress NS_SWIFT_NAME(setSocketLocalAddress(_:));

@property (nonatomic,readwrite,assign,getter=socketLocalPort,setter=setSocketLocalPort:) int socketLocalPort NS_SWIFT_NAME(socketLocalPort);

- (int)socketLocalPort NS_SWIFT_NAME(socketLocalPort());
- (void)setSocketLocalPort :(int)newSocketLocalPort NS_SWIFT_NAME(setSocketLocalPort(_:));

@property (nonatomic,readwrite,assign,getter=socketOutgoingSpeedLimit,setter=setSocketOutgoingSpeedLimit:) int socketOutgoingSpeedLimit NS_SWIFT_NAME(socketOutgoingSpeedLimit);

- (int)socketOutgoingSpeedLimit NS_SWIFT_NAME(socketOutgoingSpeedLimit());
- (void)setSocketOutgoingSpeedLimit :(int)newSocketOutgoingSpeedLimit NS_SWIFT_NAME(setSocketOutgoingSpeedLimit(_:));

@property (nonatomic,readwrite,assign,getter=socketTimeout,setter=setSocketTimeout:) int socketTimeout NS_SWIFT_NAME(socketTimeout);

- (int)socketTimeout NS_SWIFT_NAME(socketTimeout());
- (void)setSocketTimeout :(int)newSocketTimeout NS_SWIFT_NAME(setSocketTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketUseIPv6,setter=setSocketUseIPv6:) BOOL socketUseIPv6 NS_SWIFT_NAME(socketUseIPv6);

- (BOOL)socketUseIPv6 NS_SWIFT_NAME(socketUseIPv6());
- (void)setSocketUseIPv6 :(BOOL)newSocketUseIPv6 NS_SWIFT_NAME(setSocketUseIPv6(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsAutoAdjustCiphers,setter=setSSHSettingsAutoAdjustCiphers:) BOOL SSHSettingsAutoAdjustCiphers NS_SWIFT_NAME(SSHSettingsAutoAdjustCiphers);

- (BOOL)SSHSettingsAutoAdjustCiphers NS_SWIFT_NAME(SSHSettingsAutoAdjustCiphers());
- (void)setSSHSettingsAutoAdjustCiphers :(BOOL)newSSHSettingsAutoAdjustCiphers NS_SWIFT_NAME(setSSHSettingsAutoAdjustCiphers(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsBaseConfiguration,setter=setSSHSettingsBaseConfiguration:) int SSHSettingsBaseConfiguration NS_SWIFT_NAME(SSHSettingsBaseConfiguration);

- (int)SSHSettingsBaseConfiguration NS_SWIFT_NAME(SSHSettingsBaseConfiguration());
- (void)setSSHSettingsBaseConfiguration :(int)newSSHSettingsBaseConfiguration NS_SWIFT_NAME(setSSHSettingsBaseConfiguration(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsCompressionAlgorithms,setter=setSSHSettingsCompressionAlgorithms:) NSString* SSHSettingsCompressionAlgorithms NS_SWIFT_NAME(SSHSettingsCompressionAlgorithms);

- (NSString*)SSHSettingsCompressionAlgorithms NS_SWIFT_NAME(SSHSettingsCompressionAlgorithms());
- (void)setSSHSettingsCompressionAlgorithms :(NSString*)newSSHSettingsCompressionAlgorithms NS_SWIFT_NAME(setSSHSettingsCompressionAlgorithms(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsCompressionLevel,setter=setSSHSettingsCompressionLevel:) int SSHSettingsCompressionLevel NS_SWIFT_NAME(SSHSettingsCompressionLevel);

- (int)SSHSettingsCompressionLevel NS_SWIFT_NAME(SSHSettingsCompressionLevel());
- (void)setSSHSettingsCompressionLevel :(int)newSSHSettingsCompressionLevel NS_SWIFT_NAME(setSSHSettingsCompressionLevel(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsDefaultWindowSize,setter=setSSHSettingsDefaultWindowSize:) int SSHSettingsDefaultWindowSize NS_SWIFT_NAME(SSHSettingsDefaultWindowSize);

- (int)SSHSettingsDefaultWindowSize NS_SWIFT_NAME(SSHSettingsDefaultWindowSize());
- (void)setSSHSettingsDefaultWindowSize :(int)newSSHSettingsDefaultWindowSize NS_SWIFT_NAME(setSSHSettingsDefaultWindowSize(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsEncryptionAlgorithms,setter=setSSHSettingsEncryptionAlgorithms:) NSString* SSHSettingsEncryptionAlgorithms NS_SWIFT_NAME(SSHSettingsEncryptionAlgorithms);

- (NSString*)SSHSettingsEncryptionAlgorithms NS_SWIFT_NAME(SSHSettingsEncryptionAlgorithms());
- (void)setSSHSettingsEncryptionAlgorithms :(NSString*)newSSHSettingsEncryptionAlgorithms NS_SWIFT_NAME(setSSHSettingsEncryptionAlgorithms(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsForceCompression,setter=setSSHSettingsForceCompression:) BOOL SSHSettingsForceCompression NS_SWIFT_NAME(SSHSettingsForceCompression);

- (BOOL)SSHSettingsForceCompression NS_SWIFT_NAME(SSHSettingsForceCompression());
- (void)setSSHSettingsForceCompression :(BOOL)newSSHSettingsForceCompression NS_SWIFT_NAME(setSSHSettingsForceCompression(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsForwardAuthAgent,setter=setSSHSettingsForwardAuthAgent:) BOOL SSHSettingsForwardAuthAgent NS_SWIFT_NAME(SSHSettingsForwardAuthAgent);

- (BOOL)SSHSettingsForwardAuthAgent NS_SWIFT_NAME(SSHSettingsForwardAuthAgent());
- (void)setSSHSettingsForwardAuthAgent :(BOOL)newSSHSettingsForwardAuthAgent NS_SWIFT_NAME(setSSHSettingsForwardAuthAgent(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsGSSAuthTypes,setter=setSSHSettingsGSSAuthTypes:) NSString* SSHSettingsGSSAuthTypes NS_SWIFT_NAME(SSHSettingsGSSAuthTypes);

- (NSString*)SSHSettingsGSSAuthTypes NS_SWIFT_NAME(SSHSettingsGSSAuthTypes());
- (void)setSSHSettingsGSSAuthTypes :(NSString*)newSSHSettingsGSSAuthTypes NS_SWIFT_NAME(setSSHSettingsGSSAuthTypes(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsGSSDelegateCreds,setter=setSSHSettingsGSSDelegateCreds:) BOOL SSHSettingsGSSDelegateCreds NS_SWIFT_NAME(SSHSettingsGSSDelegateCreds);

- (BOOL)SSHSettingsGSSDelegateCreds NS_SWIFT_NAME(SSHSettingsGSSDelegateCreds());
- (void)setSSHSettingsGSSDelegateCreds :(BOOL)newSSHSettingsGSSDelegateCreds NS_SWIFT_NAME(setSSHSettingsGSSDelegateCreds(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsGSSHostname,setter=setSSHSettingsGSSHostname:) NSString* SSHSettingsGSSHostname NS_SWIFT_NAME(SSHSettingsGSSHostname);

- (NSString*)SSHSettingsGSSHostname NS_SWIFT_NAME(SSHSettingsGSSHostname());
- (void)setSSHSettingsGSSHostname :(NSString*)newSSHSettingsGSSHostname NS_SWIFT_NAME(setSSHSettingsGSSHostname(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsGSSLib,setter=setSSHSettingsGSSLib:) NSString* SSHSettingsGSSLib NS_SWIFT_NAME(SSHSettingsGSSLib);

- (NSString*)SSHSettingsGSSLib NS_SWIFT_NAME(SSHSettingsGSSLib());
- (void)setSSHSettingsGSSLib :(NSString*)newSSHSettingsGSSLib NS_SWIFT_NAME(setSSHSettingsGSSLib(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsGSSMechanisms,setter=setSSHSettingsGSSMechanisms:) NSString* SSHSettingsGSSMechanisms NS_SWIFT_NAME(SSHSettingsGSSMechanisms);

- (NSString*)SSHSettingsGSSMechanisms NS_SWIFT_NAME(SSHSettingsGSSMechanisms());
- (void)setSSHSettingsGSSMechanisms :(NSString*)newSSHSettingsGSSMechanisms NS_SWIFT_NAME(setSSHSettingsGSSMechanisms(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsGSSProtocols,setter=setSSHSettingsGSSProtocols:) NSString* SSHSettingsGSSProtocols NS_SWIFT_NAME(SSHSettingsGSSProtocols);

- (NSString*)SSHSettingsGSSProtocols NS_SWIFT_NAME(SSHSettingsGSSProtocols());
- (void)setSSHSettingsGSSProtocols :(NSString*)newSSHSettingsGSSProtocols NS_SWIFT_NAME(setSSHSettingsGSSProtocols(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsHandshakeTimeout,setter=setSSHSettingsHandshakeTimeout:) int SSHSettingsHandshakeTimeout NS_SWIFT_NAME(SSHSettingsHandshakeTimeout);

- (int)SSHSettingsHandshakeTimeout NS_SWIFT_NAME(SSHSettingsHandshakeTimeout());
- (void)setSSHSettingsHandshakeTimeout :(int)newSSHSettingsHandshakeTimeout NS_SWIFT_NAME(setSSHSettingsHandshakeTimeout(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsKexAlgorithms,setter=setSSHSettingsKexAlgorithms:) NSString* SSHSettingsKexAlgorithms NS_SWIFT_NAME(SSHSettingsKexAlgorithms);

- (NSString*)SSHSettingsKexAlgorithms NS_SWIFT_NAME(SSHSettingsKexAlgorithms());
- (void)setSSHSettingsKexAlgorithms :(NSString*)newSSHSettingsKexAlgorithms NS_SWIFT_NAME(setSSHSettingsKexAlgorithms(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsMacAlgorithms,setter=setSSHSettingsMacAlgorithms:) NSString* SSHSettingsMacAlgorithms NS_SWIFT_NAME(SSHSettingsMacAlgorithms);

- (NSString*)SSHSettingsMacAlgorithms NS_SWIFT_NAME(SSHSettingsMacAlgorithms());
- (void)setSSHSettingsMacAlgorithms :(NSString*)newSSHSettingsMacAlgorithms NS_SWIFT_NAME(setSSHSettingsMacAlgorithms(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsMaxSSHPacketSize,setter=setSSHSettingsMaxSSHPacketSize:) int SSHSettingsMaxSSHPacketSize NS_SWIFT_NAME(SSHSettingsMaxSSHPacketSize);

- (int)SSHSettingsMaxSSHPacketSize NS_SWIFT_NAME(SSHSettingsMaxSSHPacketSize());
- (void)setSSHSettingsMaxSSHPacketSize :(int)newSSHSettingsMaxSSHPacketSize NS_SWIFT_NAME(setSSHSettingsMaxSSHPacketSize(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsMinWindowSize,setter=setSSHSettingsMinWindowSize:) int SSHSettingsMinWindowSize NS_SWIFT_NAME(SSHSettingsMinWindowSize);

- (int)SSHSettingsMinWindowSize NS_SWIFT_NAME(SSHSettingsMinWindowSize());
- (void)setSSHSettingsMinWindowSize :(int)newSSHSettingsMinWindowSize NS_SWIFT_NAME(setSSHSettingsMinWindowSize(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsObfuscateHandshake,setter=setSSHSettingsObfuscateHandshake:) BOOL SSHSettingsObfuscateHandshake NS_SWIFT_NAME(SSHSettingsObfuscateHandshake);

- (BOOL)SSHSettingsObfuscateHandshake NS_SWIFT_NAME(SSHSettingsObfuscateHandshake());
- (void)setSSHSettingsObfuscateHandshake :(BOOL)newSSHSettingsObfuscateHandshake NS_SWIFT_NAME(setSSHSettingsObfuscateHandshake(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsObfuscationPassword,setter=setSSHSettingsObfuscationPassword:) NSString* SSHSettingsObfuscationPassword NS_SWIFT_NAME(SSHSettingsObfuscationPassword);

- (NSString*)SSHSettingsObfuscationPassword NS_SWIFT_NAME(SSHSettingsObfuscationPassword());
- (void)setSSHSettingsObfuscationPassword :(NSString*)newSSHSettingsObfuscationPassword NS_SWIFT_NAME(setSSHSettingsObfuscationPassword(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsPublicKeyAlgorithms,setter=setSSHSettingsPublicKeyAlgorithms:) NSString* SSHSettingsPublicKeyAlgorithms NS_SWIFT_NAME(SSHSettingsPublicKeyAlgorithms);

- (NSString*)SSHSettingsPublicKeyAlgorithms NS_SWIFT_NAME(SSHSettingsPublicKeyAlgorithms());
- (void)setSSHSettingsPublicKeyAlgorithms :(NSString*)newSSHSettingsPublicKeyAlgorithms NS_SWIFT_NAME(setSSHSettingsPublicKeyAlgorithms(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsRequestPasswordChange,setter=setSSHSettingsRequestPasswordChange:) BOOL SSHSettingsRequestPasswordChange NS_SWIFT_NAME(SSHSettingsRequestPasswordChange);

- (BOOL)SSHSettingsRequestPasswordChange NS_SWIFT_NAME(SSHSettingsRequestPasswordChange());
- (void)setSSHSettingsRequestPasswordChange :(BOOL)newSSHSettingsRequestPasswordChange NS_SWIFT_NAME(setSSHSettingsRequestPasswordChange(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsSoftwareName,setter=setSSHSettingsSoftwareName:) NSString* SSHSettingsSoftwareName NS_SWIFT_NAME(SSHSettingsSoftwareName);

- (NSString*)SSHSettingsSoftwareName NS_SWIFT_NAME(SSHSettingsSoftwareName());
- (void)setSSHSettingsSoftwareName :(NSString*)newSSHSettingsSoftwareName NS_SWIFT_NAME(setSSHSettingsSoftwareName(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsTrustAllKeys,setter=setSSHSettingsTrustAllKeys:) BOOL SSHSettingsTrustAllKeys NS_SWIFT_NAME(SSHSettingsTrustAllKeys);

- (BOOL)SSHSettingsTrustAllKeys NS_SWIFT_NAME(SSHSettingsTrustAllKeys());
- (void)setSSHSettingsTrustAllKeys :(BOOL)newSSHSettingsTrustAllKeys NS_SWIFT_NAME(setSSHSettingsTrustAllKeys(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsUseAuthAgent,setter=setSSHSettingsUseAuthAgent:) BOOL SSHSettingsUseAuthAgent NS_SWIFT_NAME(SSHSettingsUseAuthAgent);

- (BOOL)SSHSettingsUseAuthAgent NS_SWIFT_NAME(SSHSettingsUseAuthAgent());
- (void)setSSHSettingsUseAuthAgent :(BOOL)newSSHSettingsUseAuthAgent NS_SWIFT_NAME(setSSHSettingsUseAuthAgent(_:));

@property (nonatomic,readwrite,assign,getter=SSHSettingsVersions,setter=setSSHSettingsVersions:) int SSHSettingsVersions NS_SWIFT_NAME(SSHSettingsVersions);

- (int)SSHSettingsVersions NS_SWIFT_NAME(SSHSettingsVersions());
- (void)setSSHSettingsVersions :(int)newSSHSettingsVersions NS_SWIFT_NAME(setSSHSettingsVersions(_:));

@property (nonatomic,readwrite,assign,getter=userCount,setter=setUserCount:) int userCount NS_SWIFT_NAME(userCount);

- (int)userCount NS_SWIFT_NAME(userCount());
- (void)setUserCount :(int)newUserCount NS_SWIFT_NAME(setUserCount(_:));

- (NSData*)userAssociatedData:(int)userIndex NS_SWIFT_NAME(userAssociatedData(_:));
- (void)setUserAssociatedData:(int)userIndex :(NSData*)newUserAssociatedData NS_SWIFT_NAME(setUserAssociatedData(_:_:));

- (NSString*)userBasePath:(int)userIndex NS_SWIFT_NAME(userBasePath(_:));
- (void)setUserBasePath:(int)userIndex :(NSString*)newUserBasePath NS_SWIFT_NAME(setUserBasePath(_:_:));

- (NSData*)userCertificate:(int)userIndex NS_SWIFT_NAME(userCertificate(_:));
- (void)setUserCertificate:(int)userIndex :(NSData*)newUserCertificate NS_SWIFT_NAME(setUserCertificate(_:_:));

- (NSString*)userData:(int)userIndex NS_SWIFT_NAME(userData(_:));
- (void)setUserData:(int)userIndex :(NSString*)newUserData NS_SWIFT_NAME(setUserData(_:_:));

- (NSString*)userEmail:(int)userIndex NS_SWIFT_NAME(userEmail(_:));
- (void)setUserEmail:(int)userIndex :(NSString*)newUserEmail NS_SWIFT_NAME(setUserEmail(_:_:));

- (long long)userHandle:(int)userIndex NS_SWIFT_NAME(userHandle(_:));
- (void)setUserHandle:(int)userIndex :(long long)newUserHandle NS_SWIFT_NAME(setUserHandle(_:_:));

- (NSString*)userHashAlgorithm:(int)userIndex NS_SWIFT_NAME(userHashAlgorithm(_:));
- (void)setUserHashAlgorithm:(int)userIndex :(NSString*)newUserHashAlgorithm NS_SWIFT_NAME(setUserHashAlgorithm(_:_:));

- (int)userIncomingSpeedLimit:(int)userIndex NS_SWIFT_NAME(userIncomingSpeedLimit(_:));
- (void)setUserIncomingSpeedLimit:(int)userIndex :(int)newUserIncomingSpeedLimit NS_SWIFT_NAME(setUserIncomingSpeedLimit(_:_:));

- (int)userOtpAlgorithm:(int)userIndex NS_SWIFT_NAME(userOtpAlgorithm(_:));
- (void)setUserOtpAlgorithm:(int)userIndex :(int)newUserOtpAlgorithm NS_SWIFT_NAME(setUserOtpAlgorithm(_:_:));

- (int)userOTPLen:(int)userIndex NS_SWIFT_NAME(userOTPLen(_:));
- (void)setUserOTPLen:(int)userIndex :(int)newUserOTPLen NS_SWIFT_NAME(setUserOTPLen(_:_:));

- (int)userOtpValue:(int)userIndex NS_SWIFT_NAME(userOtpValue(_:));
- (void)setUserOtpValue:(int)userIndex :(int)newUserOtpValue NS_SWIFT_NAME(setUserOtpValue(_:_:));

- (int)userOutgoingSpeedLimit:(int)userIndex NS_SWIFT_NAME(userOutgoingSpeedLimit(_:));
- (void)setUserOutgoingSpeedLimit:(int)userIndex :(int)newUserOutgoingSpeedLimit NS_SWIFT_NAME(setUserOutgoingSpeedLimit(_:_:));

- (NSString*)userPassword:(int)userIndex NS_SWIFT_NAME(userPassword(_:));
- (void)setUserPassword:(int)userIndex :(NSString*)newUserPassword NS_SWIFT_NAME(setUserPassword(_:_:));

- (NSData*)userSharedSecret:(int)userIndex NS_SWIFT_NAME(userSharedSecret(_:));
- (void)setUserSharedSecret:(int)userIndex :(NSData*)newUserSharedSecret NS_SWIFT_NAME(setUserSharedSecret(_:_:));

- (NSData*)userSSHKey:(int)userIndex NS_SWIFT_NAME(userSSHKey(_:));
- (void)setUserSSHKey:(int)userIndex :(NSData*)newUserSSHKey NS_SWIFT_NAME(setUserSSHKey(_:_:));

- (NSString*)userUsername:(int)userIndex NS_SWIFT_NAME(userUsername(_:));
- (void)setUserUsername:(int)userIndex :(NSString*)newUserUsername NS_SWIFT_NAME(setUserUsername(_:_:));

@property (nonatomic,readwrite,assign,getter=useUTF8,setter=setUseUTF8:) BOOL useUTF8 NS_SWIFT_NAME(useUTF8);

- (BOOL)useUTF8 NS_SWIFT_NAME(useUTF8());
- (void)setUseUTF8 :(BOOL)newUseUTF8 NS_SWIFT_NAME(setUseUTF8(_:));

  /* Methods */

- (void)cleanup NS_SWIFT_NAME(cleanup());

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (void)dropClient:(long long)connectionId :(BOOL)forced NS_SWIFT_NAME(dropClient(_:_:));

- (NSData*)getClientBuffer:(long long)connectionID :(NSString*)handle NS_SWIFT_NAME(getClientBuffer(_:_:));

- (void)getClientFileEntry:(long long)connectionID :(NSString*)handle NS_SWIFT_NAME(getClientFileEntry(_:_:));

- (NSString*)listClients NS_SWIFT_NAME(listClients());

- (void)pinClient:(long long)connectionId NS_SWIFT_NAME(pinClient(_:));

- (void)reset NS_SWIFT_NAME(reset());

- (void)setClientBuffer:(long long)connectionID :(NSString*)handle :(NSData*)value NS_SWIFT_NAME(setClientBuffer(_:_:_:));

- (void)setClientFileEntry:(long long)connectionID :(NSString*)handle NS_SWIFT_NAME(setClientFileEntry(_:_:));

- (void)start NS_SWIFT_NAME(start());

- (void)stop NS_SWIFT_NAME(stop());

@end

