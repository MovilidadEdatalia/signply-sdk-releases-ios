/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//ARCHIVETYPES
#define AFT_UNKNOWN                                        0

#define AFT_ZIP                                            1

#define AFT_GZIP                                           2

#define AFT_BZIP_2                                         3

#define AFT_TAR                                            4

#define AFT_TAR_GZIP                                       5

#define AFT_TAR_BZIP_2                                     6

#define AFT_SFX                                            7

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

//ENCRYPTIONTYPES
#define AET_DEFAULT                                        0

#define AET_NO_ENCRYPTION                                  1

#define AET_GENERIC                                        2

#define AET_WIN_ZIP                                        3

#define AET_STRONG                                         4

//ACTIONS
#define AT_ADD                                             0

#define AT_KEEP                                            1

#define AT_UPDATE                                          2

#define AT_DELETE                                          3

#define AT_EXTRACT                                         4

#define AT_SKIP                                            5

//FILEDATASOURCES
#define FDS_FILE                                           0

#define FDS_STREAM                                         1

#define FDS_BUFFER                                         2

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxArchiveWriterDelegate <NSObject>
@optional
- (void)onActionNeeded:(int)whatFor :(NSString*)entryPath :(NSString*)destPath :(NSString*)description :(int*)action NS_SWIFT_NAME(onActionNeeded(_:_:_:_:_:));

- (void)onAfterCompressFile:(NSString*)path :(long long)fileSize :(int)dataSource NS_SWIFT_NAME(onAfterCompressFile(_:_:_:));

- (void)onBeforeCompressFile:(NSString*)path :(long long)fileSize :(int)dataSource NS_SWIFT_NAME(onBeforeCompressFile(_:_:_:));

- (void)onDecryptionPasswordNeeded:(NSString*)passwordTarget :(int*)cancel NS_SWIFT_NAME(onDecryptionPasswordNeeded(_:_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onPrepareFile:(NSString*)path :(long long)fileSize :(int*)dataSource :(NSString**)localPath :(int*)action NS_SWIFT_NAME(onPrepareFile(_:_:_:_:_:));

- (void)onProgress:(long long)processed :(long long)total :(long long)overallProcessed :(long long)overallTotal :(int*)cancel NS_SWIFT_NAME(onProgress(_:_:_:_:_:));

- (void)onRecipientFound:(NSString*)publicKeyHash :(BOOL)certFound NS_SWIFT_NAME(onRecipientFound(_:_:));

@end

@interface SecureBlackboxArchiveWriter : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxArchiveWriterDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasActionNeeded;

  BOOL m_delegateHasAfterCompressFile;

  BOOL m_delegateHasBeforeCompressFile;

  BOOL m_delegateHasDecryptionPasswordNeeded;

  BOOL m_delegateHasError;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasPrepareFile;

  BOOL m_delegateHasProgress;

  BOOL m_delegateHasRecipientFound;

}

+ (SecureBlackboxArchiveWriter*)archivewriter;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxArchiveWriterDelegate> delegate;
- (id <SecureBlackboxArchiveWriterDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxArchiveWriterDelegate>)anObject;

  /* Events */

- (void)onActionNeeded:(int)whatFor :(NSString*)entryPath :(NSString*)destPath :(NSString*)description :(int*)action NS_SWIFT_NAME(onActionNeeded(_:_:_:_:_:));

- (void)onAfterCompressFile:(NSString*)path :(long long)fileSize :(int)dataSource NS_SWIFT_NAME(onAfterCompressFile(_:_:_:));

- (void)onBeforeCompressFile:(NSString*)path :(long long)fileSize :(int)dataSource NS_SWIFT_NAME(onBeforeCompressFile(_:_:_:));

- (void)onDecryptionPasswordNeeded:(NSString*)passwordTarget :(int*)cancel NS_SWIFT_NAME(onDecryptionPasswordNeeded(_:_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onPrepareFile:(NSString*)path :(long long)fileSize :(int*)dataSource :(NSString**)localPath :(int*)action NS_SWIFT_NAME(onPrepareFile(_:_:_:_:_:));

- (void)onProgress:(long long)processed :(long long)total :(long long)overallProcessed :(long long)overallTotal :(int*)cancel NS_SWIFT_NAME(onProgress(_:_:_:_:_:));

- (void)onRecipientFound:(NSString*)publicKeyHash :(BOOL)certFound NS_SWIFT_NAME(onRecipientFound(_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readonly,assign,getter=archiveType) int archiveType NS_SWIFT_NAME(archiveType);

- (int)archiveType NS_SWIFT_NAME(archiveType());

@property (nonatomic,readwrite,assign,getter=compressionAlgorithm,setter=setCompressionAlgorithm:) int compressionAlgorithm NS_SWIFT_NAME(compressionAlgorithm);

- (int)compressionAlgorithm NS_SWIFT_NAME(compressionAlgorithm());
- (void)setCompressionAlgorithm :(int)newCompressionAlgorithm NS_SWIFT_NAME(setCompressionAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=compressionLevel,setter=setCompressionLevel:) int compressionLevel NS_SWIFT_NAME(compressionLevel);

- (int)compressionLevel NS_SWIFT_NAME(compressionLevel());
- (void)setCompressionLevel :(int)newCompressionLevel NS_SWIFT_NAME(setCompressionLevel(_:));

@property (nonatomic,readwrite,assign,getter=decryptionCertCount,setter=setDecryptionCertCount:) int decryptionCertCount NS_SWIFT_NAME(decryptionCertCount);

- (int)decryptionCertCount NS_SWIFT_NAME(decryptionCertCount());
- (void)setDecryptionCertCount :(int)newDecryptionCertCount NS_SWIFT_NAME(setDecryptionCertCount(_:));

- (NSData*)decryptionCertBytes:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertBytes(_:));

- (BOOL)decryptionCertCA:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertCA(_:));
- (void)setDecryptionCertCA:(int)decryptionCertIndex :(BOOL)newDecryptionCertCA NS_SWIFT_NAME(setDecryptionCertCA(_:_:));

- (NSData*)decryptionCertCAKeyID:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertCAKeyID(_:));

- (int)decryptionCertCertType:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertCertType(_:));

- (NSString*)decryptionCertCRLDistributionPoints:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertCRLDistributionPoints(_:));
- (void)setDecryptionCertCRLDistributionPoints:(int)decryptionCertIndex :(NSString*)newDecryptionCertCRLDistributionPoints NS_SWIFT_NAME(setDecryptionCertCRLDistributionPoints(_:_:));

- (NSString*)decryptionCertCurve:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertCurve(_:));
- (void)setDecryptionCertCurve:(int)decryptionCertIndex :(NSString*)newDecryptionCertCurve NS_SWIFT_NAME(setDecryptionCertCurve(_:_:));

- (NSString*)decryptionCertFingerprint:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertFingerprint(_:));

- (NSString*)decryptionCertFriendlyName:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertFriendlyName(_:));

- (long long)decryptionCertHandle:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertHandle(_:));
- (void)setDecryptionCertHandle:(int)decryptionCertIndex :(long long)newDecryptionCertHandle NS_SWIFT_NAME(setDecryptionCertHandle(_:_:));

- (NSString*)decryptionCertHashAlgorithm:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertHashAlgorithm(_:));
- (void)setDecryptionCertHashAlgorithm:(int)decryptionCertIndex :(NSString*)newDecryptionCertHashAlgorithm NS_SWIFT_NAME(setDecryptionCertHashAlgorithm(_:_:));

- (NSString*)decryptionCertIssuer:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertIssuer(_:));

- (NSString*)decryptionCertIssuerRDN:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertIssuerRDN(_:));
- (void)setDecryptionCertIssuerRDN:(int)decryptionCertIndex :(NSString*)newDecryptionCertIssuerRDN NS_SWIFT_NAME(setDecryptionCertIssuerRDN(_:_:));

- (NSString*)decryptionCertKeyAlgorithm:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertKeyAlgorithm(_:));
- (void)setDecryptionCertKeyAlgorithm:(int)decryptionCertIndex :(NSString*)newDecryptionCertKeyAlgorithm NS_SWIFT_NAME(setDecryptionCertKeyAlgorithm(_:_:));

- (int)decryptionCertKeyBits:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertKeyBits(_:));

- (NSString*)decryptionCertKeyFingerprint:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertKeyFingerprint(_:));

- (int)decryptionCertKeyUsage:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertKeyUsage(_:));
- (void)setDecryptionCertKeyUsage:(int)decryptionCertIndex :(int)newDecryptionCertKeyUsage NS_SWIFT_NAME(setDecryptionCertKeyUsage(_:_:));

- (BOOL)decryptionCertKeyValid:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertKeyValid(_:));

- (NSString*)decryptionCertOCSPLocations:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertOCSPLocations(_:));
- (void)setDecryptionCertOCSPLocations:(int)decryptionCertIndex :(NSString*)newDecryptionCertOCSPLocations NS_SWIFT_NAME(setDecryptionCertOCSPLocations(_:_:));

- (BOOL)decryptionCertOCSPNoCheck:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertOCSPNoCheck(_:));
- (void)setDecryptionCertOCSPNoCheck:(int)decryptionCertIndex :(BOOL)newDecryptionCertOCSPNoCheck NS_SWIFT_NAME(setDecryptionCertOCSPNoCheck(_:_:));

- (int)decryptionCertOrigin:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertOrigin(_:));

- (NSString*)decryptionCertPolicyIDs:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertPolicyIDs(_:));
- (void)setDecryptionCertPolicyIDs:(int)decryptionCertIndex :(NSString*)newDecryptionCertPolicyIDs NS_SWIFT_NAME(setDecryptionCertPolicyIDs(_:_:));

- (NSData*)decryptionCertPrivateKeyBytes:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertPrivateKeyBytes(_:));

- (BOOL)decryptionCertPrivateKeyExists:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertPrivateKeyExists(_:));

- (BOOL)decryptionCertPrivateKeyExtractable:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertPrivateKeyExtractable(_:));

- (NSData*)decryptionCertPublicKeyBytes:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertPublicKeyBytes(_:));

- (BOOL)decryptionCertQualified:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertQualified(_:));

- (int)decryptionCertQualifiedStatements:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertQualifiedStatements(_:));
- (void)setDecryptionCertQualifiedStatements:(int)decryptionCertIndex :(int)newDecryptionCertQualifiedStatements NS_SWIFT_NAME(setDecryptionCertQualifiedStatements(_:_:));

- (NSString*)decryptionCertQualifiers:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertQualifiers(_:));

- (BOOL)decryptionCertSelfSigned:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertSelfSigned(_:));

- (NSData*)decryptionCertSerialNumber:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertSerialNumber(_:));
- (void)setDecryptionCertSerialNumber:(int)decryptionCertIndex :(NSData*)newDecryptionCertSerialNumber NS_SWIFT_NAME(setDecryptionCertSerialNumber(_:_:));

- (NSString*)decryptionCertSigAlgorithm:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertSigAlgorithm(_:));

- (int)decryptionCertSource:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertSource(_:));

- (NSString*)decryptionCertSubject:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertSubject(_:));

- (NSString*)decryptionCertSubjectAlternativeName:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertSubjectAlternativeName(_:));
- (void)setDecryptionCertSubjectAlternativeName:(int)decryptionCertIndex :(NSString*)newDecryptionCertSubjectAlternativeName NS_SWIFT_NAME(setDecryptionCertSubjectAlternativeName(_:_:));

- (NSData*)decryptionCertSubjectKeyID:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertSubjectKeyID(_:));
- (void)setDecryptionCertSubjectKeyID:(int)decryptionCertIndex :(NSData*)newDecryptionCertSubjectKeyID NS_SWIFT_NAME(setDecryptionCertSubjectKeyID(_:_:));

- (NSString*)decryptionCertSubjectRDN:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertSubjectRDN(_:));
- (void)setDecryptionCertSubjectRDN:(int)decryptionCertIndex :(NSString*)newDecryptionCertSubjectRDN NS_SWIFT_NAME(setDecryptionCertSubjectRDN(_:_:));

- (BOOL)decryptionCertValid:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertValid(_:));

- (NSString*)decryptionCertValidFrom:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertValidFrom(_:));
- (void)setDecryptionCertValidFrom:(int)decryptionCertIndex :(NSString*)newDecryptionCertValidFrom NS_SWIFT_NAME(setDecryptionCertValidFrom(_:_:));

- (NSString*)decryptionCertValidTo:(int)decryptionCertIndex NS_SWIFT_NAME(decryptionCertValidTo(_:));
- (void)setDecryptionCertValidTo:(int)decryptionCertIndex :(NSString*)newDecryptionCertValidTo NS_SWIFT_NAME(setDecryptionCertValidTo(_:_:));

@property (nonatomic,readwrite,assign,getter=decryptionPassword,setter=setDecryptionPassword:) NSString* decryptionPassword NS_SWIFT_NAME(decryptionPassword);

- (NSString*)decryptionPassword NS_SWIFT_NAME(decryptionPassword());
- (void)setDecryptionPassword :(NSString*)newDecryptionPassword NS_SWIFT_NAME(setDecryptionPassword(_:));

@property (nonatomic,readwrite,assign,getter=encryptionAlgorithm,setter=setEncryptionAlgorithm:) NSString* encryptionAlgorithm NS_SWIFT_NAME(encryptionAlgorithm);

- (NSString*)encryptionAlgorithm NS_SWIFT_NAME(encryptionAlgorithm());
- (void)setEncryptionAlgorithm :(NSString*)newEncryptionAlgorithm NS_SWIFT_NAME(setEncryptionAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertBytes) NSData* encryptionCertBytes NS_SWIFT_NAME(encryptionCertBytes);

- (NSData*)encryptionCertBytes NS_SWIFT_NAME(encryptionCertBytes());

@property (nonatomic,readwrite,assign,getter=encryptionCertCA,setter=setEncryptionCertCA:) BOOL encryptionCertCA NS_SWIFT_NAME(encryptionCertCA);

- (BOOL)encryptionCertCA NS_SWIFT_NAME(encryptionCertCA());
- (void)setEncryptionCertCA :(BOOL)newEncryptionCertCA NS_SWIFT_NAME(setEncryptionCertCA(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertCAKeyID) NSData* encryptionCertCAKeyID NS_SWIFT_NAME(encryptionCertCAKeyID);

- (NSData*)encryptionCertCAKeyID NS_SWIFT_NAME(encryptionCertCAKeyID());

@property (nonatomic,readonly,assign,getter=encryptionCertCertType) int encryptionCertCertType NS_SWIFT_NAME(encryptionCertCertType);

- (int)encryptionCertCertType NS_SWIFT_NAME(encryptionCertCertType());

@property (nonatomic,readwrite,assign,getter=encryptionCertCRLDistributionPoints,setter=setEncryptionCertCRLDistributionPoints:) NSString* encryptionCertCRLDistributionPoints NS_SWIFT_NAME(encryptionCertCRLDistributionPoints);

- (NSString*)encryptionCertCRLDistributionPoints NS_SWIFT_NAME(encryptionCertCRLDistributionPoints());
- (void)setEncryptionCertCRLDistributionPoints :(NSString*)newEncryptionCertCRLDistributionPoints NS_SWIFT_NAME(setEncryptionCertCRLDistributionPoints(_:));

@property (nonatomic,readwrite,assign,getter=encryptionCertCurve,setter=setEncryptionCertCurve:) NSString* encryptionCertCurve NS_SWIFT_NAME(encryptionCertCurve);

- (NSString*)encryptionCertCurve NS_SWIFT_NAME(encryptionCertCurve());
- (void)setEncryptionCertCurve :(NSString*)newEncryptionCertCurve NS_SWIFT_NAME(setEncryptionCertCurve(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertFingerprint) NSString* encryptionCertFingerprint NS_SWIFT_NAME(encryptionCertFingerprint);

- (NSString*)encryptionCertFingerprint NS_SWIFT_NAME(encryptionCertFingerprint());

@property (nonatomic,readonly,assign,getter=encryptionCertFriendlyName) NSString* encryptionCertFriendlyName NS_SWIFT_NAME(encryptionCertFriendlyName);

- (NSString*)encryptionCertFriendlyName NS_SWIFT_NAME(encryptionCertFriendlyName());

@property (nonatomic,readwrite,assign,getter=encryptionCertHandle,setter=setEncryptionCertHandle:) long long encryptionCertHandle NS_SWIFT_NAME(encryptionCertHandle);

- (long long)encryptionCertHandle NS_SWIFT_NAME(encryptionCertHandle());
- (void)setEncryptionCertHandle :(long long)newEncryptionCertHandle NS_SWIFT_NAME(setEncryptionCertHandle(_:));

@property (nonatomic,readwrite,assign,getter=encryptionCertHashAlgorithm,setter=setEncryptionCertHashAlgorithm:) NSString* encryptionCertHashAlgorithm NS_SWIFT_NAME(encryptionCertHashAlgorithm);

- (NSString*)encryptionCertHashAlgorithm NS_SWIFT_NAME(encryptionCertHashAlgorithm());
- (void)setEncryptionCertHashAlgorithm :(NSString*)newEncryptionCertHashAlgorithm NS_SWIFT_NAME(setEncryptionCertHashAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertIssuer) NSString* encryptionCertIssuer NS_SWIFT_NAME(encryptionCertIssuer);

- (NSString*)encryptionCertIssuer NS_SWIFT_NAME(encryptionCertIssuer());

@property (nonatomic,readwrite,assign,getter=encryptionCertIssuerRDN,setter=setEncryptionCertIssuerRDN:) NSString* encryptionCertIssuerRDN NS_SWIFT_NAME(encryptionCertIssuerRDN);

- (NSString*)encryptionCertIssuerRDN NS_SWIFT_NAME(encryptionCertIssuerRDN());
- (void)setEncryptionCertIssuerRDN :(NSString*)newEncryptionCertIssuerRDN NS_SWIFT_NAME(setEncryptionCertIssuerRDN(_:));

@property (nonatomic,readwrite,assign,getter=encryptionCertKeyAlgorithm,setter=setEncryptionCertKeyAlgorithm:) NSString* encryptionCertKeyAlgorithm NS_SWIFT_NAME(encryptionCertKeyAlgorithm);

- (NSString*)encryptionCertKeyAlgorithm NS_SWIFT_NAME(encryptionCertKeyAlgorithm());
- (void)setEncryptionCertKeyAlgorithm :(NSString*)newEncryptionCertKeyAlgorithm NS_SWIFT_NAME(setEncryptionCertKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertKeyBits) int encryptionCertKeyBits NS_SWIFT_NAME(encryptionCertKeyBits);

- (int)encryptionCertKeyBits NS_SWIFT_NAME(encryptionCertKeyBits());

@property (nonatomic,readonly,assign,getter=encryptionCertKeyFingerprint) NSString* encryptionCertKeyFingerprint NS_SWIFT_NAME(encryptionCertKeyFingerprint);

- (NSString*)encryptionCertKeyFingerprint NS_SWIFT_NAME(encryptionCertKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=encryptionCertKeyUsage,setter=setEncryptionCertKeyUsage:) int encryptionCertKeyUsage NS_SWIFT_NAME(encryptionCertKeyUsage);

- (int)encryptionCertKeyUsage NS_SWIFT_NAME(encryptionCertKeyUsage());
- (void)setEncryptionCertKeyUsage :(int)newEncryptionCertKeyUsage NS_SWIFT_NAME(setEncryptionCertKeyUsage(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertKeyValid) BOOL encryptionCertKeyValid NS_SWIFT_NAME(encryptionCertKeyValid);

- (BOOL)encryptionCertKeyValid NS_SWIFT_NAME(encryptionCertKeyValid());

@property (nonatomic,readwrite,assign,getter=encryptionCertOCSPLocations,setter=setEncryptionCertOCSPLocations:) NSString* encryptionCertOCSPLocations NS_SWIFT_NAME(encryptionCertOCSPLocations);

- (NSString*)encryptionCertOCSPLocations NS_SWIFT_NAME(encryptionCertOCSPLocations());
- (void)setEncryptionCertOCSPLocations :(NSString*)newEncryptionCertOCSPLocations NS_SWIFT_NAME(setEncryptionCertOCSPLocations(_:));

@property (nonatomic,readwrite,assign,getter=encryptionCertOCSPNoCheck,setter=setEncryptionCertOCSPNoCheck:) BOOL encryptionCertOCSPNoCheck NS_SWIFT_NAME(encryptionCertOCSPNoCheck);

- (BOOL)encryptionCertOCSPNoCheck NS_SWIFT_NAME(encryptionCertOCSPNoCheck());
- (void)setEncryptionCertOCSPNoCheck :(BOOL)newEncryptionCertOCSPNoCheck NS_SWIFT_NAME(setEncryptionCertOCSPNoCheck(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertOrigin) int encryptionCertOrigin NS_SWIFT_NAME(encryptionCertOrigin);

- (int)encryptionCertOrigin NS_SWIFT_NAME(encryptionCertOrigin());

@property (nonatomic,readwrite,assign,getter=encryptionCertPolicyIDs,setter=setEncryptionCertPolicyIDs:) NSString* encryptionCertPolicyIDs NS_SWIFT_NAME(encryptionCertPolicyIDs);

- (NSString*)encryptionCertPolicyIDs NS_SWIFT_NAME(encryptionCertPolicyIDs());
- (void)setEncryptionCertPolicyIDs :(NSString*)newEncryptionCertPolicyIDs NS_SWIFT_NAME(setEncryptionCertPolicyIDs(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertPrivateKeyBytes) NSData* encryptionCertPrivateKeyBytes NS_SWIFT_NAME(encryptionCertPrivateKeyBytes);

- (NSData*)encryptionCertPrivateKeyBytes NS_SWIFT_NAME(encryptionCertPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=encryptionCertPrivateKeyExists) BOOL encryptionCertPrivateKeyExists NS_SWIFT_NAME(encryptionCertPrivateKeyExists);

- (BOOL)encryptionCertPrivateKeyExists NS_SWIFT_NAME(encryptionCertPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=encryptionCertPrivateKeyExtractable) BOOL encryptionCertPrivateKeyExtractable NS_SWIFT_NAME(encryptionCertPrivateKeyExtractable);

- (BOOL)encryptionCertPrivateKeyExtractable NS_SWIFT_NAME(encryptionCertPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=encryptionCertPublicKeyBytes) NSData* encryptionCertPublicKeyBytes NS_SWIFT_NAME(encryptionCertPublicKeyBytes);

- (NSData*)encryptionCertPublicKeyBytes NS_SWIFT_NAME(encryptionCertPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=encryptionCertQualified) BOOL encryptionCertQualified NS_SWIFT_NAME(encryptionCertQualified);

- (BOOL)encryptionCertQualified NS_SWIFT_NAME(encryptionCertQualified());

@property (nonatomic,readwrite,assign,getter=encryptionCertQualifiedStatements,setter=setEncryptionCertQualifiedStatements:) int encryptionCertQualifiedStatements NS_SWIFT_NAME(encryptionCertQualifiedStatements);

- (int)encryptionCertQualifiedStatements NS_SWIFT_NAME(encryptionCertQualifiedStatements());
- (void)setEncryptionCertQualifiedStatements :(int)newEncryptionCertQualifiedStatements NS_SWIFT_NAME(setEncryptionCertQualifiedStatements(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertQualifiers) NSString* encryptionCertQualifiers NS_SWIFT_NAME(encryptionCertQualifiers);

- (NSString*)encryptionCertQualifiers NS_SWIFT_NAME(encryptionCertQualifiers());

@property (nonatomic,readonly,assign,getter=encryptionCertSelfSigned) BOOL encryptionCertSelfSigned NS_SWIFT_NAME(encryptionCertSelfSigned);

- (BOOL)encryptionCertSelfSigned NS_SWIFT_NAME(encryptionCertSelfSigned());

@property (nonatomic,readwrite,assign,getter=encryptionCertSerialNumber,setter=setEncryptionCertSerialNumber:) NSData* encryptionCertSerialNumber NS_SWIFT_NAME(encryptionCertSerialNumber);

- (NSData*)encryptionCertSerialNumber NS_SWIFT_NAME(encryptionCertSerialNumber());
- (void)setEncryptionCertSerialNumber :(NSData*)newEncryptionCertSerialNumber NS_SWIFT_NAME(setEncryptionCertSerialNumber(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertSigAlgorithm) NSString* encryptionCertSigAlgorithm NS_SWIFT_NAME(encryptionCertSigAlgorithm);

- (NSString*)encryptionCertSigAlgorithm NS_SWIFT_NAME(encryptionCertSigAlgorithm());

@property (nonatomic,readonly,assign,getter=encryptionCertSource) int encryptionCertSource NS_SWIFT_NAME(encryptionCertSource);

- (int)encryptionCertSource NS_SWIFT_NAME(encryptionCertSource());

@property (nonatomic,readonly,assign,getter=encryptionCertSubject) NSString* encryptionCertSubject NS_SWIFT_NAME(encryptionCertSubject);

- (NSString*)encryptionCertSubject NS_SWIFT_NAME(encryptionCertSubject());

@property (nonatomic,readwrite,assign,getter=encryptionCertSubjectAlternativeName,setter=setEncryptionCertSubjectAlternativeName:) NSString* encryptionCertSubjectAlternativeName NS_SWIFT_NAME(encryptionCertSubjectAlternativeName);

- (NSString*)encryptionCertSubjectAlternativeName NS_SWIFT_NAME(encryptionCertSubjectAlternativeName());
- (void)setEncryptionCertSubjectAlternativeName :(NSString*)newEncryptionCertSubjectAlternativeName NS_SWIFT_NAME(setEncryptionCertSubjectAlternativeName(_:));

@property (nonatomic,readwrite,assign,getter=encryptionCertSubjectKeyID,setter=setEncryptionCertSubjectKeyID:) NSData* encryptionCertSubjectKeyID NS_SWIFT_NAME(encryptionCertSubjectKeyID);

- (NSData*)encryptionCertSubjectKeyID NS_SWIFT_NAME(encryptionCertSubjectKeyID());
- (void)setEncryptionCertSubjectKeyID :(NSData*)newEncryptionCertSubjectKeyID NS_SWIFT_NAME(setEncryptionCertSubjectKeyID(_:));

@property (nonatomic,readwrite,assign,getter=encryptionCertSubjectRDN,setter=setEncryptionCertSubjectRDN:) NSString* encryptionCertSubjectRDN NS_SWIFT_NAME(encryptionCertSubjectRDN);

- (NSString*)encryptionCertSubjectRDN NS_SWIFT_NAME(encryptionCertSubjectRDN());
- (void)setEncryptionCertSubjectRDN :(NSString*)newEncryptionCertSubjectRDN NS_SWIFT_NAME(setEncryptionCertSubjectRDN(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertValid) BOOL encryptionCertValid NS_SWIFT_NAME(encryptionCertValid);

- (BOOL)encryptionCertValid NS_SWIFT_NAME(encryptionCertValid());

@property (nonatomic,readwrite,assign,getter=encryptionCertValidFrom,setter=setEncryptionCertValidFrom:) NSString* encryptionCertValidFrom NS_SWIFT_NAME(encryptionCertValidFrom);

- (NSString*)encryptionCertValidFrom NS_SWIFT_NAME(encryptionCertValidFrom());
- (void)setEncryptionCertValidFrom :(NSString*)newEncryptionCertValidFrom NS_SWIFT_NAME(setEncryptionCertValidFrom(_:));

@property (nonatomic,readwrite,assign,getter=encryptionCertValidTo,setter=setEncryptionCertValidTo:) NSString* encryptionCertValidTo NS_SWIFT_NAME(encryptionCertValidTo);

- (NSString*)encryptionCertValidTo NS_SWIFT_NAME(encryptionCertValidTo());
- (void)setEncryptionCertValidTo :(NSString*)newEncryptionCertValidTo NS_SWIFT_NAME(setEncryptionCertValidTo(_:));

@property (nonatomic,readwrite,assign,getter=encryptionKeyLength,setter=setEncryptionKeyLength:) int encryptionKeyLength NS_SWIFT_NAME(encryptionKeyLength);

- (int)encryptionKeyLength NS_SWIFT_NAME(encryptionKeyLength());
- (void)setEncryptionKeyLength :(int)newEncryptionKeyLength NS_SWIFT_NAME(setEncryptionKeyLength(_:));

@property (nonatomic,readwrite,assign,getter=encryptionPassword,setter=setEncryptionPassword:) NSString* encryptionPassword NS_SWIFT_NAME(encryptionPassword);

- (NSString*)encryptionPassword NS_SWIFT_NAME(encryptionPassword());
- (void)setEncryptionPassword :(NSString*)newEncryptionPassword NS_SWIFT_NAME(setEncryptionPassword(_:));

@property (nonatomic,readwrite,assign,getter=encryptionType,setter=setEncryptionType:) int encryptionType NS_SWIFT_NAME(encryptionType);

- (int)encryptionType NS_SWIFT_NAME(encryptionType());
- (void)setEncryptionType :(int)newEncryptionType NS_SWIFT_NAME(setEncryptionType(_:));

@property (nonatomic,readwrite,assign,getter=fileData,setter=setFileData:) NSData* fileData NS_SWIFT_NAME(fileData);

- (NSData*)fileData NS_SWIFT_NAME(fileData());
- (void)setFileData :(NSData*)newFileData NS_SWIFT_NAME(setFileData(_:));

@property (nonatomic,readwrite,assign,getter=fileCount,setter=setFileCount:) int fileCount NS_SWIFT_NAME(fileCount);

- (int)fileCount NS_SWIFT_NAME(fileCount());
- (void)setFileCount :(int)newFileCount NS_SWIFT_NAME(setFileCount(_:));

- (int)fileAction:(int)fileIndex NS_SWIFT_NAME(fileAction(_:));
- (void)setFileAction:(int)fileIndex :(int)newFileAction NS_SWIFT_NAME(setFileAction(_:_:));

- (NSString*)fileAttributes:(int)fileIndex NS_SWIFT_NAME(fileAttributes(_:));
- (void)setFileAttributes:(int)fileIndex :(NSString*)newFileAttributes NS_SWIFT_NAME(setFileAttributes(_:_:));

- (long long)fileCompressedSize:(int)fileIndex NS_SWIFT_NAME(fileCompressedSize(_:));

- (int)fileDataSource:(int)fileIndex NS_SWIFT_NAME(fileDataSource(_:));
- (void)setFileDataSource:(int)fileIndex :(int)newFileDataSource NS_SWIFT_NAME(setFileDataSource(_:_:));

- (BOOL)fileDirectory:(int)fileIndex NS_SWIFT_NAME(fileDirectory(_:));

- (NSString*)fileEncryptionAlgorithm:(int)fileIndex NS_SWIFT_NAME(fileEncryptionAlgorithm(_:));

- (int)fileEncryptionKeyLength:(int)fileIndex NS_SWIFT_NAME(fileEncryptionKeyLength(_:));

- (int)fileEncryptionType:(int)fileIndex NS_SWIFT_NAME(fileEncryptionType(_:));

- (NSString*)fileFileName:(int)fileIndex NS_SWIFT_NAME(fileFileName(_:));
- (void)setFileFileName:(int)fileIndex :(NSString*)newFileFileName NS_SWIFT_NAME(setFileFileName(_:_:));

- (NSString*)fileFolder:(int)fileIndex NS_SWIFT_NAME(fileFolder(_:));

- (NSString*)fileLocalPath:(int)fileIndex NS_SWIFT_NAME(fileLocalPath(_:));
- (void)setFileLocalPath:(int)fileIndex :(NSString*)newFileLocalPath NS_SWIFT_NAME(setFileLocalPath(_:_:));

- (NSString*)fileMTime:(int)fileIndex NS_SWIFT_NAME(fileMTime(_:));
- (void)setFileMTime:(int)fileIndex :(NSString*)newFileMTime NS_SWIFT_NAME(setFileMTime(_:_:));

- (BOOL)fileNewFile:(int)fileIndex NS_SWIFT_NAME(fileNewFile(_:));

- (NSString*)filePath:(int)fileIndex NS_SWIFT_NAME(filePath(_:));

- (int)fileSignatureCount:(int)fileIndex NS_SWIFT_NAME(fileSignatureCount(_:));

- (BOOL)fileSigned:(int)fileIndex NS_SWIFT_NAME(fileSigned(_:));

- (long long)fileSize:(int)fileIndex NS_SWIFT_NAME(fileSize(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=hashAlgorithm,setter=setHashAlgorithm:) NSString* hashAlgorithm NS_SWIFT_NAME(hashAlgorithm);

- (NSString*)hashAlgorithm NS_SWIFT_NAME(hashAlgorithm());
- (void)setHashAlgorithm :(NSString*)newHashAlgorithm NS_SWIFT_NAME(setHashAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=newArchive) BOOL newArchive NS_SWIFT_NAME(newArchive);

- (BOOL)newArchive NS_SWIFT_NAME(newArchive());

@property (nonatomic,readonly,assign,getter=opened) BOOL opened NS_SWIFT_NAME(opened);

- (BOOL)opened NS_SWIFT_NAME(opened());

@property (nonatomic,readwrite,assign,getter=overwrite,setter=setOverwrite:) BOOL overwrite NS_SWIFT_NAME(overwrite);

- (BOOL)overwrite NS_SWIFT_NAME(overwrite());
- (void)setOverwrite :(BOOL)newOverwrite NS_SWIFT_NAME(setOverwrite(_:));

@property (nonatomic,readonly,assign,getter=signingCertBytes) NSData* signingCertBytes NS_SWIFT_NAME(signingCertBytes);

- (NSData*)signingCertBytes NS_SWIFT_NAME(signingCertBytes());

@property (nonatomic,readwrite,assign,getter=signingCertCA,setter=setSigningCertCA:) BOOL signingCertCA NS_SWIFT_NAME(signingCertCA);

- (BOOL)signingCertCA NS_SWIFT_NAME(signingCertCA());
- (void)setSigningCertCA :(BOOL)newSigningCertCA NS_SWIFT_NAME(setSigningCertCA(_:));

@property (nonatomic,readonly,assign,getter=signingCertCAKeyID) NSData* signingCertCAKeyID NS_SWIFT_NAME(signingCertCAKeyID);

- (NSData*)signingCertCAKeyID NS_SWIFT_NAME(signingCertCAKeyID());

@property (nonatomic,readonly,assign,getter=signingCertCertType) int signingCertCertType NS_SWIFT_NAME(signingCertCertType);

- (int)signingCertCertType NS_SWIFT_NAME(signingCertCertType());

@property (nonatomic,readwrite,assign,getter=signingCertCRLDistributionPoints,setter=setSigningCertCRLDistributionPoints:) NSString* signingCertCRLDistributionPoints NS_SWIFT_NAME(signingCertCRLDistributionPoints);

- (NSString*)signingCertCRLDistributionPoints NS_SWIFT_NAME(signingCertCRLDistributionPoints());
- (void)setSigningCertCRLDistributionPoints :(NSString*)newSigningCertCRLDistributionPoints NS_SWIFT_NAME(setSigningCertCRLDistributionPoints(_:));

@property (nonatomic,readwrite,assign,getter=signingCertCurve,setter=setSigningCertCurve:) NSString* signingCertCurve NS_SWIFT_NAME(signingCertCurve);

- (NSString*)signingCertCurve NS_SWIFT_NAME(signingCertCurve());
- (void)setSigningCertCurve :(NSString*)newSigningCertCurve NS_SWIFT_NAME(setSigningCertCurve(_:));

@property (nonatomic,readonly,assign,getter=signingCertFingerprint) NSString* signingCertFingerprint NS_SWIFT_NAME(signingCertFingerprint);

- (NSString*)signingCertFingerprint NS_SWIFT_NAME(signingCertFingerprint());

@property (nonatomic,readonly,assign,getter=signingCertFriendlyName) NSString* signingCertFriendlyName NS_SWIFT_NAME(signingCertFriendlyName);

- (NSString*)signingCertFriendlyName NS_SWIFT_NAME(signingCertFriendlyName());

@property (nonatomic,readwrite,assign,getter=signingCertHandle,setter=setSigningCertHandle:) long long signingCertHandle NS_SWIFT_NAME(signingCertHandle);

- (long long)signingCertHandle NS_SWIFT_NAME(signingCertHandle());
- (void)setSigningCertHandle :(long long)newSigningCertHandle NS_SWIFT_NAME(setSigningCertHandle(_:));

@property (nonatomic,readwrite,assign,getter=signingCertHashAlgorithm,setter=setSigningCertHashAlgorithm:) NSString* signingCertHashAlgorithm NS_SWIFT_NAME(signingCertHashAlgorithm);

- (NSString*)signingCertHashAlgorithm NS_SWIFT_NAME(signingCertHashAlgorithm());
- (void)setSigningCertHashAlgorithm :(NSString*)newSigningCertHashAlgorithm NS_SWIFT_NAME(setSigningCertHashAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=signingCertIssuer) NSString* signingCertIssuer NS_SWIFT_NAME(signingCertIssuer);

- (NSString*)signingCertIssuer NS_SWIFT_NAME(signingCertIssuer());

@property (nonatomic,readwrite,assign,getter=signingCertIssuerRDN,setter=setSigningCertIssuerRDN:) NSString* signingCertIssuerRDN NS_SWIFT_NAME(signingCertIssuerRDN);

- (NSString*)signingCertIssuerRDN NS_SWIFT_NAME(signingCertIssuerRDN());
- (void)setSigningCertIssuerRDN :(NSString*)newSigningCertIssuerRDN NS_SWIFT_NAME(setSigningCertIssuerRDN(_:));

@property (nonatomic,readwrite,assign,getter=signingCertKeyAlgorithm,setter=setSigningCertKeyAlgorithm:) NSString* signingCertKeyAlgorithm NS_SWIFT_NAME(signingCertKeyAlgorithm);

- (NSString*)signingCertKeyAlgorithm NS_SWIFT_NAME(signingCertKeyAlgorithm());
- (void)setSigningCertKeyAlgorithm :(NSString*)newSigningCertKeyAlgorithm NS_SWIFT_NAME(setSigningCertKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=signingCertKeyBits) int signingCertKeyBits NS_SWIFT_NAME(signingCertKeyBits);

- (int)signingCertKeyBits NS_SWIFT_NAME(signingCertKeyBits());

@property (nonatomic,readonly,assign,getter=signingCertKeyFingerprint) NSString* signingCertKeyFingerprint NS_SWIFT_NAME(signingCertKeyFingerprint);

- (NSString*)signingCertKeyFingerprint NS_SWIFT_NAME(signingCertKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=signingCertKeyUsage,setter=setSigningCertKeyUsage:) int signingCertKeyUsage NS_SWIFT_NAME(signingCertKeyUsage);

- (int)signingCertKeyUsage NS_SWIFT_NAME(signingCertKeyUsage());
- (void)setSigningCertKeyUsage :(int)newSigningCertKeyUsage NS_SWIFT_NAME(setSigningCertKeyUsage(_:));

@property (nonatomic,readonly,assign,getter=signingCertKeyValid) BOOL signingCertKeyValid NS_SWIFT_NAME(signingCertKeyValid);

- (BOOL)signingCertKeyValid NS_SWIFT_NAME(signingCertKeyValid());

@property (nonatomic,readwrite,assign,getter=signingCertOCSPLocations,setter=setSigningCertOCSPLocations:) NSString* signingCertOCSPLocations NS_SWIFT_NAME(signingCertOCSPLocations);

- (NSString*)signingCertOCSPLocations NS_SWIFT_NAME(signingCertOCSPLocations());
- (void)setSigningCertOCSPLocations :(NSString*)newSigningCertOCSPLocations NS_SWIFT_NAME(setSigningCertOCSPLocations(_:));

@property (nonatomic,readwrite,assign,getter=signingCertOCSPNoCheck,setter=setSigningCertOCSPNoCheck:) BOOL signingCertOCSPNoCheck NS_SWIFT_NAME(signingCertOCSPNoCheck);

- (BOOL)signingCertOCSPNoCheck NS_SWIFT_NAME(signingCertOCSPNoCheck());
- (void)setSigningCertOCSPNoCheck :(BOOL)newSigningCertOCSPNoCheck NS_SWIFT_NAME(setSigningCertOCSPNoCheck(_:));

@property (nonatomic,readonly,assign,getter=signingCertOrigin) int signingCertOrigin NS_SWIFT_NAME(signingCertOrigin);

- (int)signingCertOrigin NS_SWIFT_NAME(signingCertOrigin());

@property (nonatomic,readwrite,assign,getter=signingCertPolicyIDs,setter=setSigningCertPolicyIDs:) NSString* signingCertPolicyIDs NS_SWIFT_NAME(signingCertPolicyIDs);

- (NSString*)signingCertPolicyIDs NS_SWIFT_NAME(signingCertPolicyIDs());
- (void)setSigningCertPolicyIDs :(NSString*)newSigningCertPolicyIDs NS_SWIFT_NAME(setSigningCertPolicyIDs(_:));

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyBytes) NSData* signingCertPrivateKeyBytes NS_SWIFT_NAME(signingCertPrivateKeyBytes);

- (NSData*)signingCertPrivateKeyBytes NS_SWIFT_NAME(signingCertPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyExists) BOOL signingCertPrivateKeyExists NS_SWIFT_NAME(signingCertPrivateKeyExists);

- (BOOL)signingCertPrivateKeyExists NS_SWIFT_NAME(signingCertPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyExtractable) BOOL signingCertPrivateKeyExtractable NS_SWIFT_NAME(signingCertPrivateKeyExtractable);

- (BOOL)signingCertPrivateKeyExtractable NS_SWIFT_NAME(signingCertPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=signingCertPublicKeyBytes) NSData* signingCertPublicKeyBytes NS_SWIFT_NAME(signingCertPublicKeyBytes);

- (NSData*)signingCertPublicKeyBytes NS_SWIFT_NAME(signingCertPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=signingCertQualified) BOOL signingCertQualified NS_SWIFT_NAME(signingCertQualified);

- (BOOL)signingCertQualified NS_SWIFT_NAME(signingCertQualified());

@property (nonatomic,readwrite,assign,getter=signingCertQualifiedStatements,setter=setSigningCertQualifiedStatements:) int signingCertQualifiedStatements NS_SWIFT_NAME(signingCertQualifiedStatements);

- (int)signingCertQualifiedStatements NS_SWIFT_NAME(signingCertQualifiedStatements());
- (void)setSigningCertQualifiedStatements :(int)newSigningCertQualifiedStatements NS_SWIFT_NAME(setSigningCertQualifiedStatements(_:));

@property (nonatomic,readonly,assign,getter=signingCertQualifiers) NSString* signingCertQualifiers NS_SWIFT_NAME(signingCertQualifiers);

- (NSString*)signingCertQualifiers NS_SWIFT_NAME(signingCertQualifiers());

@property (nonatomic,readonly,assign,getter=signingCertSelfSigned) BOOL signingCertSelfSigned NS_SWIFT_NAME(signingCertSelfSigned);

- (BOOL)signingCertSelfSigned NS_SWIFT_NAME(signingCertSelfSigned());

@property (nonatomic,readwrite,assign,getter=signingCertSerialNumber,setter=setSigningCertSerialNumber:) NSData* signingCertSerialNumber NS_SWIFT_NAME(signingCertSerialNumber);

- (NSData*)signingCertSerialNumber NS_SWIFT_NAME(signingCertSerialNumber());
- (void)setSigningCertSerialNumber :(NSData*)newSigningCertSerialNumber NS_SWIFT_NAME(setSigningCertSerialNumber(_:));

@property (nonatomic,readonly,assign,getter=signingCertSigAlgorithm) NSString* signingCertSigAlgorithm NS_SWIFT_NAME(signingCertSigAlgorithm);

- (NSString*)signingCertSigAlgorithm NS_SWIFT_NAME(signingCertSigAlgorithm());

@property (nonatomic,readonly,assign,getter=signingCertSource) int signingCertSource NS_SWIFT_NAME(signingCertSource);

- (int)signingCertSource NS_SWIFT_NAME(signingCertSource());

@property (nonatomic,readonly,assign,getter=signingCertSubject) NSString* signingCertSubject NS_SWIFT_NAME(signingCertSubject);

- (NSString*)signingCertSubject NS_SWIFT_NAME(signingCertSubject());

@property (nonatomic,readwrite,assign,getter=signingCertSubjectAlternativeName,setter=setSigningCertSubjectAlternativeName:) NSString* signingCertSubjectAlternativeName NS_SWIFT_NAME(signingCertSubjectAlternativeName);

- (NSString*)signingCertSubjectAlternativeName NS_SWIFT_NAME(signingCertSubjectAlternativeName());
- (void)setSigningCertSubjectAlternativeName :(NSString*)newSigningCertSubjectAlternativeName NS_SWIFT_NAME(setSigningCertSubjectAlternativeName(_:));

@property (nonatomic,readwrite,assign,getter=signingCertSubjectKeyID,setter=setSigningCertSubjectKeyID:) NSData* signingCertSubjectKeyID NS_SWIFT_NAME(signingCertSubjectKeyID);

- (NSData*)signingCertSubjectKeyID NS_SWIFT_NAME(signingCertSubjectKeyID());
- (void)setSigningCertSubjectKeyID :(NSData*)newSigningCertSubjectKeyID NS_SWIFT_NAME(setSigningCertSubjectKeyID(_:));

@property (nonatomic,readwrite,assign,getter=signingCertSubjectRDN,setter=setSigningCertSubjectRDN:) NSString* signingCertSubjectRDN NS_SWIFT_NAME(signingCertSubjectRDN);

- (NSString*)signingCertSubjectRDN NS_SWIFT_NAME(signingCertSubjectRDN());
- (void)setSigningCertSubjectRDN :(NSString*)newSigningCertSubjectRDN NS_SWIFT_NAME(setSigningCertSubjectRDN(_:));

@property (nonatomic,readonly,assign,getter=signingCertValid) BOOL signingCertValid NS_SWIFT_NAME(signingCertValid);

- (BOOL)signingCertValid NS_SWIFT_NAME(signingCertValid());

@property (nonatomic,readwrite,assign,getter=signingCertValidFrom,setter=setSigningCertValidFrom:) NSString* signingCertValidFrom NS_SWIFT_NAME(signingCertValidFrom);

- (NSString*)signingCertValidFrom NS_SWIFT_NAME(signingCertValidFrom());
- (void)setSigningCertValidFrom :(NSString*)newSigningCertValidFrom NS_SWIFT_NAME(setSigningCertValidFrom(_:));

@property (nonatomic,readwrite,assign,getter=signingCertValidTo,setter=setSigningCertValidTo:) NSString* signingCertValidTo NS_SWIFT_NAME(signingCertValidTo);

- (NSString*)signingCertValidTo NS_SWIFT_NAME(signingCertValidTo());
- (void)setSigningCertValidTo :(NSString*)newSigningCertValidTo NS_SWIFT_NAME(setSigningCertValidTo(_:));

@property (nonatomic,readwrite,assign,getter=signingChainCount,setter=setSigningChainCount:) int signingChainCount NS_SWIFT_NAME(signingChainCount);

- (int)signingChainCount NS_SWIFT_NAME(signingChainCount());
- (void)setSigningChainCount :(int)newSigningChainCount NS_SWIFT_NAME(setSigningChainCount(_:));

- (NSData*)signingChainBytes:(int)signingChainIndex NS_SWIFT_NAME(signingChainBytes(_:));

- (BOOL)signingChainCA:(int)signingChainIndex NS_SWIFT_NAME(signingChainCA(_:));
- (void)setSigningChainCA:(int)signingChainIndex :(BOOL)newSigningChainCA NS_SWIFT_NAME(setSigningChainCA(_:_:));

- (NSData*)signingChainCAKeyID:(int)signingChainIndex NS_SWIFT_NAME(signingChainCAKeyID(_:));

- (int)signingChainCertType:(int)signingChainIndex NS_SWIFT_NAME(signingChainCertType(_:));

- (NSString*)signingChainCRLDistributionPoints:(int)signingChainIndex NS_SWIFT_NAME(signingChainCRLDistributionPoints(_:));
- (void)setSigningChainCRLDistributionPoints:(int)signingChainIndex :(NSString*)newSigningChainCRLDistributionPoints NS_SWIFT_NAME(setSigningChainCRLDistributionPoints(_:_:));

- (NSString*)signingChainCurve:(int)signingChainIndex NS_SWIFT_NAME(signingChainCurve(_:));
- (void)setSigningChainCurve:(int)signingChainIndex :(NSString*)newSigningChainCurve NS_SWIFT_NAME(setSigningChainCurve(_:_:));

- (NSString*)signingChainFingerprint:(int)signingChainIndex NS_SWIFT_NAME(signingChainFingerprint(_:));

- (NSString*)signingChainFriendlyName:(int)signingChainIndex NS_SWIFT_NAME(signingChainFriendlyName(_:));

- (long long)signingChainHandle:(int)signingChainIndex NS_SWIFT_NAME(signingChainHandle(_:));
- (void)setSigningChainHandle:(int)signingChainIndex :(long long)newSigningChainHandle NS_SWIFT_NAME(setSigningChainHandle(_:_:));

- (NSString*)signingChainHashAlgorithm:(int)signingChainIndex NS_SWIFT_NAME(signingChainHashAlgorithm(_:));
- (void)setSigningChainHashAlgorithm:(int)signingChainIndex :(NSString*)newSigningChainHashAlgorithm NS_SWIFT_NAME(setSigningChainHashAlgorithm(_:_:));

- (NSString*)signingChainIssuer:(int)signingChainIndex NS_SWIFT_NAME(signingChainIssuer(_:));

- (NSString*)signingChainIssuerRDN:(int)signingChainIndex NS_SWIFT_NAME(signingChainIssuerRDN(_:));
- (void)setSigningChainIssuerRDN:(int)signingChainIndex :(NSString*)newSigningChainIssuerRDN NS_SWIFT_NAME(setSigningChainIssuerRDN(_:_:));

- (NSString*)signingChainKeyAlgorithm:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyAlgorithm(_:));
- (void)setSigningChainKeyAlgorithm:(int)signingChainIndex :(NSString*)newSigningChainKeyAlgorithm NS_SWIFT_NAME(setSigningChainKeyAlgorithm(_:_:));

- (int)signingChainKeyBits:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyBits(_:));

- (NSString*)signingChainKeyFingerprint:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyFingerprint(_:));

- (int)signingChainKeyUsage:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyUsage(_:));
- (void)setSigningChainKeyUsage:(int)signingChainIndex :(int)newSigningChainKeyUsage NS_SWIFT_NAME(setSigningChainKeyUsage(_:_:));

- (BOOL)signingChainKeyValid:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyValid(_:));

- (NSString*)signingChainOCSPLocations:(int)signingChainIndex NS_SWIFT_NAME(signingChainOCSPLocations(_:));
- (void)setSigningChainOCSPLocations:(int)signingChainIndex :(NSString*)newSigningChainOCSPLocations NS_SWIFT_NAME(setSigningChainOCSPLocations(_:_:));

- (BOOL)signingChainOCSPNoCheck:(int)signingChainIndex NS_SWIFT_NAME(signingChainOCSPNoCheck(_:));
- (void)setSigningChainOCSPNoCheck:(int)signingChainIndex :(BOOL)newSigningChainOCSPNoCheck NS_SWIFT_NAME(setSigningChainOCSPNoCheck(_:_:));

- (int)signingChainOrigin:(int)signingChainIndex NS_SWIFT_NAME(signingChainOrigin(_:));

- (NSString*)signingChainPolicyIDs:(int)signingChainIndex NS_SWIFT_NAME(signingChainPolicyIDs(_:));
- (void)setSigningChainPolicyIDs:(int)signingChainIndex :(NSString*)newSigningChainPolicyIDs NS_SWIFT_NAME(setSigningChainPolicyIDs(_:_:));

- (NSData*)signingChainPrivateKeyBytes:(int)signingChainIndex NS_SWIFT_NAME(signingChainPrivateKeyBytes(_:));

- (BOOL)signingChainPrivateKeyExists:(int)signingChainIndex NS_SWIFT_NAME(signingChainPrivateKeyExists(_:));

- (BOOL)signingChainPrivateKeyExtractable:(int)signingChainIndex NS_SWIFT_NAME(signingChainPrivateKeyExtractable(_:));

- (NSData*)signingChainPublicKeyBytes:(int)signingChainIndex NS_SWIFT_NAME(signingChainPublicKeyBytes(_:));

- (BOOL)signingChainQualified:(int)signingChainIndex NS_SWIFT_NAME(signingChainQualified(_:));

- (int)signingChainQualifiedStatements:(int)signingChainIndex NS_SWIFT_NAME(signingChainQualifiedStatements(_:));
- (void)setSigningChainQualifiedStatements:(int)signingChainIndex :(int)newSigningChainQualifiedStatements NS_SWIFT_NAME(setSigningChainQualifiedStatements(_:_:));

- (NSString*)signingChainQualifiers:(int)signingChainIndex NS_SWIFT_NAME(signingChainQualifiers(_:));

- (BOOL)signingChainSelfSigned:(int)signingChainIndex NS_SWIFT_NAME(signingChainSelfSigned(_:));

- (NSData*)signingChainSerialNumber:(int)signingChainIndex NS_SWIFT_NAME(signingChainSerialNumber(_:));
- (void)setSigningChainSerialNumber:(int)signingChainIndex :(NSData*)newSigningChainSerialNumber NS_SWIFT_NAME(setSigningChainSerialNumber(_:_:));

- (NSString*)signingChainSigAlgorithm:(int)signingChainIndex NS_SWIFT_NAME(signingChainSigAlgorithm(_:));

- (int)signingChainSource:(int)signingChainIndex NS_SWIFT_NAME(signingChainSource(_:));

- (NSString*)signingChainSubject:(int)signingChainIndex NS_SWIFT_NAME(signingChainSubject(_:));

- (NSString*)signingChainSubjectAlternativeName:(int)signingChainIndex NS_SWIFT_NAME(signingChainSubjectAlternativeName(_:));
- (void)setSigningChainSubjectAlternativeName:(int)signingChainIndex :(NSString*)newSigningChainSubjectAlternativeName NS_SWIFT_NAME(setSigningChainSubjectAlternativeName(_:_:));

- (NSData*)signingChainSubjectKeyID:(int)signingChainIndex NS_SWIFT_NAME(signingChainSubjectKeyID(_:));
- (void)setSigningChainSubjectKeyID:(int)signingChainIndex :(NSData*)newSigningChainSubjectKeyID NS_SWIFT_NAME(setSigningChainSubjectKeyID(_:_:));

- (NSString*)signingChainSubjectRDN:(int)signingChainIndex NS_SWIFT_NAME(signingChainSubjectRDN(_:));
- (void)setSigningChainSubjectRDN:(int)signingChainIndex :(NSString*)newSigningChainSubjectRDN NS_SWIFT_NAME(setSigningChainSubjectRDN(_:_:));

- (BOOL)signingChainValid:(int)signingChainIndex NS_SWIFT_NAME(signingChainValid(_:));

- (NSString*)signingChainValidFrom:(int)signingChainIndex NS_SWIFT_NAME(signingChainValidFrom(_:));
- (void)setSigningChainValidFrom:(int)signingChainIndex :(NSString*)newSigningChainValidFrom NS_SWIFT_NAME(setSigningChainValidFrom(_:_:));

- (NSString*)signingChainValidTo:(int)signingChainIndex NS_SWIFT_NAME(signingChainValidTo(_:));
- (void)setSigningChainValidTo:(int)signingChainIndex :(NSString*)newSigningChainValidTo NS_SWIFT_NAME(setSigningChainValidTo(_:_:));

  /* Methods */

- (int)addEmptyDir:(NSString*)path NS_SWIFT_NAME(addEmptyDir(_:));

- (int)addFile:(NSString*)path :(NSString*)localPath NS_SWIFT_NAME(addFile(_:_:));

- (void)addFiles:(NSString*)folder :(NSString*)localPath :(BOOL)recursive NS_SWIFT_NAME(addFiles(_:_:_:));

- (int)addVirtual:(NSString*)path NS_SWIFT_NAME(addVirtual(_:));

- (void)close NS_SWIFT_NAME(close());

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (void)createNew:(int)archiveType NS_SWIFT_NAME(createNew(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (void)open:(int)archiveType :(NSString*)archiveName NS_SWIFT_NAME(open(_:_:));

- (void)openBytes:(int)archiveType :(NSData*)archiveBytes NS_SWIFT_NAME(openBytes(_:_:));

- (void)remove:(NSString*)path NS_SWIFT_NAME(remove(_:));

- (void)reset NS_SWIFT_NAME(reset());

- (void)save:(NSString*)archiveName NS_SWIFT_NAME(save(_:));

- (NSData*)saveBytes NS_SWIFT_NAME(saveBytes());

- (void)updateFile:(NSString*)path :(NSString*)localPath NS_SWIFT_NAME(updateFile(_:_:));

- (void)updateFiles:(NSString*)folder :(NSString*)localPath :(BOOL)addMissingFiles :(BOOL)removeMissingFiles :(BOOL)recursive NS_SWIFT_NAME(updateFiles(_:_:_:_:_:));

- (void)updateVirtual:(NSString*)path NS_SWIFT_NAME(updateVirtual(_:));

@end

