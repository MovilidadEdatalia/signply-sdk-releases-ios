/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//RNDSOURCES
#define RND_UNKNOWN                                        0

#define RND_BUILT_IN                                       1

#define RND_SYSTEM                                         2

#define RND_BOTH                                           3

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxRndDelegate <NSObject>
@optional
- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

@end

@interface SecureBlackboxRnd : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxRndDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasError;

  BOOL m_delegateHasNotification;

}

+ (SecureBlackboxRnd*)rnd;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxRndDelegate> delegate;
- (id <SecureBlackboxRndDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxRndDelegate>)anObject;

  /* Events */

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readwrite,assign,getter=alphabet,setter=setAlphabet:) NSString* alphabet NS_SWIFT_NAME(alphabet);

- (NSString*)alphabet NS_SWIFT_NAME(alphabet());
- (void)setAlphabet :(NSString*)newAlphabet NS_SWIFT_NAME(setAlphabet(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=source,setter=setSource:) int source NS_SWIFT_NAME(source);

- (int)source NS_SWIFT_NAME(source());
- (void)setSource :(int)newSource NS_SWIFT_NAME(setSource(_:));

  /* Methods */

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (NSData*)nextBytes:(int)len NS_SWIFT_NAME(nextBytes(_:));

- (int)nextInt NS_SWIFT_NAME(nextInt());

- (NSString*)nextPass:(BOOL)lowercase :(BOOL)uppercase :(BOOL)digits :(BOOL)specials :(int)len NS_SWIFT_NAME(nextPass(_:_:_:_:_:));

- (NSString*)nextString:(int)len NS_SWIFT_NAME(nextString(_:));

- (void)randomize NS_SWIFT_NAME(randomize());

- (void)reset NS_SWIFT_NAME(reset());

- (void)seedBytes:(NSData*)value NS_SWIFT_NAME(seedBytes(_:));

- (void)seedInt:(int)intValue NS_SWIFT_NAME(seedInt(_:));

- (void)seedString:(NSString*)strValue NS_SWIFT_NAME(seedString(_:));

- (void)seedTime NS_SWIFT_NAME(seedTime());

@end

