/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//ASYNCSIGNMETHODS
#define ASMD_PKCS1                                         0

#define ASMD_PKCS7                                         1

//EXTERNALCRYPTOMODES
#define ECM_DEFAULT                                        0

#define ECM_DISABLED                                       1

#define ECM_GENERIC                                        2

#define ECM_DCAUTH                                         3

#define ECM_DCAUTH_JSON                                    4

//MESSAGEENCODINGS
#define ENC_NONE                                           0

#define ENC_AUTO                                           1

#define ENC_BASE_64                                        2

//PROXYAUTHTYPES
#define PAT_NO_AUTHENTICATION                              0

#define PAT_BASIC                                          1

#define PAT_DIGEST                                         2

#define PAT_NTLM                                           3

//PROXYTYPES
#define CPT_NONE                                           0

#define CPT_SOCKS_4                                        1

#define CPT_SOCKS_5                                        2

#define CPT_WEB_TUNNEL                                     3

#define CPT_HTTP                                           4

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

//DNSRESOLVEMODES
#define DM_AUTO                                            0

#define DM_PLATFORM                                        1

#define DM_OWN                                             2

#define DM_OWN_SECURE                                      3

//SECURETRANSPORTPREDEFINEDCONFIGURATIONS
#define STPC_DEFAULT                                       0

#define STPC_COMPATIBLE                                    1

#define STPC_COMPREHENSIVE_INSECURE                        2

#define STPC_HIGHLY_SECURE                                 3

//CLIENTAUTHTYPES
#define CCAT_NO_AUTH                                       0

#define CCAT_REQUEST_CERT                                  1

#define CCAT_REQUIRE_CERT                                  2

//RENEGOTIATIONATTACKPREVENTIONMODES
#define CRAPM_COMPATIBLE                                   0

#define CRAPM_STRICT                                       1

#define CRAPM_AUTO                                         2

//REVOCATIONCHECKKINDS
#define CRC_NONE                                           0

#define CRC_AUTO                                           1

#define CRC_ALL_CRL                                        2

#define CRC_ALL_OCSP                                       3

#define CRC_ALL_CRLAND_OCSP                                4

#define CRC_ANY_CRL                                        5

#define CRC_ANY_OCSP                                       6

#define CRC_ANY_CRLOR_OCSP                                 7

#define CRC_ANY_OCSPOR_CRL                                 8

//SSLMODES
#define SM_DEFAULT                                         0

#define SM_NO_TLS                                          1

#define SM_EXPLICIT_TLS                                    2

#define SM_IMPLICIT_TLS                                    3

#define SM_MIXED_TLS                                       4

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxDCAuthDelegate <NSObject>
@optional
- (void)onCustomParametersReceived:(NSString*)value NS_SWIFT_NAME(onCustomParametersReceived(_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onExternalSign:(NSString*)operationId :(NSString*)hashAlgorithm :(NSString*)pars :(NSString*)methodPars :(NSString*)data :(NSString**)signedData NS_SWIFT_NAME(onExternalSign(_:_:_:_:_:_:));

- (void)onKeySecretNeeded:(NSString*)keyId :(NSString**)keySecret NS_SWIFT_NAME(onKeySecretNeeded(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onParameterReceived:(NSString*)name :(NSString*)value NS_SWIFT_NAME(onParameterReceived(_:_:));

- (void)onSignRequest:(int)method :(NSString*)hashAlgorithm :(NSData*)hash :(NSString*)keyID :(NSString*)pars :(NSString*)methodPars :(int*)allow NS_SWIFT_NAME(onSignRequest(_:_:_:_:_:_:_:));

- (void)onSignRequestCompleted:(int)method :(NSString*)hashAlgorithm :(NSData*)hash :(NSString*)keyID :(NSString*)pars :(NSString*)methodPars :(NSData*)signature NS_SWIFT_NAME(onSignRequestCompleted(_:_:_:_:_:_:_:));

- (void)onTimestampRequest:(NSString*)TSA :(NSString*)timestampRequest :(NSString**)timestampResponse :(int*)suppressDefault NS_SWIFT_NAME(onTimestampRequest(_:_:_:_:));

- (void)onTLSCertNeeded:(NSString*)host :(NSString*)CANames NS_SWIFT_NAME(onTLSCertNeeded(_:_:));

- (void)onTLSCertValidate:(NSString*)serverHost :(NSString*)serverIP :(int*)accept NS_SWIFT_NAME(onTLSCertValidate(_:_:_:));

- (void)onTLSEstablished:(NSString*)host :(NSString*)version :(NSString*)ciphersuite :(NSData*)connectionId :(int*)abort NS_SWIFT_NAME(onTLSEstablished(_:_:_:_:_:));

- (void)onTLSHandshake:(NSString*)host :(int*)abort NS_SWIFT_NAME(onTLSHandshake(_:_:));

- (void)onTLSShutdown:(NSString*)host NS_SWIFT_NAME(onTLSShutdown(_:));

@end

@interface SecureBlackboxDCAuth : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxDCAuthDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasCustomParametersReceived;

  BOOL m_delegateHasError;

  BOOL m_delegateHasExternalSign;

  BOOL m_delegateHasKeySecretNeeded;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasParameterReceived;

  BOOL m_delegateHasSignRequest;

  BOOL m_delegateHasSignRequestCompleted;

  BOOL m_delegateHasTimestampRequest;

  BOOL m_delegateHasTLSCertNeeded;

  BOOL m_delegateHasTLSCertValidate;

  BOOL m_delegateHasTLSEstablished;

  BOOL m_delegateHasTLSHandshake;

  BOOL m_delegateHasTLSShutdown;

}

+ (SecureBlackboxDCAuth*)dcauth;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxDCAuthDelegate> delegate;
- (id <SecureBlackboxDCAuthDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxDCAuthDelegate>)anObject;

  /* Events */

- (void)onCustomParametersReceived:(NSString*)value NS_SWIFT_NAME(onCustomParametersReceived(_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onExternalSign:(NSString*)operationId :(NSString*)hashAlgorithm :(NSString*)pars :(NSString*)methodPars :(NSString*)data :(NSString**)signedData NS_SWIFT_NAME(onExternalSign(_:_:_:_:_:_:));

- (void)onKeySecretNeeded:(NSString*)keyId :(NSString**)keySecret NS_SWIFT_NAME(onKeySecretNeeded(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onParameterReceived:(NSString*)name :(NSString*)value NS_SWIFT_NAME(onParameterReceived(_:_:));

- (void)onSignRequest:(int)method :(NSString*)hashAlgorithm :(NSData*)hash :(NSString*)keyID :(NSString*)pars :(NSString*)methodPars :(int*)allow NS_SWIFT_NAME(onSignRequest(_:_:_:_:_:_:_:));

- (void)onSignRequestCompleted:(int)method :(NSString*)hashAlgorithm :(NSData*)hash :(NSString*)keyID :(NSString*)pars :(NSString*)methodPars :(NSData*)signature NS_SWIFT_NAME(onSignRequestCompleted(_:_:_:_:_:_:_:));

- (void)onTimestampRequest:(NSString*)TSA :(NSString*)timestampRequest :(NSString**)timestampResponse :(int*)suppressDefault NS_SWIFT_NAME(onTimestampRequest(_:_:_:_:));

- (void)onTLSCertNeeded:(NSString*)host :(NSString*)CANames NS_SWIFT_NAME(onTLSCertNeeded(_:_:));

- (void)onTLSCertValidate:(NSString*)serverHost :(NSString*)serverIP :(int*)accept NS_SWIFT_NAME(onTLSCertValidate(_:_:_:));

- (void)onTLSEstablished:(NSString*)host :(NSString*)version :(NSString*)ciphersuite :(NSData*)connectionId :(int*)abort NS_SWIFT_NAME(onTLSEstablished(_:_:_:_:_:));

- (void)onTLSHandshake:(NSString*)host :(int*)abort NS_SWIFT_NAME(onTLSHandshake(_:_:));

- (void)onTLSShutdown:(NSString*)host NS_SWIFT_NAME(onTLSShutdown(_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readwrite,assign,getter=claimedSigningTime,setter=setClaimedSigningTime:) NSString* claimedSigningTime NS_SWIFT_NAME(claimedSigningTime);

- (NSString*)claimedSigningTime NS_SWIFT_NAME(claimedSigningTime());
- (void)setClaimedSigningTime :(NSString*)newClaimedSigningTime NS_SWIFT_NAME(setClaimedSigningTime(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoAsyncDocumentID,setter=setExternalCryptoAsyncDocumentID:) NSString* externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID);

- (NSString*)externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID());
- (void)setExternalCryptoAsyncDocumentID :(NSString*)newExternalCryptoAsyncDocumentID NS_SWIFT_NAME(setExternalCryptoAsyncDocumentID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoCustomParams,setter=setExternalCryptoCustomParams:) NSString* externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams);

- (NSString*)externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams());
- (void)setExternalCryptoCustomParams :(NSString*)newExternalCryptoCustomParams NS_SWIFT_NAME(setExternalCryptoCustomParams(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoData,setter=setExternalCryptoData:) NSString* externalCryptoData NS_SWIFT_NAME(externalCryptoData);

- (NSString*)externalCryptoData NS_SWIFT_NAME(externalCryptoData());
- (void)setExternalCryptoData :(NSString*)newExternalCryptoData NS_SWIFT_NAME(setExternalCryptoData(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoExternalHashCalculation,setter=setExternalCryptoExternalHashCalculation:) BOOL externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation);

- (BOOL)externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation());
- (void)setExternalCryptoExternalHashCalculation :(BOOL)newExternalCryptoExternalHashCalculation NS_SWIFT_NAME(setExternalCryptoExternalHashCalculation(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoHashAlgorithm,setter=setExternalCryptoHashAlgorithm:) NSString* externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm);

- (NSString*)externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm());
- (void)setExternalCryptoHashAlgorithm :(NSString*)newExternalCryptoHashAlgorithm NS_SWIFT_NAME(setExternalCryptoHashAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeyID,setter=setExternalCryptoKeyID:) NSString* externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID);

- (NSString*)externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID());
- (void)setExternalCryptoKeyID :(NSString*)newExternalCryptoKeyID NS_SWIFT_NAME(setExternalCryptoKeyID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeySecret,setter=setExternalCryptoKeySecret:) NSString* externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret);

- (NSString*)externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret());
- (void)setExternalCryptoKeySecret :(NSString*)newExternalCryptoKeySecret NS_SWIFT_NAME(setExternalCryptoKeySecret(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMethod,setter=setExternalCryptoMethod:) int externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod);

- (int)externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod());
- (void)setExternalCryptoMethod :(int)newExternalCryptoMethod NS_SWIFT_NAME(setExternalCryptoMethod(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMode,setter=setExternalCryptoMode:) int externalCryptoMode NS_SWIFT_NAME(externalCryptoMode);

- (int)externalCryptoMode NS_SWIFT_NAME(externalCryptoMode());
- (void)setExternalCryptoMode :(int)newExternalCryptoMode NS_SWIFT_NAME(setExternalCryptoMode(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoPublicKeyAlgorithm,setter=setExternalCryptoPublicKeyAlgorithm:) NSString* externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm);

- (NSString*)externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm());
- (void)setExternalCryptoPublicKeyAlgorithm :(NSString*)newExternalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(setExternalCryptoPublicKeyAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=input,setter=setInput:) NSString* input NS_SWIFT_NAME(input);

- (NSString*)input NS_SWIFT_NAME(input());
- (void)setInput :(NSString*)newInput NS_SWIFT_NAME(setInput(_:));

@property (nonatomic,readwrite,assign,getter=inputEncoding,setter=setInputEncoding:) int inputEncoding NS_SWIFT_NAME(inputEncoding);

- (int)inputEncoding NS_SWIFT_NAME(inputEncoding());
- (void)setInputEncoding :(int)newInputEncoding NS_SWIFT_NAME(setInputEncoding(_:));

@property (nonatomic,readwrite,assign,getter=keyId,setter=setKeyId:) NSString* keyId NS_SWIFT_NAME(keyId);

- (NSString*)keyId NS_SWIFT_NAME(keyId());
- (void)setKeyId :(NSString*)newKeyId NS_SWIFT_NAME(setKeyId(_:));

@property (nonatomic,readwrite,assign,getter=keySecret,setter=setKeySecret:) NSString* keySecret NS_SWIFT_NAME(keySecret);

- (NSString*)keySecret NS_SWIFT_NAME(keySecret());
- (void)setKeySecret :(NSString*)newKeySecret NS_SWIFT_NAME(setKeySecret(_:));

@property (nonatomic,readonly,assign,getter=output) NSString* output NS_SWIFT_NAME(output);

- (NSString*)output NS_SWIFT_NAME(output());

@property (nonatomic,readwrite,assign,getter=outputEncoding,setter=setOutputEncoding:) int outputEncoding NS_SWIFT_NAME(outputEncoding);

- (int)outputEncoding NS_SWIFT_NAME(outputEncoding());
- (void)setOutputEncoding :(int)newOutputEncoding NS_SWIFT_NAME(setOutputEncoding(_:));

@property (nonatomic,readwrite,assign,getter=policies,setter=setPolicies:) int policies NS_SWIFT_NAME(policies);

- (int)policies NS_SWIFT_NAME(policies());
- (void)setPolicies :(int)newPolicies NS_SWIFT_NAME(setPolicies(_:));

@property (nonatomic,readwrite,assign,getter=profile,setter=setProfile:) NSString* profile NS_SWIFT_NAME(profile);

- (NSString*)profile NS_SWIFT_NAME(profile());
- (void)setProfile :(NSString*)newProfile NS_SWIFT_NAME(setProfile(_:));

@property (nonatomic,readwrite,assign,getter=proxyAddress,setter=setProxyAddress:) NSString* proxyAddress NS_SWIFT_NAME(proxyAddress);

- (NSString*)proxyAddress NS_SWIFT_NAME(proxyAddress());
- (void)setProxyAddress :(NSString*)newProxyAddress NS_SWIFT_NAME(setProxyAddress(_:));

@property (nonatomic,readwrite,assign,getter=proxyAuthentication,setter=setProxyAuthentication:) int proxyAuthentication NS_SWIFT_NAME(proxyAuthentication);

- (int)proxyAuthentication NS_SWIFT_NAME(proxyAuthentication());
- (void)setProxyAuthentication :(int)newProxyAuthentication NS_SWIFT_NAME(setProxyAuthentication(_:));

@property (nonatomic,readwrite,assign,getter=proxyPassword,setter=setProxyPassword:) NSString* proxyPassword NS_SWIFT_NAME(proxyPassword);

- (NSString*)proxyPassword NS_SWIFT_NAME(proxyPassword());
- (void)setProxyPassword :(NSString*)newProxyPassword NS_SWIFT_NAME(setProxyPassword(_:));

@property (nonatomic,readwrite,assign,getter=proxyPort,setter=setProxyPort:) int proxyPort NS_SWIFT_NAME(proxyPort);

- (int)proxyPort NS_SWIFT_NAME(proxyPort());
- (void)setProxyPort :(int)newProxyPort NS_SWIFT_NAME(setProxyPort(_:));

@property (nonatomic,readwrite,assign,getter=proxyProxyType,setter=setProxyProxyType:) int proxyProxyType NS_SWIFT_NAME(proxyProxyType);

- (int)proxyProxyType NS_SWIFT_NAME(proxyProxyType());
- (void)setProxyProxyType :(int)newProxyProxyType NS_SWIFT_NAME(setProxyProxyType(_:));

@property (nonatomic,readwrite,assign,getter=proxyRequestHeaders,setter=setProxyRequestHeaders:) NSString* proxyRequestHeaders NS_SWIFT_NAME(proxyRequestHeaders);

- (NSString*)proxyRequestHeaders NS_SWIFT_NAME(proxyRequestHeaders());
- (void)setProxyRequestHeaders :(NSString*)newProxyRequestHeaders NS_SWIFT_NAME(setProxyRequestHeaders(_:));

@property (nonatomic,readwrite,assign,getter=proxyResponseBody,setter=setProxyResponseBody:) NSString* proxyResponseBody NS_SWIFT_NAME(proxyResponseBody);

- (NSString*)proxyResponseBody NS_SWIFT_NAME(proxyResponseBody());
- (void)setProxyResponseBody :(NSString*)newProxyResponseBody NS_SWIFT_NAME(setProxyResponseBody(_:));

@property (nonatomic,readwrite,assign,getter=proxyResponseHeaders,setter=setProxyResponseHeaders:) NSString* proxyResponseHeaders NS_SWIFT_NAME(proxyResponseHeaders);

- (NSString*)proxyResponseHeaders NS_SWIFT_NAME(proxyResponseHeaders());
- (void)setProxyResponseHeaders :(NSString*)newProxyResponseHeaders NS_SWIFT_NAME(setProxyResponseHeaders(_:));

@property (nonatomic,readwrite,assign,getter=proxyUseIPv6,setter=setProxyUseIPv6:) BOOL proxyUseIPv6 NS_SWIFT_NAME(proxyUseIPv6);

- (BOOL)proxyUseIPv6 NS_SWIFT_NAME(proxyUseIPv6());
- (void)setProxyUseIPv6 :(BOOL)newProxyUseIPv6 NS_SWIFT_NAME(setProxyUseIPv6(_:));

@property (nonatomic,readwrite,assign,getter=proxyUsername,setter=setProxyUsername:) NSString* proxyUsername NS_SWIFT_NAME(proxyUsername);

- (NSString*)proxyUsername NS_SWIFT_NAME(proxyUsername());
- (void)setProxyUsername :(NSString*)newProxyUsername NS_SWIFT_NAME(setProxyUsername(_:));

@property (nonatomic,readonly,assign,getter=signingCertBytes) NSData* signingCertBytes NS_SWIFT_NAME(signingCertBytes);

- (NSData*)signingCertBytes NS_SWIFT_NAME(signingCertBytes());

@property (nonatomic,readwrite,assign,getter=signingCertCA,setter=setSigningCertCA:) BOOL signingCertCA NS_SWIFT_NAME(signingCertCA);

- (BOOL)signingCertCA NS_SWIFT_NAME(signingCertCA());
- (void)setSigningCertCA :(BOOL)newSigningCertCA NS_SWIFT_NAME(setSigningCertCA(_:));

@property (nonatomic,readonly,assign,getter=signingCertCAKeyID) NSData* signingCertCAKeyID NS_SWIFT_NAME(signingCertCAKeyID);

- (NSData*)signingCertCAKeyID NS_SWIFT_NAME(signingCertCAKeyID());

@property (nonatomic,readonly,assign,getter=signingCertCertType) int signingCertCertType NS_SWIFT_NAME(signingCertCertType);

- (int)signingCertCertType NS_SWIFT_NAME(signingCertCertType());

@property (nonatomic,readwrite,assign,getter=signingCertCRLDistributionPoints,setter=setSigningCertCRLDistributionPoints:) NSString* signingCertCRLDistributionPoints NS_SWIFT_NAME(signingCertCRLDistributionPoints);

- (NSString*)signingCertCRLDistributionPoints NS_SWIFT_NAME(signingCertCRLDistributionPoints());
- (void)setSigningCertCRLDistributionPoints :(NSString*)newSigningCertCRLDistributionPoints NS_SWIFT_NAME(setSigningCertCRLDistributionPoints(_:));

@property (nonatomic,readwrite,assign,getter=signingCertCurve,setter=setSigningCertCurve:) NSString* signingCertCurve NS_SWIFT_NAME(signingCertCurve);

- (NSString*)signingCertCurve NS_SWIFT_NAME(signingCertCurve());
- (void)setSigningCertCurve :(NSString*)newSigningCertCurve NS_SWIFT_NAME(setSigningCertCurve(_:));

@property (nonatomic,readonly,assign,getter=signingCertFingerprint) NSString* signingCertFingerprint NS_SWIFT_NAME(signingCertFingerprint);

- (NSString*)signingCertFingerprint NS_SWIFT_NAME(signingCertFingerprint());

@property (nonatomic,readonly,assign,getter=signingCertFriendlyName) NSString* signingCertFriendlyName NS_SWIFT_NAME(signingCertFriendlyName);

- (NSString*)signingCertFriendlyName NS_SWIFT_NAME(signingCertFriendlyName());

@property (nonatomic,readwrite,assign,getter=signingCertHandle,setter=setSigningCertHandle:) long long signingCertHandle NS_SWIFT_NAME(signingCertHandle);

- (long long)signingCertHandle NS_SWIFT_NAME(signingCertHandle());
- (void)setSigningCertHandle :(long long)newSigningCertHandle NS_SWIFT_NAME(setSigningCertHandle(_:));

@property (nonatomic,readwrite,assign,getter=signingCertHashAlgorithm,setter=setSigningCertHashAlgorithm:) NSString* signingCertHashAlgorithm NS_SWIFT_NAME(signingCertHashAlgorithm);

- (NSString*)signingCertHashAlgorithm NS_SWIFT_NAME(signingCertHashAlgorithm());
- (void)setSigningCertHashAlgorithm :(NSString*)newSigningCertHashAlgorithm NS_SWIFT_NAME(setSigningCertHashAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=signingCertIssuer) NSString* signingCertIssuer NS_SWIFT_NAME(signingCertIssuer);

- (NSString*)signingCertIssuer NS_SWIFT_NAME(signingCertIssuer());

@property (nonatomic,readwrite,assign,getter=signingCertIssuerRDN,setter=setSigningCertIssuerRDN:) NSString* signingCertIssuerRDN NS_SWIFT_NAME(signingCertIssuerRDN);

- (NSString*)signingCertIssuerRDN NS_SWIFT_NAME(signingCertIssuerRDN());
- (void)setSigningCertIssuerRDN :(NSString*)newSigningCertIssuerRDN NS_SWIFT_NAME(setSigningCertIssuerRDN(_:));

@property (nonatomic,readwrite,assign,getter=signingCertKeyAlgorithm,setter=setSigningCertKeyAlgorithm:) NSString* signingCertKeyAlgorithm NS_SWIFT_NAME(signingCertKeyAlgorithm);

- (NSString*)signingCertKeyAlgorithm NS_SWIFT_NAME(signingCertKeyAlgorithm());
- (void)setSigningCertKeyAlgorithm :(NSString*)newSigningCertKeyAlgorithm NS_SWIFT_NAME(setSigningCertKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=signingCertKeyBits) int signingCertKeyBits NS_SWIFT_NAME(signingCertKeyBits);

- (int)signingCertKeyBits NS_SWIFT_NAME(signingCertKeyBits());

@property (nonatomic,readonly,assign,getter=signingCertKeyFingerprint) NSString* signingCertKeyFingerprint NS_SWIFT_NAME(signingCertKeyFingerprint);

- (NSString*)signingCertKeyFingerprint NS_SWIFT_NAME(signingCertKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=signingCertKeyUsage,setter=setSigningCertKeyUsage:) int signingCertKeyUsage NS_SWIFT_NAME(signingCertKeyUsage);

- (int)signingCertKeyUsage NS_SWIFT_NAME(signingCertKeyUsage());
- (void)setSigningCertKeyUsage :(int)newSigningCertKeyUsage NS_SWIFT_NAME(setSigningCertKeyUsage(_:));

@property (nonatomic,readonly,assign,getter=signingCertKeyValid) BOOL signingCertKeyValid NS_SWIFT_NAME(signingCertKeyValid);

- (BOOL)signingCertKeyValid NS_SWIFT_NAME(signingCertKeyValid());

@property (nonatomic,readwrite,assign,getter=signingCertOCSPLocations,setter=setSigningCertOCSPLocations:) NSString* signingCertOCSPLocations NS_SWIFT_NAME(signingCertOCSPLocations);

- (NSString*)signingCertOCSPLocations NS_SWIFT_NAME(signingCertOCSPLocations());
- (void)setSigningCertOCSPLocations :(NSString*)newSigningCertOCSPLocations NS_SWIFT_NAME(setSigningCertOCSPLocations(_:));

@property (nonatomic,readwrite,assign,getter=signingCertOCSPNoCheck,setter=setSigningCertOCSPNoCheck:) BOOL signingCertOCSPNoCheck NS_SWIFT_NAME(signingCertOCSPNoCheck);

- (BOOL)signingCertOCSPNoCheck NS_SWIFT_NAME(signingCertOCSPNoCheck());
- (void)setSigningCertOCSPNoCheck :(BOOL)newSigningCertOCSPNoCheck NS_SWIFT_NAME(setSigningCertOCSPNoCheck(_:));

@property (nonatomic,readonly,assign,getter=signingCertOrigin) int signingCertOrigin NS_SWIFT_NAME(signingCertOrigin);

- (int)signingCertOrigin NS_SWIFT_NAME(signingCertOrigin());

@property (nonatomic,readwrite,assign,getter=signingCertPolicyIDs,setter=setSigningCertPolicyIDs:) NSString* signingCertPolicyIDs NS_SWIFT_NAME(signingCertPolicyIDs);

- (NSString*)signingCertPolicyIDs NS_SWIFT_NAME(signingCertPolicyIDs());
- (void)setSigningCertPolicyIDs :(NSString*)newSigningCertPolicyIDs NS_SWIFT_NAME(setSigningCertPolicyIDs(_:));

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyBytes) NSData* signingCertPrivateKeyBytes NS_SWIFT_NAME(signingCertPrivateKeyBytes);

- (NSData*)signingCertPrivateKeyBytes NS_SWIFT_NAME(signingCertPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyExists) BOOL signingCertPrivateKeyExists NS_SWIFT_NAME(signingCertPrivateKeyExists);

- (BOOL)signingCertPrivateKeyExists NS_SWIFT_NAME(signingCertPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyExtractable) BOOL signingCertPrivateKeyExtractable NS_SWIFT_NAME(signingCertPrivateKeyExtractable);

- (BOOL)signingCertPrivateKeyExtractable NS_SWIFT_NAME(signingCertPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=signingCertPublicKeyBytes) NSData* signingCertPublicKeyBytes NS_SWIFT_NAME(signingCertPublicKeyBytes);

- (NSData*)signingCertPublicKeyBytes NS_SWIFT_NAME(signingCertPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=signingCertQualified) BOOL signingCertQualified NS_SWIFT_NAME(signingCertQualified);

- (BOOL)signingCertQualified NS_SWIFT_NAME(signingCertQualified());

@property (nonatomic,readwrite,assign,getter=signingCertQualifiedStatements,setter=setSigningCertQualifiedStatements:) int signingCertQualifiedStatements NS_SWIFT_NAME(signingCertQualifiedStatements);

- (int)signingCertQualifiedStatements NS_SWIFT_NAME(signingCertQualifiedStatements());
- (void)setSigningCertQualifiedStatements :(int)newSigningCertQualifiedStatements NS_SWIFT_NAME(setSigningCertQualifiedStatements(_:));

@property (nonatomic,readonly,assign,getter=signingCertQualifiers) NSString* signingCertQualifiers NS_SWIFT_NAME(signingCertQualifiers);

- (NSString*)signingCertQualifiers NS_SWIFT_NAME(signingCertQualifiers());

@property (nonatomic,readonly,assign,getter=signingCertSelfSigned) BOOL signingCertSelfSigned NS_SWIFT_NAME(signingCertSelfSigned);

- (BOOL)signingCertSelfSigned NS_SWIFT_NAME(signingCertSelfSigned());

@property (nonatomic,readwrite,assign,getter=signingCertSerialNumber,setter=setSigningCertSerialNumber:) NSData* signingCertSerialNumber NS_SWIFT_NAME(signingCertSerialNumber);

- (NSData*)signingCertSerialNumber NS_SWIFT_NAME(signingCertSerialNumber());
- (void)setSigningCertSerialNumber :(NSData*)newSigningCertSerialNumber NS_SWIFT_NAME(setSigningCertSerialNumber(_:));

@property (nonatomic,readonly,assign,getter=signingCertSigAlgorithm) NSString* signingCertSigAlgorithm NS_SWIFT_NAME(signingCertSigAlgorithm);

- (NSString*)signingCertSigAlgorithm NS_SWIFT_NAME(signingCertSigAlgorithm());

@property (nonatomic,readonly,assign,getter=signingCertSource) int signingCertSource NS_SWIFT_NAME(signingCertSource);

- (int)signingCertSource NS_SWIFT_NAME(signingCertSource());

@property (nonatomic,readonly,assign,getter=signingCertSubject) NSString* signingCertSubject NS_SWIFT_NAME(signingCertSubject);

- (NSString*)signingCertSubject NS_SWIFT_NAME(signingCertSubject());

@property (nonatomic,readwrite,assign,getter=signingCertSubjectAlternativeName,setter=setSigningCertSubjectAlternativeName:) NSString* signingCertSubjectAlternativeName NS_SWIFT_NAME(signingCertSubjectAlternativeName);

- (NSString*)signingCertSubjectAlternativeName NS_SWIFT_NAME(signingCertSubjectAlternativeName());
- (void)setSigningCertSubjectAlternativeName :(NSString*)newSigningCertSubjectAlternativeName NS_SWIFT_NAME(setSigningCertSubjectAlternativeName(_:));

@property (nonatomic,readwrite,assign,getter=signingCertSubjectKeyID,setter=setSigningCertSubjectKeyID:) NSData* signingCertSubjectKeyID NS_SWIFT_NAME(signingCertSubjectKeyID);

- (NSData*)signingCertSubjectKeyID NS_SWIFT_NAME(signingCertSubjectKeyID());
- (void)setSigningCertSubjectKeyID :(NSData*)newSigningCertSubjectKeyID NS_SWIFT_NAME(setSigningCertSubjectKeyID(_:));

@property (nonatomic,readwrite,assign,getter=signingCertSubjectRDN,setter=setSigningCertSubjectRDN:) NSString* signingCertSubjectRDN NS_SWIFT_NAME(signingCertSubjectRDN);

- (NSString*)signingCertSubjectRDN NS_SWIFT_NAME(signingCertSubjectRDN());
- (void)setSigningCertSubjectRDN :(NSString*)newSigningCertSubjectRDN NS_SWIFT_NAME(setSigningCertSubjectRDN(_:));

@property (nonatomic,readonly,assign,getter=signingCertValid) BOOL signingCertValid NS_SWIFT_NAME(signingCertValid);

- (BOOL)signingCertValid NS_SWIFT_NAME(signingCertValid());

@property (nonatomic,readwrite,assign,getter=signingCertValidFrom,setter=setSigningCertValidFrom:) NSString* signingCertValidFrom NS_SWIFT_NAME(signingCertValidFrom);

- (NSString*)signingCertValidFrom NS_SWIFT_NAME(signingCertValidFrom());
- (void)setSigningCertValidFrom :(NSString*)newSigningCertValidFrom NS_SWIFT_NAME(setSigningCertValidFrom(_:));

@property (nonatomic,readwrite,assign,getter=signingCertValidTo,setter=setSigningCertValidTo:) NSString* signingCertValidTo NS_SWIFT_NAME(signingCertValidTo);

- (NSString*)signingCertValidTo NS_SWIFT_NAME(signingCertValidTo());
- (void)setSigningCertValidTo :(NSString*)newSigningCertValidTo NS_SWIFT_NAME(setSigningCertValidTo(_:));

@property (nonatomic,readwrite,assign,getter=signingChainCount,setter=setSigningChainCount:) int signingChainCount NS_SWIFT_NAME(signingChainCount);

- (int)signingChainCount NS_SWIFT_NAME(signingChainCount());
- (void)setSigningChainCount :(int)newSigningChainCount NS_SWIFT_NAME(setSigningChainCount(_:));

- (NSData*)signingChainBytes:(int)signingChainIndex NS_SWIFT_NAME(signingChainBytes(_:));

- (BOOL)signingChainCA:(int)signingChainIndex NS_SWIFT_NAME(signingChainCA(_:));
- (void)setSigningChainCA:(int)signingChainIndex :(BOOL)newSigningChainCA NS_SWIFT_NAME(setSigningChainCA(_:_:));

- (NSData*)signingChainCAKeyID:(int)signingChainIndex NS_SWIFT_NAME(signingChainCAKeyID(_:));

- (int)signingChainCertType:(int)signingChainIndex NS_SWIFT_NAME(signingChainCertType(_:));

- (NSString*)signingChainCRLDistributionPoints:(int)signingChainIndex NS_SWIFT_NAME(signingChainCRLDistributionPoints(_:));
- (void)setSigningChainCRLDistributionPoints:(int)signingChainIndex :(NSString*)newSigningChainCRLDistributionPoints NS_SWIFT_NAME(setSigningChainCRLDistributionPoints(_:_:));

- (NSString*)signingChainCurve:(int)signingChainIndex NS_SWIFT_NAME(signingChainCurve(_:));
- (void)setSigningChainCurve:(int)signingChainIndex :(NSString*)newSigningChainCurve NS_SWIFT_NAME(setSigningChainCurve(_:_:));

- (NSString*)signingChainFingerprint:(int)signingChainIndex NS_SWIFT_NAME(signingChainFingerprint(_:));

- (NSString*)signingChainFriendlyName:(int)signingChainIndex NS_SWIFT_NAME(signingChainFriendlyName(_:));

- (long long)signingChainHandle:(int)signingChainIndex NS_SWIFT_NAME(signingChainHandle(_:));
- (void)setSigningChainHandle:(int)signingChainIndex :(long long)newSigningChainHandle NS_SWIFT_NAME(setSigningChainHandle(_:_:));

- (NSString*)signingChainHashAlgorithm:(int)signingChainIndex NS_SWIFT_NAME(signingChainHashAlgorithm(_:));
- (void)setSigningChainHashAlgorithm:(int)signingChainIndex :(NSString*)newSigningChainHashAlgorithm NS_SWIFT_NAME(setSigningChainHashAlgorithm(_:_:));

- (NSString*)signingChainIssuer:(int)signingChainIndex NS_SWIFT_NAME(signingChainIssuer(_:));

- (NSString*)signingChainIssuerRDN:(int)signingChainIndex NS_SWIFT_NAME(signingChainIssuerRDN(_:));
- (void)setSigningChainIssuerRDN:(int)signingChainIndex :(NSString*)newSigningChainIssuerRDN NS_SWIFT_NAME(setSigningChainIssuerRDN(_:_:));

- (NSString*)signingChainKeyAlgorithm:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyAlgorithm(_:));
- (void)setSigningChainKeyAlgorithm:(int)signingChainIndex :(NSString*)newSigningChainKeyAlgorithm NS_SWIFT_NAME(setSigningChainKeyAlgorithm(_:_:));

- (int)signingChainKeyBits:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyBits(_:));

- (NSString*)signingChainKeyFingerprint:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyFingerprint(_:));

- (int)signingChainKeyUsage:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyUsage(_:));
- (void)setSigningChainKeyUsage:(int)signingChainIndex :(int)newSigningChainKeyUsage NS_SWIFT_NAME(setSigningChainKeyUsage(_:_:));

- (BOOL)signingChainKeyValid:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyValid(_:));

- (NSString*)signingChainOCSPLocations:(int)signingChainIndex NS_SWIFT_NAME(signingChainOCSPLocations(_:));
- (void)setSigningChainOCSPLocations:(int)signingChainIndex :(NSString*)newSigningChainOCSPLocations NS_SWIFT_NAME(setSigningChainOCSPLocations(_:_:));

- (BOOL)signingChainOCSPNoCheck:(int)signingChainIndex NS_SWIFT_NAME(signingChainOCSPNoCheck(_:));
- (void)setSigningChainOCSPNoCheck:(int)signingChainIndex :(BOOL)newSigningChainOCSPNoCheck NS_SWIFT_NAME(setSigningChainOCSPNoCheck(_:_:));

- (int)signingChainOrigin:(int)signingChainIndex NS_SWIFT_NAME(signingChainOrigin(_:));

- (NSString*)signingChainPolicyIDs:(int)signingChainIndex NS_SWIFT_NAME(signingChainPolicyIDs(_:));
- (void)setSigningChainPolicyIDs:(int)signingChainIndex :(NSString*)newSigningChainPolicyIDs NS_SWIFT_NAME(setSigningChainPolicyIDs(_:_:));

- (NSData*)signingChainPrivateKeyBytes:(int)signingChainIndex NS_SWIFT_NAME(signingChainPrivateKeyBytes(_:));

- (BOOL)signingChainPrivateKeyExists:(int)signingChainIndex NS_SWIFT_NAME(signingChainPrivateKeyExists(_:));

- (BOOL)signingChainPrivateKeyExtractable:(int)signingChainIndex NS_SWIFT_NAME(signingChainPrivateKeyExtractable(_:));

- (NSData*)signingChainPublicKeyBytes:(int)signingChainIndex NS_SWIFT_NAME(signingChainPublicKeyBytes(_:));

- (BOOL)signingChainQualified:(int)signingChainIndex NS_SWIFT_NAME(signingChainQualified(_:));

- (int)signingChainQualifiedStatements:(int)signingChainIndex NS_SWIFT_NAME(signingChainQualifiedStatements(_:));
- (void)setSigningChainQualifiedStatements:(int)signingChainIndex :(int)newSigningChainQualifiedStatements NS_SWIFT_NAME(setSigningChainQualifiedStatements(_:_:));

- (NSString*)signingChainQualifiers:(int)signingChainIndex NS_SWIFT_NAME(signingChainQualifiers(_:));

- (BOOL)signingChainSelfSigned:(int)signingChainIndex NS_SWIFT_NAME(signingChainSelfSigned(_:));

- (NSData*)signingChainSerialNumber:(int)signingChainIndex NS_SWIFT_NAME(signingChainSerialNumber(_:));
- (void)setSigningChainSerialNumber:(int)signingChainIndex :(NSData*)newSigningChainSerialNumber NS_SWIFT_NAME(setSigningChainSerialNumber(_:_:));

- (NSString*)signingChainSigAlgorithm:(int)signingChainIndex NS_SWIFT_NAME(signingChainSigAlgorithm(_:));

- (int)signingChainSource:(int)signingChainIndex NS_SWIFT_NAME(signingChainSource(_:));

- (NSString*)signingChainSubject:(int)signingChainIndex NS_SWIFT_NAME(signingChainSubject(_:));

- (NSString*)signingChainSubjectAlternativeName:(int)signingChainIndex NS_SWIFT_NAME(signingChainSubjectAlternativeName(_:));
- (void)setSigningChainSubjectAlternativeName:(int)signingChainIndex :(NSString*)newSigningChainSubjectAlternativeName NS_SWIFT_NAME(setSigningChainSubjectAlternativeName(_:_:));

- (NSData*)signingChainSubjectKeyID:(int)signingChainIndex NS_SWIFT_NAME(signingChainSubjectKeyID(_:));
- (void)setSigningChainSubjectKeyID:(int)signingChainIndex :(NSData*)newSigningChainSubjectKeyID NS_SWIFT_NAME(setSigningChainSubjectKeyID(_:_:));

- (NSString*)signingChainSubjectRDN:(int)signingChainIndex NS_SWIFT_NAME(signingChainSubjectRDN(_:));
- (void)setSigningChainSubjectRDN:(int)signingChainIndex :(NSString*)newSigningChainSubjectRDN NS_SWIFT_NAME(setSigningChainSubjectRDN(_:_:));

- (BOOL)signingChainValid:(int)signingChainIndex NS_SWIFT_NAME(signingChainValid(_:));

- (NSString*)signingChainValidFrom:(int)signingChainIndex NS_SWIFT_NAME(signingChainValidFrom(_:));
- (void)setSigningChainValidFrom:(int)signingChainIndex :(NSString*)newSigningChainValidFrom NS_SWIFT_NAME(setSigningChainValidFrom(_:_:));

- (NSString*)signingChainValidTo:(int)signingChainIndex NS_SWIFT_NAME(signingChainValidTo(_:));
- (void)setSigningChainValidTo:(int)signingChainIndex :(NSString*)newSigningChainValidTo NS_SWIFT_NAME(setSigningChainValidTo(_:_:));

@property (nonatomic,readwrite,assign,getter=socketDNSMode,setter=setSocketDNSMode:) int socketDNSMode NS_SWIFT_NAME(socketDNSMode);

- (int)socketDNSMode NS_SWIFT_NAME(socketDNSMode());
- (void)setSocketDNSMode :(int)newSocketDNSMode NS_SWIFT_NAME(setSocketDNSMode(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSPort,setter=setSocketDNSPort:) int socketDNSPort NS_SWIFT_NAME(socketDNSPort);

- (int)socketDNSPort NS_SWIFT_NAME(socketDNSPort());
- (void)setSocketDNSPort :(int)newSocketDNSPort NS_SWIFT_NAME(setSocketDNSPort(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSQueryTimeout,setter=setSocketDNSQueryTimeout:) int socketDNSQueryTimeout NS_SWIFT_NAME(socketDNSQueryTimeout);

- (int)socketDNSQueryTimeout NS_SWIFT_NAME(socketDNSQueryTimeout());
- (void)setSocketDNSQueryTimeout :(int)newSocketDNSQueryTimeout NS_SWIFT_NAME(setSocketDNSQueryTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSServers,setter=setSocketDNSServers:) NSString* socketDNSServers NS_SWIFT_NAME(socketDNSServers);

- (NSString*)socketDNSServers NS_SWIFT_NAME(socketDNSServers());
- (void)setSocketDNSServers :(NSString*)newSocketDNSServers NS_SWIFT_NAME(setSocketDNSServers(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSTotalTimeout,setter=setSocketDNSTotalTimeout:) int socketDNSTotalTimeout NS_SWIFT_NAME(socketDNSTotalTimeout);

- (int)socketDNSTotalTimeout NS_SWIFT_NAME(socketDNSTotalTimeout());
- (void)setSocketDNSTotalTimeout :(int)newSocketDNSTotalTimeout NS_SWIFT_NAME(setSocketDNSTotalTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketIncomingSpeedLimit,setter=setSocketIncomingSpeedLimit:) int socketIncomingSpeedLimit NS_SWIFT_NAME(socketIncomingSpeedLimit);

- (int)socketIncomingSpeedLimit NS_SWIFT_NAME(socketIncomingSpeedLimit());
- (void)setSocketIncomingSpeedLimit :(int)newSocketIncomingSpeedLimit NS_SWIFT_NAME(setSocketIncomingSpeedLimit(_:));

@property (nonatomic,readwrite,assign,getter=socketLocalAddress,setter=setSocketLocalAddress:) NSString* socketLocalAddress NS_SWIFT_NAME(socketLocalAddress);

- (NSString*)socketLocalAddress NS_SWIFT_NAME(socketLocalAddress());
- (void)setSocketLocalAddress :(NSString*)newSocketLocalAddress NS_SWIFT_NAME(setSocketLocalAddress(_:));

@property (nonatomic,readwrite,assign,getter=socketLocalPort,setter=setSocketLocalPort:) int socketLocalPort NS_SWIFT_NAME(socketLocalPort);

- (int)socketLocalPort NS_SWIFT_NAME(socketLocalPort());
- (void)setSocketLocalPort :(int)newSocketLocalPort NS_SWIFT_NAME(setSocketLocalPort(_:));

@property (nonatomic,readwrite,assign,getter=socketOutgoingSpeedLimit,setter=setSocketOutgoingSpeedLimit:) int socketOutgoingSpeedLimit NS_SWIFT_NAME(socketOutgoingSpeedLimit);

- (int)socketOutgoingSpeedLimit NS_SWIFT_NAME(socketOutgoingSpeedLimit());
- (void)setSocketOutgoingSpeedLimit :(int)newSocketOutgoingSpeedLimit NS_SWIFT_NAME(setSocketOutgoingSpeedLimit(_:));

@property (nonatomic,readwrite,assign,getter=socketTimeout,setter=setSocketTimeout:) int socketTimeout NS_SWIFT_NAME(socketTimeout);

- (int)socketTimeout NS_SWIFT_NAME(socketTimeout());
- (void)setSocketTimeout :(int)newSocketTimeout NS_SWIFT_NAME(setSocketTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketUseIPv6,setter=setSocketUseIPv6:) BOOL socketUseIPv6 NS_SWIFT_NAME(socketUseIPv6);

- (BOOL)socketUseIPv6 NS_SWIFT_NAME(socketUseIPv6());
- (void)setSocketUseIPv6 :(BOOL)newSocketUseIPv6 NS_SWIFT_NAME(setSocketUseIPv6(_:));

@property (nonatomic,readwrite,assign,getter=storageId,setter=setStorageId:) NSString* storageId NS_SWIFT_NAME(storageId);

- (NSString*)storageId NS_SWIFT_NAME(storageId());
- (void)setStorageId :(NSString*)newStorageId NS_SWIFT_NAME(setStorageId(_:));

@property (nonatomic,readwrite,assign,getter=timestampServer,setter=setTimestampServer:) NSString* timestampServer NS_SWIFT_NAME(timestampServer);

- (NSString*)timestampServer NS_SWIFT_NAME(timestampServer());
- (void)setTimestampServer :(NSString*)newTimestampServer NS_SWIFT_NAME(setTimestampServer(_:));

@property (nonatomic,readwrite,assign,getter=TLSClientCertCount,setter=setTLSClientCertCount:) int TLSClientCertCount NS_SWIFT_NAME(TLSClientCertCount);

- (int)TLSClientCertCount NS_SWIFT_NAME(TLSClientCertCount());
- (void)setTLSClientCertCount :(int)newTLSClientCertCount NS_SWIFT_NAME(setTLSClientCertCount(_:));

- (NSData*)TLSClientCertBytes:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertBytes(_:));

- (BOOL)TLSClientCertCA:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCA(_:));
- (void)setTLSClientCertCA:(int)tLSClientCertIndex :(BOOL)newTLSClientCertCA NS_SWIFT_NAME(setTLSClientCertCA(_:_:));

- (NSData*)TLSClientCertCAKeyID:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCAKeyID(_:));

- (int)TLSClientCertCertType:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCertType(_:));

- (NSString*)TLSClientCertCRLDistributionPoints:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCRLDistributionPoints(_:));
- (void)setTLSClientCertCRLDistributionPoints:(int)tLSClientCertIndex :(NSString*)newTLSClientCertCRLDistributionPoints NS_SWIFT_NAME(setTLSClientCertCRLDistributionPoints(_:_:));

- (NSString*)TLSClientCertCurve:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCurve(_:));
- (void)setTLSClientCertCurve:(int)tLSClientCertIndex :(NSString*)newTLSClientCertCurve NS_SWIFT_NAME(setTLSClientCertCurve(_:_:));

- (NSString*)TLSClientCertFingerprint:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertFingerprint(_:));

- (NSString*)TLSClientCertFriendlyName:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertFriendlyName(_:));

- (long long)TLSClientCertHandle:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertHandle(_:));
- (void)setTLSClientCertHandle:(int)tLSClientCertIndex :(long long)newTLSClientCertHandle NS_SWIFT_NAME(setTLSClientCertHandle(_:_:));

- (NSString*)TLSClientCertHashAlgorithm:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertHashAlgorithm(_:));
- (void)setTLSClientCertHashAlgorithm:(int)tLSClientCertIndex :(NSString*)newTLSClientCertHashAlgorithm NS_SWIFT_NAME(setTLSClientCertHashAlgorithm(_:_:));

- (NSString*)TLSClientCertIssuer:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertIssuer(_:));

- (NSString*)TLSClientCertIssuerRDN:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertIssuerRDN(_:));
- (void)setTLSClientCertIssuerRDN:(int)tLSClientCertIndex :(NSString*)newTLSClientCertIssuerRDN NS_SWIFT_NAME(setTLSClientCertIssuerRDN(_:_:));

- (NSString*)TLSClientCertKeyAlgorithm:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyAlgorithm(_:));
- (void)setTLSClientCertKeyAlgorithm:(int)tLSClientCertIndex :(NSString*)newTLSClientCertKeyAlgorithm NS_SWIFT_NAME(setTLSClientCertKeyAlgorithm(_:_:));

- (int)TLSClientCertKeyBits:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyBits(_:));

- (NSString*)TLSClientCertKeyFingerprint:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyFingerprint(_:));

- (int)TLSClientCertKeyUsage:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyUsage(_:));
- (void)setTLSClientCertKeyUsage:(int)tLSClientCertIndex :(int)newTLSClientCertKeyUsage NS_SWIFT_NAME(setTLSClientCertKeyUsage(_:_:));

- (BOOL)TLSClientCertKeyValid:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyValid(_:));

- (NSString*)TLSClientCertOCSPLocations:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertOCSPLocations(_:));
- (void)setTLSClientCertOCSPLocations:(int)tLSClientCertIndex :(NSString*)newTLSClientCertOCSPLocations NS_SWIFT_NAME(setTLSClientCertOCSPLocations(_:_:));

- (BOOL)TLSClientCertOCSPNoCheck:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertOCSPNoCheck(_:));
- (void)setTLSClientCertOCSPNoCheck:(int)tLSClientCertIndex :(BOOL)newTLSClientCertOCSPNoCheck NS_SWIFT_NAME(setTLSClientCertOCSPNoCheck(_:_:));

- (int)TLSClientCertOrigin:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertOrigin(_:));

- (NSString*)TLSClientCertPolicyIDs:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPolicyIDs(_:));
- (void)setTLSClientCertPolicyIDs:(int)tLSClientCertIndex :(NSString*)newTLSClientCertPolicyIDs NS_SWIFT_NAME(setTLSClientCertPolicyIDs(_:_:));

- (NSData*)TLSClientCertPrivateKeyBytes:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPrivateKeyBytes(_:));

- (BOOL)TLSClientCertPrivateKeyExists:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPrivateKeyExists(_:));

- (BOOL)TLSClientCertPrivateKeyExtractable:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPrivateKeyExtractable(_:));

- (NSData*)TLSClientCertPublicKeyBytes:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPublicKeyBytes(_:));

- (BOOL)TLSClientCertQualified:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertQualified(_:));

- (int)TLSClientCertQualifiedStatements:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertQualifiedStatements(_:));
- (void)setTLSClientCertQualifiedStatements:(int)tLSClientCertIndex :(int)newTLSClientCertQualifiedStatements NS_SWIFT_NAME(setTLSClientCertQualifiedStatements(_:_:));

- (NSString*)TLSClientCertQualifiers:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertQualifiers(_:));

- (BOOL)TLSClientCertSelfSigned:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSelfSigned(_:));

- (NSData*)TLSClientCertSerialNumber:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSerialNumber(_:));
- (void)setTLSClientCertSerialNumber:(int)tLSClientCertIndex :(NSData*)newTLSClientCertSerialNumber NS_SWIFT_NAME(setTLSClientCertSerialNumber(_:_:));

- (NSString*)TLSClientCertSigAlgorithm:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSigAlgorithm(_:));

- (int)TLSClientCertSource:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSource(_:));

- (NSString*)TLSClientCertSubject:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSubject(_:));

- (NSString*)TLSClientCertSubjectAlternativeName:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSubjectAlternativeName(_:));
- (void)setTLSClientCertSubjectAlternativeName:(int)tLSClientCertIndex :(NSString*)newTLSClientCertSubjectAlternativeName NS_SWIFT_NAME(setTLSClientCertSubjectAlternativeName(_:_:));

- (NSData*)TLSClientCertSubjectKeyID:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSubjectKeyID(_:));
- (void)setTLSClientCertSubjectKeyID:(int)tLSClientCertIndex :(NSData*)newTLSClientCertSubjectKeyID NS_SWIFT_NAME(setTLSClientCertSubjectKeyID(_:_:));

- (NSString*)TLSClientCertSubjectRDN:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSubjectRDN(_:));
- (void)setTLSClientCertSubjectRDN:(int)tLSClientCertIndex :(NSString*)newTLSClientCertSubjectRDN NS_SWIFT_NAME(setTLSClientCertSubjectRDN(_:_:));

- (BOOL)TLSClientCertValid:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertValid(_:));

- (NSString*)TLSClientCertValidFrom:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertValidFrom(_:));
- (void)setTLSClientCertValidFrom:(int)tLSClientCertIndex :(NSString*)newTLSClientCertValidFrom NS_SWIFT_NAME(setTLSClientCertValidFrom(_:_:));

- (NSString*)TLSClientCertValidTo:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertValidTo(_:));
- (void)setTLSClientCertValidTo:(int)tLSClientCertIndex :(NSString*)newTLSClientCertValidTo NS_SWIFT_NAME(setTLSClientCertValidTo(_:_:));

@property (nonatomic,readonly,assign,getter=TLSServerCertCount) int TLSServerCertCount NS_SWIFT_NAME(TLSServerCertCount);

- (int)TLSServerCertCount NS_SWIFT_NAME(TLSServerCertCount());

- (NSData*)TLSServerCertBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertBytes(_:));

- (BOOL)TLSServerCertCA:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCA(_:));

- (NSData*)TLSServerCertCAKeyID:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCAKeyID(_:));

- (int)TLSServerCertCertType:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCertType(_:));

- (NSString*)TLSServerCertCRLDistributionPoints:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCRLDistributionPoints(_:));

- (NSString*)TLSServerCertCurve:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCurve(_:));

- (NSString*)TLSServerCertFingerprint:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertFingerprint(_:));

- (NSString*)TLSServerCertFriendlyName:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertFriendlyName(_:));

- (long long)TLSServerCertHandle:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertHandle(_:));

- (NSString*)TLSServerCertHashAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertHashAlgorithm(_:));

- (NSString*)TLSServerCertIssuer:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertIssuer(_:));

- (NSString*)TLSServerCertIssuerRDN:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertIssuerRDN(_:));

- (NSString*)TLSServerCertKeyAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyAlgorithm(_:));

- (int)TLSServerCertKeyBits:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyBits(_:));

- (NSString*)TLSServerCertKeyFingerprint:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyFingerprint(_:));

- (int)TLSServerCertKeyUsage:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyUsage(_:));

- (BOOL)TLSServerCertKeyValid:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyValid(_:));

- (NSString*)TLSServerCertOCSPLocations:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOCSPLocations(_:));

- (BOOL)TLSServerCertOCSPNoCheck:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOCSPNoCheck(_:));

- (int)TLSServerCertOrigin:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOrigin(_:));

- (NSString*)TLSServerCertPolicyIDs:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPolicyIDs(_:));

- (NSData*)TLSServerCertPrivateKeyBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyBytes(_:));

- (BOOL)TLSServerCertPrivateKeyExists:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyExists(_:));

- (BOOL)TLSServerCertPrivateKeyExtractable:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyExtractable(_:));

- (NSData*)TLSServerCertPublicKeyBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPublicKeyBytes(_:));

- (BOOL)TLSServerCertQualified:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualified(_:));

- (int)TLSServerCertQualifiedStatements:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualifiedStatements(_:));

- (NSString*)TLSServerCertQualifiers:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualifiers(_:));

- (BOOL)TLSServerCertSelfSigned:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSelfSigned(_:));

- (NSData*)TLSServerCertSerialNumber:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSerialNumber(_:));

- (NSString*)TLSServerCertSigAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSigAlgorithm(_:));

- (int)TLSServerCertSource:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSource(_:));

- (NSString*)TLSServerCertSubject:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubject(_:));

- (NSString*)TLSServerCertSubjectAlternativeName:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectAlternativeName(_:));

- (NSData*)TLSServerCertSubjectKeyID:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectKeyID(_:));

- (NSString*)TLSServerCertSubjectRDN:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectRDN(_:));

- (BOOL)TLSServerCertValid:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValid(_:));

- (NSString*)TLSServerCertValidFrom:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValidFrom(_:));

- (NSString*)TLSServerCertValidTo:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValidTo(_:));

@property (nonatomic,readwrite,assign,getter=TLSAutoValidateCertificates,setter=setTLSAutoValidateCertificates:) BOOL TLSAutoValidateCertificates NS_SWIFT_NAME(TLSAutoValidateCertificates);

- (BOOL)TLSAutoValidateCertificates NS_SWIFT_NAME(TLSAutoValidateCertificates());
- (void)setTLSAutoValidateCertificates :(BOOL)newTLSAutoValidateCertificates NS_SWIFT_NAME(setTLSAutoValidateCertificates(_:));

@property (nonatomic,readwrite,assign,getter=TLSBaseConfiguration,setter=setTLSBaseConfiguration:) int TLSBaseConfiguration NS_SWIFT_NAME(TLSBaseConfiguration);

- (int)TLSBaseConfiguration NS_SWIFT_NAME(TLSBaseConfiguration());
- (void)setTLSBaseConfiguration :(int)newTLSBaseConfiguration NS_SWIFT_NAME(setTLSBaseConfiguration(_:));

@property (nonatomic,readwrite,assign,getter=TLSCiphersuites,setter=setTLSCiphersuites:) NSString* TLSCiphersuites NS_SWIFT_NAME(TLSCiphersuites);

- (NSString*)TLSCiphersuites NS_SWIFT_NAME(TLSCiphersuites());
- (void)setTLSCiphersuites :(NSString*)newTLSCiphersuites NS_SWIFT_NAME(setTLSCiphersuites(_:));

@property (nonatomic,readwrite,assign,getter=TLSClientAuth,setter=setTLSClientAuth:) int TLSClientAuth NS_SWIFT_NAME(TLSClientAuth);

- (int)TLSClientAuth NS_SWIFT_NAME(TLSClientAuth());
- (void)setTLSClientAuth :(int)newTLSClientAuth NS_SWIFT_NAME(setTLSClientAuth(_:));

@property (nonatomic,readwrite,assign,getter=TLSECCurves,setter=setTLSECCurves:) NSString* TLSECCurves NS_SWIFT_NAME(TLSECCurves);

- (NSString*)TLSECCurves NS_SWIFT_NAME(TLSECCurves());
- (void)setTLSECCurves :(NSString*)newTLSECCurves NS_SWIFT_NAME(setTLSECCurves(_:));

@property (nonatomic,readwrite,assign,getter=TLSExtensions,setter=setTLSExtensions:) NSString* TLSExtensions NS_SWIFT_NAME(TLSExtensions);

- (NSString*)TLSExtensions NS_SWIFT_NAME(TLSExtensions());
- (void)setTLSExtensions :(NSString*)newTLSExtensions NS_SWIFT_NAME(setTLSExtensions(_:));

@property (nonatomic,readwrite,assign,getter=TLSForceResumeIfDestinationChanges,setter=setTLSForceResumeIfDestinationChanges:) BOOL TLSForceResumeIfDestinationChanges NS_SWIFT_NAME(TLSForceResumeIfDestinationChanges);

- (BOOL)TLSForceResumeIfDestinationChanges NS_SWIFT_NAME(TLSForceResumeIfDestinationChanges());
- (void)setTLSForceResumeIfDestinationChanges :(BOOL)newTLSForceResumeIfDestinationChanges NS_SWIFT_NAME(setTLSForceResumeIfDestinationChanges(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedIdentity,setter=setTLSPreSharedIdentity:) NSString* TLSPreSharedIdentity NS_SWIFT_NAME(TLSPreSharedIdentity);

- (NSString*)TLSPreSharedIdentity NS_SWIFT_NAME(TLSPreSharedIdentity());
- (void)setTLSPreSharedIdentity :(NSString*)newTLSPreSharedIdentity NS_SWIFT_NAME(setTLSPreSharedIdentity(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedKey,setter=setTLSPreSharedKey:) NSString* TLSPreSharedKey NS_SWIFT_NAME(TLSPreSharedKey);

- (NSString*)TLSPreSharedKey NS_SWIFT_NAME(TLSPreSharedKey());
- (void)setTLSPreSharedKey :(NSString*)newTLSPreSharedKey NS_SWIFT_NAME(setTLSPreSharedKey(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedKeyCiphersuite,setter=setTLSPreSharedKeyCiphersuite:) NSString* TLSPreSharedKeyCiphersuite NS_SWIFT_NAME(TLSPreSharedKeyCiphersuite);

- (NSString*)TLSPreSharedKeyCiphersuite NS_SWIFT_NAME(TLSPreSharedKeyCiphersuite());
- (void)setTLSPreSharedKeyCiphersuite :(NSString*)newTLSPreSharedKeyCiphersuite NS_SWIFT_NAME(setTLSPreSharedKeyCiphersuite(_:));

@property (nonatomic,readwrite,assign,getter=TLSRenegotiationAttackPreventionMode,setter=setTLSRenegotiationAttackPreventionMode:) int TLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(TLSRenegotiationAttackPreventionMode);

- (int)TLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(TLSRenegotiationAttackPreventionMode());
- (void)setTLSRenegotiationAttackPreventionMode :(int)newTLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(setTLSRenegotiationAttackPreventionMode(_:));

@property (nonatomic,readwrite,assign,getter=TLSRevocationCheck,setter=setTLSRevocationCheck:) int TLSRevocationCheck NS_SWIFT_NAME(TLSRevocationCheck);

- (int)TLSRevocationCheck NS_SWIFT_NAME(TLSRevocationCheck());
- (void)setTLSRevocationCheck :(int)newTLSRevocationCheck NS_SWIFT_NAME(setTLSRevocationCheck(_:));

@property (nonatomic,readwrite,assign,getter=TLSSSLOptions,setter=setTLSSSLOptions:) int TLSSSLOptions NS_SWIFT_NAME(TLSSSLOptions);

- (int)TLSSSLOptions NS_SWIFT_NAME(TLSSSLOptions());
- (void)setTLSSSLOptions :(int)newTLSSSLOptions NS_SWIFT_NAME(setTLSSSLOptions(_:));

@property (nonatomic,readwrite,assign,getter=TLSTLSMode,setter=setTLSTLSMode:) int TLSTLSMode NS_SWIFT_NAME(TLSTLSMode);

- (int)TLSTLSMode NS_SWIFT_NAME(TLSTLSMode());
- (void)setTLSTLSMode :(int)newTLSTLSMode NS_SWIFT_NAME(setTLSTLSMode(_:));

@property (nonatomic,readwrite,assign,getter=TLSUseExtendedMasterSecret,setter=setTLSUseExtendedMasterSecret:) BOOL TLSUseExtendedMasterSecret NS_SWIFT_NAME(TLSUseExtendedMasterSecret);

- (BOOL)TLSUseExtendedMasterSecret NS_SWIFT_NAME(TLSUseExtendedMasterSecret());
- (void)setTLSUseExtendedMasterSecret :(BOOL)newTLSUseExtendedMasterSecret NS_SWIFT_NAME(setTLSUseExtendedMasterSecret(_:));

@property (nonatomic,readwrite,assign,getter=TLSUseSessionResumption,setter=setTLSUseSessionResumption:) BOOL TLSUseSessionResumption NS_SWIFT_NAME(TLSUseSessionResumption);

- (BOOL)TLSUseSessionResumption NS_SWIFT_NAME(TLSUseSessionResumption());
- (void)setTLSUseSessionResumption :(BOOL)newTLSUseSessionResumption NS_SWIFT_NAME(setTLSUseSessionResumption(_:));

@property (nonatomic,readwrite,assign,getter=TLSVersions,setter=setTLSVersions:) int TLSVersions NS_SWIFT_NAME(TLSVersions);

- (int)TLSVersions NS_SWIFT_NAME(TLSVersions());
- (void)setTLSVersions :(int)newTLSVersions NS_SWIFT_NAME(setTLSVersions(_:));

  /* Methods */

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (void)processRequest NS_SWIFT_NAME(processRequest());

- (void)reset NS_SWIFT_NAME(reset());

@end

