/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//SAMLAUTHNCONTEXTCOMPARISONS
#define CACCT_NONE                                         0

#define CACCT_EXACT                                        1

#define CACCT_MINIMUM                                      2

#define CACCT_MAXIMUM                                      3

#define CACCT_BETTER                                       4

//SAMLAUTHNREFTYPES
#define CACRT_UNKNOWN                                      0

#define CACRT_CLASS                                        1

#define CACRT_DECL                                         2

//SAMLBINDINGTYPES
#define CSBT_NONE                                          0

#define CSBT_SOAP                                          1

#define CSBT_PAOS                                          2

#define CSBT_REDIRECT                                      3

#define CSBT_POST                                          4

#define CSBT_ARTIFACT                                      5

//SAMLPOSTBINDINGMODES
#define CSPM_CLIENT                                        0

#define CSPM_SERVER                                        1

//SIGNATUREVALIDITIES
#define SVT_VALID                                          0

#define SVT_UNKNOWN                                        1

#define SVT_CORRUPTED                                      2

#define SVT_SIGNER_NOT_FOUND                               3

#define SVT_FAILURE                                        4

#define SVT_REFERENCE_CORRUPTED                            5

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

//SAMLCONDITIONTYPES
#define CSCT_AUDIENCE_RESTRICTION                          0

#define CSCT_ONE_TIME_USE                                  1

#define CSCT_PROXY_RESTRICTION                             2

#define CSCT_NOT_BEFORE                                    3

#define CSCT_NOT_ON_OR_AFTER                               4

//SAMLCONTENTTYPES
#define CSTY_NONE                                          0

#define CSTY_ASSERTION_IDREQUEST                           1

#define CSTY_SUBJECT_QUERY                                 2

#define CSTY_AUTHN_QUERY                                   3

#define CSTY_ATTRIBUTE_QUERY                               4

#define CSTY_AUTHZ_DECISION_QUERY                          5

#define CSTY_AUTHN_REQUEST                                 6

#define CSTY_MANAGE_NAME_IDREQUEST                         7

#define CSTY_LOGOUT_REQUEST                                8

#define CSTY_NAME_IDMAPPING_REQUEST                        9

#define CSTY_ARTIFACT_RESOLVE                              10

#define CSTY_RESPONSE                                      11

#define CSTY_ASSERTION                                     12

//SAMLASSERTIONTYPES
#define CSAT_ASSERTION_IDREF                               0

#define CSAT_ASSERTION_URIREF                              1

#define CSAT_ASSERTION                                     2

#define CSAT_ENCRYPTED_ASSERTION                           3

//PROXYAUTHTYPES
#define PAT_NO_AUTHENTICATION                              0

#define PAT_BASIC                                          1

#define PAT_DIGEST                                         2

#define PAT_NTLM                                           3

//PROXYTYPES
#define CPT_NONE                                           0

#define CPT_SOCKS_4                                        1

#define CPT_SOCKS_5                                        2

#define CPT_WEB_TUNNEL                                     3

#define CPT_HTTP                                           4

//SAMLRESPONSETYPES
#define CSRT_RESPONSE                                      0

#define CSRT_ARTIFACT_RESPONSE                             1

#define CSRT_NAME_IDMAPPING_RESPONSE                       2

//SAMLSIGNATUREPOLICIES
#define SSP_AUTO                                           0

#define SSP_VALIDATE                                       1

#define SSP_REQUIRE                                        2

#define SSP_IGNORE                                         3

//DNSRESOLVEMODES
#define DM_AUTO                                            0

#define DM_PLATFORM                                        1

#define DM_OWN                                             2

#define DM_OWN_SECURE                                      3

//SAMLDECISIONS
#define CSADN_PERMIT                                       0

#define CSADN_DENY                                         1

#define CSADN_INDETERMINATE                                2

//SAMLASSERTIONSTATEMENTTYPES
#define CSAST_AUTHN                                        0

#define CSAST_ATTRIBUTE                                    1

#define CSAST_AUTHZ_DECISION                               2

//SECURETRANSPORTPREDEFINEDCONFIGURATIONS
#define STPC_DEFAULT                                       0

#define STPC_COMPATIBLE                                    1

#define STPC_COMPREHENSIVE_INSECURE                        2

#define STPC_HIGHLY_SECURE                                 3

//CLIENTAUTHTYPES
#define CCAT_NO_AUTH                                       0

#define CCAT_REQUEST_CERT                                  1

#define CCAT_REQUIRE_CERT                                  2

//RENEGOTIATIONATTACKPREVENTIONMODES
#define CRAPM_COMPATIBLE                                   0

#define CRAPM_STRICT                                       1

#define CRAPM_AUTO                                         2

//REVOCATIONCHECKKINDS
#define CRC_NONE                                           0

#define CRC_AUTO                                           1

#define CRC_ALL_CRL                                        2

#define CRC_ALL_OCSP                                       3

#define CRC_ALL_CRLAND_OCSP                                4

#define CRC_ANY_CRL                                        5

#define CRC_ANY_OCSP                                       6

#define CRC_ANY_CRLOR_OCSP                                 7

#define CRC_ANY_OCSPOR_CRL                                 8

//SSLMODES
#define SM_DEFAULT                                         0

#define SM_NO_TLS                                          1

#define SM_EXPLICIT_TLS                                    2

#define SM_IMPLICIT_TLS                                    3

#define SM_MIXED_TLS                                       4

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxSAMLReaderDelegate <NSObject>
@optional
- (void)onEncrypted:(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(BOOL)needCredential :(int*)skipThis NS_SWIFT_NAME(onEncrypted(_:_:_:_:_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onSignatureFound:(int)scope :(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(BOOL)certFound :(int*)validate NS_SWIFT_NAME(onSignatureFound(_:_:_:_:_:_:));

- (void)onSignatureValidated:(int)scope :(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(int*)validationResult NS_SWIFT_NAME(onSignatureValidated(_:_:_:_:_:));

@end

@interface SecureBlackboxSAMLReader : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxSAMLReaderDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasEncrypted;

  BOOL m_delegateHasError;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasSignatureFound;

  BOOL m_delegateHasSignatureValidated;

}

+ (SecureBlackboxSAMLReader*)samlreader;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxSAMLReaderDelegate> delegate;
- (id <SecureBlackboxSAMLReaderDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxSAMLReaderDelegate>)anObject;

  /* Events */

- (void)onEncrypted:(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(BOOL)needCredential :(int*)skipThis NS_SWIFT_NAME(onEncrypted(_:_:_:_:_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onSignatureFound:(int)scope :(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(BOOL)certFound :(int*)validate NS_SWIFT_NAME(onSignatureFound(_:_:_:_:_:_:));

- (void)onSignatureValidated:(int)scope :(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(int*)validationResult NS_SWIFT_NAME(onSignatureValidated(_:_:_:_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readonly,assign,getter=artifactEndpointIndex) int artifactEndpointIndex NS_SWIFT_NAME(artifactEndpointIndex);

- (int)artifactEndpointIndex NS_SWIFT_NAME(artifactEndpointIndex());

@property (nonatomic,readonly,assign,getter=artifactMessageHandle) NSData* artifactMessageHandle NS_SWIFT_NAME(artifactMessageHandle);

- (NSData*)artifactMessageHandle NS_SWIFT_NAME(artifactMessageHandle());

@property (nonatomic,readonly,assign,getter=artifactRemainingArtifact) NSData* artifactRemainingArtifact NS_SWIFT_NAME(artifactRemainingArtifact);

- (NSData*)artifactRemainingArtifact NS_SWIFT_NAME(artifactRemainingArtifact());

@property (nonatomic,readonly,assign,getter=artifactSourceID) NSData* artifactSourceID NS_SWIFT_NAME(artifactSourceID);

- (NSData*)artifactSourceID NS_SWIFT_NAME(artifactSourceID());

@property (nonatomic,readonly,assign,getter=artifactTypeCode) int artifactTypeCode NS_SWIFT_NAME(artifactTypeCode);

- (int)artifactTypeCode NS_SWIFT_NAME(artifactTypeCode());

@property (nonatomic,readonly,assign,getter=artifactURI) NSString* artifactURI NS_SWIFT_NAME(artifactURI);

- (NSString*)artifactURI NS_SWIFT_NAME(artifactURI());

@property (nonatomic,readonly,assign,getter=artifactResolveQuery) NSString* artifactResolveQuery NS_SWIFT_NAME(artifactResolveQuery);

- (NSString*)artifactResolveQuery NS_SWIFT_NAME(artifactResolveQuery());

@property (nonatomic,readonly,assign,getter=assertionCount) int assertionCount NS_SWIFT_NAME(assertionCount);

- (int)assertionCount NS_SWIFT_NAME(assertionCount());

@property (nonatomic,readonly,assign,getter=attributeCount) int attributeCount NS_SWIFT_NAME(attributeCount);

- (int)attributeCount NS_SWIFT_NAME(attributeCount());

- (NSString*)attributeFriendlyName:(int)attributeIndex NS_SWIFT_NAME(attributeFriendlyName(_:));

- (NSString*)attributeName:(int)attributeIndex NS_SWIFT_NAME(attributeName(_:));

- (NSString*)attributeNameFormat:(int)attributeIndex NS_SWIFT_NAME(attributeNameFormat(_:));

- (int)attributeStatementIndex:(int)attributeIndex NS_SWIFT_NAME(attributeStatementIndex(_:));

- (NSString*)attributeValues:(int)attributeIndex NS_SWIFT_NAME(attributeValues(_:));

@property (nonatomic,readonly,assign,getter=authnQueryComparison) int authnQueryComparison NS_SWIFT_NAME(authnQueryComparison);

- (int)authnQueryComparison NS_SWIFT_NAME(authnQueryComparison());

@property (nonatomic,readonly,assign,getter=authnQueryContextClassRefs) NSString* authnQueryContextClassRefs NS_SWIFT_NAME(authnQueryContextClassRefs);

- (NSString*)authnQueryContextClassRefs NS_SWIFT_NAME(authnQueryContextClassRefs());

@property (nonatomic,readonly,assign,getter=authnQueryRefType) int authnQueryRefType NS_SWIFT_NAME(authnQueryRefType);

- (int)authnQueryRefType NS_SWIFT_NAME(authnQueryRefType());

@property (nonatomic,readonly,assign,getter=authnQuerySessionIndex) NSString* authnQuerySessionIndex NS_SWIFT_NAME(authnQuerySessionIndex);

- (NSString*)authnQuerySessionIndex NS_SWIFT_NAME(authnQuerySessionIndex());

@property (nonatomic,readonly,assign,getter=authnRequestAssertionConsumerServiceIndex) int authnRequestAssertionConsumerServiceIndex NS_SWIFT_NAME(authnRequestAssertionConsumerServiceIndex);

- (int)authnRequestAssertionConsumerServiceIndex NS_SWIFT_NAME(authnRequestAssertionConsumerServiceIndex());

@property (nonatomic,readonly,assign,getter=authnRequestAssertionConsumerServiceURL) NSString* authnRequestAssertionConsumerServiceURL NS_SWIFT_NAME(authnRequestAssertionConsumerServiceURL);

- (NSString*)authnRequestAssertionConsumerServiceURL NS_SWIFT_NAME(authnRequestAssertionConsumerServiceURL());

@property (nonatomic,readonly,assign,getter=authnRequestAttributeConsumingServiceIndex) int authnRequestAttributeConsumingServiceIndex NS_SWIFT_NAME(authnRequestAttributeConsumingServiceIndex);

- (int)authnRequestAttributeConsumingServiceIndex NS_SWIFT_NAME(authnRequestAttributeConsumingServiceIndex());

@property (nonatomic,readonly,assign,getter=authnRequestContextClassRefs) NSString* authnRequestContextClassRefs NS_SWIFT_NAME(authnRequestContextClassRefs);

- (NSString*)authnRequestContextClassRefs NS_SWIFT_NAME(authnRequestContextClassRefs());

@property (nonatomic,readonly,assign,getter=authnRequestContextComparison) int authnRequestContextComparison NS_SWIFT_NAME(authnRequestContextComparison);

- (int)authnRequestContextComparison NS_SWIFT_NAME(authnRequestContextComparison());

@property (nonatomic,readonly,assign,getter=authnRequestContextRefType) int authnRequestContextRefType NS_SWIFT_NAME(authnRequestContextRefType);

- (int)authnRequestContextRefType NS_SWIFT_NAME(authnRequestContextRefType());

@property (nonatomic,readonly,assign,getter=authnRequestFlags) int authnRequestFlags NS_SWIFT_NAME(authnRequestFlags);

- (int)authnRequestFlags NS_SWIFT_NAME(authnRequestFlags());

@property (nonatomic,readonly,assign,getter=authnRequestForceAuthn) BOOL authnRequestForceAuthn NS_SWIFT_NAME(authnRequestForceAuthn);

- (BOOL)authnRequestForceAuthn NS_SWIFT_NAME(authnRequestForceAuthn());

@property (nonatomic,readonly,assign,getter=authnRequestIsPassive) BOOL authnRequestIsPassive NS_SWIFT_NAME(authnRequestIsPassive);

- (BOOL)authnRequestIsPassive NS_SWIFT_NAME(authnRequestIsPassive());

@property (nonatomic,readonly,assign,getter=authnRequestNameIDPolicyAllowCreate) BOOL authnRequestNameIDPolicyAllowCreate NS_SWIFT_NAME(authnRequestNameIDPolicyAllowCreate);

- (BOOL)authnRequestNameIDPolicyAllowCreate NS_SWIFT_NAME(authnRequestNameIDPolicyAllowCreate());

@property (nonatomic,readonly,assign,getter=authnRequestNameIDPolicyFormat) NSString* authnRequestNameIDPolicyFormat NS_SWIFT_NAME(authnRequestNameIDPolicyFormat);

- (NSString*)authnRequestNameIDPolicyFormat NS_SWIFT_NAME(authnRequestNameIDPolicyFormat());

@property (nonatomic,readonly,assign,getter=authnRequestNameIDPolicySPNameQualifier) NSString* authnRequestNameIDPolicySPNameQualifier NS_SWIFT_NAME(authnRequestNameIDPolicySPNameQualifier);

- (NSString*)authnRequestNameIDPolicySPNameQualifier NS_SWIFT_NAME(authnRequestNameIDPolicySPNameQualifier());

@property (nonatomic,readonly,assign,getter=authnRequestProtocolBinding) NSString* authnRequestProtocolBinding NS_SWIFT_NAME(authnRequestProtocolBinding);

- (NSString*)authnRequestProtocolBinding NS_SWIFT_NAME(authnRequestProtocolBinding());

@property (nonatomic,readonly,assign,getter=authnRequestProviderName) NSString* authnRequestProviderName NS_SWIFT_NAME(authnRequestProviderName);

- (NSString*)authnRequestProviderName NS_SWIFT_NAME(authnRequestProviderName());

@property (nonatomic,readonly,assign,getter=authnRequestScopingGetComplete) NSString* authnRequestScopingGetComplete NS_SWIFT_NAME(authnRequestScopingGetComplete);

- (NSString*)authnRequestScopingGetComplete NS_SWIFT_NAME(authnRequestScopingGetComplete());

@property (nonatomic,readonly,assign,getter=authnRequestScopingProxyCount) int authnRequestScopingProxyCount NS_SWIFT_NAME(authnRequestScopingProxyCount);

- (int)authnRequestScopingProxyCount NS_SWIFT_NAME(authnRequestScopingProxyCount());

@property (nonatomic,readonly,assign,getter=authnRequestScopingRequesterIDs) NSString* authnRequestScopingRequesterIDs NS_SWIFT_NAME(authnRequestScopingRequesterIDs);

- (NSString*)authnRequestScopingRequesterIDs NS_SWIFT_NAME(authnRequestScopingRequesterIDs());

@property (nonatomic,readonly,assign,getter=authzDecisionQueryActions) NSString* authzDecisionQueryActions NS_SWIFT_NAME(authzDecisionQueryActions);

- (NSString*)authzDecisionQueryActions NS_SWIFT_NAME(authzDecisionQueryActions());

@property (nonatomic,readonly,assign,getter=authzDecisionQueryResource) NSString* authzDecisionQueryResource NS_SWIFT_NAME(authzDecisionQueryResource);

- (NSString*)authzDecisionQueryResource NS_SWIFT_NAME(authzDecisionQueryResource());

@property (nonatomic,readonly,assign,getter=bindingBindingType) int bindingBindingType NS_SWIFT_NAME(bindingBindingType);

- (int)bindingBindingType NS_SWIFT_NAME(bindingBindingType());

@property (nonatomic,readonly,assign,getter=bindingBody) NSString* bindingBody NS_SWIFT_NAME(bindingBody);

- (NSString*)bindingBody NS_SWIFT_NAME(bindingBody());

@property (nonatomic,readonly,assign,getter=bindingEncoding) NSString* bindingEncoding NS_SWIFT_NAME(bindingEncoding);

- (NSString*)bindingEncoding NS_SWIFT_NAME(bindingEncoding());

@property (nonatomic,readonly,assign,getter=bindingForceSign) BOOL bindingForceSign NS_SWIFT_NAME(bindingForceSign);

- (BOOL)bindingForceSign NS_SWIFT_NAME(bindingForceSign());

@property (nonatomic,readonly,assign,getter=bindingFormTemplate) NSString* bindingFormTemplate NS_SWIFT_NAME(bindingFormTemplate);

- (NSString*)bindingFormTemplate NS_SWIFT_NAME(bindingFormTemplate());

@property (nonatomic,readonly,assign,getter=bindingPOSTMode) int bindingPOSTMode NS_SWIFT_NAME(bindingPOSTMode);

- (int)bindingPOSTMode NS_SWIFT_NAME(bindingPOSTMode());

@property (nonatomic,readonly,assign,getter=bindingRelayState) NSString* bindingRelayState NS_SWIFT_NAME(bindingRelayState);

- (NSString*)bindingRelayState NS_SWIFT_NAME(bindingRelayState());

@property (nonatomic,readonly,assign,getter=bindingSignatureAlgorithm) NSString* bindingSignatureAlgorithm NS_SWIFT_NAME(bindingSignatureAlgorithm);

- (NSString*)bindingSignatureAlgorithm NS_SWIFT_NAME(bindingSignatureAlgorithm());

@property (nonatomic,readonly,assign,getter=bindingSignatureValidationResult) int bindingSignatureValidationResult NS_SWIFT_NAME(bindingSignatureValidationResult);

- (int)bindingSignatureValidationResult NS_SWIFT_NAME(bindingSignatureValidationResult());

@property (nonatomic,readonly,assign,getter=bindingSigned) BOOL bindingSigned NS_SWIFT_NAME(bindingSigned);

- (BOOL)bindingSigned NS_SWIFT_NAME(bindingSigned());

@property (nonatomic,readonly,assign,getter=bindingURL) NSString* bindingURL NS_SWIFT_NAME(bindingURL);

- (NSString*)bindingURL NS_SWIFT_NAME(bindingURL());

@property (nonatomic,readonly,assign,getter=bindingVerifySignatures) BOOL bindingVerifySignatures NS_SWIFT_NAME(bindingVerifySignatures);

- (BOOL)bindingVerifySignatures NS_SWIFT_NAME(bindingVerifySignatures());

@property (nonatomic,readwrite,assign,getter=bindingKeyAlgorithm,setter=setBindingKeyAlgorithm:) NSString* bindingKeyAlgorithm NS_SWIFT_NAME(bindingKeyAlgorithm);

- (NSString*)bindingKeyAlgorithm NS_SWIFT_NAME(bindingKeyAlgorithm());
- (void)setBindingKeyAlgorithm :(NSString*)newBindingKeyAlgorithm NS_SWIFT_NAME(setBindingKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=bindingKeyBits) int bindingKeyBits NS_SWIFT_NAME(bindingKeyBits);

- (int)bindingKeyBits NS_SWIFT_NAME(bindingKeyBits());

@property (nonatomic,readwrite,assign,getter=bindingKeyCurve,setter=setBindingKeyCurve:) NSString* bindingKeyCurve NS_SWIFT_NAME(bindingKeyCurve);

- (NSString*)bindingKeyCurve NS_SWIFT_NAME(bindingKeyCurve());
- (void)setBindingKeyCurve :(NSString*)newBindingKeyCurve NS_SWIFT_NAME(setBindingKeyCurve(_:));

@property (nonatomic,readonly,assign,getter=bindingKeyExportable) BOOL bindingKeyExportable NS_SWIFT_NAME(bindingKeyExportable);

- (BOOL)bindingKeyExportable NS_SWIFT_NAME(bindingKeyExportable());

@property (nonatomic,readonly,assign,getter=bindingKeyFingerprint) NSString* bindingKeyFingerprint NS_SWIFT_NAME(bindingKeyFingerprint);

- (NSString*)bindingKeyFingerprint NS_SWIFT_NAME(bindingKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=bindingKeyHandle,setter=setBindingKeyHandle:) long long bindingKeyHandle NS_SWIFT_NAME(bindingKeyHandle);

- (long long)bindingKeyHandle NS_SWIFT_NAME(bindingKeyHandle());
- (void)setBindingKeyHandle :(long long)newBindingKeyHandle NS_SWIFT_NAME(setBindingKeyHandle(_:));

@property (nonatomic,readwrite,assign,getter=bindingKeyID,setter=setBindingKeyID:) NSData* bindingKeyID NS_SWIFT_NAME(bindingKeyID);

- (NSData*)bindingKeyID NS_SWIFT_NAME(bindingKeyID());
- (void)setBindingKeyID :(NSData*)newBindingKeyID NS_SWIFT_NAME(setBindingKeyID(_:));

@property (nonatomic,readwrite,assign,getter=bindingKeyIV,setter=setBindingKeyIV:) NSData* bindingKeyIV NS_SWIFT_NAME(bindingKeyIV);

- (NSData*)bindingKeyIV NS_SWIFT_NAME(bindingKeyIV());
- (void)setBindingKeyIV :(NSData*)newBindingKeyIV NS_SWIFT_NAME(setBindingKeyIV(_:));

@property (nonatomic,readonly,assign,getter=bindingKeyKey) NSData* bindingKeyKey NS_SWIFT_NAME(bindingKeyKey);

- (NSData*)bindingKeyKey NS_SWIFT_NAME(bindingKeyKey());

@property (nonatomic,readwrite,assign,getter=bindingKeyNonce,setter=setBindingKeyNonce:) NSData* bindingKeyNonce NS_SWIFT_NAME(bindingKeyNonce);

- (NSData*)bindingKeyNonce NS_SWIFT_NAME(bindingKeyNonce());
- (void)setBindingKeyNonce :(NSData*)newBindingKeyNonce NS_SWIFT_NAME(setBindingKeyNonce(_:));

@property (nonatomic,readonly,assign,getter=bindingKeyPrivate) BOOL bindingKeyPrivate NS_SWIFT_NAME(bindingKeyPrivate);

- (BOOL)bindingKeyPrivate NS_SWIFT_NAME(bindingKeyPrivate());

@property (nonatomic,readonly,assign,getter=bindingKeyPublic) BOOL bindingKeyPublic NS_SWIFT_NAME(bindingKeyPublic);

- (BOOL)bindingKeyPublic NS_SWIFT_NAME(bindingKeyPublic());

@property (nonatomic,readwrite,assign,getter=bindingKeySubject,setter=setBindingKeySubject:) NSData* bindingKeySubject NS_SWIFT_NAME(bindingKeySubject);

- (NSData*)bindingKeySubject NS_SWIFT_NAME(bindingKeySubject());
- (void)setBindingKeySubject :(NSData*)newBindingKeySubject NS_SWIFT_NAME(setBindingKeySubject(_:));

@property (nonatomic,readonly,assign,getter=bindingKeySymmetric) BOOL bindingKeySymmetric NS_SWIFT_NAME(bindingKeySymmetric);

- (BOOL)bindingKeySymmetric NS_SWIFT_NAME(bindingKeySymmetric());

@property (nonatomic,readonly,assign,getter=bindingKeyValid) BOOL bindingKeyValid NS_SWIFT_NAME(bindingKeyValid);

- (BOOL)bindingKeyValid NS_SWIFT_NAME(bindingKeyValid());

@property (nonatomic,readwrite,assign,getter=certCount,setter=setCertCount:) int certCount NS_SWIFT_NAME(certCount);

- (int)certCount NS_SWIFT_NAME(certCount());
- (void)setCertCount :(int)newCertCount NS_SWIFT_NAME(setCertCount(_:));

- (NSData*)certBytes:(int)certIndex NS_SWIFT_NAME(certBytes(_:));

- (BOOL)certCA:(int)certIndex NS_SWIFT_NAME(certCA(_:));
- (void)setCertCA:(int)certIndex :(BOOL)newCertCA NS_SWIFT_NAME(setCertCA(_:_:));

- (NSData*)certCAKeyID:(int)certIndex NS_SWIFT_NAME(certCAKeyID(_:));

- (int)certCertType:(int)certIndex NS_SWIFT_NAME(certCertType(_:));

- (NSString*)certCRLDistributionPoints:(int)certIndex NS_SWIFT_NAME(certCRLDistributionPoints(_:));
- (void)setCertCRLDistributionPoints:(int)certIndex :(NSString*)newCertCRLDistributionPoints NS_SWIFT_NAME(setCertCRLDistributionPoints(_:_:));

- (NSString*)certCurve:(int)certIndex NS_SWIFT_NAME(certCurve(_:));
- (void)setCertCurve:(int)certIndex :(NSString*)newCertCurve NS_SWIFT_NAME(setCertCurve(_:_:));

- (NSString*)certFingerprint:(int)certIndex NS_SWIFT_NAME(certFingerprint(_:));

- (NSString*)certFriendlyName:(int)certIndex NS_SWIFT_NAME(certFriendlyName(_:));

- (long long)certHandle:(int)certIndex NS_SWIFT_NAME(certHandle(_:));
- (void)setCertHandle:(int)certIndex :(long long)newCertHandle NS_SWIFT_NAME(setCertHandle(_:_:));

- (NSString*)certHashAlgorithm:(int)certIndex NS_SWIFT_NAME(certHashAlgorithm(_:));
- (void)setCertHashAlgorithm:(int)certIndex :(NSString*)newCertHashAlgorithm NS_SWIFT_NAME(setCertHashAlgorithm(_:_:));

- (NSString*)certIssuer:(int)certIndex NS_SWIFT_NAME(certIssuer(_:));

- (NSString*)certIssuerRDN:(int)certIndex NS_SWIFT_NAME(certIssuerRDN(_:));
- (void)setCertIssuerRDN:(int)certIndex :(NSString*)newCertIssuerRDN NS_SWIFT_NAME(setCertIssuerRDN(_:_:));

- (NSString*)certKeyAlgorithm:(int)certIndex NS_SWIFT_NAME(certKeyAlgorithm(_:));
- (void)setCertKeyAlgorithm:(int)certIndex :(NSString*)newCertKeyAlgorithm NS_SWIFT_NAME(setCertKeyAlgorithm(_:_:));

- (int)certKeyBits:(int)certIndex NS_SWIFT_NAME(certKeyBits(_:));

- (NSString*)certKeyFingerprint:(int)certIndex NS_SWIFT_NAME(certKeyFingerprint(_:));

- (int)certKeyUsage:(int)certIndex NS_SWIFT_NAME(certKeyUsage(_:));
- (void)setCertKeyUsage:(int)certIndex :(int)newCertKeyUsage NS_SWIFT_NAME(setCertKeyUsage(_:_:));

- (BOOL)certKeyValid:(int)certIndex NS_SWIFT_NAME(certKeyValid(_:));

- (NSString*)certOCSPLocations:(int)certIndex NS_SWIFT_NAME(certOCSPLocations(_:));
- (void)setCertOCSPLocations:(int)certIndex :(NSString*)newCertOCSPLocations NS_SWIFT_NAME(setCertOCSPLocations(_:_:));

- (BOOL)certOCSPNoCheck:(int)certIndex NS_SWIFT_NAME(certOCSPNoCheck(_:));
- (void)setCertOCSPNoCheck:(int)certIndex :(BOOL)newCertOCSPNoCheck NS_SWIFT_NAME(setCertOCSPNoCheck(_:_:));

- (int)certOrigin:(int)certIndex NS_SWIFT_NAME(certOrigin(_:));

- (NSString*)certPolicyIDs:(int)certIndex NS_SWIFT_NAME(certPolicyIDs(_:));
- (void)setCertPolicyIDs:(int)certIndex :(NSString*)newCertPolicyIDs NS_SWIFT_NAME(setCertPolicyIDs(_:_:));

- (NSData*)certPrivateKeyBytes:(int)certIndex NS_SWIFT_NAME(certPrivateKeyBytes(_:));

- (BOOL)certPrivateKeyExists:(int)certIndex NS_SWIFT_NAME(certPrivateKeyExists(_:));

- (BOOL)certPrivateKeyExtractable:(int)certIndex NS_SWIFT_NAME(certPrivateKeyExtractable(_:));

- (NSData*)certPublicKeyBytes:(int)certIndex NS_SWIFT_NAME(certPublicKeyBytes(_:));

- (BOOL)certQualified:(int)certIndex NS_SWIFT_NAME(certQualified(_:));

- (int)certQualifiedStatements:(int)certIndex NS_SWIFT_NAME(certQualifiedStatements(_:));
- (void)setCertQualifiedStatements:(int)certIndex :(int)newCertQualifiedStatements NS_SWIFT_NAME(setCertQualifiedStatements(_:_:));

- (NSString*)certQualifiers:(int)certIndex NS_SWIFT_NAME(certQualifiers(_:));

- (BOOL)certSelfSigned:(int)certIndex NS_SWIFT_NAME(certSelfSigned(_:));

- (NSData*)certSerialNumber:(int)certIndex NS_SWIFT_NAME(certSerialNumber(_:));
- (void)setCertSerialNumber:(int)certIndex :(NSData*)newCertSerialNumber NS_SWIFT_NAME(setCertSerialNumber(_:_:));

- (NSString*)certSigAlgorithm:(int)certIndex NS_SWIFT_NAME(certSigAlgorithm(_:));

- (int)certSource:(int)certIndex NS_SWIFT_NAME(certSource(_:));

- (NSString*)certSubject:(int)certIndex NS_SWIFT_NAME(certSubject(_:));

- (NSString*)certSubjectAlternativeName:(int)certIndex NS_SWIFT_NAME(certSubjectAlternativeName(_:));
- (void)setCertSubjectAlternativeName:(int)certIndex :(NSString*)newCertSubjectAlternativeName NS_SWIFT_NAME(setCertSubjectAlternativeName(_:_:));

- (NSData*)certSubjectKeyID:(int)certIndex NS_SWIFT_NAME(certSubjectKeyID(_:));
- (void)setCertSubjectKeyID:(int)certIndex :(NSData*)newCertSubjectKeyID NS_SWIFT_NAME(setCertSubjectKeyID(_:_:));

- (NSString*)certSubjectRDN:(int)certIndex NS_SWIFT_NAME(certSubjectRDN(_:));
- (void)setCertSubjectRDN:(int)certIndex :(NSString*)newCertSubjectRDN NS_SWIFT_NAME(setCertSubjectRDN(_:_:));

- (BOOL)certValid:(int)certIndex NS_SWIFT_NAME(certValid(_:));

- (NSString*)certValidFrom:(int)certIndex NS_SWIFT_NAME(certValidFrom(_:));
- (void)setCertValidFrom:(int)certIndex :(NSString*)newCertValidFrom NS_SWIFT_NAME(setCertValidFrom(_:_:));

- (NSString*)certValidTo:(int)certIndex NS_SWIFT_NAME(certValidTo(_:));
- (void)setCertValidTo:(int)certIndex :(NSString*)newCertValidTo NS_SWIFT_NAME(setCertValidTo(_:_:));

@property (nonatomic,readonly,assign,getter=conditionCount) int conditionCount NS_SWIFT_NAME(conditionCount);

- (int)conditionCount NS_SWIFT_NAME(conditionCount());

- (NSString*)conditionCondition:(int)conditionIndex NS_SWIFT_NAME(conditionCondition(_:));

- (int)conditionConditionType:(int)conditionIndex NS_SWIFT_NAME(conditionConditionType(_:));

@property (nonatomic,readonly,assign,getter=decryptionCertificateBytes) NSData* decryptionCertificateBytes NS_SWIFT_NAME(decryptionCertificateBytes);

- (NSData*)decryptionCertificateBytes NS_SWIFT_NAME(decryptionCertificateBytes());

@property (nonatomic,readwrite,assign,getter=decryptionCertificateCA,setter=setDecryptionCertificateCA:) BOOL decryptionCertificateCA NS_SWIFT_NAME(decryptionCertificateCA);

- (BOOL)decryptionCertificateCA NS_SWIFT_NAME(decryptionCertificateCA());
- (void)setDecryptionCertificateCA :(BOOL)newDecryptionCertificateCA NS_SWIFT_NAME(setDecryptionCertificateCA(_:));

@property (nonatomic,readonly,assign,getter=decryptionCertificateCAKeyID) NSData* decryptionCertificateCAKeyID NS_SWIFT_NAME(decryptionCertificateCAKeyID);

- (NSData*)decryptionCertificateCAKeyID NS_SWIFT_NAME(decryptionCertificateCAKeyID());

@property (nonatomic,readonly,assign,getter=decryptionCertificateCertType) int decryptionCertificateCertType NS_SWIFT_NAME(decryptionCertificateCertType);

- (int)decryptionCertificateCertType NS_SWIFT_NAME(decryptionCertificateCertType());

@property (nonatomic,readwrite,assign,getter=decryptionCertificateCRLDistributionPoints,setter=setDecryptionCertificateCRLDistributionPoints:) NSString* decryptionCertificateCRLDistributionPoints NS_SWIFT_NAME(decryptionCertificateCRLDistributionPoints);

- (NSString*)decryptionCertificateCRLDistributionPoints NS_SWIFT_NAME(decryptionCertificateCRLDistributionPoints());
- (void)setDecryptionCertificateCRLDistributionPoints :(NSString*)newDecryptionCertificateCRLDistributionPoints NS_SWIFT_NAME(setDecryptionCertificateCRLDistributionPoints(_:));

@property (nonatomic,readwrite,assign,getter=decryptionCertificateCurve,setter=setDecryptionCertificateCurve:) NSString* decryptionCertificateCurve NS_SWIFT_NAME(decryptionCertificateCurve);

- (NSString*)decryptionCertificateCurve NS_SWIFT_NAME(decryptionCertificateCurve());
- (void)setDecryptionCertificateCurve :(NSString*)newDecryptionCertificateCurve NS_SWIFT_NAME(setDecryptionCertificateCurve(_:));

@property (nonatomic,readonly,assign,getter=decryptionCertificateFingerprint) NSString* decryptionCertificateFingerprint NS_SWIFT_NAME(decryptionCertificateFingerprint);

- (NSString*)decryptionCertificateFingerprint NS_SWIFT_NAME(decryptionCertificateFingerprint());

@property (nonatomic,readonly,assign,getter=decryptionCertificateFriendlyName) NSString* decryptionCertificateFriendlyName NS_SWIFT_NAME(decryptionCertificateFriendlyName);

- (NSString*)decryptionCertificateFriendlyName NS_SWIFT_NAME(decryptionCertificateFriendlyName());

@property (nonatomic,readwrite,assign,getter=decryptionCertificateHandle,setter=setDecryptionCertificateHandle:) long long decryptionCertificateHandle NS_SWIFT_NAME(decryptionCertificateHandle);

- (long long)decryptionCertificateHandle NS_SWIFT_NAME(decryptionCertificateHandle());
- (void)setDecryptionCertificateHandle :(long long)newDecryptionCertificateHandle NS_SWIFT_NAME(setDecryptionCertificateHandle(_:));

@property (nonatomic,readwrite,assign,getter=decryptionCertificateHashAlgorithm,setter=setDecryptionCertificateHashAlgorithm:) NSString* decryptionCertificateHashAlgorithm NS_SWIFT_NAME(decryptionCertificateHashAlgorithm);

- (NSString*)decryptionCertificateHashAlgorithm NS_SWIFT_NAME(decryptionCertificateHashAlgorithm());
- (void)setDecryptionCertificateHashAlgorithm :(NSString*)newDecryptionCertificateHashAlgorithm NS_SWIFT_NAME(setDecryptionCertificateHashAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=decryptionCertificateIssuer) NSString* decryptionCertificateIssuer NS_SWIFT_NAME(decryptionCertificateIssuer);

- (NSString*)decryptionCertificateIssuer NS_SWIFT_NAME(decryptionCertificateIssuer());

@property (nonatomic,readwrite,assign,getter=decryptionCertificateIssuerRDN,setter=setDecryptionCertificateIssuerRDN:) NSString* decryptionCertificateIssuerRDN NS_SWIFT_NAME(decryptionCertificateIssuerRDN);

- (NSString*)decryptionCertificateIssuerRDN NS_SWIFT_NAME(decryptionCertificateIssuerRDN());
- (void)setDecryptionCertificateIssuerRDN :(NSString*)newDecryptionCertificateIssuerRDN NS_SWIFT_NAME(setDecryptionCertificateIssuerRDN(_:));

@property (nonatomic,readwrite,assign,getter=decryptionCertificateKeyAlgorithm,setter=setDecryptionCertificateKeyAlgorithm:) NSString* decryptionCertificateKeyAlgorithm NS_SWIFT_NAME(decryptionCertificateKeyAlgorithm);

- (NSString*)decryptionCertificateKeyAlgorithm NS_SWIFT_NAME(decryptionCertificateKeyAlgorithm());
- (void)setDecryptionCertificateKeyAlgorithm :(NSString*)newDecryptionCertificateKeyAlgorithm NS_SWIFT_NAME(setDecryptionCertificateKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=decryptionCertificateKeyBits) int decryptionCertificateKeyBits NS_SWIFT_NAME(decryptionCertificateKeyBits);

- (int)decryptionCertificateKeyBits NS_SWIFT_NAME(decryptionCertificateKeyBits());

@property (nonatomic,readonly,assign,getter=decryptionCertificateKeyFingerprint) NSString* decryptionCertificateKeyFingerprint NS_SWIFT_NAME(decryptionCertificateKeyFingerprint);

- (NSString*)decryptionCertificateKeyFingerprint NS_SWIFT_NAME(decryptionCertificateKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=decryptionCertificateKeyUsage,setter=setDecryptionCertificateKeyUsage:) int decryptionCertificateKeyUsage NS_SWIFT_NAME(decryptionCertificateKeyUsage);

- (int)decryptionCertificateKeyUsage NS_SWIFT_NAME(decryptionCertificateKeyUsage());
- (void)setDecryptionCertificateKeyUsage :(int)newDecryptionCertificateKeyUsage NS_SWIFT_NAME(setDecryptionCertificateKeyUsage(_:));

@property (nonatomic,readonly,assign,getter=decryptionCertificateKeyValid) BOOL decryptionCertificateKeyValid NS_SWIFT_NAME(decryptionCertificateKeyValid);

- (BOOL)decryptionCertificateKeyValid NS_SWIFT_NAME(decryptionCertificateKeyValid());

@property (nonatomic,readwrite,assign,getter=decryptionCertificateOCSPLocations,setter=setDecryptionCertificateOCSPLocations:) NSString* decryptionCertificateOCSPLocations NS_SWIFT_NAME(decryptionCertificateOCSPLocations);

- (NSString*)decryptionCertificateOCSPLocations NS_SWIFT_NAME(decryptionCertificateOCSPLocations());
- (void)setDecryptionCertificateOCSPLocations :(NSString*)newDecryptionCertificateOCSPLocations NS_SWIFT_NAME(setDecryptionCertificateOCSPLocations(_:));

@property (nonatomic,readwrite,assign,getter=decryptionCertificateOCSPNoCheck,setter=setDecryptionCertificateOCSPNoCheck:) BOOL decryptionCertificateOCSPNoCheck NS_SWIFT_NAME(decryptionCertificateOCSPNoCheck);

- (BOOL)decryptionCertificateOCSPNoCheck NS_SWIFT_NAME(decryptionCertificateOCSPNoCheck());
- (void)setDecryptionCertificateOCSPNoCheck :(BOOL)newDecryptionCertificateOCSPNoCheck NS_SWIFT_NAME(setDecryptionCertificateOCSPNoCheck(_:));

@property (nonatomic,readonly,assign,getter=decryptionCertificateOrigin) int decryptionCertificateOrigin NS_SWIFT_NAME(decryptionCertificateOrigin);

- (int)decryptionCertificateOrigin NS_SWIFT_NAME(decryptionCertificateOrigin());

@property (nonatomic,readwrite,assign,getter=decryptionCertificatePolicyIDs,setter=setDecryptionCertificatePolicyIDs:) NSString* decryptionCertificatePolicyIDs NS_SWIFT_NAME(decryptionCertificatePolicyIDs);

- (NSString*)decryptionCertificatePolicyIDs NS_SWIFT_NAME(decryptionCertificatePolicyIDs());
- (void)setDecryptionCertificatePolicyIDs :(NSString*)newDecryptionCertificatePolicyIDs NS_SWIFT_NAME(setDecryptionCertificatePolicyIDs(_:));

@property (nonatomic,readonly,assign,getter=decryptionCertificatePrivateKeyBytes) NSData* decryptionCertificatePrivateKeyBytes NS_SWIFT_NAME(decryptionCertificatePrivateKeyBytes);

- (NSData*)decryptionCertificatePrivateKeyBytes NS_SWIFT_NAME(decryptionCertificatePrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=decryptionCertificatePrivateKeyExists) BOOL decryptionCertificatePrivateKeyExists NS_SWIFT_NAME(decryptionCertificatePrivateKeyExists);

- (BOOL)decryptionCertificatePrivateKeyExists NS_SWIFT_NAME(decryptionCertificatePrivateKeyExists());

@property (nonatomic,readonly,assign,getter=decryptionCertificatePrivateKeyExtractable) BOOL decryptionCertificatePrivateKeyExtractable NS_SWIFT_NAME(decryptionCertificatePrivateKeyExtractable);

- (BOOL)decryptionCertificatePrivateKeyExtractable NS_SWIFT_NAME(decryptionCertificatePrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=decryptionCertificatePublicKeyBytes) NSData* decryptionCertificatePublicKeyBytes NS_SWIFT_NAME(decryptionCertificatePublicKeyBytes);

- (NSData*)decryptionCertificatePublicKeyBytes NS_SWIFT_NAME(decryptionCertificatePublicKeyBytes());

@property (nonatomic,readonly,assign,getter=decryptionCertificateQualified) BOOL decryptionCertificateQualified NS_SWIFT_NAME(decryptionCertificateQualified);

- (BOOL)decryptionCertificateQualified NS_SWIFT_NAME(decryptionCertificateQualified());

@property (nonatomic,readwrite,assign,getter=decryptionCertificateQualifiedStatements,setter=setDecryptionCertificateQualifiedStatements:) int decryptionCertificateQualifiedStatements NS_SWIFT_NAME(decryptionCertificateQualifiedStatements);

- (int)decryptionCertificateQualifiedStatements NS_SWIFT_NAME(decryptionCertificateQualifiedStatements());
- (void)setDecryptionCertificateQualifiedStatements :(int)newDecryptionCertificateQualifiedStatements NS_SWIFT_NAME(setDecryptionCertificateQualifiedStatements(_:));

@property (nonatomic,readonly,assign,getter=decryptionCertificateQualifiers) NSString* decryptionCertificateQualifiers NS_SWIFT_NAME(decryptionCertificateQualifiers);

- (NSString*)decryptionCertificateQualifiers NS_SWIFT_NAME(decryptionCertificateQualifiers());

@property (nonatomic,readonly,assign,getter=decryptionCertificateSelfSigned) BOOL decryptionCertificateSelfSigned NS_SWIFT_NAME(decryptionCertificateSelfSigned);

- (BOOL)decryptionCertificateSelfSigned NS_SWIFT_NAME(decryptionCertificateSelfSigned());

@property (nonatomic,readwrite,assign,getter=decryptionCertificateSerialNumber,setter=setDecryptionCertificateSerialNumber:) NSData* decryptionCertificateSerialNumber NS_SWIFT_NAME(decryptionCertificateSerialNumber);

- (NSData*)decryptionCertificateSerialNumber NS_SWIFT_NAME(decryptionCertificateSerialNumber());
- (void)setDecryptionCertificateSerialNumber :(NSData*)newDecryptionCertificateSerialNumber NS_SWIFT_NAME(setDecryptionCertificateSerialNumber(_:));

@property (nonatomic,readonly,assign,getter=decryptionCertificateSigAlgorithm) NSString* decryptionCertificateSigAlgorithm NS_SWIFT_NAME(decryptionCertificateSigAlgorithm);

- (NSString*)decryptionCertificateSigAlgorithm NS_SWIFT_NAME(decryptionCertificateSigAlgorithm());

@property (nonatomic,readonly,assign,getter=decryptionCertificateSource) int decryptionCertificateSource NS_SWIFT_NAME(decryptionCertificateSource);

- (int)decryptionCertificateSource NS_SWIFT_NAME(decryptionCertificateSource());

@property (nonatomic,readonly,assign,getter=decryptionCertificateSubject) NSString* decryptionCertificateSubject NS_SWIFT_NAME(decryptionCertificateSubject);

- (NSString*)decryptionCertificateSubject NS_SWIFT_NAME(decryptionCertificateSubject());

@property (nonatomic,readwrite,assign,getter=decryptionCertificateSubjectAlternativeName,setter=setDecryptionCertificateSubjectAlternativeName:) NSString* decryptionCertificateSubjectAlternativeName NS_SWIFT_NAME(decryptionCertificateSubjectAlternativeName);

- (NSString*)decryptionCertificateSubjectAlternativeName NS_SWIFT_NAME(decryptionCertificateSubjectAlternativeName());
- (void)setDecryptionCertificateSubjectAlternativeName :(NSString*)newDecryptionCertificateSubjectAlternativeName NS_SWIFT_NAME(setDecryptionCertificateSubjectAlternativeName(_:));

@property (nonatomic,readwrite,assign,getter=decryptionCertificateSubjectKeyID,setter=setDecryptionCertificateSubjectKeyID:) NSData* decryptionCertificateSubjectKeyID NS_SWIFT_NAME(decryptionCertificateSubjectKeyID);

- (NSData*)decryptionCertificateSubjectKeyID NS_SWIFT_NAME(decryptionCertificateSubjectKeyID());
- (void)setDecryptionCertificateSubjectKeyID :(NSData*)newDecryptionCertificateSubjectKeyID NS_SWIFT_NAME(setDecryptionCertificateSubjectKeyID(_:));

@property (nonatomic,readwrite,assign,getter=decryptionCertificateSubjectRDN,setter=setDecryptionCertificateSubjectRDN:) NSString* decryptionCertificateSubjectRDN NS_SWIFT_NAME(decryptionCertificateSubjectRDN);

- (NSString*)decryptionCertificateSubjectRDN NS_SWIFT_NAME(decryptionCertificateSubjectRDN());
- (void)setDecryptionCertificateSubjectRDN :(NSString*)newDecryptionCertificateSubjectRDN NS_SWIFT_NAME(setDecryptionCertificateSubjectRDN(_:));

@property (nonatomic,readonly,assign,getter=decryptionCertificateValid) BOOL decryptionCertificateValid NS_SWIFT_NAME(decryptionCertificateValid);

- (BOOL)decryptionCertificateValid NS_SWIFT_NAME(decryptionCertificateValid());

@property (nonatomic,readwrite,assign,getter=decryptionCertificateValidFrom,setter=setDecryptionCertificateValidFrom:) NSString* decryptionCertificateValidFrom NS_SWIFT_NAME(decryptionCertificateValidFrom);

- (NSString*)decryptionCertificateValidFrom NS_SWIFT_NAME(decryptionCertificateValidFrom());
- (void)setDecryptionCertificateValidFrom :(NSString*)newDecryptionCertificateValidFrom NS_SWIFT_NAME(setDecryptionCertificateValidFrom(_:));

@property (nonatomic,readwrite,assign,getter=decryptionCertificateValidTo,setter=setDecryptionCertificateValidTo:) NSString* decryptionCertificateValidTo NS_SWIFT_NAME(decryptionCertificateValidTo);

- (NSString*)decryptionCertificateValidTo NS_SWIFT_NAME(decryptionCertificateValidTo());
- (void)setDecryptionCertificateValidTo :(NSString*)newDecryptionCertificateValidTo NS_SWIFT_NAME(setDecryptionCertificateValidTo(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readonly,assign,getter=logoutRequestNameID) NSString* logoutRequestNameID NS_SWIFT_NAME(logoutRequestNameID);

- (NSString*)logoutRequestNameID NS_SWIFT_NAME(logoutRequestNameID());

@property (nonatomic,readonly,assign,getter=logoutRequestNotOnOrAfter) NSString* logoutRequestNotOnOrAfter NS_SWIFT_NAME(logoutRequestNotOnOrAfter);

- (NSString*)logoutRequestNotOnOrAfter NS_SWIFT_NAME(logoutRequestNotOnOrAfter());

@property (nonatomic,readonly,assign,getter=logoutRequestReason) NSString* logoutRequestReason NS_SWIFT_NAME(logoutRequestReason);

- (NSString*)logoutRequestReason NS_SWIFT_NAME(logoutRequestReason());

@property (nonatomic,readonly,assign,getter=logoutRequestSessionIndexes) NSString* logoutRequestSessionIndexes NS_SWIFT_NAME(logoutRequestSessionIndexes);

- (NSString*)logoutRequestSessionIndexes NS_SWIFT_NAME(logoutRequestSessionIndexes());

@property (nonatomic,readonly,assign,getter=manageNameIDRequestNameID) NSString* manageNameIDRequestNameID NS_SWIFT_NAME(manageNameIDRequestNameID);

- (NSString*)manageNameIDRequestNameID NS_SWIFT_NAME(manageNameIDRequestNameID());

@property (nonatomic,readonly,assign,getter=manageNameIDRequestNewEncryptedID) NSString* manageNameIDRequestNewEncryptedID NS_SWIFT_NAME(manageNameIDRequestNewEncryptedID);

- (NSString*)manageNameIDRequestNewEncryptedID NS_SWIFT_NAME(manageNameIDRequestNewEncryptedID());

@property (nonatomic,readonly,assign,getter=manageNameIDRequestNewID) NSString* manageNameIDRequestNewID NS_SWIFT_NAME(manageNameIDRequestNewID);

- (NSString*)manageNameIDRequestNewID NS_SWIFT_NAME(manageNameIDRequestNewID());

@property (nonatomic,readonly,assign,getter=manageNameIDRequestTerminate) NSString* manageNameIDRequestTerminate NS_SWIFT_NAME(manageNameIDRequestTerminate);

- (NSString*)manageNameIDRequestTerminate NS_SWIFT_NAME(manageNameIDRequestTerminate());

@property (nonatomic,readonly,assign,getter=messageConsent) NSString* messageConsent NS_SWIFT_NAME(messageConsent);

- (NSString*)messageConsent NS_SWIFT_NAME(messageConsent());

@property (nonatomic,readonly,assign,getter=messageContentType) int messageContentType NS_SWIFT_NAME(messageContentType);

- (int)messageContentType NS_SWIFT_NAME(messageContentType());

@property (nonatomic,readonly,assign,getter=messageContentTypeString) NSString* messageContentTypeString NS_SWIFT_NAME(messageContentTypeString);

- (NSString*)messageContentTypeString NS_SWIFT_NAME(messageContentTypeString());

@property (nonatomic,readonly,assign,getter=messageDestination) NSString* messageDestination NS_SWIFT_NAME(messageDestination);

- (NSString*)messageDestination NS_SWIFT_NAME(messageDestination());

@property (nonatomic,readonly,assign,getter=messageID) NSString* messageID NS_SWIFT_NAME(messageID);

- (NSString*)messageID NS_SWIFT_NAME(messageID());

@property (nonatomic,readonly,assign,getter=messageInResponseTo) NSString* messageInResponseTo NS_SWIFT_NAME(messageInResponseTo);

- (NSString*)messageInResponseTo NS_SWIFT_NAME(messageInResponseTo());

@property (nonatomic,readonly,assign,getter=messageIssueInstant) NSString* messageIssueInstant NS_SWIFT_NAME(messageIssueInstant);

- (NSString*)messageIssueInstant NS_SWIFT_NAME(messageIssueInstant());

@property (nonatomic,readonly,assign,getter=messageIssuer) NSString* messageIssuer NS_SWIFT_NAME(messageIssuer);

- (NSString*)messageIssuer NS_SWIFT_NAME(messageIssuer());

@property (nonatomic,readonly,assign,getter=messageSignatureValidationResult) int messageSignatureValidationResult NS_SWIFT_NAME(messageSignatureValidationResult);

- (int)messageSignatureValidationResult NS_SWIFT_NAME(messageSignatureValidationResult());

@property (nonatomic,readonly,assign,getter=messageSigned) BOOL messageSigned NS_SWIFT_NAME(messageSigned);

- (BOOL)messageSigned NS_SWIFT_NAME(messageSigned());

@property (nonatomic,readonly,assign,getter=messageSubject) NSString* messageSubject NS_SWIFT_NAME(messageSubject);

- (NSString*)messageSubject NS_SWIFT_NAME(messageSubject());

@property (nonatomic,readonly,assign,getter=messageVersion) NSString* messageVersion NS_SWIFT_NAME(messageVersion);

- (NSString*)messageVersion NS_SWIFT_NAME(messageVersion());

@property (nonatomic,readonly,assign,getter=messageXMLHeader) BOOL messageXMLHeader NS_SWIFT_NAME(messageXMLHeader);

- (BOOL)messageXMLHeader NS_SWIFT_NAME(messageXMLHeader());

@property (nonatomic,readonly,assign,getter=nameIDMappingRequestNameID) NSString* nameIDMappingRequestNameID NS_SWIFT_NAME(nameIDMappingRequestNameID);

- (NSString*)nameIDMappingRequestNameID NS_SWIFT_NAME(nameIDMappingRequestNameID());

@property (nonatomic,readonly,assign,getter=nameIDMappingRequestNameIDPolicyAllowCreate) BOOL nameIDMappingRequestNameIDPolicyAllowCreate NS_SWIFT_NAME(nameIDMappingRequestNameIDPolicyAllowCreate);

- (BOOL)nameIDMappingRequestNameIDPolicyAllowCreate NS_SWIFT_NAME(nameIDMappingRequestNameIDPolicyAllowCreate());

@property (nonatomic,readonly,assign,getter=nameIDMappingRequestNameIDPolicyFormat) NSString* nameIDMappingRequestNameIDPolicyFormat NS_SWIFT_NAME(nameIDMappingRequestNameIDPolicyFormat);

- (NSString*)nameIDMappingRequestNameIDPolicyFormat NS_SWIFT_NAME(nameIDMappingRequestNameIDPolicyFormat());

@property (nonatomic,readonly,assign,getter=nameIDMappingRequestNameIDPolicySPNameQualifier) NSString* nameIDMappingRequestNameIDPolicySPNameQualifier NS_SWIFT_NAME(nameIDMappingRequestNameIDPolicySPNameQualifier);

- (NSString*)nameIDMappingRequestNameIDPolicySPNameQualifier NS_SWIFT_NAME(nameIDMappingRequestNameIDPolicySPNameQualifier());

@property (nonatomic,readonly,assign,getter=nameIDMappingRequestNameIDPolicyUseAllowCreate) BOOL nameIDMappingRequestNameIDPolicyUseAllowCreate NS_SWIFT_NAME(nameIDMappingRequestNameIDPolicyUseAllowCreate);

- (BOOL)nameIDMappingRequestNameIDPolicyUseAllowCreate NS_SWIFT_NAME(nameIDMappingRequestNameIDPolicyUseAllowCreate());

@property (nonatomic,readonly,assign,getter=pinnedAssertionAssertionType) int pinnedAssertionAssertionType NS_SWIFT_NAME(pinnedAssertionAssertionType);

- (int)pinnedAssertionAssertionType NS_SWIFT_NAME(pinnedAssertionAssertionType());

@property (nonatomic,readonly,assign,getter=pinnedAssertionEncryptedContent) NSString* pinnedAssertionEncryptedContent NS_SWIFT_NAME(pinnedAssertionEncryptedContent);

- (NSString*)pinnedAssertionEncryptedContent NS_SWIFT_NAME(pinnedAssertionEncryptedContent());

@property (nonatomic,readonly,assign,getter=pinnedAssertionID) NSString* pinnedAssertionID NS_SWIFT_NAME(pinnedAssertionID);

- (NSString*)pinnedAssertionID NS_SWIFT_NAME(pinnedAssertionID());

@property (nonatomic,readonly,assign,getter=pinnedAssertionIDRef) NSString* pinnedAssertionIDRef NS_SWIFT_NAME(pinnedAssertionIDRef);

- (NSString*)pinnedAssertionIDRef NS_SWIFT_NAME(pinnedAssertionIDRef());

@property (nonatomic,readonly,assign,getter=pinnedAssertionIssueInstant) NSString* pinnedAssertionIssueInstant NS_SWIFT_NAME(pinnedAssertionIssueInstant);

- (NSString*)pinnedAssertionIssueInstant NS_SWIFT_NAME(pinnedAssertionIssueInstant());

@property (nonatomic,readonly,assign,getter=pinnedAssertionIssuer) NSString* pinnedAssertionIssuer NS_SWIFT_NAME(pinnedAssertionIssuer);

- (NSString*)pinnedAssertionIssuer NS_SWIFT_NAME(pinnedAssertionIssuer());

@property (nonatomic,readonly,assign,getter=pinnedAssertionParentAssertion) int pinnedAssertionParentAssertion NS_SWIFT_NAME(pinnedAssertionParentAssertion);

- (int)pinnedAssertionParentAssertion NS_SWIFT_NAME(pinnedAssertionParentAssertion());

@property (nonatomic,readonly,assign,getter=pinnedAssertionSignatureValidationResult) int pinnedAssertionSignatureValidationResult NS_SWIFT_NAME(pinnedAssertionSignatureValidationResult);

- (int)pinnedAssertionSignatureValidationResult NS_SWIFT_NAME(pinnedAssertionSignatureValidationResult());

@property (nonatomic,readonly,assign,getter=pinnedAssertionSigned) BOOL pinnedAssertionSigned NS_SWIFT_NAME(pinnedAssertionSigned);

- (BOOL)pinnedAssertionSigned NS_SWIFT_NAME(pinnedAssertionSigned());

@property (nonatomic,readonly,assign,getter=pinnedAssertionSubject) NSString* pinnedAssertionSubject NS_SWIFT_NAME(pinnedAssertionSubject);

- (NSString*)pinnedAssertionSubject NS_SWIFT_NAME(pinnedAssertionSubject());

@property (nonatomic,readonly,assign,getter=pinnedAssertionURIRef) NSString* pinnedAssertionURIRef NS_SWIFT_NAME(pinnedAssertionURIRef);

- (NSString*)pinnedAssertionURIRef NS_SWIFT_NAME(pinnedAssertionURIRef());

@property (nonatomic,readonly,assign,getter=pinnedAssertionVersion) NSString* pinnedAssertionVersion NS_SWIFT_NAME(pinnedAssertionVersion);

- (NSString*)pinnedAssertionVersion NS_SWIFT_NAME(pinnedAssertionVersion());

@property (nonatomic,readwrite,assign,getter=profile,setter=setProfile:) NSString* profile NS_SWIFT_NAME(profile);

- (NSString*)profile NS_SWIFT_NAME(profile());
- (void)setProfile :(NSString*)newProfile NS_SWIFT_NAME(setProfile(_:));

@property (nonatomic,readwrite,assign,getter=proxyAddress,setter=setProxyAddress:) NSString* proxyAddress NS_SWIFT_NAME(proxyAddress);

- (NSString*)proxyAddress NS_SWIFT_NAME(proxyAddress());
- (void)setProxyAddress :(NSString*)newProxyAddress NS_SWIFT_NAME(setProxyAddress(_:));

@property (nonatomic,readwrite,assign,getter=proxyAuthentication,setter=setProxyAuthentication:) int proxyAuthentication NS_SWIFT_NAME(proxyAuthentication);

- (int)proxyAuthentication NS_SWIFT_NAME(proxyAuthentication());
- (void)setProxyAuthentication :(int)newProxyAuthentication NS_SWIFT_NAME(setProxyAuthentication(_:));

@property (nonatomic,readwrite,assign,getter=proxyPassword,setter=setProxyPassword:) NSString* proxyPassword NS_SWIFT_NAME(proxyPassword);

- (NSString*)proxyPassword NS_SWIFT_NAME(proxyPassword());
- (void)setProxyPassword :(NSString*)newProxyPassword NS_SWIFT_NAME(setProxyPassword(_:));

@property (nonatomic,readwrite,assign,getter=proxyPort,setter=setProxyPort:) int proxyPort NS_SWIFT_NAME(proxyPort);

- (int)proxyPort NS_SWIFT_NAME(proxyPort());
- (void)setProxyPort :(int)newProxyPort NS_SWIFT_NAME(setProxyPort(_:));

@property (nonatomic,readwrite,assign,getter=proxyProxyType,setter=setProxyProxyType:) int proxyProxyType NS_SWIFT_NAME(proxyProxyType);

- (int)proxyProxyType NS_SWIFT_NAME(proxyProxyType());
- (void)setProxyProxyType :(int)newProxyProxyType NS_SWIFT_NAME(setProxyProxyType(_:));

@property (nonatomic,readwrite,assign,getter=proxyRequestHeaders,setter=setProxyRequestHeaders:) NSString* proxyRequestHeaders NS_SWIFT_NAME(proxyRequestHeaders);

- (NSString*)proxyRequestHeaders NS_SWIFT_NAME(proxyRequestHeaders());
- (void)setProxyRequestHeaders :(NSString*)newProxyRequestHeaders NS_SWIFT_NAME(setProxyRequestHeaders(_:));

@property (nonatomic,readwrite,assign,getter=proxyResponseBody,setter=setProxyResponseBody:) NSString* proxyResponseBody NS_SWIFT_NAME(proxyResponseBody);

- (NSString*)proxyResponseBody NS_SWIFT_NAME(proxyResponseBody());
- (void)setProxyResponseBody :(NSString*)newProxyResponseBody NS_SWIFT_NAME(setProxyResponseBody(_:));

@property (nonatomic,readwrite,assign,getter=proxyResponseHeaders,setter=setProxyResponseHeaders:) NSString* proxyResponseHeaders NS_SWIFT_NAME(proxyResponseHeaders);

- (NSString*)proxyResponseHeaders NS_SWIFT_NAME(proxyResponseHeaders());
- (void)setProxyResponseHeaders :(NSString*)newProxyResponseHeaders NS_SWIFT_NAME(setProxyResponseHeaders(_:));

@property (nonatomic,readwrite,assign,getter=proxyUseIPv6,setter=setProxyUseIPv6:) BOOL proxyUseIPv6 NS_SWIFT_NAME(proxyUseIPv6);

- (BOOL)proxyUseIPv6 NS_SWIFT_NAME(proxyUseIPv6());
- (void)setProxyUseIPv6 :(BOOL)newProxyUseIPv6 NS_SWIFT_NAME(setProxyUseIPv6(_:));

@property (nonatomic,readwrite,assign,getter=proxyUsername,setter=setProxyUsername:) NSString* proxyUsername NS_SWIFT_NAME(proxyUsername);

- (NSString*)proxyUsername NS_SWIFT_NAME(proxyUsername());
- (void)setProxyUsername :(NSString*)newProxyUsername NS_SWIFT_NAME(setProxyUsername(_:));

@property (nonatomic,readonly,assign,getter=references) NSString* references NS_SWIFT_NAME(references);

- (NSString*)references NS_SWIFT_NAME(references());

@property (nonatomic,readonly,assign,getter=responseNameID) NSString* responseNameID NS_SWIFT_NAME(responseNameID);

- (NSString*)responseNameID NS_SWIFT_NAME(responseNameID());

@property (nonatomic,readonly,assign,getter=responseOptionalElement) NSString* responseOptionalElement NS_SWIFT_NAME(responseOptionalElement);

- (NSString*)responseOptionalElement NS_SWIFT_NAME(responseOptionalElement());

@property (nonatomic,readonly,assign,getter=responseResponseType) int responseResponseType NS_SWIFT_NAME(responseResponseType);

- (int)responseResponseType NS_SWIFT_NAME(responseResponseType());

@property (nonatomic,readonly,assign,getter=responseStatus) int responseStatus NS_SWIFT_NAME(responseStatus);

- (int)responseStatus NS_SWIFT_NAME(responseStatus());

@property (nonatomic,readonly,assign,getter=responseStatusCodeSubValue) NSString* responseStatusCodeSubValue NS_SWIFT_NAME(responseStatusCodeSubValue);

- (NSString*)responseStatusCodeSubValue NS_SWIFT_NAME(responseStatusCodeSubValue());

@property (nonatomic,readonly,assign,getter=responseStatusCodeValue) NSString* responseStatusCodeValue NS_SWIFT_NAME(responseStatusCodeValue);

- (NSString*)responseStatusCodeValue NS_SWIFT_NAME(responseStatusCodeValue());

@property (nonatomic,readonly,assign,getter=responseStatusDetail) NSString* responseStatusDetail NS_SWIFT_NAME(responseStatusDetail);

- (NSString*)responseStatusDetail NS_SWIFT_NAME(responseStatusDetail());

@property (nonatomic,readonly,assign,getter=responseStatusMessage) NSString* responseStatusMessage NS_SWIFT_NAME(responseStatusMessage);

- (NSString*)responseStatusMessage NS_SWIFT_NAME(responseStatusMessage());

@property (nonatomic,readonly,assign,getter=scopingIDPCount) int scopingIDPCount NS_SWIFT_NAME(scopingIDPCount);

- (int)scopingIDPCount NS_SWIFT_NAME(scopingIDPCount());

- (NSString*)scopingIDPLoc:(int)scopingIDPIndex NS_SWIFT_NAME(scopingIDPLoc(_:));

- (NSString*)scopingIDPName:(int)scopingIDPIndex NS_SWIFT_NAME(scopingIDPName(_:));

- (NSString*)scopingIDPProviderID:(int)scopingIDPIndex NS_SWIFT_NAME(scopingIDPProviderID(_:));

@property (nonatomic,readonly,assign,getter=securityCanonicalizationMethod) NSString* securityCanonicalizationMethod NS_SWIFT_NAME(securityCanonicalizationMethod);

- (NSString*)securityCanonicalizationMethod NS_SWIFT_NAME(securityCanonicalizationMethod());

@property (nonatomic,readonly,assign,getter=securityDigestMethod) NSString* securityDigestMethod NS_SWIFT_NAME(securityDigestMethod);

- (NSString*)securityDigestMethod NS_SWIFT_NAME(securityDigestMethod());

@property (nonatomic,readonly,assign,getter=securityEncryptionMethod) NSString* securityEncryptionMethod NS_SWIFT_NAME(securityEncryptionMethod);

- (NSString*)securityEncryptionMethod NS_SWIFT_NAME(securityEncryptionMethod());

@property (nonatomic,readonly,assign,getter=securityFlags) int securityFlags NS_SWIFT_NAME(securityFlags);

- (int)securityFlags NS_SWIFT_NAME(securityFlags());

@property (nonatomic,readonly,assign,getter=securitySigMethod) NSString* securitySigMethod NS_SWIFT_NAME(securitySigMethod);

- (NSString*)securitySigMethod NS_SWIFT_NAME(securitySigMethod());

@property (nonatomic,readonly,assign,getter=securitySignaturePolicy) int securitySignaturePolicy NS_SWIFT_NAME(securitySignaturePolicy);

- (int)securitySignaturePolicy NS_SWIFT_NAME(securitySignaturePolicy());

@property (nonatomic,readonly,assign,getter=signingCertBytes) NSData* signingCertBytes NS_SWIFT_NAME(signingCertBytes);

- (NSData*)signingCertBytes NS_SWIFT_NAME(signingCertBytes());

@property (nonatomic,readonly,assign,getter=signingCertCA) BOOL signingCertCA NS_SWIFT_NAME(signingCertCA);

- (BOOL)signingCertCA NS_SWIFT_NAME(signingCertCA());

@property (nonatomic,readonly,assign,getter=signingCertCAKeyID) NSData* signingCertCAKeyID NS_SWIFT_NAME(signingCertCAKeyID);

- (NSData*)signingCertCAKeyID NS_SWIFT_NAME(signingCertCAKeyID());

@property (nonatomic,readonly,assign,getter=signingCertCertType) int signingCertCertType NS_SWIFT_NAME(signingCertCertType);

- (int)signingCertCertType NS_SWIFT_NAME(signingCertCertType());

@property (nonatomic,readonly,assign,getter=signingCertCRLDistributionPoints) NSString* signingCertCRLDistributionPoints NS_SWIFT_NAME(signingCertCRLDistributionPoints);

- (NSString*)signingCertCRLDistributionPoints NS_SWIFT_NAME(signingCertCRLDistributionPoints());

@property (nonatomic,readonly,assign,getter=signingCertCurve) NSString* signingCertCurve NS_SWIFT_NAME(signingCertCurve);

- (NSString*)signingCertCurve NS_SWIFT_NAME(signingCertCurve());

@property (nonatomic,readonly,assign,getter=signingCertFingerprint) NSString* signingCertFingerprint NS_SWIFT_NAME(signingCertFingerprint);

- (NSString*)signingCertFingerprint NS_SWIFT_NAME(signingCertFingerprint());

@property (nonatomic,readonly,assign,getter=signingCertFriendlyName) NSString* signingCertFriendlyName NS_SWIFT_NAME(signingCertFriendlyName);

- (NSString*)signingCertFriendlyName NS_SWIFT_NAME(signingCertFriendlyName());

@property (nonatomic,readonly,assign,getter=signingCertHandle) long long signingCertHandle NS_SWIFT_NAME(signingCertHandle);

- (long long)signingCertHandle NS_SWIFT_NAME(signingCertHandle());

@property (nonatomic,readonly,assign,getter=signingCertHashAlgorithm) NSString* signingCertHashAlgorithm NS_SWIFT_NAME(signingCertHashAlgorithm);

- (NSString*)signingCertHashAlgorithm NS_SWIFT_NAME(signingCertHashAlgorithm());

@property (nonatomic,readonly,assign,getter=signingCertIssuer) NSString* signingCertIssuer NS_SWIFT_NAME(signingCertIssuer);

- (NSString*)signingCertIssuer NS_SWIFT_NAME(signingCertIssuer());

@property (nonatomic,readonly,assign,getter=signingCertIssuerRDN) NSString* signingCertIssuerRDN NS_SWIFT_NAME(signingCertIssuerRDN);

- (NSString*)signingCertIssuerRDN NS_SWIFT_NAME(signingCertIssuerRDN());

@property (nonatomic,readonly,assign,getter=signingCertKeyAlgorithm) NSString* signingCertKeyAlgorithm NS_SWIFT_NAME(signingCertKeyAlgorithm);

- (NSString*)signingCertKeyAlgorithm NS_SWIFT_NAME(signingCertKeyAlgorithm());

@property (nonatomic,readonly,assign,getter=signingCertKeyBits) int signingCertKeyBits NS_SWIFT_NAME(signingCertKeyBits);

- (int)signingCertKeyBits NS_SWIFT_NAME(signingCertKeyBits());

@property (nonatomic,readonly,assign,getter=signingCertKeyFingerprint) NSString* signingCertKeyFingerprint NS_SWIFT_NAME(signingCertKeyFingerprint);

- (NSString*)signingCertKeyFingerprint NS_SWIFT_NAME(signingCertKeyFingerprint());

@property (nonatomic,readonly,assign,getter=signingCertKeyUsage) int signingCertKeyUsage NS_SWIFT_NAME(signingCertKeyUsage);

- (int)signingCertKeyUsage NS_SWIFT_NAME(signingCertKeyUsage());

@property (nonatomic,readonly,assign,getter=signingCertKeyValid) BOOL signingCertKeyValid NS_SWIFT_NAME(signingCertKeyValid);

- (BOOL)signingCertKeyValid NS_SWIFT_NAME(signingCertKeyValid());

@property (nonatomic,readonly,assign,getter=signingCertOCSPLocations) NSString* signingCertOCSPLocations NS_SWIFT_NAME(signingCertOCSPLocations);

- (NSString*)signingCertOCSPLocations NS_SWIFT_NAME(signingCertOCSPLocations());

@property (nonatomic,readonly,assign,getter=signingCertOCSPNoCheck) BOOL signingCertOCSPNoCheck NS_SWIFT_NAME(signingCertOCSPNoCheck);

- (BOOL)signingCertOCSPNoCheck NS_SWIFT_NAME(signingCertOCSPNoCheck());

@property (nonatomic,readonly,assign,getter=signingCertOrigin) int signingCertOrigin NS_SWIFT_NAME(signingCertOrigin);

- (int)signingCertOrigin NS_SWIFT_NAME(signingCertOrigin());

@property (nonatomic,readonly,assign,getter=signingCertPolicyIDs) NSString* signingCertPolicyIDs NS_SWIFT_NAME(signingCertPolicyIDs);

- (NSString*)signingCertPolicyIDs NS_SWIFT_NAME(signingCertPolicyIDs());

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyBytes) NSData* signingCertPrivateKeyBytes NS_SWIFT_NAME(signingCertPrivateKeyBytes);

- (NSData*)signingCertPrivateKeyBytes NS_SWIFT_NAME(signingCertPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyExists) BOOL signingCertPrivateKeyExists NS_SWIFT_NAME(signingCertPrivateKeyExists);

- (BOOL)signingCertPrivateKeyExists NS_SWIFT_NAME(signingCertPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyExtractable) BOOL signingCertPrivateKeyExtractable NS_SWIFT_NAME(signingCertPrivateKeyExtractable);

- (BOOL)signingCertPrivateKeyExtractable NS_SWIFT_NAME(signingCertPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=signingCertPublicKeyBytes) NSData* signingCertPublicKeyBytes NS_SWIFT_NAME(signingCertPublicKeyBytes);

- (NSData*)signingCertPublicKeyBytes NS_SWIFT_NAME(signingCertPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=signingCertQualified) BOOL signingCertQualified NS_SWIFT_NAME(signingCertQualified);

- (BOOL)signingCertQualified NS_SWIFT_NAME(signingCertQualified());

@property (nonatomic,readonly,assign,getter=signingCertQualifiedStatements) int signingCertQualifiedStatements NS_SWIFT_NAME(signingCertQualifiedStatements);

- (int)signingCertQualifiedStatements NS_SWIFT_NAME(signingCertQualifiedStatements());

@property (nonatomic,readonly,assign,getter=signingCertQualifiers) NSString* signingCertQualifiers NS_SWIFT_NAME(signingCertQualifiers);

- (NSString*)signingCertQualifiers NS_SWIFT_NAME(signingCertQualifiers());

@property (nonatomic,readonly,assign,getter=signingCertSelfSigned) BOOL signingCertSelfSigned NS_SWIFT_NAME(signingCertSelfSigned);

- (BOOL)signingCertSelfSigned NS_SWIFT_NAME(signingCertSelfSigned());

@property (nonatomic,readonly,assign,getter=signingCertSerialNumber) NSData* signingCertSerialNumber NS_SWIFT_NAME(signingCertSerialNumber);

- (NSData*)signingCertSerialNumber NS_SWIFT_NAME(signingCertSerialNumber());

@property (nonatomic,readonly,assign,getter=signingCertSigAlgorithm) NSString* signingCertSigAlgorithm NS_SWIFT_NAME(signingCertSigAlgorithm);

- (NSString*)signingCertSigAlgorithm NS_SWIFT_NAME(signingCertSigAlgorithm());

@property (nonatomic,readonly,assign,getter=signingCertSource) int signingCertSource NS_SWIFT_NAME(signingCertSource);

- (int)signingCertSource NS_SWIFT_NAME(signingCertSource());

@property (nonatomic,readonly,assign,getter=signingCertSubject) NSString* signingCertSubject NS_SWIFT_NAME(signingCertSubject);

- (NSString*)signingCertSubject NS_SWIFT_NAME(signingCertSubject());

@property (nonatomic,readonly,assign,getter=signingCertSubjectAlternativeName) NSString* signingCertSubjectAlternativeName NS_SWIFT_NAME(signingCertSubjectAlternativeName);

- (NSString*)signingCertSubjectAlternativeName NS_SWIFT_NAME(signingCertSubjectAlternativeName());

@property (nonatomic,readonly,assign,getter=signingCertSubjectKeyID) NSData* signingCertSubjectKeyID NS_SWIFT_NAME(signingCertSubjectKeyID);

- (NSData*)signingCertSubjectKeyID NS_SWIFT_NAME(signingCertSubjectKeyID());

@property (nonatomic,readonly,assign,getter=signingCertSubjectRDN) NSString* signingCertSubjectRDN NS_SWIFT_NAME(signingCertSubjectRDN);

- (NSString*)signingCertSubjectRDN NS_SWIFT_NAME(signingCertSubjectRDN());

@property (nonatomic,readonly,assign,getter=signingCertValid) BOOL signingCertValid NS_SWIFT_NAME(signingCertValid);

- (BOOL)signingCertValid NS_SWIFT_NAME(signingCertValid());

@property (nonatomic,readonly,assign,getter=signingCertValidFrom) NSString* signingCertValidFrom NS_SWIFT_NAME(signingCertValidFrom);

- (NSString*)signingCertValidFrom NS_SWIFT_NAME(signingCertValidFrom());

@property (nonatomic,readonly,assign,getter=signingCertValidTo) NSString* signingCertValidTo NS_SWIFT_NAME(signingCertValidTo);

- (NSString*)signingCertValidTo NS_SWIFT_NAME(signingCertValidTo());

@property (nonatomic,readwrite,assign,getter=socketDNSMode,setter=setSocketDNSMode:) int socketDNSMode NS_SWIFT_NAME(socketDNSMode);

- (int)socketDNSMode NS_SWIFT_NAME(socketDNSMode());
- (void)setSocketDNSMode :(int)newSocketDNSMode NS_SWIFT_NAME(setSocketDNSMode(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSPort,setter=setSocketDNSPort:) int socketDNSPort NS_SWIFT_NAME(socketDNSPort);

- (int)socketDNSPort NS_SWIFT_NAME(socketDNSPort());
- (void)setSocketDNSPort :(int)newSocketDNSPort NS_SWIFT_NAME(setSocketDNSPort(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSQueryTimeout,setter=setSocketDNSQueryTimeout:) int socketDNSQueryTimeout NS_SWIFT_NAME(socketDNSQueryTimeout);

- (int)socketDNSQueryTimeout NS_SWIFT_NAME(socketDNSQueryTimeout());
- (void)setSocketDNSQueryTimeout :(int)newSocketDNSQueryTimeout NS_SWIFT_NAME(setSocketDNSQueryTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSServers,setter=setSocketDNSServers:) NSString* socketDNSServers NS_SWIFT_NAME(socketDNSServers);

- (NSString*)socketDNSServers NS_SWIFT_NAME(socketDNSServers());
- (void)setSocketDNSServers :(NSString*)newSocketDNSServers NS_SWIFT_NAME(setSocketDNSServers(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSTotalTimeout,setter=setSocketDNSTotalTimeout:) int socketDNSTotalTimeout NS_SWIFT_NAME(socketDNSTotalTimeout);

- (int)socketDNSTotalTimeout NS_SWIFT_NAME(socketDNSTotalTimeout());
- (void)setSocketDNSTotalTimeout :(int)newSocketDNSTotalTimeout NS_SWIFT_NAME(setSocketDNSTotalTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketIncomingSpeedLimit,setter=setSocketIncomingSpeedLimit:) int socketIncomingSpeedLimit NS_SWIFT_NAME(socketIncomingSpeedLimit);

- (int)socketIncomingSpeedLimit NS_SWIFT_NAME(socketIncomingSpeedLimit());
- (void)setSocketIncomingSpeedLimit :(int)newSocketIncomingSpeedLimit NS_SWIFT_NAME(setSocketIncomingSpeedLimit(_:));

@property (nonatomic,readwrite,assign,getter=socketLocalAddress,setter=setSocketLocalAddress:) NSString* socketLocalAddress NS_SWIFT_NAME(socketLocalAddress);

- (NSString*)socketLocalAddress NS_SWIFT_NAME(socketLocalAddress());
- (void)setSocketLocalAddress :(NSString*)newSocketLocalAddress NS_SWIFT_NAME(setSocketLocalAddress(_:));

@property (nonatomic,readwrite,assign,getter=socketLocalPort,setter=setSocketLocalPort:) int socketLocalPort NS_SWIFT_NAME(socketLocalPort);

- (int)socketLocalPort NS_SWIFT_NAME(socketLocalPort());
- (void)setSocketLocalPort :(int)newSocketLocalPort NS_SWIFT_NAME(setSocketLocalPort(_:));

@property (nonatomic,readwrite,assign,getter=socketOutgoingSpeedLimit,setter=setSocketOutgoingSpeedLimit:) int socketOutgoingSpeedLimit NS_SWIFT_NAME(socketOutgoingSpeedLimit);

- (int)socketOutgoingSpeedLimit NS_SWIFT_NAME(socketOutgoingSpeedLimit());
- (void)setSocketOutgoingSpeedLimit :(int)newSocketOutgoingSpeedLimit NS_SWIFT_NAME(setSocketOutgoingSpeedLimit(_:));

@property (nonatomic,readwrite,assign,getter=socketTimeout,setter=setSocketTimeout:) int socketTimeout NS_SWIFT_NAME(socketTimeout);

- (int)socketTimeout NS_SWIFT_NAME(socketTimeout());
- (void)setSocketTimeout :(int)newSocketTimeout NS_SWIFT_NAME(setSocketTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketUseIPv6,setter=setSocketUseIPv6:) BOOL socketUseIPv6 NS_SWIFT_NAME(socketUseIPv6);

- (BOOL)socketUseIPv6 NS_SWIFT_NAME(socketUseIPv6());
- (void)setSocketUseIPv6 :(BOOL)newSocketUseIPv6 NS_SWIFT_NAME(setSocketUseIPv6(_:));

@property (nonatomic,readonly,assign,getter=statementCount) int statementCount NS_SWIFT_NAME(statementCount);

- (int)statementCount NS_SWIFT_NAME(statementCount());

- (NSString*)statementAuthnContextAuthenticatingAuthorities:(int)statementIndex NS_SWIFT_NAME(statementAuthnContextAuthenticatingAuthorities(_:));

- (NSString*)statementAuthnContextChoice:(int)statementIndex NS_SWIFT_NAME(statementAuthnContextChoice(_:));

- (NSString*)statementAuthnContextClassRef:(int)statementIndex NS_SWIFT_NAME(statementAuthnContextClassRef(_:));

- (NSString*)statementAuthnContextDecl:(int)statementIndex NS_SWIFT_NAME(statementAuthnContextDecl(_:));

- (NSString*)statementAuthnContextDeclRef:(int)statementIndex NS_SWIFT_NAME(statementAuthnContextDeclRef(_:));

- (NSString*)statementAuthnInstant:(int)statementIndex NS_SWIFT_NAME(statementAuthnInstant(_:));

- (NSString*)statementAuthnSessionIndex:(int)statementIndex NS_SWIFT_NAME(statementAuthnSessionIndex(_:));

- (NSString*)statementAuthnSessionNotOnOrAfter:(int)statementIndex NS_SWIFT_NAME(statementAuthnSessionNotOnOrAfter(_:));

- (NSString*)statementAuthnSubjectLocalityAddress:(int)statementIndex NS_SWIFT_NAME(statementAuthnSubjectLocalityAddress(_:));

- (NSString*)statementAuthnSubjectLocalityDNSName:(int)statementIndex NS_SWIFT_NAME(statementAuthnSubjectLocalityDNSName(_:));

- (NSString*)statementAuthzActions:(int)statementIndex NS_SWIFT_NAME(statementAuthzActions(_:));

- (int)statementAuthzDecision:(int)statementIndex NS_SWIFT_NAME(statementAuthzDecision(_:));

- (NSString*)statementAuthzDecisionEvidence:(int)statementIndex NS_SWIFT_NAME(statementAuthzDecisionEvidence(_:));

- (NSString*)statementAuthzDecisionResource:(int)statementIndex NS_SWIFT_NAME(statementAuthzDecisionResource(_:));

- (int)statementStatementType:(int)statementIndex NS_SWIFT_NAME(statementStatementType(_:));

@property (nonatomic,readonly,assign,getter=subjectConfirmationCount) int subjectConfirmationCount NS_SWIFT_NAME(subjectConfirmationCount);

- (int)subjectConfirmationCount NS_SWIFT_NAME(subjectConfirmationCount());

- (NSString*)subjectConfirmationAddress:(int)subjectConfirmationIndex NS_SWIFT_NAME(subjectConfirmationAddress(_:));

- (NSString*)subjectConfirmationData:(int)subjectConfirmationIndex NS_SWIFT_NAME(subjectConfirmationData(_:));

- (NSString*)subjectConfirmationDataType:(int)subjectConfirmationIndex NS_SWIFT_NAME(subjectConfirmationDataType(_:));

- (NSString*)subjectConfirmationID:(int)subjectConfirmationIndex NS_SWIFT_NAME(subjectConfirmationID(_:));

- (NSString*)subjectConfirmationInResponseTo:(int)subjectConfirmationIndex NS_SWIFT_NAME(subjectConfirmationInResponseTo(_:));

- (NSString*)subjectConfirmationMethod:(int)subjectConfirmationIndex NS_SWIFT_NAME(subjectConfirmationMethod(_:));

- (NSString*)subjectConfirmationNotBefore:(int)subjectConfirmationIndex NS_SWIFT_NAME(subjectConfirmationNotBefore(_:));

- (NSString*)subjectConfirmationNotOnOrAfter:(int)subjectConfirmationIndex NS_SWIFT_NAME(subjectConfirmationNotOnOrAfter(_:));

- (NSString*)subjectConfirmationRecipient:(int)subjectConfirmationIndex NS_SWIFT_NAME(subjectConfirmationRecipient(_:));

@property (nonatomic,readwrite,assign,getter=TLSAutoValidateCertificates,setter=setTLSAutoValidateCertificates:) BOOL TLSAutoValidateCertificates NS_SWIFT_NAME(TLSAutoValidateCertificates);

- (BOOL)TLSAutoValidateCertificates NS_SWIFT_NAME(TLSAutoValidateCertificates());
- (void)setTLSAutoValidateCertificates :(BOOL)newTLSAutoValidateCertificates NS_SWIFT_NAME(setTLSAutoValidateCertificates(_:));

@property (nonatomic,readwrite,assign,getter=TLSBaseConfiguration,setter=setTLSBaseConfiguration:) int TLSBaseConfiguration NS_SWIFT_NAME(TLSBaseConfiguration);

- (int)TLSBaseConfiguration NS_SWIFT_NAME(TLSBaseConfiguration());
- (void)setTLSBaseConfiguration :(int)newTLSBaseConfiguration NS_SWIFT_NAME(setTLSBaseConfiguration(_:));

@property (nonatomic,readwrite,assign,getter=TLSCiphersuites,setter=setTLSCiphersuites:) NSString* TLSCiphersuites NS_SWIFT_NAME(TLSCiphersuites);

- (NSString*)TLSCiphersuites NS_SWIFT_NAME(TLSCiphersuites());
- (void)setTLSCiphersuites :(NSString*)newTLSCiphersuites NS_SWIFT_NAME(setTLSCiphersuites(_:));

@property (nonatomic,readwrite,assign,getter=TLSClientAuth,setter=setTLSClientAuth:) int TLSClientAuth NS_SWIFT_NAME(TLSClientAuth);

- (int)TLSClientAuth NS_SWIFT_NAME(TLSClientAuth());
- (void)setTLSClientAuth :(int)newTLSClientAuth NS_SWIFT_NAME(setTLSClientAuth(_:));

@property (nonatomic,readwrite,assign,getter=TLSECCurves,setter=setTLSECCurves:) NSString* TLSECCurves NS_SWIFT_NAME(TLSECCurves);

- (NSString*)TLSECCurves NS_SWIFT_NAME(TLSECCurves());
- (void)setTLSECCurves :(NSString*)newTLSECCurves NS_SWIFT_NAME(setTLSECCurves(_:));

@property (nonatomic,readwrite,assign,getter=TLSExtensions,setter=setTLSExtensions:) NSString* TLSExtensions NS_SWIFT_NAME(TLSExtensions);

- (NSString*)TLSExtensions NS_SWIFT_NAME(TLSExtensions());
- (void)setTLSExtensions :(NSString*)newTLSExtensions NS_SWIFT_NAME(setTLSExtensions(_:));

@property (nonatomic,readwrite,assign,getter=TLSForceResumeIfDestinationChanges,setter=setTLSForceResumeIfDestinationChanges:) BOOL TLSForceResumeIfDestinationChanges NS_SWIFT_NAME(TLSForceResumeIfDestinationChanges);

- (BOOL)TLSForceResumeIfDestinationChanges NS_SWIFT_NAME(TLSForceResumeIfDestinationChanges());
- (void)setTLSForceResumeIfDestinationChanges :(BOOL)newTLSForceResumeIfDestinationChanges NS_SWIFT_NAME(setTLSForceResumeIfDestinationChanges(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedIdentity,setter=setTLSPreSharedIdentity:) NSString* TLSPreSharedIdentity NS_SWIFT_NAME(TLSPreSharedIdentity);

- (NSString*)TLSPreSharedIdentity NS_SWIFT_NAME(TLSPreSharedIdentity());
- (void)setTLSPreSharedIdentity :(NSString*)newTLSPreSharedIdentity NS_SWIFT_NAME(setTLSPreSharedIdentity(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedKey,setter=setTLSPreSharedKey:) NSString* TLSPreSharedKey NS_SWIFT_NAME(TLSPreSharedKey);

- (NSString*)TLSPreSharedKey NS_SWIFT_NAME(TLSPreSharedKey());
- (void)setTLSPreSharedKey :(NSString*)newTLSPreSharedKey NS_SWIFT_NAME(setTLSPreSharedKey(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedKeyCiphersuite,setter=setTLSPreSharedKeyCiphersuite:) NSString* TLSPreSharedKeyCiphersuite NS_SWIFT_NAME(TLSPreSharedKeyCiphersuite);

- (NSString*)TLSPreSharedKeyCiphersuite NS_SWIFT_NAME(TLSPreSharedKeyCiphersuite());
- (void)setTLSPreSharedKeyCiphersuite :(NSString*)newTLSPreSharedKeyCiphersuite NS_SWIFT_NAME(setTLSPreSharedKeyCiphersuite(_:));

@property (nonatomic,readwrite,assign,getter=TLSRenegotiationAttackPreventionMode,setter=setTLSRenegotiationAttackPreventionMode:) int TLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(TLSRenegotiationAttackPreventionMode);

- (int)TLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(TLSRenegotiationAttackPreventionMode());
- (void)setTLSRenegotiationAttackPreventionMode :(int)newTLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(setTLSRenegotiationAttackPreventionMode(_:));

@property (nonatomic,readwrite,assign,getter=TLSRevocationCheck,setter=setTLSRevocationCheck:) int TLSRevocationCheck NS_SWIFT_NAME(TLSRevocationCheck);

- (int)TLSRevocationCheck NS_SWIFT_NAME(TLSRevocationCheck());
- (void)setTLSRevocationCheck :(int)newTLSRevocationCheck NS_SWIFT_NAME(setTLSRevocationCheck(_:));

@property (nonatomic,readwrite,assign,getter=TLSSSLOptions,setter=setTLSSSLOptions:) int TLSSSLOptions NS_SWIFT_NAME(TLSSSLOptions);

- (int)TLSSSLOptions NS_SWIFT_NAME(TLSSSLOptions());
- (void)setTLSSSLOptions :(int)newTLSSSLOptions NS_SWIFT_NAME(setTLSSSLOptions(_:));

@property (nonatomic,readwrite,assign,getter=TLSTLSMode,setter=setTLSTLSMode:) int TLSTLSMode NS_SWIFT_NAME(TLSTLSMode);

- (int)TLSTLSMode NS_SWIFT_NAME(TLSTLSMode());
- (void)setTLSTLSMode :(int)newTLSTLSMode NS_SWIFT_NAME(setTLSTLSMode(_:));

@property (nonatomic,readwrite,assign,getter=TLSUseExtendedMasterSecret,setter=setTLSUseExtendedMasterSecret:) BOOL TLSUseExtendedMasterSecret NS_SWIFT_NAME(TLSUseExtendedMasterSecret);

- (BOOL)TLSUseExtendedMasterSecret NS_SWIFT_NAME(TLSUseExtendedMasterSecret());
- (void)setTLSUseExtendedMasterSecret :(BOOL)newTLSUseExtendedMasterSecret NS_SWIFT_NAME(setTLSUseExtendedMasterSecret(_:));

@property (nonatomic,readwrite,assign,getter=TLSUseSessionResumption,setter=setTLSUseSessionResumption:) BOOL TLSUseSessionResumption NS_SWIFT_NAME(TLSUseSessionResumption);

- (BOOL)TLSUseSessionResumption NS_SWIFT_NAME(TLSUseSessionResumption());
- (void)setTLSUseSessionResumption :(BOOL)newTLSUseSessionResumption NS_SWIFT_NAME(setTLSUseSessionResumption(_:));

@property (nonatomic,readwrite,assign,getter=TLSVersions,setter=setTLSVersions:) int TLSVersions NS_SWIFT_NAME(TLSVersions);

- (int)TLSVersions NS_SWIFT_NAME(TLSVersions());
- (void)setTLSVersions :(int)newTLSVersions NS_SWIFT_NAME(setTLSVersions(_:));

@property (nonatomic,readwrite,assign,getter=useBinding,setter=setUseBinding:) BOOL useBinding NS_SWIFT_NAME(useBinding);

- (BOOL)useBinding NS_SWIFT_NAME(useBinding());
- (void)setUseBinding :(BOOL)newUseBinding NS_SWIFT_NAME(setUseBinding(_:));

@property (nonatomic,readwrite,assign,getter=validateSignatures,setter=setValidateSignatures:) BOOL validateSignatures NS_SWIFT_NAME(validateSignatures);

- (BOOL)validateSignatures NS_SWIFT_NAME(validateSignatures());
- (void)setValidateSignatures :(BOOL)newValidateSignatures NS_SWIFT_NAME(setValidateSignatures(_:));

  /* Methods */

- (BOOL)compareIDs:(NSString*)ID1 :(NSString*)ID2 NS_SWIFT_NAME(compareIDs(_:_:));

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (NSString*)getIDProp:(NSString*)ID :(NSString*)propName NS_SWIFT_NAME(getIDProp(_:_:));

- (void)open:(NSString*)input NS_SWIFT_NAME(open(_:));

- (void)openBytes:(NSData*)inputBytes NS_SWIFT_NAME(openBytes(_:));

- (void)openFile:(NSString*)inputFile NS_SWIFT_NAME(openFile(_:));

- (void)pinAssertion:(int)assertionIndex NS_SWIFT_NAME(pinAssertion(_:));

- (void)reset NS_SWIFT_NAME(reset());

@end

