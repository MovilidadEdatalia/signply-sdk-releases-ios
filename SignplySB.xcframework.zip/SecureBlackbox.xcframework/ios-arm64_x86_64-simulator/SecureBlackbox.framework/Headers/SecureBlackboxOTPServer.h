/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//OTPALGORITHMS
#define OA_NONE                                            0

#define OA_HMAC                                            1

#define OA_TIME                                            2

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxOTPServerDelegate <NSObject>
@optional
- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

@end

@interface SecureBlackboxOTPServer : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxOTPServerDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasError;

  BOOL m_delegateHasNotification;

}

+ (SecureBlackboxOTPServer*)otpserver;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxOTPServerDelegate> delegate;
- (id <SecureBlackboxOTPServerDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxOTPServerDelegate>)anObject;

  /* Events */

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readwrite,assign,getter=baseTime,setter=setBaseTime:) NSString* baseTime NS_SWIFT_NAME(baseTime);

- (NSString*)baseTime NS_SWIFT_NAME(baseTime());
- (void)setBaseTime :(NSString*)newBaseTime NS_SWIFT_NAME(setBaseTime(_:));

@property (nonatomic,readwrite,assign,getter=delta,setter=setDelta:) int delta NS_SWIFT_NAME(delta);

- (int)delta NS_SWIFT_NAME(delta());
- (void)setDelta :(int)newDelta NS_SWIFT_NAME(setDelta(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=userCount,setter=setUserCount:) int userCount NS_SWIFT_NAME(userCount);

- (int)userCount NS_SWIFT_NAME(userCount());
- (void)setUserCount :(int)newUserCount NS_SWIFT_NAME(setUserCount(_:));

- (NSData*)userAssociatedData:(int)userIndex NS_SWIFT_NAME(userAssociatedData(_:));
- (void)setUserAssociatedData:(int)userIndex :(NSData*)newUserAssociatedData NS_SWIFT_NAME(setUserAssociatedData(_:_:));

- (NSString*)userBasePath:(int)userIndex NS_SWIFT_NAME(userBasePath(_:));
- (void)setUserBasePath:(int)userIndex :(NSString*)newUserBasePath NS_SWIFT_NAME(setUserBasePath(_:_:));

- (NSData*)userCertificate:(int)userIndex NS_SWIFT_NAME(userCertificate(_:));
- (void)setUserCertificate:(int)userIndex :(NSData*)newUserCertificate NS_SWIFT_NAME(setUserCertificate(_:_:));

- (NSString*)userData:(int)userIndex NS_SWIFT_NAME(userData(_:));
- (void)setUserData:(int)userIndex :(NSString*)newUserData NS_SWIFT_NAME(setUserData(_:_:));

- (NSString*)userEmail:(int)userIndex NS_SWIFT_NAME(userEmail(_:));
- (void)setUserEmail:(int)userIndex :(NSString*)newUserEmail NS_SWIFT_NAME(setUserEmail(_:_:));

- (long long)userHandle:(int)userIndex NS_SWIFT_NAME(userHandle(_:));
- (void)setUserHandle:(int)userIndex :(long long)newUserHandle NS_SWIFT_NAME(setUserHandle(_:_:));

- (NSString*)userHashAlgorithm:(int)userIndex NS_SWIFT_NAME(userHashAlgorithm(_:));
- (void)setUserHashAlgorithm:(int)userIndex :(NSString*)newUserHashAlgorithm NS_SWIFT_NAME(setUserHashAlgorithm(_:_:));

- (int)userIncomingSpeedLimit:(int)userIndex NS_SWIFT_NAME(userIncomingSpeedLimit(_:));
- (void)setUserIncomingSpeedLimit:(int)userIndex :(int)newUserIncomingSpeedLimit NS_SWIFT_NAME(setUserIncomingSpeedLimit(_:_:));

- (int)userOtpAlgorithm:(int)userIndex NS_SWIFT_NAME(userOtpAlgorithm(_:));
- (void)setUserOtpAlgorithm:(int)userIndex :(int)newUserOtpAlgorithm NS_SWIFT_NAME(setUserOtpAlgorithm(_:_:));

- (int)userOTPLen:(int)userIndex NS_SWIFT_NAME(userOTPLen(_:));
- (void)setUserOTPLen:(int)userIndex :(int)newUserOTPLen NS_SWIFT_NAME(setUserOTPLen(_:_:));

- (int)userOtpValue:(int)userIndex NS_SWIFT_NAME(userOtpValue(_:));
- (void)setUserOtpValue:(int)userIndex :(int)newUserOtpValue NS_SWIFT_NAME(setUserOtpValue(_:_:));

- (int)userOutgoingSpeedLimit:(int)userIndex NS_SWIFT_NAME(userOutgoingSpeedLimit(_:));
- (void)setUserOutgoingSpeedLimit:(int)userIndex :(int)newUserOutgoingSpeedLimit NS_SWIFT_NAME(setUserOutgoingSpeedLimit(_:_:));

- (NSString*)userPassword:(int)userIndex NS_SWIFT_NAME(userPassword(_:));
- (void)setUserPassword:(int)userIndex :(NSString*)newUserPassword NS_SWIFT_NAME(setUserPassword(_:_:));

- (NSData*)userSharedSecret:(int)userIndex NS_SWIFT_NAME(userSharedSecret(_:));
- (void)setUserSharedSecret:(int)userIndex :(NSData*)newUserSharedSecret NS_SWIFT_NAME(setUserSharedSecret(_:_:));

- (NSData*)userSSHKey:(int)userIndex NS_SWIFT_NAME(userSSHKey(_:));
- (void)setUserSSHKey:(int)userIndex :(NSData*)newUserSSHKey NS_SWIFT_NAME(setUserSSHKey(_:_:));

- (NSString*)userUsername:(int)userIndex NS_SWIFT_NAME(userUsername(_:));
- (void)setUserUsername:(int)userIndex :(NSString*)newUserUsername NS_SWIFT_NAME(setUserUsername(_:_:));

  /* Methods */

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (BOOL)isHOTPPasswordValid:(NSData*)keySecret :(int)passwordLength :(int)counter :(NSString*)password NS_SWIFT_NAME(isHOTPPasswordValid(_:_:_:_:));

- (BOOL)isPasswordValid:(NSString*)username :(NSString*)password NS_SWIFT_NAME(isPasswordValid(_:_:));

- (BOOL)isTOTPPasswordValid:(NSData*)keySecret :(int)passwordLength :(int)timeInterval :(NSString*)hashAlgorithm :(NSString*)password NS_SWIFT_NAME(isTOTPPasswordValid(_:_:_:_:_:));

- (void)reset NS_SWIFT_NAME(reset());

@end

