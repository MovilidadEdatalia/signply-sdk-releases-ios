/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

//CHAINVALIDITIES
#define CVT_VALID                                          0

#define CVT_VALID_BUT_UNTRUSTED                            1

#define CVT_INVALID                                        2

#define CVT_CANT_BE_ESTABLISHED                            3

//PROXYAUTHTYPES
#define PAT_NO_AUTHENTICATION                              0

#define PAT_BASIC                                          1

#define PAT_DIGEST                                         2

#define PAT_NTLM                                           3

//PROXYTYPES
#define CPT_NONE                                           0

#define CPT_SOCKS_4                                        1

#define CPT_SOCKS_5                                        2

#define CPT_WEB_TUNNEL                                     3

#define CPT_HTTP                                           4

//QUALIFIEDINFOSOURCES
#define QIS_UNKNOWN                                        0

#define QIS_CERTIFICATE                                    1

#define QIS_TSL                                            2

#define QIS_BOTH                                           3

//QUALIFIEDSERVICESTATUSES
#define SQS_UNKNOWN                                        0

#define SQS_NONE                                           1

#define SQS_GRANTED                                        2

#define SQS_WITHDRAWN                                      3

#define SQS_SET_BY_NATIONAL_LAW                            4

#define SQS_DEPRECATED_BY_NATIONAL_LAW                     5

#define SQS_RECOGNIZED_AT_NATIONAL_LEVEL                   6

#define SQS_DEPRECATED_AT_NATIONAL_LEVEL                   7

#define SQS_UNDER_SUPERVISION                              8

#define SQS_SUPERVISION_IN_CESSATION                       9

#define SQS_SUPERVISION_CEASED                             10

#define SQS_SUPERVISION_REVOKED                            11

#define SQS_ACCREDITED                                     12

#define SQS_ACCREDITATION_CEASED                           13

#define SQS_ACCREDITATION_REVOKED                          14

#define SQS_IN_ACCORDANCE                                  15

#define SQS_EXPIRED                                        16

#define SQS_SUSPENDED                                      17

#define SQS_REVOKED                                        18

#define SQS_NOT_IN_ACCORDANCE                              19

//REVOCATIONCHECKKINDS
#define CRC_NONE                                           0

#define CRC_AUTO                                           1

#define CRC_ALL_CRL                                        2

#define CRC_ALL_OCSP                                       3

#define CRC_ALL_CRLAND_OCSP                                4

#define CRC_ANY_CRL                                        5

#define CRC_ANY_OCSP                                       6

#define CRC_ANY_CRLOR_OCSP                                 7

#define CRC_ANY_OCSPOR_CRL                                 8

//DNSRESOLVEMODES
#define DM_AUTO                                            0

#define DM_PLATFORM                                        1

#define DM_OWN                                             2

#define DM_OWN_SECURE                                      3

//SECURETRANSPORTPREDEFINEDCONFIGURATIONS
#define STPC_DEFAULT                                       0

#define STPC_COMPATIBLE                                    1

#define STPC_COMPREHENSIVE_INSECURE                        2

#define STPC_HIGHLY_SECURE                                 3

//CLIENTAUTHTYPES
#define CCAT_NO_AUTH                                       0

#define CCAT_REQUEST_CERT                                  1

#define CCAT_REQUIRE_CERT                                  2

//RENEGOTIATIONATTACKPREVENTIONMODES
#define CRAPM_COMPATIBLE                                   0

#define CRAPM_STRICT                                       1

#define CRAPM_AUTO                                         2

//SSLMODES
#define SM_DEFAULT                                         0

#define SM_NO_TLS                                          1

#define SM_EXPLICIT_TLS                                    2

#define SM_IMPLICIT_TLS                                    3

#define SM_MIXED_TLS                                       4

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxCertificateValidatorDelegate <NSObject>
@optional
- (void)onAfterCertificateProcessing:(NSString*)cert :(int)validity :(int)validationDetails NS_SWIFT_NAME(onAfterCertificateProcessing(_:_:_:));

- (void)onAfterCertificateValidation:(NSString*)cert :(NSString*)CACert :(int)validity :(int)validationDetails NS_SWIFT_NAME(onAfterCertificateValidation(_:_:_:_:));

- (void)onBeforeCACertificateDownload:(NSString*)cert :(NSString*)location NS_SWIFT_NAME(onBeforeCACertificateDownload(_:_:));

- (void)onBeforeCertificateProcessing:(NSString*)cert :(int)validity :(int)validationDetails NS_SWIFT_NAME(onBeforeCertificateProcessing(_:_:_:));

- (void)onBeforeCertificateValidation:(NSString*)cert :(NSString*)CACert NS_SWIFT_NAME(onBeforeCertificateValidation(_:_:));

- (void)onBeforeCRLDownload:(NSString*)cert :(NSString*)CACert :(NSString*)location NS_SWIFT_NAME(onBeforeCRLDownload(_:_:_:));

- (void)onBeforeOCSPDownload:(NSString*)cert :(NSString*)CACert :(NSString*)location NS_SWIFT_NAME(onBeforeOCSPDownload(_:_:_:));

- (void)onCACertificateDownloaded:(NSString*)cert :(NSString*)location NS_SWIFT_NAME(onCACertificateDownloaded(_:_:));

- (void)onCACertificateNeeded:(NSString*)cert NS_SWIFT_NAME(onCACertificateNeeded(_:));

- (void)onCRLDownloaded:(NSString*)cert :(NSString*)CACert :(NSString*)location NS_SWIFT_NAME(onCRLDownloaded(_:_:_:));

- (void)onCRLNeeded:(NSString*)cert :(NSString*)CACert NS_SWIFT_NAME(onCRLNeeded(_:_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onOCSPDownloaded:(NSString*)cert :(NSString*)CACert :(NSString*)location NS_SWIFT_NAME(onOCSPDownloaded(_:_:_:));

- (void)onTLSCertNeeded:(NSString*)host :(NSString*)CANames NS_SWIFT_NAME(onTLSCertNeeded(_:_:));

- (void)onTLSCertValidate:(NSString*)serverHost :(NSString*)serverIP :(int*)accept NS_SWIFT_NAME(onTLSCertValidate(_:_:_:));

- (void)onTLSEstablished:(NSString*)host :(NSString*)version :(NSString*)ciphersuite :(NSData*)connectionId :(int*)abort NS_SWIFT_NAME(onTLSEstablished(_:_:_:_:_:));

- (void)onTLSHandshake:(NSString*)host :(int*)abort NS_SWIFT_NAME(onTLSHandshake(_:_:));

- (void)onTLSShutdown:(NSString*)host NS_SWIFT_NAME(onTLSShutdown(_:));

@end

@interface SecureBlackboxCertificateValidator : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxCertificateValidatorDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasAfterCertificateProcessing;

  BOOL m_delegateHasAfterCertificateValidation;

  BOOL m_delegateHasBeforeCACertificateDownload;

  BOOL m_delegateHasBeforeCertificateProcessing;

  BOOL m_delegateHasBeforeCertificateValidation;

  BOOL m_delegateHasBeforeCRLDownload;

  BOOL m_delegateHasBeforeOCSPDownload;

  BOOL m_delegateHasCACertificateDownloaded;

  BOOL m_delegateHasCACertificateNeeded;

  BOOL m_delegateHasCRLDownloaded;

  BOOL m_delegateHasCRLNeeded;

  BOOL m_delegateHasError;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasOCSPDownloaded;

  BOOL m_delegateHasTLSCertNeeded;

  BOOL m_delegateHasTLSCertValidate;

  BOOL m_delegateHasTLSEstablished;

  BOOL m_delegateHasTLSHandshake;

  BOOL m_delegateHasTLSShutdown;

}

+ (SecureBlackboxCertificateValidator*)certificatevalidator;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxCertificateValidatorDelegate> delegate;
- (id <SecureBlackboxCertificateValidatorDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxCertificateValidatorDelegate>)anObject;

  /* Events */

- (void)onAfterCertificateProcessing:(NSString*)cert :(int)validity :(int)validationDetails NS_SWIFT_NAME(onAfterCertificateProcessing(_:_:_:));

- (void)onAfterCertificateValidation:(NSString*)cert :(NSString*)CACert :(int)validity :(int)validationDetails NS_SWIFT_NAME(onAfterCertificateValidation(_:_:_:_:));

- (void)onBeforeCACertificateDownload:(NSString*)cert :(NSString*)location NS_SWIFT_NAME(onBeforeCACertificateDownload(_:_:));

- (void)onBeforeCertificateProcessing:(NSString*)cert :(int)validity :(int)validationDetails NS_SWIFT_NAME(onBeforeCertificateProcessing(_:_:_:));

- (void)onBeforeCertificateValidation:(NSString*)cert :(NSString*)CACert NS_SWIFT_NAME(onBeforeCertificateValidation(_:_:));

- (void)onBeforeCRLDownload:(NSString*)cert :(NSString*)CACert :(NSString*)location NS_SWIFT_NAME(onBeforeCRLDownload(_:_:_:));

- (void)onBeforeOCSPDownload:(NSString*)cert :(NSString*)CACert :(NSString*)location NS_SWIFT_NAME(onBeforeOCSPDownload(_:_:_:));

- (void)onCACertificateDownloaded:(NSString*)cert :(NSString*)location NS_SWIFT_NAME(onCACertificateDownloaded(_:_:));

- (void)onCACertificateNeeded:(NSString*)cert NS_SWIFT_NAME(onCACertificateNeeded(_:));

- (void)onCRLDownloaded:(NSString*)cert :(NSString*)CACert :(NSString*)location NS_SWIFT_NAME(onCRLDownloaded(_:_:_:));

- (void)onCRLNeeded:(NSString*)cert :(NSString*)CACert NS_SWIFT_NAME(onCRLNeeded(_:_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onOCSPDownloaded:(NSString*)cert :(NSString*)CACert :(NSString*)location NS_SWIFT_NAME(onOCSPDownloaded(_:_:_:));

- (void)onTLSCertNeeded:(NSString*)host :(NSString*)CANames NS_SWIFT_NAME(onTLSCertNeeded(_:_:));

- (void)onTLSCertValidate:(NSString*)serverHost :(NSString*)serverIP :(int*)accept NS_SWIFT_NAME(onTLSCertValidate(_:_:_:));

- (void)onTLSEstablished:(NSString*)host :(NSString*)version :(NSString*)ciphersuite :(NSData*)connectionId :(int*)abort NS_SWIFT_NAME(onTLSEstablished(_:_:_:_:_:));

- (void)onTLSHandshake:(NSString*)host :(int*)abort NS_SWIFT_NAME(onTLSHandshake(_:_:));

- (void)onTLSShutdown:(NSString*)host NS_SWIFT_NAME(onTLSShutdown(_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readwrite,assign,getter=blockedCertCount,setter=setBlockedCertCount:) int blockedCertCount NS_SWIFT_NAME(blockedCertCount);

- (int)blockedCertCount NS_SWIFT_NAME(blockedCertCount());
- (void)setBlockedCertCount :(int)newBlockedCertCount NS_SWIFT_NAME(setBlockedCertCount(_:));

- (NSData*)blockedCertBytes:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertBytes(_:));

- (BOOL)blockedCertCA:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertCA(_:));
- (void)setBlockedCertCA:(int)blockedCertIndex :(BOOL)newBlockedCertCA NS_SWIFT_NAME(setBlockedCertCA(_:_:));

- (NSData*)blockedCertCAKeyID:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertCAKeyID(_:));

- (int)blockedCertCertType:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertCertType(_:));

- (NSString*)blockedCertCRLDistributionPoints:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertCRLDistributionPoints(_:));
- (void)setBlockedCertCRLDistributionPoints:(int)blockedCertIndex :(NSString*)newBlockedCertCRLDistributionPoints NS_SWIFT_NAME(setBlockedCertCRLDistributionPoints(_:_:));

- (NSString*)blockedCertCurve:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertCurve(_:));
- (void)setBlockedCertCurve:(int)blockedCertIndex :(NSString*)newBlockedCertCurve NS_SWIFT_NAME(setBlockedCertCurve(_:_:));

- (NSString*)blockedCertFingerprint:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertFingerprint(_:));

- (NSString*)blockedCertFriendlyName:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertFriendlyName(_:));

- (long long)blockedCertHandle:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertHandle(_:));
- (void)setBlockedCertHandle:(int)blockedCertIndex :(long long)newBlockedCertHandle NS_SWIFT_NAME(setBlockedCertHandle(_:_:));

- (NSString*)blockedCertHashAlgorithm:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertHashAlgorithm(_:));
- (void)setBlockedCertHashAlgorithm:(int)blockedCertIndex :(NSString*)newBlockedCertHashAlgorithm NS_SWIFT_NAME(setBlockedCertHashAlgorithm(_:_:));

- (NSString*)blockedCertIssuer:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertIssuer(_:));

- (NSString*)blockedCertIssuerRDN:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertIssuerRDN(_:));
- (void)setBlockedCertIssuerRDN:(int)blockedCertIndex :(NSString*)newBlockedCertIssuerRDN NS_SWIFT_NAME(setBlockedCertIssuerRDN(_:_:));

- (NSString*)blockedCertKeyAlgorithm:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertKeyAlgorithm(_:));
- (void)setBlockedCertKeyAlgorithm:(int)blockedCertIndex :(NSString*)newBlockedCertKeyAlgorithm NS_SWIFT_NAME(setBlockedCertKeyAlgorithm(_:_:));

- (int)blockedCertKeyBits:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertKeyBits(_:));

- (NSString*)blockedCertKeyFingerprint:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertKeyFingerprint(_:));

- (int)blockedCertKeyUsage:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertKeyUsage(_:));
- (void)setBlockedCertKeyUsage:(int)blockedCertIndex :(int)newBlockedCertKeyUsage NS_SWIFT_NAME(setBlockedCertKeyUsage(_:_:));

- (BOOL)blockedCertKeyValid:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertKeyValid(_:));

- (NSString*)blockedCertOCSPLocations:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertOCSPLocations(_:));
- (void)setBlockedCertOCSPLocations:(int)blockedCertIndex :(NSString*)newBlockedCertOCSPLocations NS_SWIFT_NAME(setBlockedCertOCSPLocations(_:_:));

- (BOOL)blockedCertOCSPNoCheck:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertOCSPNoCheck(_:));
- (void)setBlockedCertOCSPNoCheck:(int)blockedCertIndex :(BOOL)newBlockedCertOCSPNoCheck NS_SWIFT_NAME(setBlockedCertOCSPNoCheck(_:_:));

- (int)blockedCertOrigin:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertOrigin(_:));

- (NSString*)blockedCertPolicyIDs:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertPolicyIDs(_:));
- (void)setBlockedCertPolicyIDs:(int)blockedCertIndex :(NSString*)newBlockedCertPolicyIDs NS_SWIFT_NAME(setBlockedCertPolicyIDs(_:_:));

- (NSData*)blockedCertPrivateKeyBytes:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertPrivateKeyBytes(_:));

- (BOOL)blockedCertPrivateKeyExists:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertPrivateKeyExists(_:));

- (BOOL)blockedCertPrivateKeyExtractable:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertPrivateKeyExtractable(_:));

- (NSData*)blockedCertPublicKeyBytes:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertPublicKeyBytes(_:));

- (BOOL)blockedCertQualified:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertQualified(_:));

- (int)blockedCertQualifiedStatements:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertQualifiedStatements(_:));
- (void)setBlockedCertQualifiedStatements:(int)blockedCertIndex :(int)newBlockedCertQualifiedStatements NS_SWIFT_NAME(setBlockedCertQualifiedStatements(_:_:));

- (NSString*)blockedCertQualifiers:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertQualifiers(_:));

- (BOOL)blockedCertSelfSigned:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSelfSigned(_:));

- (NSData*)blockedCertSerialNumber:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSerialNumber(_:));
- (void)setBlockedCertSerialNumber:(int)blockedCertIndex :(NSData*)newBlockedCertSerialNumber NS_SWIFT_NAME(setBlockedCertSerialNumber(_:_:));

- (NSString*)blockedCertSigAlgorithm:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSigAlgorithm(_:));

- (int)blockedCertSource:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSource(_:));

- (NSString*)blockedCertSubject:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSubject(_:));

- (NSString*)blockedCertSubjectAlternativeName:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSubjectAlternativeName(_:));
- (void)setBlockedCertSubjectAlternativeName:(int)blockedCertIndex :(NSString*)newBlockedCertSubjectAlternativeName NS_SWIFT_NAME(setBlockedCertSubjectAlternativeName(_:_:));

- (NSData*)blockedCertSubjectKeyID:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSubjectKeyID(_:));
- (void)setBlockedCertSubjectKeyID:(int)blockedCertIndex :(NSData*)newBlockedCertSubjectKeyID NS_SWIFT_NAME(setBlockedCertSubjectKeyID(_:_:));

- (NSString*)blockedCertSubjectRDN:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSubjectRDN(_:));
- (void)setBlockedCertSubjectRDN:(int)blockedCertIndex :(NSString*)newBlockedCertSubjectRDN NS_SWIFT_NAME(setBlockedCertSubjectRDN(_:_:));

- (BOOL)blockedCertValid:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertValid(_:));

- (NSString*)blockedCertValidFrom:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertValidFrom(_:));
- (void)setBlockedCertValidFrom:(int)blockedCertIndex :(NSString*)newBlockedCertValidFrom NS_SWIFT_NAME(setBlockedCertValidFrom(_:_:));

- (NSString*)blockedCertValidTo:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertValidTo(_:));
- (void)setBlockedCertValidTo:(int)blockedCertIndex :(NSString*)newBlockedCertValidTo NS_SWIFT_NAME(setBlockedCertValidTo(_:_:));

@property (nonatomic,readwrite,assign,getter=cacheValidationResults,setter=setCacheValidationResults:) BOOL cacheValidationResults NS_SWIFT_NAME(cacheValidationResults);

- (BOOL)cacheValidationResults NS_SWIFT_NAME(cacheValidationResults());
- (void)setCacheValidationResults :(BOOL)newCacheValidationResults NS_SWIFT_NAME(setCacheValidationResults(_:));

@property (nonatomic,readonly,assign,getter=certBytes) NSData* certBytes NS_SWIFT_NAME(certBytes);

- (NSData*)certBytes NS_SWIFT_NAME(certBytes());

@property (nonatomic,readwrite,assign,getter=certCA,setter=setCertCA:) BOOL certCA NS_SWIFT_NAME(certCA);

- (BOOL)certCA NS_SWIFT_NAME(certCA());
- (void)setCertCA :(BOOL)newCertCA NS_SWIFT_NAME(setCertCA(_:));

@property (nonatomic,readonly,assign,getter=certCAKeyID) NSData* certCAKeyID NS_SWIFT_NAME(certCAKeyID);

- (NSData*)certCAKeyID NS_SWIFT_NAME(certCAKeyID());

@property (nonatomic,readonly,assign,getter=certCertType) int certCertType NS_SWIFT_NAME(certCertType);

- (int)certCertType NS_SWIFT_NAME(certCertType());

@property (nonatomic,readwrite,assign,getter=certCRLDistributionPoints,setter=setCertCRLDistributionPoints:) NSString* certCRLDistributionPoints NS_SWIFT_NAME(certCRLDistributionPoints);

- (NSString*)certCRLDistributionPoints NS_SWIFT_NAME(certCRLDistributionPoints());
- (void)setCertCRLDistributionPoints :(NSString*)newCertCRLDistributionPoints NS_SWIFT_NAME(setCertCRLDistributionPoints(_:));

@property (nonatomic,readwrite,assign,getter=certCurve,setter=setCertCurve:) NSString* certCurve NS_SWIFT_NAME(certCurve);

- (NSString*)certCurve NS_SWIFT_NAME(certCurve());
- (void)setCertCurve :(NSString*)newCertCurve NS_SWIFT_NAME(setCertCurve(_:));

@property (nonatomic,readonly,assign,getter=certFingerprint) NSString* certFingerprint NS_SWIFT_NAME(certFingerprint);

- (NSString*)certFingerprint NS_SWIFT_NAME(certFingerprint());

@property (nonatomic,readonly,assign,getter=certFriendlyName) NSString* certFriendlyName NS_SWIFT_NAME(certFriendlyName);

- (NSString*)certFriendlyName NS_SWIFT_NAME(certFriendlyName());

@property (nonatomic,readwrite,assign,getter=certHandle,setter=setCertHandle:) long long certHandle NS_SWIFT_NAME(certHandle);

- (long long)certHandle NS_SWIFT_NAME(certHandle());
- (void)setCertHandle :(long long)newCertHandle NS_SWIFT_NAME(setCertHandle(_:));

@property (nonatomic,readwrite,assign,getter=certHashAlgorithm,setter=setCertHashAlgorithm:) NSString* certHashAlgorithm NS_SWIFT_NAME(certHashAlgorithm);

- (NSString*)certHashAlgorithm NS_SWIFT_NAME(certHashAlgorithm());
- (void)setCertHashAlgorithm :(NSString*)newCertHashAlgorithm NS_SWIFT_NAME(setCertHashAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=certIssuer) NSString* certIssuer NS_SWIFT_NAME(certIssuer);

- (NSString*)certIssuer NS_SWIFT_NAME(certIssuer());

@property (nonatomic,readwrite,assign,getter=certIssuerRDN,setter=setCertIssuerRDN:) NSString* certIssuerRDN NS_SWIFT_NAME(certIssuerRDN);

- (NSString*)certIssuerRDN NS_SWIFT_NAME(certIssuerRDN());
- (void)setCertIssuerRDN :(NSString*)newCertIssuerRDN NS_SWIFT_NAME(setCertIssuerRDN(_:));

@property (nonatomic,readwrite,assign,getter=certKeyAlgorithm,setter=setCertKeyAlgorithm:) NSString* certKeyAlgorithm NS_SWIFT_NAME(certKeyAlgorithm);

- (NSString*)certKeyAlgorithm NS_SWIFT_NAME(certKeyAlgorithm());
- (void)setCertKeyAlgorithm :(NSString*)newCertKeyAlgorithm NS_SWIFT_NAME(setCertKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=certKeyBits) int certKeyBits NS_SWIFT_NAME(certKeyBits);

- (int)certKeyBits NS_SWIFT_NAME(certKeyBits());

@property (nonatomic,readonly,assign,getter=certKeyFingerprint) NSString* certKeyFingerprint NS_SWIFT_NAME(certKeyFingerprint);

- (NSString*)certKeyFingerprint NS_SWIFT_NAME(certKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=certKeyUsage,setter=setCertKeyUsage:) int certKeyUsage NS_SWIFT_NAME(certKeyUsage);

- (int)certKeyUsage NS_SWIFT_NAME(certKeyUsage());
- (void)setCertKeyUsage :(int)newCertKeyUsage NS_SWIFT_NAME(setCertKeyUsage(_:));

@property (nonatomic,readonly,assign,getter=certKeyValid) BOOL certKeyValid NS_SWIFT_NAME(certKeyValid);

- (BOOL)certKeyValid NS_SWIFT_NAME(certKeyValid());

@property (nonatomic,readwrite,assign,getter=certOCSPLocations,setter=setCertOCSPLocations:) NSString* certOCSPLocations NS_SWIFT_NAME(certOCSPLocations);

- (NSString*)certOCSPLocations NS_SWIFT_NAME(certOCSPLocations());
- (void)setCertOCSPLocations :(NSString*)newCertOCSPLocations NS_SWIFT_NAME(setCertOCSPLocations(_:));

@property (nonatomic,readwrite,assign,getter=certOCSPNoCheck,setter=setCertOCSPNoCheck:) BOOL certOCSPNoCheck NS_SWIFT_NAME(certOCSPNoCheck);

- (BOOL)certOCSPNoCheck NS_SWIFT_NAME(certOCSPNoCheck());
- (void)setCertOCSPNoCheck :(BOOL)newCertOCSPNoCheck NS_SWIFT_NAME(setCertOCSPNoCheck(_:));

@property (nonatomic,readonly,assign,getter=certOrigin) int certOrigin NS_SWIFT_NAME(certOrigin);

- (int)certOrigin NS_SWIFT_NAME(certOrigin());

@property (nonatomic,readwrite,assign,getter=certPolicyIDs,setter=setCertPolicyIDs:) NSString* certPolicyIDs NS_SWIFT_NAME(certPolicyIDs);

- (NSString*)certPolicyIDs NS_SWIFT_NAME(certPolicyIDs());
- (void)setCertPolicyIDs :(NSString*)newCertPolicyIDs NS_SWIFT_NAME(setCertPolicyIDs(_:));

@property (nonatomic,readonly,assign,getter=certPrivateKeyBytes) NSData* certPrivateKeyBytes NS_SWIFT_NAME(certPrivateKeyBytes);

- (NSData*)certPrivateKeyBytes NS_SWIFT_NAME(certPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=certPrivateKeyExists) BOOL certPrivateKeyExists NS_SWIFT_NAME(certPrivateKeyExists);

- (BOOL)certPrivateKeyExists NS_SWIFT_NAME(certPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=certPrivateKeyExtractable) BOOL certPrivateKeyExtractable NS_SWIFT_NAME(certPrivateKeyExtractable);

- (BOOL)certPrivateKeyExtractable NS_SWIFT_NAME(certPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=certPublicKeyBytes) NSData* certPublicKeyBytes NS_SWIFT_NAME(certPublicKeyBytes);

- (NSData*)certPublicKeyBytes NS_SWIFT_NAME(certPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=certQualified) BOOL certQualified NS_SWIFT_NAME(certQualified);

- (BOOL)certQualified NS_SWIFT_NAME(certQualified());

@property (nonatomic,readwrite,assign,getter=certQualifiedStatements,setter=setCertQualifiedStatements:) int certQualifiedStatements NS_SWIFT_NAME(certQualifiedStatements);

- (int)certQualifiedStatements NS_SWIFT_NAME(certQualifiedStatements());
- (void)setCertQualifiedStatements :(int)newCertQualifiedStatements NS_SWIFT_NAME(setCertQualifiedStatements(_:));

@property (nonatomic,readonly,assign,getter=certQualifiers) NSString* certQualifiers NS_SWIFT_NAME(certQualifiers);

- (NSString*)certQualifiers NS_SWIFT_NAME(certQualifiers());

@property (nonatomic,readonly,assign,getter=certSelfSigned) BOOL certSelfSigned NS_SWIFT_NAME(certSelfSigned);

- (BOOL)certSelfSigned NS_SWIFT_NAME(certSelfSigned());

@property (nonatomic,readwrite,assign,getter=certSerialNumber,setter=setCertSerialNumber:) NSData* certSerialNumber NS_SWIFT_NAME(certSerialNumber);

- (NSData*)certSerialNumber NS_SWIFT_NAME(certSerialNumber());
- (void)setCertSerialNumber :(NSData*)newCertSerialNumber NS_SWIFT_NAME(setCertSerialNumber(_:));

@property (nonatomic,readonly,assign,getter=certSigAlgorithm) NSString* certSigAlgorithm NS_SWIFT_NAME(certSigAlgorithm);

- (NSString*)certSigAlgorithm NS_SWIFT_NAME(certSigAlgorithm());

@property (nonatomic,readonly,assign,getter=certSource) int certSource NS_SWIFT_NAME(certSource);

- (int)certSource NS_SWIFT_NAME(certSource());

@property (nonatomic,readonly,assign,getter=certSubject) NSString* certSubject NS_SWIFT_NAME(certSubject);

- (NSString*)certSubject NS_SWIFT_NAME(certSubject());

@property (nonatomic,readwrite,assign,getter=certSubjectAlternativeName,setter=setCertSubjectAlternativeName:) NSString* certSubjectAlternativeName NS_SWIFT_NAME(certSubjectAlternativeName);

- (NSString*)certSubjectAlternativeName NS_SWIFT_NAME(certSubjectAlternativeName());
- (void)setCertSubjectAlternativeName :(NSString*)newCertSubjectAlternativeName NS_SWIFT_NAME(setCertSubjectAlternativeName(_:));

@property (nonatomic,readwrite,assign,getter=certSubjectKeyID,setter=setCertSubjectKeyID:) NSData* certSubjectKeyID NS_SWIFT_NAME(certSubjectKeyID);

- (NSData*)certSubjectKeyID NS_SWIFT_NAME(certSubjectKeyID());
- (void)setCertSubjectKeyID :(NSData*)newCertSubjectKeyID NS_SWIFT_NAME(setCertSubjectKeyID(_:));

@property (nonatomic,readwrite,assign,getter=certSubjectRDN,setter=setCertSubjectRDN:) NSString* certSubjectRDN NS_SWIFT_NAME(certSubjectRDN);

- (NSString*)certSubjectRDN NS_SWIFT_NAME(certSubjectRDN());
- (void)setCertSubjectRDN :(NSString*)newCertSubjectRDN NS_SWIFT_NAME(setCertSubjectRDN(_:));

@property (nonatomic,readonly,assign,getter=certValid) BOOL certValid NS_SWIFT_NAME(certValid);

- (BOOL)certValid NS_SWIFT_NAME(certValid());

@property (nonatomic,readwrite,assign,getter=certValidFrom,setter=setCertValidFrom:) NSString* certValidFrom NS_SWIFT_NAME(certValidFrom);

- (NSString*)certValidFrom NS_SWIFT_NAME(certValidFrom());
- (void)setCertValidFrom :(NSString*)newCertValidFrom NS_SWIFT_NAME(setCertValidFrom(_:));

@property (nonatomic,readwrite,assign,getter=certValidTo,setter=setCertValidTo:) NSString* certValidTo NS_SWIFT_NAME(certValidTo);

- (NSString*)certValidTo NS_SWIFT_NAME(certValidTo());
- (void)setCertValidTo :(NSString*)newCertValidTo NS_SWIFT_NAME(setCertValidTo(_:));

@property (nonatomic,readonly,assign,getter=chainValidationDetails) int chainValidationDetails NS_SWIFT_NAME(chainValidationDetails);

- (int)chainValidationDetails NS_SWIFT_NAME(chainValidationDetails());

@property (nonatomic,readonly,assign,getter=chainValidationResult) int chainValidationResult NS_SWIFT_NAME(chainValidationResult);

- (int)chainValidationResult NS_SWIFT_NAME(chainValidationResult());

@property (nonatomic,readwrite,assign,getter=checkTrustedLists,setter=setCheckTrustedLists:) BOOL checkTrustedLists NS_SWIFT_NAME(checkTrustedLists);

- (BOOL)checkTrustedLists NS_SWIFT_NAME(checkTrustedLists());
- (void)setCheckTrustedLists :(BOOL)newCheckTrustedLists NS_SWIFT_NAME(setCheckTrustedLists(_:));

@property (nonatomic,readonly,assign,getter=currentCACertBytes) NSData* currentCACertBytes NS_SWIFT_NAME(currentCACertBytes);

- (NSData*)currentCACertBytes NS_SWIFT_NAME(currentCACertBytes());

@property (nonatomic,readonly,assign,getter=currentCACertCA) BOOL currentCACertCA NS_SWIFT_NAME(currentCACertCA);

- (BOOL)currentCACertCA NS_SWIFT_NAME(currentCACertCA());

@property (nonatomic,readonly,assign,getter=currentCACertCAKeyID) NSData* currentCACertCAKeyID NS_SWIFT_NAME(currentCACertCAKeyID);

- (NSData*)currentCACertCAKeyID NS_SWIFT_NAME(currentCACertCAKeyID());

@property (nonatomic,readonly,assign,getter=currentCACertCertType) int currentCACertCertType NS_SWIFT_NAME(currentCACertCertType);

- (int)currentCACertCertType NS_SWIFT_NAME(currentCACertCertType());

@property (nonatomic,readonly,assign,getter=currentCACertCRLDistributionPoints) NSString* currentCACertCRLDistributionPoints NS_SWIFT_NAME(currentCACertCRLDistributionPoints);

- (NSString*)currentCACertCRLDistributionPoints NS_SWIFT_NAME(currentCACertCRLDistributionPoints());

@property (nonatomic,readonly,assign,getter=currentCACertCurve) NSString* currentCACertCurve NS_SWIFT_NAME(currentCACertCurve);

- (NSString*)currentCACertCurve NS_SWIFT_NAME(currentCACertCurve());

@property (nonatomic,readonly,assign,getter=currentCACertFingerprint) NSString* currentCACertFingerprint NS_SWIFT_NAME(currentCACertFingerprint);

- (NSString*)currentCACertFingerprint NS_SWIFT_NAME(currentCACertFingerprint());

@property (nonatomic,readonly,assign,getter=currentCACertFriendlyName) NSString* currentCACertFriendlyName NS_SWIFT_NAME(currentCACertFriendlyName);

- (NSString*)currentCACertFriendlyName NS_SWIFT_NAME(currentCACertFriendlyName());

@property (nonatomic,readonly,assign,getter=currentCACertHandle) long long currentCACertHandle NS_SWIFT_NAME(currentCACertHandle);

- (long long)currentCACertHandle NS_SWIFT_NAME(currentCACertHandle());

@property (nonatomic,readonly,assign,getter=currentCACertHashAlgorithm) NSString* currentCACertHashAlgorithm NS_SWIFT_NAME(currentCACertHashAlgorithm);

- (NSString*)currentCACertHashAlgorithm NS_SWIFT_NAME(currentCACertHashAlgorithm());

@property (nonatomic,readonly,assign,getter=currentCACertIssuer) NSString* currentCACertIssuer NS_SWIFT_NAME(currentCACertIssuer);

- (NSString*)currentCACertIssuer NS_SWIFT_NAME(currentCACertIssuer());

@property (nonatomic,readonly,assign,getter=currentCACertIssuerRDN) NSString* currentCACertIssuerRDN NS_SWIFT_NAME(currentCACertIssuerRDN);

- (NSString*)currentCACertIssuerRDN NS_SWIFT_NAME(currentCACertIssuerRDN());

@property (nonatomic,readonly,assign,getter=currentCACertKeyAlgorithm) NSString* currentCACertKeyAlgorithm NS_SWIFT_NAME(currentCACertKeyAlgorithm);

- (NSString*)currentCACertKeyAlgorithm NS_SWIFT_NAME(currentCACertKeyAlgorithm());

@property (nonatomic,readonly,assign,getter=currentCACertKeyBits) int currentCACertKeyBits NS_SWIFT_NAME(currentCACertKeyBits);

- (int)currentCACertKeyBits NS_SWIFT_NAME(currentCACertKeyBits());

@property (nonatomic,readonly,assign,getter=currentCACertKeyFingerprint) NSString* currentCACertKeyFingerprint NS_SWIFT_NAME(currentCACertKeyFingerprint);

- (NSString*)currentCACertKeyFingerprint NS_SWIFT_NAME(currentCACertKeyFingerprint());

@property (nonatomic,readonly,assign,getter=currentCACertKeyUsage) int currentCACertKeyUsage NS_SWIFT_NAME(currentCACertKeyUsage);

- (int)currentCACertKeyUsage NS_SWIFT_NAME(currentCACertKeyUsage());

@property (nonatomic,readonly,assign,getter=currentCACertKeyValid) BOOL currentCACertKeyValid NS_SWIFT_NAME(currentCACertKeyValid);

- (BOOL)currentCACertKeyValid NS_SWIFT_NAME(currentCACertKeyValid());

@property (nonatomic,readonly,assign,getter=currentCACertOCSPLocations) NSString* currentCACertOCSPLocations NS_SWIFT_NAME(currentCACertOCSPLocations);

- (NSString*)currentCACertOCSPLocations NS_SWIFT_NAME(currentCACertOCSPLocations());

@property (nonatomic,readonly,assign,getter=currentCACertOCSPNoCheck) BOOL currentCACertOCSPNoCheck NS_SWIFT_NAME(currentCACertOCSPNoCheck);

- (BOOL)currentCACertOCSPNoCheck NS_SWIFT_NAME(currentCACertOCSPNoCheck());

@property (nonatomic,readonly,assign,getter=currentCACertOrigin) int currentCACertOrigin NS_SWIFT_NAME(currentCACertOrigin);

- (int)currentCACertOrigin NS_SWIFT_NAME(currentCACertOrigin());

@property (nonatomic,readonly,assign,getter=currentCACertPolicyIDs) NSString* currentCACertPolicyIDs NS_SWIFT_NAME(currentCACertPolicyIDs);

- (NSString*)currentCACertPolicyIDs NS_SWIFT_NAME(currentCACertPolicyIDs());

@property (nonatomic,readonly,assign,getter=currentCACertPrivateKeyBytes) NSData* currentCACertPrivateKeyBytes NS_SWIFT_NAME(currentCACertPrivateKeyBytes);

- (NSData*)currentCACertPrivateKeyBytes NS_SWIFT_NAME(currentCACertPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=currentCACertPrivateKeyExists) BOOL currentCACertPrivateKeyExists NS_SWIFT_NAME(currentCACertPrivateKeyExists);

- (BOOL)currentCACertPrivateKeyExists NS_SWIFT_NAME(currentCACertPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=currentCACertPrivateKeyExtractable) BOOL currentCACertPrivateKeyExtractable NS_SWIFT_NAME(currentCACertPrivateKeyExtractable);

- (BOOL)currentCACertPrivateKeyExtractable NS_SWIFT_NAME(currentCACertPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=currentCACertPublicKeyBytes) NSData* currentCACertPublicKeyBytes NS_SWIFT_NAME(currentCACertPublicKeyBytes);

- (NSData*)currentCACertPublicKeyBytes NS_SWIFT_NAME(currentCACertPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=currentCACertQualified) BOOL currentCACertQualified NS_SWIFT_NAME(currentCACertQualified);

- (BOOL)currentCACertQualified NS_SWIFT_NAME(currentCACertQualified());

@property (nonatomic,readonly,assign,getter=currentCACertQualifiedStatements) int currentCACertQualifiedStatements NS_SWIFT_NAME(currentCACertQualifiedStatements);

- (int)currentCACertQualifiedStatements NS_SWIFT_NAME(currentCACertQualifiedStatements());

@property (nonatomic,readonly,assign,getter=currentCACertQualifiers) NSString* currentCACertQualifiers NS_SWIFT_NAME(currentCACertQualifiers);

- (NSString*)currentCACertQualifiers NS_SWIFT_NAME(currentCACertQualifiers());

@property (nonatomic,readonly,assign,getter=currentCACertSelfSigned) BOOL currentCACertSelfSigned NS_SWIFT_NAME(currentCACertSelfSigned);

- (BOOL)currentCACertSelfSigned NS_SWIFT_NAME(currentCACertSelfSigned());

@property (nonatomic,readonly,assign,getter=currentCACertSerialNumber) NSData* currentCACertSerialNumber NS_SWIFT_NAME(currentCACertSerialNumber);

- (NSData*)currentCACertSerialNumber NS_SWIFT_NAME(currentCACertSerialNumber());

@property (nonatomic,readonly,assign,getter=currentCACertSigAlgorithm) NSString* currentCACertSigAlgorithm NS_SWIFT_NAME(currentCACertSigAlgorithm);

- (NSString*)currentCACertSigAlgorithm NS_SWIFT_NAME(currentCACertSigAlgorithm());

@property (nonatomic,readonly,assign,getter=currentCACertSource) int currentCACertSource NS_SWIFT_NAME(currentCACertSource);

- (int)currentCACertSource NS_SWIFT_NAME(currentCACertSource());

@property (nonatomic,readonly,assign,getter=currentCACertSubject) NSString* currentCACertSubject NS_SWIFT_NAME(currentCACertSubject);

- (NSString*)currentCACertSubject NS_SWIFT_NAME(currentCACertSubject());

@property (nonatomic,readonly,assign,getter=currentCACertSubjectAlternativeName) NSString* currentCACertSubjectAlternativeName NS_SWIFT_NAME(currentCACertSubjectAlternativeName);

- (NSString*)currentCACertSubjectAlternativeName NS_SWIFT_NAME(currentCACertSubjectAlternativeName());

@property (nonatomic,readonly,assign,getter=currentCACertSubjectKeyID) NSData* currentCACertSubjectKeyID NS_SWIFT_NAME(currentCACertSubjectKeyID);

- (NSData*)currentCACertSubjectKeyID NS_SWIFT_NAME(currentCACertSubjectKeyID());

@property (nonatomic,readonly,assign,getter=currentCACertSubjectRDN) NSString* currentCACertSubjectRDN NS_SWIFT_NAME(currentCACertSubjectRDN);

- (NSString*)currentCACertSubjectRDN NS_SWIFT_NAME(currentCACertSubjectRDN());

@property (nonatomic,readonly,assign,getter=currentCACertValid) BOOL currentCACertValid NS_SWIFT_NAME(currentCACertValid);

- (BOOL)currentCACertValid NS_SWIFT_NAME(currentCACertValid());

@property (nonatomic,readonly,assign,getter=currentCACertValidFrom) NSString* currentCACertValidFrom NS_SWIFT_NAME(currentCACertValidFrom);

- (NSString*)currentCACertValidFrom NS_SWIFT_NAME(currentCACertValidFrom());

@property (nonatomic,readonly,assign,getter=currentCACertValidTo) NSString* currentCACertValidTo NS_SWIFT_NAME(currentCACertValidTo);

- (NSString*)currentCACertValidTo NS_SWIFT_NAME(currentCACertValidTo());

@property (nonatomic,readonly,assign,getter=currentCertBytes) NSData* currentCertBytes NS_SWIFT_NAME(currentCertBytes);

- (NSData*)currentCertBytes NS_SWIFT_NAME(currentCertBytes());

@property (nonatomic,readonly,assign,getter=currentCertCA) BOOL currentCertCA NS_SWIFT_NAME(currentCertCA);

- (BOOL)currentCertCA NS_SWIFT_NAME(currentCertCA());

@property (nonatomic,readonly,assign,getter=currentCertCAKeyID) NSData* currentCertCAKeyID NS_SWIFT_NAME(currentCertCAKeyID);

- (NSData*)currentCertCAKeyID NS_SWIFT_NAME(currentCertCAKeyID());

@property (nonatomic,readonly,assign,getter=currentCertCertType) int currentCertCertType NS_SWIFT_NAME(currentCertCertType);

- (int)currentCertCertType NS_SWIFT_NAME(currentCertCertType());

@property (nonatomic,readonly,assign,getter=currentCertCRLDistributionPoints) NSString* currentCertCRLDistributionPoints NS_SWIFT_NAME(currentCertCRLDistributionPoints);

- (NSString*)currentCertCRLDistributionPoints NS_SWIFT_NAME(currentCertCRLDistributionPoints());

@property (nonatomic,readonly,assign,getter=currentCertCurve) NSString* currentCertCurve NS_SWIFT_NAME(currentCertCurve);

- (NSString*)currentCertCurve NS_SWIFT_NAME(currentCertCurve());

@property (nonatomic,readonly,assign,getter=currentCertFingerprint) NSString* currentCertFingerprint NS_SWIFT_NAME(currentCertFingerprint);

- (NSString*)currentCertFingerprint NS_SWIFT_NAME(currentCertFingerprint());

@property (nonatomic,readonly,assign,getter=currentCertFriendlyName) NSString* currentCertFriendlyName NS_SWIFT_NAME(currentCertFriendlyName);

- (NSString*)currentCertFriendlyName NS_SWIFT_NAME(currentCertFriendlyName());

@property (nonatomic,readonly,assign,getter=currentCertHandle) long long currentCertHandle NS_SWIFT_NAME(currentCertHandle);

- (long long)currentCertHandle NS_SWIFT_NAME(currentCertHandle());

@property (nonatomic,readonly,assign,getter=currentCertHashAlgorithm) NSString* currentCertHashAlgorithm NS_SWIFT_NAME(currentCertHashAlgorithm);

- (NSString*)currentCertHashAlgorithm NS_SWIFT_NAME(currentCertHashAlgorithm());

@property (nonatomic,readonly,assign,getter=currentCertIssuer) NSString* currentCertIssuer NS_SWIFT_NAME(currentCertIssuer);

- (NSString*)currentCertIssuer NS_SWIFT_NAME(currentCertIssuer());

@property (nonatomic,readonly,assign,getter=currentCertIssuerRDN) NSString* currentCertIssuerRDN NS_SWIFT_NAME(currentCertIssuerRDN);

- (NSString*)currentCertIssuerRDN NS_SWIFT_NAME(currentCertIssuerRDN());

@property (nonatomic,readonly,assign,getter=currentCertKeyAlgorithm) NSString* currentCertKeyAlgorithm NS_SWIFT_NAME(currentCertKeyAlgorithm);

- (NSString*)currentCertKeyAlgorithm NS_SWIFT_NAME(currentCertKeyAlgorithm());

@property (nonatomic,readonly,assign,getter=currentCertKeyBits) int currentCertKeyBits NS_SWIFT_NAME(currentCertKeyBits);

- (int)currentCertKeyBits NS_SWIFT_NAME(currentCertKeyBits());

@property (nonatomic,readonly,assign,getter=currentCertKeyFingerprint) NSString* currentCertKeyFingerprint NS_SWIFT_NAME(currentCertKeyFingerprint);

- (NSString*)currentCertKeyFingerprint NS_SWIFT_NAME(currentCertKeyFingerprint());

@property (nonatomic,readonly,assign,getter=currentCertKeyUsage) int currentCertKeyUsage NS_SWIFT_NAME(currentCertKeyUsage);

- (int)currentCertKeyUsage NS_SWIFT_NAME(currentCertKeyUsage());

@property (nonatomic,readonly,assign,getter=currentCertKeyValid) BOOL currentCertKeyValid NS_SWIFT_NAME(currentCertKeyValid);

- (BOOL)currentCertKeyValid NS_SWIFT_NAME(currentCertKeyValid());

@property (nonatomic,readonly,assign,getter=currentCertOCSPLocations) NSString* currentCertOCSPLocations NS_SWIFT_NAME(currentCertOCSPLocations);

- (NSString*)currentCertOCSPLocations NS_SWIFT_NAME(currentCertOCSPLocations());

@property (nonatomic,readonly,assign,getter=currentCertOCSPNoCheck) BOOL currentCertOCSPNoCheck NS_SWIFT_NAME(currentCertOCSPNoCheck);

- (BOOL)currentCertOCSPNoCheck NS_SWIFT_NAME(currentCertOCSPNoCheck());

@property (nonatomic,readonly,assign,getter=currentCertOrigin) int currentCertOrigin NS_SWIFT_NAME(currentCertOrigin);

- (int)currentCertOrigin NS_SWIFT_NAME(currentCertOrigin());

@property (nonatomic,readonly,assign,getter=currentCertPolicyIDs) NSString* currentCertPolicyIDs NS_SWIFT_NAME(currentCertPolicyIDs);

- (NSString*)currentCertPolicyIDs NS_SWIFT_NAME(currentCertPolicyIDs());

@property (nonatomic,readonly,assign,getter=currentCertPrivateKeyBytes) NSData* currentCertPrivateKeyBytes NS_SWIFT_NAME(currentCertPrivateKeyBytes);

- (NSData*)currentCertPrivateKeyBytes NS_SWIFT_NAME(currentCertPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=currentCertPrivateKeyExists) BOOL currentCertPrivateKeyExists NS_SWIFT_NAME(currentCertPrivateKeyExists);

- (BOOL)currentCertPrivateKeyExists NS_SWIFT_NAME(currentCertPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=currentCertPrivateKeyExtractable) BOOL currentCertPrivateKeyExtractable NS_SWIFT_NAME(currentCertPrivateKeyExtractable);

- (BOOL)currentCertPrivateKeyExtractable NS_SWIFT_NAME(currentCertPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=currentCertPublicKeyBytes) NSData* currentCertPublicKeyBytes NS_SWIFT_NAME(currentCertPublicKeyBytes);

- (NSData*)currentCertPublicKeyBytes NS_SWIFT_NAME(currentCertPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=currentCertQualified) BOOL currentCertQualified NS_SWIFT_NAME(currentCertQualified);

- (BOOL)currentCertQualified NS_SWIFT_NAME(currentCertQualified());

@property (nonatomic,readonly,assign,getter=currentCertQualifiedStatements) int currentCertQualifiedStatements NS_SWIFT_NAME(currentCertQualifiedStatements);

- (int)currentCertQualifiedStatements NS_SWIFT_NAME(currentCertQualifiedStatements());

@property (nonatomic,readonly,assign,getter=currentCertQualifiers) NSString* currentCertQualifiers NS_SWIFT_NAME(currentCertQualifiers);

- (NSString*)currentCertQualifiers NS_SWIFT_NAME(currentCertQualifiers());

@property (nonatomic,readonly,assign,getter=currentCertSelfSigned) BOOL currentCertSelfSigned NS_SWIFT_NAME(currentCertSelfSigned);

- (BOOL)currentCertSelfSigned NS_SWIFT_NAME(currentCertSelfSigned());

@property (nonatomic,readonly,assign,getter=currentCertSerialNumber) NSData* currentCertSerialNumber NS_SWIFT_NAME(currentCertSerialNumber);

- (NSData*)currentCertSerialNumber NS_SWIFT_NAME(currentCertSerialNumber());

@property (nonatomic,readonly,assign,getter=currentCertSigAlgorithm) NSString* currentCertSigAlgorithm NS_SWIFT_NAME(currentCertSigAlgorithm);

- (NSString*)currentCertSigAlgorithm NS_SWIFT_NAME(currentCertSigAlgorithm());

@property (nonatomic,readonly,assign,getter=currentCertSource) int currentCertSource NS_SWIFT_NAME(currentCertSource);

- (int)currentCertSource NS_SWIFT_NAME(currentCertSource());

@property (nonatomic,readonly,assign,getter=currentCertSubject) NSString* currentCertSubject NS_SWIFT_NAME(currentCertSubject);

- (NSString*)currentCertSubject NS_SWIFT_NAME(currentCertSubject());

@property (nonatomic,readonly,assign,getter=currentCertSubjectAlternativeName) NSString* currentCertSubjectAlternativeName NS_SWIFT_NAME(currentCertSubjectAlternativeName);

- (NSString*)currentCertSubjectAlternativeName NS_SWIFT_NAME(currentCertSubjectAlternativeName());

@property (nonatomic,readonly,assign,getter=currentCertSubjectKeyID) NSData* currentCertSubjectKeyID NS_SWIFT_NAME(currentCertSubjectKeyID);

- (NSData*)currentCertSubjectKeyID NS_SWIFT_NAME(currentCertSubjectKeyID());

@property (nonatomic,readonly,assign,getter=currentCertSubjectRDN) NSString* currentCertSubjectRDN NS_SWIFT_NAME(currentCertSubjectRDN);

- (NSString*)currentCertSubjectRDN NS_SWIFT_NAME(currentCertSubjectRDN());

@property (nonatomic,readonly,assign,getter=currentCertValid) BOOL currentCertValid NS_SWIFT_NAME(currentCertValid);

- (BOOL)currentCertValid NS_SWIFT_NAME(currentCertValid());

@property (nonatomic,readonly,assign,getter=currentCertValidFrom) NSString* currentCertValidFrom NS_SWIFT_NAME(currentCertValidFrom);

- (NSString*)currentCertValidFrom NS_SWIFT_NAME(currentCertValidFrom());

@property (nonatomic,readonly,assign,getter=currentCertValidTo) NSString* currentCertValidTo NS_SWIFT_NAME(currentCertValidTo);

- (NSString*)currentCertValidTo NS_SWIFT_NAME(currentCertValidTo());

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=gracePeriod,setter=setGracePeriod:) int gracePeriod NS_SWIFT_NAME(gracePeriod);

- (int)gracePeriod NS_SWIFT_NAME(gracePeriod());
- (void)setGracePeriod :(int)newGracePeriod NS_SWIFT_NAME(setGracePeriod(_:));

@property (nonatomic,readwrite,assign,getter=interimValidationDetails,setter=setInterimValidationDetails:) int interimValidationDetails NS_SWIFT_NAME(interimValidationDetails);

- (int)interimValidationDetails NS_SWIFT_NAME(interimValidationDetails());
- (void)setInterimValidationDetails :(int)newInterimValidationDetails NS_SWIFT_NAME(setInterimValidationDetails(_:));

@property (nonatomic,readwrite,assign,getter=interimValidationResult,setter=setInterimValidationResult:) int interimValidationResult NS_SWIFT_NAME(interimValidationResult);

- (int)interimValidationResult NS_SWIFT_NAME(interimValidationResult());
- (void)setInterimValidationResult :(int)newInterimValidationResult NS_SWIFT_NAME(setInterimValidationResult(_:));

@property (nonatomic,readwrite,assign,getter=knownCertCount,setter=setKnownCertCount:) int knownCertCount NS_SWIFT_NAME(knownCertCount);

- (int)knownCertCount NS_SWIFT_NAME(knownCertCount());
- (void)setKnownCertCount :(int)newKnownCertCount NS_SWIFT_NAME(setKnownCertCount(_:));

- (NSData*)knownCertBytes:(int)knownCertIndex NS_SWIFT_NAME(knownCertBytes(_:));

- (BOOL)knownCertCA:(int)knownCertIndex NS_SWIFT_NAME(knownCertCA(_:));
- (void)setKnownCertCA:(int)knownCertIndex :(BOOL)newKnownCertCA NS_SWIFT_NAME(setKnownCertCA(_:_:));

- (NSData*)knownCertCAKeyID:(int)knownCertIndex NS_SWIFT_NAME(knownCertCAKeyID(_:));

- (int)knownCertCertType:(int)knownCertIndex NS_SWIFT_NAME(knownCertCertType(_:));

- (NSString*)knownCertCRLDistributionPoints:(int)knownCertIndex NS_SWIFT_NAME(knownCertCRLDistributionPoints(_:));
- (void)setKnownCertCRLDistributionPoints:(int)knownCertIndex :(NSString*)newKnownCertCRLDistributionPoints NS_SWIFT_NAME(setKnownCertCRLDistributionPoints(_:_:));

- (NSString*)knownCertCurve:(int)knownCertIndex NS_SWIFT_NAME(knownCertCurve(_:));
- (void)setKnownCertCurve:(int)knownCertIndex :(NSString*)newKnownCertCurve NS_SWIFT_NAME(setKnownCertCurve(_:_:));

- (NSString*)knownCertFingerprint:(int)knownCertIndex NS_SWIFT_NAME(knownCertFingerprint(_:));

- (NSString*)knownCertFriendlyName:(int)knownCertIndex NS_SWIFT_NAME(knownCertFriendlyName(_:));

- (long long)knownCertHandle:(int)knownCertIndex NS_SWIFT_NAME(knownCertHandle(_:));
- (void)setKnownCertHandle:(int)knownCertIndex :(long long)newKnownCertHandle NS_SWIFT_NAME(setKnownCertHandle(_:_:));

- (NSString*)knownCertHashAlgorithm:(int)knownCertIndex NS_SWIFT_NAME(knownCertHashAlgorithm(_:));
- (void)setKnownCertHashAlgorithm:(int)knownCertIndex :(NSString*)newKnownCertHashAlgorithm NS_SWIFT_NAME(setKnownCertHashAlgorithm(_:_:));

- (NSString*)knownCertIssuer:(int)knownCertIndex NS_SWIFT_NAME(knownCertIssuer(_:));

- (NSString*)knownCertIssuerRDN:(int)knownCertIndex NS_SWIFT_NAME(knownCertIssuerRDN(_:));
- (void)setKnownCertIssuerRDN:(int)knownCertIndex :(NSString*)newKnownCertIssuerRDN NS_SWIFT_NAME(setKnownCertIssuerRDN(_:_:));

- (NSString*)knownCertKeyAlgorithm:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyAlgorithm(_:));
- (void)setKnownCertKeyAlgorithm:(int)knownCertIndex :(NSString*)newKnownCertKeyAlgorithm NS_SWIFT_NAME(setKnownCertKeyAlgorithm(_:_:));

- (int)knownCertKeyBits:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyBits(_:));

- (NSString*)knownCertKeyFingerprint:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyFingerprint(_:));

- (int)knownCertKeyUsage:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyUsage(_:));
- (void)setKnownCertKeyUsage:(int)knownCertIndex :(int)newKnownCertKeyUsage NS_SWIFT_NAME(setKnownCertKeyUsage(_:_:));

- (BOOL)knownCertKeyValid:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyValid(_:));

- (NSString*)knownCertOCSPLocations:(int)knownCertIndex NS_SWIFT_NAME(knownCertOCSPLocations(_:));
- (void)setKnownCertOCSPLocations:(int)knownCertIndex :(NSString*)newKnownCertOCSPLocations NS_SWIFT_NAME(setKnownCertOCSPLocations(_:_:));

- (BOOL)knownCertOCSPNoCheck:(int)knownCertIndex NS_SWIFT_NAME(knownCertOCSPNoCheck(_:));
- (void)setKnownCertOCSPNoCheck:(int)knownCertIndex :(BOOL)newKnownCertOCSPNoCheck NS_SWIFT_NAME(setKnownCertOCSPNoCheck(_:_:));

- (int)knownCertOrigin:(int)knownCertIndex NS_SWIFT_NAME(knownCertOrigin(_:));

- (NSString*)knownCertPolicyIDs:(int)knownCertIndex NS_SWIFT_NAME(knownCertPolicyIDs(_:));
- (void)setKnownCertPolicyIDs:(int)knownCertIndex :(NSString*)newKnownCertPolicyIDs NS_SWIFT_NAME(setKnownCertPolicyIDs(_:_:));

- (NSData*)knownCertPrivateKeyBytes:(int)knownCertIndex NS_SWIFT_NAME(knownCertPrivateKeyBytes(_:));

- (BOOL)knownCertPrivateKeyExists:(int)knownCertIndex NS_SWIFT_NAME(knownCertPrivateKeyExists(_:));

- (BOOL)knownCertPrivateKeyExtractable:(int)knownCertIndex NS_SWIFT_NAME(knownCertPrivateKeyExtractable(_:));

- (NSData*)knownCertPublicKeyBytes:(int)knownCertIndex NS_SWIFT_NAME(knownCertPublicKeyBytes(_:));

- (BOOL)knownCertQualified:(int)knownCertIndex NS_SWIFT_NAME(knownCertQualified(_:));

- (int)knownCertQualifiedStatements:(int)knownCertIndex NS_SWIFT_NAME(knownCertQualifiedStatements(_:));
- (void)setKnownCertQualifiedStatements:(int)knownCertIndex :(int)newKnownCertQualifiedStatements NS_SWIFT_NAME(setKnownCertQualifiedStatements(_:_:));

- (NSString*)knownCertQualifiers:(int)knownCertIndex NS_SWIFT_NAME(knownCertQualifiers(_:));

- (BOOL)knownCertSelfSigned:(int)knownCertIndex NS_SWIFT_NAME(knownCertSelfSigned(_:));

- (NSData*)knownCertSerialNumber:(int)knownCertIndex NS_SWIFT_NAME(knownCertSerialNumber(_:));
- (void)setKnownCertSerialNumber:(int)knownCertIndex :(NSData*)newKnownCertSerialNumber NS_SWIFT_NAME(setKnownCertSerialNumber(_:_:));

- (NSString*)knownCertSigAlgorithm:(int)knownCertIndex NS_SWIFT_NAME(knownCertSigAlgorithm(_:));

- (int)knownCertSource:(int)knownCertIndex NS_SWIFT_NAME(knownCertSource(_:));

- (NSString*)knownCertSubject:(int)knownCertIndex NS_SWIFT_NAME(knownCertSubject(_:));

- (NSString*)knownCertSubjectAlternativeName:(int)knownCertIndex NS_SWIFT_NAME(knownCertSubjectAlternativeName(_:));
- (void)setKnownCertSubjectAlternativeName:(int)knownCertIndex :(NSString*)newKnownCertSubjectAlternativeName NS_SWIFT_NAME(setKnownCertSubjectAlternativeName(_:_:));

- (NSData*)knownCertSubjectKeyID:(int)knownCertIndex NS_SWIFT_NAME(knownCertSubjectKeyID(_:));
- (void)setKnownCertSubjectKeyID:(int)knownCertIndex :(NSData*)newKnownCertSubjectKeyID NS_SWIFT_NAME(setKnownCertSubjectKeyID(_:_:));

- (NSString*)knownCertSubjectRDN:(int)knownCertIndex NS_SWIFT_NAME(knownCertSubjectRDN(_:));
- (void)setKnownCertSubjectRDN:(int)knownCertIndex :(NSString*)newKnownCertSubjectRDN NS_SWIFT_NAME(setKnownCertSubjectRDN(_:_:));

- (BOOL)knownCertValid:(int)knownCertIndex NS_SWIFT_NAME(knownCertValid(_:));

- (NSString*)knownCertValidFrom:(int)knownCertIndex NS_SWIFT_NAME(knownCertValidFrom(_:));
- (void)setKnownCertValidFrom:(int)knownCertIndex :(NSString*)newKnownCertValidFrom NS_SWIFT_NAME(setKnownCertValidFrom(_:_:));

- (NSString*)knownCertValidTo:(int)knownCertIndex NS_SWIFT_NAME(knownCertValidTo(_:));
- (void)setKnownCertValidTo:(int)knownCertIndex :(NSString*)newKnownCertValidTo NS_SWIFT_NAME(setKnownCertValidTo(_:_:));

@property (nonatomic,readwrite,assign,getter=knownCRLCount,setter=setKnownCRLCount:) int knownCRLCount NS_SWIFT_NAME(knownCRLCount);

- (int)knownCRLCount NS_SWIFT_NAME(knownCRLCount());
- (void)setKnownCRLCount :(int)newKnownCRLCount NS_SWIFT_NAME(setKnownCRLCount(_:));

- (NSData*)knownCRLBytes:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLBytes(_:));

- (NSData*)knownCRLCAKeyID:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLCAKeyID(_:));
- (void)setKnownCRLCAKeyID:(int)knownCRLIndex :(NSData*)newKnownCRLCAKeyID NS_SWIFT_NAME(setKnownCRLCAKeyID(_:_:));

- (int)knownCRLEntryCount:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLEntryCount(_:));

- (long long)knownCRLHandle:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLHandle(_:));
- (void)setKnownCRLHandle:(int)knownCRLIndex :(long long)newKnownCRLHandle NS_SWIFT_NAME(setKnownCRLHandle(_:_:));

- (NSString*)knownCRLIssuer:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLIssuer(_:));

- (NSString*)knownCRLIssuerRDN:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLIssuerRDN(_:));

- (NSString*)knownCRLLocation:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLLocation(_:));

- (NSString*)knownCRLNextUpdate:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLNextUpdate(_:));
- (void)setKnownCRLNextUpdate:(int)knownCRLIndex :(NSString*)newKnownCRLNextUpdate NS_SWIFT_NAME(setKnownCRLNextUpdate(_:_:));

- (NSString*)knownCRLSigAlgorithm:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLSigAlgorithm(_:));
- (void)setKnownCRLSigAlgorithm:(int)knownCRLIndex :(NSString*)newKnownCRLSigAlgorithm NS_SWIFT_NAME(setKnownCRLSigAlgorithm(_:_:));

- (int)knownCRLSource:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLSource(_:));

- (NSData*)knownCRLTBS:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLTBS(_:));

- (NSString*)knownCRLThisUpdate:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLThisUpdate(_:));
- (void)setKnownCRLThisUpdate:(int)knownCRLIndex :(NSString*)newKnownCRLThisUpdate NS_SWIFT_NAME(setKnownCRLThisUpdate(_:_:));

@property (nonatomic,readwrite,assign,getter=knownOCSPCount,setter=setKnownOCSPCount:) int knownOCSPCount NS_SWIFT_NAME(knownOCSPCount);

- (int)knownOCSPCount NS_SWIFT_NAME(knownOCSPCount());
- (void)setKnownOCSPCount :(int)newKnownOCSPCount NS_SWIFT_NAME(setKnownOCSPCount(_:));

- (NSData*)knownOCSPBytes:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPBytes(_:));

- (int)knownOCSPEntryCount:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPEntryCount(_:));

- (long long)knownOCSPHandle:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPHandle(_:));
- (void)setKnownOCSPHandle:(int)knownOCSPIndex :(long long)newKnownOCSPHandle NS_SWIFT_NAME(setKnownOCSPHandle(_:_:));

- (NSString*)knownOCSPIssuer:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPIssuer(_:));

- (NSString*)knownOCSPIssuerRDN:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPIssuerRDN(_:));

- (NSString*)knownOCSPLocation:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPLocation(_:));

- (NSString*)knownOCSPProducedAt:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPProducedAt(_:));
- (void)setKnownOCSPProducedAt:(int)knownOCSPIndex :(NSString*)newKnownOCSPProducedAt NS_SWIFT_NAME(setKnownOCSPProducedAt(_:_:));

- (NSString*)knownOCSPSigAlgorithm:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPSigAlgorithm(_:));
- (void)setKnownOCSPSigAlgorithm:(int)knownOCSPIndex :(NSString*)newKnownOCSPSigAlgorithm NS_SWIFT_NAME(setKnownOCSPSigAlgorithm(_:_:));

- (int)knownOCSPSource:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPSource(_:));

@property (nonatomic,readwrite,assign,getter=maxValidationTime,setter=setMaxValidationTime:) int maxValidationTime NS_SWIFT_NAME(maxValidationTime);

- (int)maxValidationTime NS_SWIFT_NAME(maxValidationTime());
- (void)setMaxValidationTime :(int)newMaxValidationTime NS_SWIFT_NAME(setMaxValidationTime(_:));

@property (nonatomic,readwrite,assign,getter=offlineMode,setter=setOfflineMode:) BOOL offlineMode NS_SWIFT_NAME(offlineMode);

- (BOOL)offlineMode NS_SWIFT_NAME(offlineMode());
- (void)setOfflineMode :(BOOL)newOfflineMode NS_SWIFT_NAME(setOfflineMode(_:));

@property (nonatomic,readwrite,assign,getter=proxyAddress,setter=setProxyAddress:) NSString* proxyAddress NS_SWIFT_NAME(proxyAddress);

- (NSString*)proxyAddress NS_SWIFT_NAME(proxyAddress());
- (void)setProxyAddress :(NSString*)newProxyAddress NS_SWIFT_NAME(setProxyAddress(_:));

@property (nonatomic,readwrite,assign,getter=proxyAuthentication,setter=setProxyAuthentication:) int proxyAuthentication NS_SWIFT_NAME(proxyAuthentication);

- (int)proxyAuthentication NS_SWIFT_NAME(proxyAuthentication());
- (void)setProxyAuthentication :(int)newProxyAuthentication NS_SWIFT_NAME(setProxyAuthentication(_:));

@property (nonatomic,readwrite,assign,getter=proxyPassword,setter=setProxyPassword:) NSString* proxyPassword NS_SWIFT_NAME(proxyPassword);

- (NSString*)proxyPassword NS_SWIFT_NAME(proxyPassword());
- (void)setProxyPassword :(NSString*)newProxyPassword NS_SWIFT_NAME(setProxyPassword(_:));

@property (nonatomic,readwrite,assign,getter=proxyPort,setter=setProxyPort:) int proxyPort NS_SWIFT_NAME(proxyPort);

- (int)proxyPort NS_SWIFT_NAME(proxyPort());
- (void)setProxyPort :(int)newProxyPort NS_SWIFT_NAME(setProxyPort(_:));

@property (nonatomic,readwrite,assign,getter=proxyProxyType,setter=setProxyProxyType:) int proxyProxyType NS_SWIFT_NAME(proxyProxyType);

- (int)proxyProxyType NS_SWIFT_NAME(proxyProxyType());
- (void)setProxyProxyType :(int)newProxyProxyType NS_SWIFT_NAME(setProxyProxyType(_:));

@property (nonatomic,readwrite,assign,getter=proxyRequestHeaders,setter=setProxyRequestHeaders:) NSString* proxyRequestHeaders NS_SWIFT_NAME(proxyRequestHeaders);

- (NSString*)proxyRequestHeaders NS_SWIFT_NAME(proxyRequestHeaders());
- (void)setProxyRequestHeaders :(NSString*)newProxyRequestHeaders NS_SWIFT_NAME(setProxyRequestHeaders(_:));

@property (nonatomic,readwrite,assign,getter=proxyResponseBody,setter=setProxyResponseBody:) NSString* proxyResponseBody NS_SWIFT_NAME(proxyResponseBody);

- (NSString*)proxyResponseBody NS_SWIFT_NAME(proxyResponseBody());
- (void)setProxyResponseBody :(NSString*)newProxyResponseBody NS_SWIFT_NAME(setProxyResponseBody(_:));

@property (nonatomic,readwrite,assign,getter=proxyResponseHeaders,setter=setProxyResponseHeaders:) NSString* proxyResponseHeaders NS_SWIFT_NAME(proxyResponseHeaders);

- (NSString*)proxyResponseHeaders NS_SWIFT_NAME(proxyResponseHeaders());
- (void)setProxyResponseHeaders :(NSString*)newProxyResponseHeaders NS_SWIFT_NAME(setProxyResponseHeaders(_:));

@property (nonatomic,readwrite,assign,getter=proxyUseIPv6,setter=setProxyUseIPv6:) BOOL proxyUseIPv6 NS_SWIFT_NAME(proxyUseIPv6);

- (BOOL)proxyUseIPv6 NS_SWIFT_NAME(proxyUseIPv6());
- (void)setProxyUseIPv6 :(BOOL)newProxyUseIPv6 NS_SWIFT_NAME(setProxyUseIPv6(_:));

@property (nonatomic,readwrite,assign,getter=proxyUsername,setter=setProxyUsername:) NSString* proxyUsername NS_SWIFT_NAME(proxyUsername);

- (NSString*)proxyUsername NS_SWIFT_NAME(proxyUsername());
- (void)setProxyUsername :(NSString*)newProxyUsername NS_SWIFT_NAME(setProxyUsername(_:));

@property (nonatomic,readonly,assign,getter=qualifiedInfoAddress) NSString* qualifiedInfoAddress NS_SWIFT_NAME(qualifiedInfoAddress);

- (NSString*)qualifiedInfoAddress NS_SWIFT_NAME(qualifiedInfoAddress());

@property (nonatomic,readwrite,assign,getter=qualifiedInfoCustomTrustedLists,setter=setQualifiedInfoCustomTrustedLists:) NSString* qualifiedInfoCustomTrustedLists NS_SWIFT_NAME(qualifiedInfoCustomTrustedLists);

- (NSString*)qualifiedInfoCustomTrustedLists NS_SWIFT_NAME(qualifiedInfoCustomTrustedLists());
- (void)setQualifiedInfoCustomTrustedLists :(NSString*)newQualifiedInfoCustomTrustedLists NS_SWIFT_NAME(setQualifiedInfoCustomTrustedLists(_:));

@property (nonatomic,readonly,assign,getter=qualifiedInfoDownloadLog) NSString* qualifiedInfoDownloadLog NS_SWIFT_NAME(qualifiedInfoDownloadLog);

- (NSString*)qualifiedInfoDownloadLog NS_SWIFT_NAME(qualifiedInfoDownloadLog());

@property (nonatomic,readonly,assign,getter=qualifiedInfoInformationURI) NSString* qualifiedInfoInformationURI NS_SWIFT_NAME(qualifiedInfoInformationURI);

- (NSString*)qualifiedInfoInformationURI NS_SWIFT_NAME(qualifiedInfoInformationURI());

@property (nonatomic,readwrite,assign,getter=qualifiedInfoLanguages,setter=setQualifiedInfoLanguages:) NSString* qualifiedInfoLanguages NS_SWIFT_NAME(qualifiedInfoLanguages);

- (NSString*)qualifiedInfoLanguages NS_SWIFT_NAME(qualifiedInfoLanguages());
- (void)setQualifiedInfoLanguages :(NSString*)newQualifiedInfoLanguages NS_SWIFT_NAME(setQualifiedInfoLanguages(_:));

@property (nonatomic,readonly,assign,getter=qualifiedInfoNextUpdate) NSString* qualifiedInfoNextUpdate NS_SWIFT_NAME(qualifiedInfoNextUpdate);

- (NSString*)qualifiedInfoNextUpdate NS_SWIFT_NAME(qualifiedInfoNextUpdate());

@property (nonatomic,readonly,assign,getter=qualifiedInfoProvider) NSString* qualifiedInfoProvider NS_SWIFT_NAME(qualifiedInfoProvider);

- (NSString*)qualifiedInfoProvider NS_SWIFT_NAME(qualifiedInfoProvider());

@property (nonatomic,readonly,assign,getter=qualifiedInfoQualified) BOOL qualifiedInfoQualified NS_SWIFT_NAME(qualifiedInfoQualified);

- (BOOL)qualifiedInfoQualified NS_SWIFT_NAME(qualifiedInfoQualified());

@property (nonatomic,readonly,assign,getter=qualifiedInfoQualifiers) NSString* qualifiedInfoQualifiers NS_SWIFT_NAME(qualifiedInfoQualifiers);

- (NSString*)qualifiedInfoQualifiers NS_SWIFT_NAME(qualifiedInfoQualifiers());

@property (nonatomic,readonly,assign,getter=qualifiedInfoServiceName) NSString* qualifiedInfoServiceName NS_SWIFT_NAME(qualifiedInfoServiceName);

- (NSString*)qualifiedInfoServiceName NS_SWIFT_NAME(qualifiedInfoServiceName());

@property (nonatomic,readonly,assign,getter=qualifiedInfoServiceTypeId) NSString* qualifiedInfoServiceTypeId NS_SWIFT_NAME(qualifiedInfoServiceTypeId);

- (NSString*)qualifiedInfoServiceTypeId NS_SWIFT_NAME(qualifiedInfoServiceTypeId());

@property (nonatomic,readonly,assign,getter=qualifiedInfoSource) int qualifiedInfoSource NS_SWIFT_NAME(qualifiedInfoSource);

- (int)qualifiedInfoSource NS_SWIFT_NAME(qualifiedInfoSource());

@property (nonatomic,readonly,assign,getter=qualifiedInfoStatus) int qualifiedInfoStatus NS_SWIFT_NAME(qualifiedInfoStatus);

- (int)qualifiedInfoStatus NS_SWIFT_NAME(qualifiedInfoStatus());

@property (nonatomic,readonly,assign,getter=qualifiedInfoTradeName) NSString* qualifiedInfoTradeName NS_SWIFT_NAME(qualifiedInfoTradeName);

- (NSString*)qualifiedInfoTradeName NS_SWIFT_NAME(qualifiedInfoTradeName());

@property (nonatomic,readonly,assign,getter=qualifiedInfoTrusted) BOOL qualifiedInfoTrusted NS_SWIFT_NAME(qualifiedInfoTrusted);

- (BOOL)qualifiedInfoTrusted NS_SWIFT_NAME(qualifiedInfoTrusted());

@property (nonatomic,readwrite,assign,getter=qualifiedInfoUseDefaultTrustedLists,setter=setQualifiedInfoUseDefaultTrustedLists:) BOOL qualifiedInfoUseDefaultTrustedLists NS_SWIFT_NAME(qualifiedInfoUseDefaultTrustedLists);

- (BOOL)qualifiedInfoUseDefaultTrustedLists NS_SWIFT_NAME(qualifiedInfoUseDefaultTrustedLists());
- (void)setQualifiedInfoUseDefaultTrustedLists :(BOOL)newQualifiedInfoUseDefaultTrustedLists NS_SWIFT_NAME(setQualifiedInfoUseDefaultTrustedLists(_:));

@property (nonatomic,readonly,assign,getter=qualifiedInfoValidationLog) NSString* qualifiedInfoValidationLog NS_SWIFT_NAME(qualifiedInfoValidationLog);

- (NSString*)qualifiedInfoValidationLog NS_SWIFT_NAME(qualifiedInfoValidationLog());

@property (nonatomic,readonly,assign,getter=qualifiedInfoXML) NSString* qualifiedInfoXML NS_SWIFT_NAME(qualifiedInfoXML);

- (NSString*)qualifiedInfoXML NS_SWIFT_NAME(qualifiedInfoXML());

@property (nonatomic,readwrite,assign,getter=revocationCheck,setter=setRevocationCheck:) int revocationCheck NS_SWIFT_NAME(revocationCheck);

- (int)revocationCheck NS_SWIFT_NAME(revocationCheck());
- (void)setRevocationCheck :(int)newRevocationCheck NS_SWIFT_NAME(setRevocationCheck(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSMode,setter=setSocketDNSMode:) int socketDNSMode NS_SWIFT_NAME(socketDNSMode);

- (int)socketDNSMode NS_SWIFT_NAME(socketDNSMode());
- (void)setSocketDNSMode :(int)newSocketDNSMode NS_SWIFT_NAME(setSocketDNSMode(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSPort,setter=setSocketDNSPort:) int socketDNSPort NS_SWIFT_NAME(socketDNSPort);

- (int)socketDNSPort NS_SWIFT_NAME(socketDNSPort());
- (void)setSocketDNSPort :(int)newSocketDNSPort NS_SWIFT_NAME(setSocketDNSPort(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSQueryTimeout,setter=setSocketDNSQueryTimeout:) int socketDNSQueryTimeout NS_SWIFT_NAME(socketDNSQueryTimeout);

- (int)socketDNSQueryTimeout NS_SWIFT_NAME(socketDNSQueryTimeout());
- (void)setSocketDNSQueryTimeout :(int)newSocketDNSQueryTimeout NS_SWIFT_NAME(setSocketDNSQueryTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSServers,setter=setSocketDNSServers:) NSString* socketDNSServers NS_SWIFT_NAME(socketDNSServers);

- (NSString*)socketDNSServers NS_SWIFT_NAME(socketDNSServers());
- (void)setSocketDNSServers :(NSString*)newSocketDNSServers NS_SWIFT_NAME(setSocketDNSServers(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSTotalTimeout,setter=setSocketDNSTotalTimeout:) int socketDNSTotalTimeout NS_SWIFT_NAME(socketDNSTotalTimeout);

- (int)socketDNSTotalTimeout NS_SWIFT_NAME(socketDNSTotalTimeout());
- (void)setSocketDNSTotalTimeout :(int)newSocketDNSTotalTimeout NS_SWIFT_NAME(setSocketDNSTotalTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketIncomingSpeedLimit,setter=setSocketIncomingSpeedLimit:) int socketIncomingSpeedLimit NS_SWIFT_NAME(socketIncomingSpeedLimit);

- (int)socketIncomingSpeedLimit NS_SWIFT_NAME(socketIncomingSpeedLimit());
- (void)setSocketIncomingSpeedLimit :(int)newSocketIncomingSpeedLimit NS_SWIFT_NAME(setSocketIncomingSpeedLimit(_:));

@property (nonatomic,readwrite,assign,getter=socketLocalAddress,setter=setSocketLocalAddress:) NSString* socketLocalAddress NS_SWIFT_NAME(socketLocalAddress);

- (NSString*)socketLocalAddress NS_SWIFT_NAME(socketLocalAddress());
- (void)setSocketLocalAddress :(NSString*)newSocketLocalAddress NS_SWIFT_NAME(setSocketLocalAddress(_:));

@property (nonatomic,readwrite,assign,getter=socketLocalPort,setter=setSocketLocalPort:) int socketLocalPort NS_SWIFT_NAME(socketLocalPort);

- (int)socketLocalPort NS_SWIFT_NAME(socketLocalPort());
- (void)setSocketLocalPort :(int)newSocketLocalPort NS_SWIFT_NAME(setSocketLocalPort(_:));

@property (nonatomic,readwrite,assign,getter=socketOutgoingSpeedLimit,setter=setSocketOutgoingSpeedLimit:) int socketOutgoingSpeedLimit NS_SWIFT_NAME(socketOutgoingSpeedLimit);

- (int)socketOutgoingSpeedLimit NS_SWIFT_NAME(socketOutgoingSpeedLimit());
- (void)setSocketOutgoingSpeedLimit :(int)newSocketOutgoingSpeedLimit NS_SWIFT_NAME(setSocketOutgoingSpeedLimit(_:));

@property (nonatomic,readwrite,assign,getter=socketTimeout,setter=setSocketTimeout:) int socketTimeout NS_SWIFT_NAME(socketTimeout);

- (int)socketTimeout NS_SWIFT_NAME(socketTimeout());
- (void)setSocketTimeout :(int)newSocketTimeout NS_SWIFT_NAME(setSocketTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketUseIPv6,setter=setSocketUseIPv6:) BOOL socketUseIPv6 NS_SWIFT_NAME(socketUseIPv6);

- (BOOL)socketUseIPv6 NS_SWIFT_NAME(socketUseIPv6());
- (void)setSocketUseIPv6 :(BOOL)newSocketUseIPv6 NS_SWIFT_NAME(setSocketUseIPv6(_:));

@property (nonatomic,readwrite,assign,getter=TLSClientCertCount,setter=setTLSClientCertCount:) int TLSClientCertCount NS_SWIFT_NAME(TLSClientCertCount);

- (int)TLSClientCertCount NS_SWIFT_NAME(TLSClientCertCount());
- (void)setTLSClientCertCount :(int)newTLSClientCertCount NS_SWIFT_NAME(setTLSClientCertCount(_:));

- (NSData*)TLSClientCertBytes:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertBytes(_:));

- (BOOL)TLSClientCertCA:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCA(_:));
- (void)setTLSClientCertCA:(int)tLSClientCertIndex :(BOOL)newTLSClientCertCA NS_SWIFT_NAME(setTLSClientCertCA(_:_:));

- (NSData*)TLSClientCertCAKeyID:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCAKeyID(_:));

- (int)TLSClientCertCertType:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCertType(_:));

- (NSString*)TLSClientCertCRLDistributionPoints:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCRLDistributionPoints(_:));
- (void)setTLSClientCertCRLDistributionPoints:(int)tLSClientCertIndex :(NSString*)newTLSClientCertCRLDistributionPoints NS_SWIFT_NAME(setTLSClientCertCRLDistributionPoints(_:_:));

- (NSString*)TLSClientCertCurve:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCurve(_:));
- (void)setTLSClientCertCurve:(int)tLSClientCertIndex :(NSString*)newTLSClientCertCurve NS_SWIFT_NAME(setTLSClientCertCurve(_:_:));

- (NSString*)TLSClientCertFingerprint:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertFingerprint(_:));

- (NSString*)TLSClientCertFriendlyName:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertFriendlyName(_:));

- (long long)TLSClientCertHandle:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertHandle(_:));
- (void)setTLSClientCertHandle:(int)tLSClientCertIndex :(long long)newTLSClientCertHandle NS_SWIFT_NAME(setTLSClientCertHandle(_:_:));

- (NSString*)TLSClientCertHashAlgorithm:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertHashAlgorithm(_:));
- (void)setTLSClientCertHashAlgorithm:(int)tLSClientCertIndex :(NSString*)newTLSClientCertHashAlgorithm NS_SWIFT_NAME(setTLSClientCertHashAlgorithm(_:_:));

- (NSString*)TLSClientCertIssuer:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertIssuer(_:));

- (NSString*)TLSClientCertIssuerRDN:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertIssuerRDN(_:));
- (void)setTLSClientCertIssuerRDN:(int)tLSClientCertIndex :(NSString*)newTLSClientCertIssuerRDN NS_SWIFT_NAME(setTLSClientCertIssuerRDN(_:_:));

- (NSString*)TLSClientCertKeyAlgorithm:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyAlgorithm(_:));
- (void)setTLSClientCertKeyAlgorithm:(int)tLSClientCertIndex :(NSString*)newTLSClientCertKeyAlgorithm NS_SWIFT_NAME(setTLSClientCertKeyAlgorithm(_:_:));

- (int)TLSClientCertKeyBits:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyBits(_:));

- (NSString*)TLSClientCertKeyFingerprint:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyFingerprint(_:));

- (int)TLSClientCertKeyUsage:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyUsage(_:));
- (void)setTLSClientCertKeyUsage:(int)tLSClientCertIndex :(int)newTLSClientCertKeyUsage NS_SWIFT_NAME(setTLSClientCertKeyUsage(_:_:));

- (BOOL)TLSClientCertKeyValid:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyValid(_:));

- (NSString*)TLSClientCertOCSPLocations:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertOCSPLocations(_:));
- (void)setTLSClientCertOCSPLocations:(int)tLSClientCertIndex :(NSString*)newTLSClientCertOCSPLocations NS_SWIFT_NAME(setTLSClientCertOCSPLocations(_:_:));

- (BOOL)TLSClientCertOCSPNoCheck:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertOCSPNoCheck(_:));
- (void)setTLSClientCertOCSPNoCheck:(int)tLSClientCertIndex :(BOOL)newTLSClientCertOCSPNoCheck NS_SWIFT_NAME(setTLSClientCertOCSPNoCheck(_:_:));

- (int)TLSClientCertOrigin:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertOrigin(_:));

- (NSString*)TLSClientCertPolicyIDs:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPolicyIDs(_:));
- (void)setTLSClientCertPolicyIDs:(int)tLSClientCertIndex :(NSString*)newTLSClientCertPolicyIDs NS_SWIFT_NAME(setTLSClientCertPolicyIDs(_:_:));

- (NSData*)TLSClientCertPrivateKeyBytes:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPrivateKeyBytes(_:));

- (BOOL)TLSClientCertPrivateKeyExists:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPrivateKeyExists(_:));

- (BOOL)TLSClientCertPrivateKeyExtractable:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPrivateKeyExtractable(_:));

- (NSData*)TLSClientCertPublicKeyBytes:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPublicKeyBytes(_:));

- (BOOL)TLSClientCertQualified:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertQualified(_:));

- (int)TLSClientCertQualifiedStatements:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertQualifiedStatements(_:));
- (void)setTLSClientCertQualifiedStatements:(int)tLSClientCertIndex :(int)newTLSClientCertQualifiedStatements NS_SWIFT_NAME(setTLSClientCertQualifiedStatements(_:_:));

- (NSString*)TLSClientCertQualifiers:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertQualifiers(_:));

- (BOOL)TLSClientCertSelfSigned:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSelfSigned(_:));

- (NSData*)TLSClientCertSerialNumber:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSerialNumber(_:));
- (void)setTLSClientCertSerialNumber:(int)tLSClientCertIndex :(NSData*)newTLSClientCertSerialNumber NS_SWIFT_NAME(setTLSClientCertSerialNumber(_:_:));

- (NSString*)TLSClientCertSigAlgorithm:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSigAlgorithm(_:));

- (int)TLSClientCertSource:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSource(_:));

- (NSString*)TLSClientCertSubject:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSubject(_:));

- (NSString*)TLSClientCertSubjectAlternativeName:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSubjectAlternativeName(_:));
- (void)setTLSClientCertSubjectAlternativeName:(int)tLSClientCertIndex :(NSString*)newTLSClientCertSubjectAlternativeName NS_SWIFT_NAME(setTLSClientCertSubjectAlternativeName(_:_:));

- (NSData*)TLSClientCertSubjectKeyID:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSubjectKeyID(_:));
- (void)setTLSClientCertSubjectKeyID:(int)tLSClientCertIndex :(NSData*)newTLSClientCertSubjectKeyID NS_SWIFT_NAME(setTLSClientCertSubjectKeyID(_:_:));

- (NSString*)TLSClientCertSubjectRDN:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSubjectRDN(_:));
- (void)setTLSClientCertSubjectRDN:(int)tLSClientCertIndex :(NSString*)newTLSClientCertSubjectRDN NS_SWIFT_NAME(setTLSClientCertSubjectRDN(_:_:));

- (BOOL)TLSClientCertValid:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertValid(_:));

- (NSString*)TLSClientCertValidFrom:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertValidFrom(_:));
- (void)setTLSClientCertValidFrom:(int)tLSClientCertIndex :(NSString*)newTLSClientCertValidFrom NS_SWIFT_NAME(setTLSClientCertValidFrom(_:_:));

- (NSString*)TLSClientCertValidTo:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertValidTo(_:));
- (void)setTLSClientCertValidTo:(int)tLSClientCertIndex :(NSString*)newTLSClientCertValidTo NS_SWIFT_NAME(setTLSClientCertValidTo(_:_:));

@property (nonatomic,readonly,assign,getter=TLSServerCertCount) int TLSServerCertCount NS_SWIFT_NAME(TLSServerCertCount);

- (int)TLSServerCertCount NS_SWIFT_NAME(TLSServerCertCount());

- (NSData*)TLSServerCertBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertBytes(_:));

- (BOOL)TLSServerCertCA:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCA(_:));

- (NSData*)TLSServerCertCAKeyID:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCAKeyID(_:));

- (int)TLSServerCertCertType:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCertType(_:));

- (NSString*)TLSServerCertCRLDistributionPoints:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCRLDistributionPoints(_:));

- (NSString*)TLSServerCertCurve:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCurve(_:));

- (NSString*)TLSServerCertFingerprint:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertFingerprint(_:));

- (NSString*)TLSServerCertFriendlyName:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertFriendlyName(_:));

- (long long)TLSServerCertHandle:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertHandle(_:));

- (NSString*)TLSServerCertHashAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertHashAlgorithm(_:));

- (NSString*)TLSServerCertIssuer:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertIssuer(_:));

- (NSString*)TLSServerCertIssuerRDN:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertIssuerRDN(_:));

- (NSString*)TLSServerCertKeyAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyAlgorithm(_:));

- (int)TLSServerCertKeyBits:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyBits(_:));

- (NSString*)TLSServerCertKeyFingerprint:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyFingerprint(_:));

- (int)TLSServerCertKeyUsage:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyUsage(_:));

- (BOOL)TLSServerCertKeyValid:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyValid(_:));

- (NSString*)TLSServerCertOCSPLocations:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOCSPLocations(_:));

- (BOOL)TLSServerCertOCSPNoCheck:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOCSPNoCheck(_:));

- (int)TLSServerCertOrigin:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOrigin(_:));

- (NSString*)TLSServerCertPolicyIDs:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPolicyIDs(_:));

- (NSData*)TLSServerCertPrivateKeyBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyBytes(_:));

- (BOOL)TLSServerCertPrivateKeyExists:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyExists(_:));

- (BOOL)TLSServerCertPrivateKeyExtractable:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyExtractable(_:));

- (NSData*)TLSServerCertPublicKeyBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPublicKeyBytes(_:));

- (BOOL)TLSServerCertQualified:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualified(_:));

- (int)TLSServerCertQualifiedStatements:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualifiedStatements(_:));

- (NSString*)TLSServerCertQualifiers:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualifiers(_:));

- (BOOL)TLSServerCertSelfSigned:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSelfSigned(_:));

- (NSData*)TLSServerCertSerialNumber:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSerialNumber(_:));

- (NSString*)TLSServerCertSigAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSigAlgorithm(_:));

- (int)TLSServerCertSource:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSource(_:));

- (NSString*)TLSServerCertSubject:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubject(_:));

- (NSString*)TLSServerCertSubjectAlternativeName:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectAlternativeName(_:));

- (NSData*)TLSServerCertSubjectKeyID:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectKeyID(_:));

- (NSString*)TLSServerCertSubjectRDN:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectRDN(_:));

- (BOOL)TLSServerCertValid:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValid(_:));

- (NSString*)TLSServerCertValidFrom:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValidFrom(_:));

- (NSString*)TLSServerCertValidTo:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValidTo(_:));

@property (nonatomic,readwrite,assign,getter=TLSAutoValidateCertificates,setter=setTLSAutoValidateCertificates:) BOOL TLSAutoValidateCertificates NS_SWIFT_NAME(TLSAutoValidateCertificates);

- (BOOL)TLSAutoValidateCertificates NS_SWIFT_NAME(TLSAutoValidateCertificates());
- (void)setTLSAutoValidateCertificates :(BOOL)newTLSAutoValidateCertificates NS_SWIFT_NAME(setTLSAutoValidateCertificates(_:));

@property (nonatomic,readwrite,assign,getter=TLSBaseConfiguration,setter=setTLSBaseConfiguration:) int TLSBaseConfiguration NS_SWIFT_NAME(TLSBaseConfiguration);

- (int)TLSBaseConfiguration NS_SWIFT_NAME(TLSBaseConfiguration());
- (void)setTLSBaseConfiguration :(int)newTLSBaseConfiguration NS_SWIFT_NAME(setTLSBaseConfiguration(_:));

@property (nonatomic,readwrite,assign,getter=TLSCiphersuites,setter=setTLSCiphersuites:) NSString* TLSCiphersuites NS_SWIFT_NAME(TLSCiphersuites);

- (NSString*)TLSCiphersuites NS_SWIFT_NAME(TLSCiphersuites());
- (void)setTLSCiphersuites :(NSString*)newTLSCiphersuites NS_SWIFT_NAME(setTLSCiphersuites(_:));

@property (nonatomic,readwrite,assign,getter=TLSClientAuth,setter=setTLSClientAuth:) int TLSClientAuth NS_SWIFT_NAME(TLSClientAuth);

- (int)TLSClientAuth NS_SWIFT_NAME(TLSClientAuth());
- (void)setTLSClientAuth :(int)newTLSClientAuth NS_SWIFT_NAME(setTLSClientAuth(_:));

@property (nonatomic,readwrite,assign,getter=TLSECCurves,setter=setTLSECCurves:) NSString* TLSECCurves NS_SWIFT_NAME(TLSECCurves);

- (NSString*)TLSECCurves NS_SWIFT_NAME(TLSECCurves());
- (void)setTLSECCurves :(NSString*)newTLSECCurves NS_SWIFT_NAME(setTLSECCurves(_:));

@property (nonatomic,readwrite,assign,getter=TLSExtensions,setter=setTLSExtensions:) NSString* TLSExtensions NS_SWIFT_NAME(TLSExtensions);

- (NSString*)TLSExtensions NS_SWIFT_NAME(TLSExtensions());
- (void)setTLSExtensions :(NSString*)newTLSExtensions NS_SWIFT_NAME(setTLSExtensions(_:));

@property (nonatomic,readwrite,assign,getter=TLSForceResumeIfDestinationChanges,setter=setTLSForceResumeIfDestinationChanges:) BOOL TLSForceResumeIfDestinationChanges NS_SWIFT_NAME(TLSForceResumeIfDestinationChanges);

- (BOOL)TLSForceResumeIfDestinationChanges NS_SWIFT_NAME(TLSForceResumeIfDestinationChanges());
- (void)setTLSForceResumeIfDestinationChanges :(BOOL)newTLSForceResumeIfDestinationChanges NS_SWIFT_NAME(setTLSForceResumeIfDestinationChanges(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedIdentity,setter=setTLSPreSharedIdentity:) NSString* TLSPreSharedIdentity NS_SWIFT_NAME(TLSPreSharedIdentity);

- (NSString*)TLSPreSharedIdentity NS_SWIFT_NAME(TLSPreSharedIdentity());
- (void)setTLSPreSharedIdentity :(NSString*)newTLSPreSharedIdentity NS_SWIFT_NAME(setTLSPreSharedIdentity(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedKey,setter=setTLSPreSharedKey:) NSString* TLSPreSharedKey NS_SWIFT_NAME(TLSPreSharedKey);

- (NSString*)TLSPreSharedKey NS_SWIFT_NAME(TLSPreSharedKey());
- (void)setTLSPreSharedKey :(NSString*)newTLSPreSharedKey NS_SWIFT_NAME(setTLSPreSharedKey(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedKeyCiphersuite,setter=setTLSPreSharedKeyCiphersuite:) NSString* TLSPreSharedKeyCiphersuite NS_SWIFT_NAME(TLSPreSharedKeyCiphersuite);

- (NSString*)TLSPreSharedKeyCiphersuite NS_SWIFT_NAME(TLSPreSharedKeyCiphersuite());
- (void)setTLSPreSharedKeyCiphersuite :(NSString*)newTLSPreSharedKeyCiphersuite NS_SWIFT_NAME(setTLSPreSharedKeyCiphersuite(_:));

@property (nonatomic,readwrite,assign,getter=TLSRenegotiationAttackPreventionMode,setter=setTLSRenegotiationAttackPreventionMode:) int TLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(TLSRenegotiationAttackPreventionMode);

- (int)TLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(TLSRenegotiationAttackPreventionMode());
- (void)setTLSRenegotiationAttackPreventionMode :(int)newTLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(setTLSRenegotiationAttackPreventionMode(_:));

@property (nonatomic,readwrite,assign,getter=TLSRevocationCheck,setter=setTLSRevocationCheck:) int TLSRevocationCheck NS_SWIFT_NAME(TLSRevocationCheck);

- (int)TLSRevocationCheck NS_SWIFT_NAME(TLSRevocationCheck());
- (void)setTLSRevocationCheck :(int)newTLSRevocationCheck NS_SWIFT_NAME(setTLSRevocationCheck(_:));

@property (nonatomic,readwrite,assign,getter=TLSSSLOptions,setter=setTLSSSLOptions:) int TLSSSLOptions NS_SWIFT_NAME(TLSSSLOptions);

- (int)TLSSSLOptions NS_SWIFT_NAME(TLSSSLOptions());
- (void)setTLSSSLOptions :(int)newTLSSSLOptions NS_SWIFT_NAME(setTLSSSLOptions(_:));

@property (nonatomic,readwrite,assign,getter=TLSTLSMode,setter=setTLSTLSMode:) int TLSTLSMode NS_SWIFT_NAME(TLSTLSMode);

- (int)TLSTLSMode NS_SWIFT_NAME(TLSTLSMode());
- (void)setTLSTLSMode :(int)newTLSTLSMode NS_SWIFT_NAME(setTLSTLSMode(_:));

@property (nonatomic,readwrite,assign,getter=TLSUseExtendedMasterSecret,setter=setTLSUseExtendedMasterSecret:) BOOL TLSUseExtendedMasterSecret NS_SWIFT_NAME(TLSUseExtendedMasterSecret);

- (BOOL)TLSUseExtendedMasterSecret NS_SWIFT_NAME(TLSUseExtendedMasterSecret());
- (void)setTLSUseExtendedMasterSecret :(BOOL)newTLSUseExtendedMasterSecret NS_SWIFT_NAME(setTLSUseExtendedMasterSecret(_:));

@property (nonatomic,readwrite,assign,getter=TLSUseSessionResumption,setter=setTLSUseSessionResumption:) BOOL TLSUseSessionResumption NS_SWIFT_NAME(TLSUseSessionResumption);

- (BOOL)TLSUseSessionResumption NS_SWIFT_NAME(TLSUseSessionResumption());
- (void)setTLSUseSessionResumption :(BOOL)newTLSUseSessionResumption NS_SWIFT_NAME(setTLSUseSessionResumption(_:));

@property (nonatomic,readwrite,assign,getter=TLSVersions,setter=setTLSVersions:) int TLSVersions NS_SWIFT_NAME(TLSVersions);

- (int)TLSVersions NS_SWIFT_NAME(TLSVersions());
- (void)setTLSVersions :(int)newTLSVersions NS_SWIFT_NAME(setTLSVersions(_:));

@property (nonatomic,readwrite,assign,getter=trustedCertCount,setter=setTrustedCertCount:) int trustedCertCount NS_SWIFT_NAME(trustedCertCount);

- (int)trustedCertCount NS_SWIFT_NAME(trustedCertCount());
- (void)setTrustedCertCount :(int)newTrustedCertCount NS_SWIFT_NAME(setTrustedCertCount(_:));

- (NSData*)trustedCertBytes:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertBytes(_:));

- (BOOL)trustedCertCA:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertCA(_:));
- (void)setTrustedCertCA:(int)trustedCertIndex :(BOOL)newTrustedCertCA NS_SWIFT_NAME(setTrustedCertCA(_:_:));

- (NSData*)trustedCertCAKeyID:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertCAKeyID(_:));

- (int)trustedCertCertType:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertCertType(_:));

- (NSString*)trustedCertCRLDistributionPoints:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertCRLDistributionPoints(_:));
- (void)setTrustedCertCRLDistributionPoints:(int)trustedCertIndex :(NSString*)newTrustedCertCRLDistributionPoints NS_SWIFT_NAME(setTrustedCertCRLDistributionPoints(_:_:));

- (NSString*)trustedCertCurve:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertCurve(_:));
- (void)setTrustedCertCurve:(int)trustedCertIndex :(NSString*)newTrustedCertCurve NS_SWIFT_NAME(setTrustedCertCurve(_:_:));

- (NSString*)trustedCertFingerprint:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertFingerprint(_:));

- (NSString*)trustedCertFriendlyName:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertFriendlyName(_:));

- (long long)trustedCertHandle:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertHandle(_:));
- (void)setTrustedCertHandle:(int)trustedCertIndex :(long long)newTrustedCertHandle NS_SWIFT_NAME(setTrustedCertHandle(_:_:));

- (NSString*)trustedCertHashAlgorithm:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertHashAlgorithm(_:));
- (void)setTrustedCertHashAlgorithm:(int)trustedCertIndex :(NSString*)newTrustedCertHashAlgorithm NS_SWIFT_NAME(setTrustedCertHashAlgorithm(_:_:));

- (NSString*)trustedCertIssuer:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertIssuer(_:));

- (NSString*)trustedCertIssuerRDN:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertIssuerRDN(_:));
- (void)setTrustedCertIssuerRDN:(int)trustedCertIndex :(NSString*)newTrustedCertIssuerRDN NS_SWIFT_NAME(setTrustedCertIssuerRDN(_:_:));

- (NSString*)trustedCertKeyAlgorithm:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertKeyAlgorithm(_:));
- (void)setTrustedCertKeyAlgorithm:(int)trustedCertIndex :(NSString*)newTrustedCertKeyAlgorithm NS_SWIFT_NAME(setTrustedCertKeyAlgorithm(_:_:));

- (int)trustedCertKeyBits:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertKeyBits(_:));

- (NSString*)trustedCertKeyFingerprint:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertKeyFingerprint(_:));

- (int)trustedCertKeyUsage:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertKeyUsage(_:));
- (void)setTrustedCertKeyUsage:(int)trustedCertIndex :(int)newTrustedCertKeyUsage NS_SWIFT_NAME(setTrustedCertKeyUsage(_:_:));

- (BOOL)trustedCertKeyValid:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertKeyValid(_:));

- (NSString*)trustedCertOCSPLocations:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertOCSPLocations(_:));
- (void)setTrustedCertOCSPLocations:(int)trustedCertIndex :(NSString*)newTrustedCertOCSPLocations NS_SWIFT_NAME(setTrustedCertOCSPLocations(_:_:));

- (BOOL)trustedCertOCSPNoCheck:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertOCSPNoCheck(_:));
- (void)setTrustedCertOCSPNoCheck:(int)trustedCertIndex :(BOOL)newTrustedCertOCSPNoCheck NS_SWIFT_NAME(setTrustedCertOCSPNoCheck(_:_:));

- (int)trustedCertOrigin:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertOrigin(_:));

- (NSString*)trustedCertPolicyIDs:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertPolicyIDs(_:));
- (void)setTrustedCertPolicyIDs:(int)trustedCertIndex :(NSString*)newTrustedCertPolicyIDs NS_SWIFT_NAME(setTrustedCertPolicyIDs(_:_:));

- (NSData*)trustedCertPrivateKeyBytes:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertPrivateKeyBytes(_:));

- (BOOL)trustedCertPrivateKeyExists:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertPrivateKeyExists(_:));

- (BOOL)trustedCertPrivateKeyExtractable:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertPrivateKeyExtractable(_:));

- (NSData*)trustedCertPublicKeyBytes:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertPublicKeyBytes(_:));

- (BOOL)trustedCertQualified:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertQualified(_:));

- (int)trustedCertQualifiedStatements:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertQualifiedStatements(_:));
- (void)setTrustedCertQualifiedStatements:(int)trustedCertIndex :(int)newTrustedCertQualifiedStatements NS_SWIFT_NAME(setTrustedCertQualifiedStatements(_:_:));

- (NSString*)trustedCertQualifiers:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertQualifiers(_:));

- (BOOL)trustedCertSelfSigned:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSelfSigned(_:));

- (NSData*)trustedCertSerialNumber:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSerialNumber(_:));
- (void)setTrustedCertSerialNumber:(int)trustedCertIndex :(NSData*)newTrustedCertSerialNumber NS_SWIFT_NAME(setTrustedCertSerialNumber(_:_:));

- (NSString*)trustedCertSigAlgorithm:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSigAlgorithm(_:));

- (int)trustedCertSource:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSource(_:));

- (NSString*)trustedCertSubject:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSubject(_:));

- (NSString*)trustedCertSubjectAlternativeName:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSubjectAlternativeName(_:));
- (void)setTrustedCertSubjectAlternativeName:(int)trustedCertIndex :(NSString*)newTrustedCertSubjectAlternativeName NS_SWIFT_NAME(setTrustedCertSubjectAlternativeName(_:_:));

- (NSData*)trustedCertSubjectKeyID:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSubjectKeyID(_:));
- (void)setTrustedCertSubjectKeyID:(int)trustedCertIndex :(NSData*)newTrustedCertSubjectKeyID NS_SWIFT_NAME(setTrustedCertSubjectKeyID(_:_:));

- (NSString*)trustedCertSubjectRDN:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSubjectRDN(_:));
- (void)setTrustedCertSubjectRDN:(int)trustedCertIndex :(NSString*)newTrustedCertSubjectRDN NS_SWIFT_NAME(setTrustedCertSubjectRDN(_:_:));

- (BOOL)trustedCertValid:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertValid(_:));

- (NSString*)trustedCertValidFrom:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertValidFrom(_:));
- (void)setTrustedCertValidFrom:(int)trustedCertIndex :(NSString*)newTrustedCertValidFrom NS_SWIFT_NAME(setTrustedCertValidFrom(_:_:));

- (NSString*)trustedCertValidTo:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertValidTo(_:));
- (void)setTrustedCertValidTo:(int)trustedCertIndex :(NSString*)newTrustedCertValidTo NS_SWIFT_NAME(setTrustedCertValidTo(_:_:));

@property (nonatomic,readonly,assign,getter=usedCertCount) int usedCertCount NS_SWIFT_NAME(usedCertCount);

- (int)usedCertCount NS_SWIFT_NAME(usedCertCount());

- (NSData*)usedCertBytes:(int)usedCertIndex NS_SWIFT_NAME(usedCertBytes(_:));

- (BOOL)usedCertCA:(int)usedCertIndex NS_SWIFT_NAME(usedCertCA(_:));

- (NSData*)usedCertCAKeyID:(int)usedCertIndex NS_SWIFT_NAME(usedCertCAKeyID(_:));

- (int)usedCertCertType:(int)usedCertIndex NS_SWIFT_NAME(usedCertCertType(_:));

- (NSString*)usedCertCRLDistributionPoints:(int)usedCertIndex NS_SWIFT_NAME(usedCertCRLDistributionPoints(_:));

- (NSString*)usedCertCurve:(int)usedCertIndex NS_SWIFT_NAME(usedCertCurve(_:));

- (NSString*)usedCertFingerprint:(int)usedCertIndex NS_SWIFT_NAME(usedCertFingerprint(_:));

- (NSString*)usedCertFriendlyName:(int)usedCertIndex NS_SWIFT_NAME(usedCertFriendlyName(_:));

- (long long)usedCertHandle:(int)usedCertIndex NS_SWIFT_NAME(usedCertHandle(_:));

- (NSString*)usedCertHashAlgorithm:(int)usedCertIndex NS_SWIFT_NAME(usedCertHashAlgorithm(_:));

- (NSString*)usedCertIssuer:(int)usedCertIndex NS_SWIFT_NAME(usedCertIssuer(_:));

- (NSString*)usedCertIssuerRDN:(int)usedCertIndex NS_SWIFT_NAME(usedCertIssuerRDN(_:));

- (NSString*)usedCertKeyAlgorithm:(int)usedCertIndex NS_SWIFT_NAME(usedCertKeyAlgorithm(_:));

- (int)usedCertKeyBits:(int)usedCertIndex NS_SWIFT_NAME(usedCertKeyBits(_:));

- (NSString*)usedCertKeyFingerprint:(int)usedCertIndex NS_SWIFT_NAME(usedCertKeyFingerprint(_:));

- (int)usedCertKeyUsage:(int)usedCertIndex NS_SWIFT_NAME(usedCertKeyUsage(_:));

- (BOOL)usedCertKeyValid:(int)usedCertIndex NS_SWIFT_NAME(usedCertKeyValid(_:));

- (NSString*)usedCertOCSPLocations:(int)usedCertIndex NS_SWIFT_NAME(usedCertOCSPLocations(_:));

- (BOOL)usedCertOCSPNoCheck:(int)usedCertIndex NS_SWIFT_NAME(usedCertOCSPNoCheck(_:));

- (int)usedCertOrigin:(int)usedCertIndex NS_SWIFT_NAME(usedCertOrigin(_:));

- (NSString*)usedCertPolicyIDs:(int)usedCertIndex NS_SWIFT_NAME(usedCertPolicyIDs(_:));

- (NSData*)usedCertPrivateKeyBytes:(int)usedCertIndex NS_SWIFT_NAME(usedCertPrivateKeyBytes(_:));

- (BOOL)usedCertPrivateKeyExists:(int)usedCertIndex NS_SWIFT_NAME(usedCertPrivateKeyExists(_:));

- (BOOL)usedCertPrivateKeyExtractable:(int)usedCertIndex NS_SWIFT_NAME(usedCertPrivateKeyExtractable(_:));

- (NSData*)usedCertPublicKeyBytes:(int)usedCertIndex NS_SWIFT_NAME(usedCertPublicKeyBytes(_:));

- (BOOL)usedCertQualified:(int)usedCertIndex NS_SWIFT_NAME(usedCertQualified(_:));

- (int)usedCertQualifiedStatements:(int)usedCertIndex NS_SWIFT_NAME(usedCertQualifiedStatements(_:));

- (NSString*)usedCertQualifiers:(int)usedCertIndex NS_SWIFT_NAME(usedCertQualifiers(_:));

- (BOOL)usedCertSelfSigned:(int)usedCertIndex NS_SWIFT_NAME(usedCertSelfSigned(_:));

- (NSData*)usedCertSerialNumber:(int)usedCertIndex NS_SWIFT_NAME(usedCertSerialNumber(_:));

- (NSString*)usedCertSigAlgorithm:(int)usedCertIndex NS_SWIFT_NAME(usedCertSigAlgorithm(_:));

- (int)usedCertSource:(int)usedCertIndex NS_SWIFT_NAME(usedCertSource(_:));

- (NSString*)usedCertSubject:(int)usedCertIndex NS_SWIFT_NAME(usedCertSubject(_:));

- (NSString*)usedCertSubjectAlternativeName:(int)usedCertIndex NS_SWIFT_NAME(usedCertSubjectAlternativeName(_:));

- (NSData*)usedCertSubjectKeyID:(int)usedCertIndex NS_SWIFT_NAME(usedCertSubjectKeyID(_:));

- (NSString*)usedCertSubjectRDN:(int)usedCertIndex NS_SWIFT_NAME(usedCertSubjectRDN(_:));

- (BOOL)usedCertValid:(int)usedCertIndex NS_SWIFT_NAME(usedCertValid(_:));

- (NSString*)usedCertValidFrom:(int)usedCertIndex NS_SWIFT_NAME(usedCertValidFrom(_:));

- (NSString*)usedCertValidTo:(int)usedCertIndex NS_SWIFT_NAME(usedCertValidTo(_:));

@property (nonatomic,readonly,assign,getter=usedCRLCount) int usedCRLCount NS_SWIFT_NAME(usedCRLCount);

- (int)usedCRLCount NS_SWIFT_NAME(usedCRLCount());

- (NSData*)usedCRLBytes:(int)usedCRLIndex NS_SWIFT_NAME(usedCRLBytes(_:));

- (NSData*)usedCRLCAKeyID:(int)usedCRLIndex NS_SWIFT_NAME(usedCRLCAKeyID(_:));

- (int)usedCRLEntryCount:(int)usedCRLIndex NS_SWIFT_NAME(usedCRLEntryCount(_:));

- (long long)usedCRLHandle:(int)usedCRLIndex NS_SWIFT_NAME(usedCRLHandle(_:));

- (NSString*)usedCRLIssuer:(int)usedCRLIndex NS_SWIFT_NAME(usedCRLIssuer(_:));

- (NSString*)usedCRLIssuerRDN:(int)usedCRLIndex NS_SWIFT_NAME(usedCRLIssuerRDN(_:));

- (NSString*)usedCRLLocation:(int)usedCRLIndex NS_SWIFT_NAME(usedCRLLocation(_:));

- (NSString*)usedCRLNextUpdate:(int)usedCRLIndex NS_SWIFT_NAME(usedCRLNextUpdate(_:));

- (NSString*)usedCRLSigAlgorithm:(int)usedCRLIndex NS_SWIFT_NAME(usedCRLSigAlgorithm(_:));

- (int)usedCRLSource:(int)usedCRLIndex NS_SWIFT_NAME(usedCRLSource(_:));

- (NSData*)usedCRLTBS:(int)usedCRLIndex NS_SWIFT_NAME(usedCRLTBS(_:));

- (NSString*)usedCRLThisUpdate:(int)usedCRLIndex NS_SWIFT_NAME(usedCRLThisUpdate(_:));

@property (nonatomic,readonly,assign,getter=usedOCSPCount) int usedOCSPCount NS_SWIFT_NAME(usedOCSPCount);

- (int)usedOCSPCount NS_SWIFT_NAME(usedOCSPCount());

- (NSData*)usedOCSPBytes:(int)usedOCSPIndex NS_SWIFT_NAME(usedOCSPBytes(_:));

- (int)usedOCSPEntryCount:(int)usedOCSPIndex NS_SWIFT_NAME(usedOCSPEntryCount(_:));

- (long long)usedOCSPHandle:(int)usedOCSPIndex NS_SWIFT_NAME(usedOCSPHandle(_:));

- (NSString*)usedOCSPIssuer:(int)usedOCSPIndex NS_SWIFT_NAME(usedOCSPIssuer(_:));

- (NSString*)usedOCSPIssuerRDN:(int)usedOCSPIndex NS_SWIFT_NAME(usedOCSPIssuerRDN(_:));

- (NSString*)usedOCSPLocation:(int)usedOCSPIndex NS_SWIFT_NAME(usedOCSPLocation(_:));

- (NSString*)usedOCSPProducedAt:(int)usedOCSPIndex NS_SWIFT_NAME(usedOCSPProducedAt(_:));

- (NSString*)usedOCSPSigAlgorithm:(int)usedOCSPIndex NS_SWIFT_NAME(usedOCSPSigAlgorithm(_:));

- (int)usedOCSPSource:(int)usedOCSPIndex NS_SWIFT_NAME(usedOCSPSource(_:));

@property (nonatomic,readwrite,assign,getter=useSystemCertificates,setter=setUseSystemCertificates:) BOOL useSystemCertificates NS_SWIFT_NAME(useSystemCertificates);

- (BOOL)useSystemCertificates NS_SWIFT_NAME(useSystemCertificates());
- (void)setUseSystemCertificates :(BOOL)newUseSystemCertificates NS_SWIFT_NAME(setUseSystemCertificates(_:));

@property (nonatomic,readonly,assign,getter=validationLog) NSString* validationLog NS_SWIFT_NAME(validationLog);

- (NSString*)validationLog NS_SWIFT_NAME(validationLog());

@property (nonatomic,readwrite,assign,getter=validationMoment,setter=setValidationMoment:) NSString* validationMoment NS_SWIFT_NAME(validationMoment);

- (NSString*)validationMoment NS_SWIFT_NAME(validationMoment());
- (void)setValidationMoment :(NSString*)newValidationMoment NS_SWIFT_NAME(setValidationMoment(_:));

  /* Methods */

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (void)getQualifiedStatus NS_SWIFT_NAME(getQualifiedStatus());

- (NSString*)getTrustedListProperty:(NSString*)propName :(NSString*)language NS_SWIFT_NAME(getTrustedListProperty(_:_:));

- (void)refreshCache NS_SWIFT_NAME(refreshCache());

- (void)reset NS_SWIFT_NAME(reset());

- (void)resetCache NS_SWIFT_NAME(resetCache());

- (void)terminate NS_SWIFT_NAME(terminate());

- (int)validate NS_SWIFT_NAME(validate());

- (int)validateForSMIME:(NSString*)emailAddress NS_SWIFT_NAME(validateForSMIME(_:));

- (int)validateForSSL:(NSString*)URL :(NSString*)IPAddress NS_SWIFT_NAME(validateForSSL(_:_:));

@end

