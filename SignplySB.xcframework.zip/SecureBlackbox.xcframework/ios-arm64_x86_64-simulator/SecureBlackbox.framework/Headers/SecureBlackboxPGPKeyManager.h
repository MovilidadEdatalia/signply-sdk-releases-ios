/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//PGPPROTECTIONTYPES
#define PPT_NONE                                           0

#define PPT_LOW                                            1

#define PPT_NORMAL                                         2

#define PPT_HIGH                                           3

//PGPCERTIFICATIONTYPES
#define PCT_GENERIC                                        0

#define PCT_PERSONA                                        1

#define PCT_CASUAL                                         2

#define PCT_POSITIVE                                       3

//PGPSIGNATURECLASSES
#define PSC_DOCUMENT                                       0

#define PSC_TEXT_DOCUMENT                                  1

#define PSC_STANDALONE                                     2

#define PSC_UIDGENERIC                                     3

#define PSC_UIDPERSONA                                     4

#define PSC_UIDCASUAL                                      5

#define PSC_UIDPOSITIVE                                    6

#define PSC_SUBKEY_BINDING                                 7

#define PSC_PRIMARY_KEY_BINDING                            8

#define PSC_DIRECT_KEY                                     9

#define PSC_KEY_REVOCATION                                 10

#define PSC_SUBKEY_REVOCATION                              11

#define PSC_CERT_REVOCATION                                12

#define PSC_TIMESTAMP                                      13

#define PSC_THIRD_PARTY                                    14

#define PSC_NOT_SPECIFIED                                  15

//SIGNATUREVALIDITIES
#define SVT_VALID                                          0

#define SVT_UNKNOWN                                        1

#define SVT_CORRUPTED                                      2

#define SVT_SIGNER_NOT_FOUND                               3

#define SVT_FAILURE                                        4

#define SVT_REFERENCE_CORRUPTED                            5

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxPGPKeyManagerDelegate <NSObject>
@optional
- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onKeyPassphraseNeeded:(NSString*)keyID :(NSString*)userID :(BOOL)mainKey :(NSString**)passphrase :(int*)skip NS_SWIFT_NAME(onKeyPassphraseNeeded(_:_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

@end

@interface SecureBlackboxPGPKeyManager : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxPGPKeyManagerDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasError;

  BOOL m_delegateHasKeyPassphraseNeeded;

  BOOL m_delegateHasNotification;

}

+ (SecureBlackboxPGPKeyManager*)pgpkeymanager;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxPGPKeyManagerDelegate> delegate;
- (id <SecureBlackboxPGPKeyManagerDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxPGPKeyManagerDelegate>)anObject;

  /* Events */

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onKeyPassphraseNeeded:(NSString*)keyID :(NSString*)userID :(BOOL)mainKey :(NSString**)passphrase :(int*)skip NS_SWIFT_NAME(onKeyPassphraseNeeded(_:_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readonly,assign,getter=keyBitsInKey) int keyBitsInKey NS_SWIFT_NAME(keyBitsInKey);

- (int)keyBitsInKey NS_SWIFT_NAME(keyBitsInKey());

@property (nonatomic,readonly,assign,getter=keyCanEncrypt) BOOL keyCanEncrypt NS_SWIFT_NAME(keyCanEncrypt);

- (BOOL)keyCanEncrypt NS_SWIFT_NAME(keyCanEncrypt());

@property (nonatomic,readonly,assign,getter=keyCanSign) BOOL keyCanSign NS_SWIFT_NAME(keyCanSign);

- (BOOL)keyCanSign NS_SWIFT_NAME(keyCanSign());

@property (nonatomic,readonly,assign,getter=keyCurve) NSString* keyCurve NS_SWIFT_NAME(keyCurve);

- (NSString*)keyCurve NS_SWIFT_NAME(keyCurve());

@property (nonatomic,readwrite,assign,getter=keyEnabled,setter=setKeyEnabled:) BOOL keyEnabled NS_SWIFT_NAME(keyEnabled);

- (BOOL)keyEnabled NS_SWIFT_NAME(keyEnabled());
- (void)setKeyEnabled :(BOOL)newKeyEnabled NS_SWIFT_NAME(setKeyEnabled(_:));

@property (nonatomic,readonly,assign,getter=keyEncryptionAlgorithm) NSString* keyEncryptionAlgorithm NS_SWIFT_NAME(keyEncryptionAlgorithm);

- (NSString*)keyEncryptionAlgorithm NS_SWIFT_NAME(keyEncryptionAlgorithm());

@property (nonatomic,readwrite,assign,getter=keyHandle,setter=setKeyHandle:) long long keyHandle NS_SWIFT_NAME(keyHandle);

- (long long)keyHandle NS_SWIFT_NAME(keyHandle());
- (void)setKeyHandle :(long long)newKeyHandle NS_SWIFT_NAME(setKeyHandle(_:));

@property (nonatomic,readonly,assign,getter=keyIsPublic) BOOL keyIsPublic NS_SWIFT_NAME(keyIsPublic);

- (BOOL)keyIsPublic NS_SWIFT_NAME(keyIsPublic());

@property (nonatomic,readonly,assign,getter=keyIsSecret) BOOL keyIsSecret NS_SWIFT_NAME(keyIsSecret);

- (BOOL)keyIsSecret NS_SWIFT_NAME(keyIsSecret());

@property (nonatomic,readonly,assign,getter=keyIsSubkey) BOOL keyIsSubkey NS_SWIFT_NAME(keyIsSubkey);

- (BOOL)keyIsSubkey NS_SWIFT_NAME(keyIsSubkey());

@property (nonatomic,readonly,assign,getter=keyKeyFP) NSString* keyKeyFP NS_SWIFT_NAME(keyKeyFP);

- (NSString*)keyKeyFP NS_SWIFT_NAME(keyKeyFP());

@property (nonatomic,readonly,assign,getter=keyKeyID) NSString* keyKeyID NS_SWIFT_NAME(keyKeyID);

- (NSString*)keyKeyID NS_SWIFT_NAME(keyKeyID());

@property (nonatomic,readwrite,assign,getter=keyPassphrase,setter=setKeyPassphrase:) NSString* keyPassphrase NS_SWIFT_NAME(keyPassphrase);

- (NSString*)keyPassphrase NS_SWIFT_NAME(keyPassphrase());
- (void)setKeyPassphrase :(NSString*)newKeyPassphrase NS_SWIFT_NAME(setKeyPassphrase(_:));

@property (nonatomic,readonly,assign,getter=keyPassphraseValid) BOOL keyPassphraseValid NS_SWIFT_NAME(keyPassphraseValid);

- (BOOL)keyPassphraseValid NS_SWIFT_NAME(keyPassphraseValid());

@property (nonatomic,readonly,assign,getter=keyPrimaryKeyID) NSString* keyPrimaryKeyID NS_SWIFT_NAME(keyPrimaryKeyID);

- (NSString*)keyPrimaryKeyID NS_SWIFT_NAME(keyPrimaryKeyID());

@property (nonatomic,readonly,assign,getter=keyProtection) int keyProtection NS_SWIFT_NAME(keyProtection);

- (int)keyProtection NS_SWIFT_NAME(keyProtection());

@property (nonatomic,readonly,assign,getter=keyPublicKeyAlgorithm) NSString* keyPublicKeyAlgorithm NS_SWIFT_NAME(keyPublicKeyAlgorithm);

- (NSString*)keyPublicKeyAlgorithm NS_SWIFT_NAME(keyPublicKeyAlgorithm());

@property (nonatomic,readonly,assign,getter=keyQBits) int keyQBits NS_SWIFT_NAME(keyQBits);

- (int)keyQBits NS_SWIFT_NAME(keyQBits());

@property (nonatomic,readonly,assign,getter=keyTimestamp) NSString* keyTimestamp NS_SWIFT_NAME(keyTimestamp);

- (NSString*)keyTimestamp NS_SWIFT_NAME(keyTimestamp());

@property (nonatomic,readonly,assign,getter=keyUsername) NSString* keyUsername NS_SWIFT_NAME(keyUsername);

- (NSString*)keyUsername NS_SWIFT_NAME(keyUsername());

@property (nonatomic,readonly,assign,getter=keyValidTo) NSString* keyValidTo NS_SWIFT_NAME(keyValidTo);

- (NSString*)keyValidTo NS_SWIFT_NAME(keyValidTo());

@property (nonatomic,readonly,assign,getter=keyVersion) int keyVersion NS_SWIFT_NAME(keyVersion);

- (int)keyVersion NS_SWIFT_NAME(keyVersion());

@property (nonatomic,readonly,assign,getter=pinnedKeyBitsInKey) int pinnedKeyBitsInKey NS_SWIFT_NAME(pinnedKeyBitsInKey);

- (int)pinnedKeyBitsInKey NS_SWIFT_NAME(pinnedKeyBitsInKey());

@property (nonatomic,readonly,assign,getter=pinnedKeyCanEncrypt) BOOL pinnedKeyCanEncrypt NS_SWIFT_NAME(pinnedKeyCanEncrypt);

- (BOOL)pinnedKeyCanEncrypt NS_SWIFT_NAME(pinnedKeyCanEncrypt());

@property (nonatomic,readonly,assign,getter=pinnedKeyCanSign) BOOL pinnedKeyCanSign NS_SWIFT_NAME(pinnedKeyCanSign);

- (BOOL)pinnedKeyCanSign NS_SWIFT_NAME(pinnedKeyCanSign());

@property (nonatomic,readonly,assign,getter=pinnedKeyCurve) NSString* pinnedKeyCurve NS_SWIFT_NAME(pinnedKeyCurve);

- (NSString*)pinnedKeyCurve NS_SWIFT_NAME(pinnedKeyCurve());

@property (nonatomic,readwrite,assign,getter=pinnedKeyEnabled,setter=setPinnedKeyEnabled:) BOOL pinnedKeyEnabled NS_SWIFT_NAME(pinnedKeyEnabled);

- (BOOL)pinnedKeyEnabled NS_SWIFT_NAME(pinnedKeyEnabled());
- (void)setPinnedKeyEnabled :(BOOL)newPinnedKeyEnabled NS_SWIFT_NAME(setPinnedKeyEnabled(_:));

@property (nonatomic,readonly,assign,getter=pinnedKeyEncryptionAlgorithm) NSString* pinnedKeyEncryptionAlgorithm NS_SWIFT_NAME(pinnedKeyEncryptionAlgorithm);

- (NSString*)pinnedKeyEncryptionAlgorithm NS_SWIFT_NAME(pinnedKeyEncryptionAlgorithm());

@property (nonatomic,readwrite,assign,getter=pinnedKeyHandle,setter=setPinnedKeyHandle:) long long pinnedKeyHandle NS_SWIFT_NAME(pinnedKeyHandle);

- (long long)pinnedKeyHandle NS_SWIFT_NAME(pinnedKeyHandle());
- (void)setPinnedKeyHandle :(long long)newPinnedKeyHandle NS_SWIFT_NAME(setPinnedKeyHandle(_:));

@property (nonatomic,readonly,assign,getter=pinnedKeyIsPublic) BOOL pinnedKeyIsPublic NS_SWIFT_NAME(pinnedKeyIsPublic);

- (BOOL)pinnedKeyIsPublic NS_SWIFT_NAME(pinnedKeyIsPublic());

@property (nonatomic,readonly,assign,getter=pinnedKeyIsSecret) BOOL pinnedKeyIsSecret NS_SWIFT_NAME(pinnedKeyIsSecret);

- (BOOL)pinnedKeyIsSecret NS_SWIFT_NAME(pinnedKeyIsSecret());

@property (nonatomic,readonly,assign,getter=pinnedKeyIsSubkey) BOOL pinnedKeyIsSubkey NS_SWIFT_NAME(pinnedKeyIsSubkey);

- (BOOL)pinnedKeyIsSubkey NS_SWIFT_NAME(pinnedKeyIsSubkey());

@property (nonatomic,readonly,assign,getter=pinnedKeyKeyFP) NSString* pinnedKeyKeyFP NS_SWIFT_NAME(pinnedKeyKeyFP);

- (NSString*)pinnedKeyKeyFP NS_SWIFT_NAME(pinnedKeyKeyFP());

@property (nonatomic,readonly,assign,getter=pinnedKeyKeyID) NSString* pinnedKeyKeyID NS_SWIFT_NAME(pinnedKeyKeyID);

- (NSString*)pinnedKeyKeyID NS_SWIFT_NAME(pinnedKeyKeyID());

@property (nonatomic,readwrite,assign,getter=pinnedKeyPassphrase,setter=setPinnedKeyPassphrase:) NSString* pinnedKeyPassphrase NS_SWIFT_NAME(pinnedKeyPassphrase);

- (NSString*)pinnedKeyPassphrase NS_SWIFT_NAME(pinnedKeyPassphrase());
- (void)setPinnedKeyPassphrase :(NSString*)newPinnedKeyPassphrase NS_SWIFT_NAME(setPinnedKeyPassphrase(_:));

@property (nonatomic,readonly,assign,getter=pinnedKeyPassphraseValid) BOOL pinnedKeyPassphraseValid NS_SWIFT_NAME(pinnedKeyPassphraseValid);

- (BOOL)pinnedKeyPassphraseValid NS_SWIFT_NAME(pinnedKeyPassphraseValid());

@property (nonatomic,readonly,assign,getter=pinnedKeyPrimaryKeyID) NSString* pinnedKeyPrimaryKeyID NS_SWIFT_NAME(pinnedKeyPrimaryKeyID);

- (NSString*)pinnedKeyPrimaryKeyID NS_SWIFT_NAME(pinnedKeyPrimaryKeyID());

@property (nonatomic,readonly,assign,getter=pinnedKeyProtection) int pinnedKeyProtection NS_SWIFT_NAME(pinnedKeyProtection);

- (int)pinnedKeyProtection NS_SWIFT_NAME(pinnedKeyProtection());

@property (nonatomic,readonly,assign,getter=pinnedKeyPublicKeyAlgorithm) NSString* pinnedKeyPublicKeyAlgorithm NS_SWIFT_NAME(pinnedKeyPublicKeyAlgorithm);

- (NSString*)pinnedKeyPublicKeyAlgorithm NS_SWIFT_NAME(pinnedKeyPublicKeyAlgorithm());

@property (nonatomic,readonly,assign,getter=pinnedKeyQBits) int pinnedKeyQBits NS_SWIFT_NAME(pinnedKeyQBits);

- (int)pinnedKeyQBits NS_SWIFT_NAME(pinnedKeyQBits());

@property (nonatomic,readonly,assign,getter=pinnedKeyTimestamp) NSString* pinnedKeyTimestamp NS_SWIFT_NAME(pinnedKeyTimestamp);

- (NSString*)pinnedKeyTimestamp NS_SWIFT_NAME(pinnedKeyTimestamp());

@property (nonatomic,readonly,assign,getter=pinnedKeyUsername) NSString* pinnedKeyUsername NS_SWIFT_NAME(pinnedKeyUsername);

- (NSString*)pinnedKeyUsername NS_SWIFT_NAME(pinnedKeyUsername());

@property (nonatomic,readonly,assign,getter=pinnedKeyValidTo) NSString* pinnedKeyValidTo NS_SWIFT_NAME(pinnedKeyValidTo);

- (NSString*)pinnedKeyValidTo NS_SWIFT_NAME(pinnedKeyValidTo());

@property (nonatomic,readonly,assign,getter=pinnedKeyVersion) int pinnedKeyVersion NS_SWIFT_NAME(pinnedKeyVersion);

- (int)pinnedKeyVersion NS_SWIFT_NAME(pinnedKeyVersion());

@property (nonatomic,readonly,assign,getter=signatureCount) int signatureCount NS_SWIFT_NAME(signatureCount);

- (int)signatureCount NS_SWIFT_NAME(signatureCount());

- (int)signatureCertificationType:(int)signatureIndex NS_SWIFT_NAME(signatureCertificationType(_:));

- (NSString*)signatureCreationTime:(int)signatureIndex NS_SWIFT_NAME(signatureCreationTime(_:));

- (int)signatureExpirationTime:(int)signatureIndex NS_SWIFT_NAME(signatureExpirationTime(_:));

- (BOOL)signatureExportable:(int)signatureIndex NS_SWIFT_NAME(signatureExportable(_:));

- (long long)signatureHandle:(int)signatureIndex NS_SWIFT_NAME(signatureHandle(_:));

- (NSString*)signatureHashAlgorithm:(int)signatureIndex NS_SWIFT_NAME(signatureHashAlgorithm(_:));

- (int)signatureHashMark:(int)signatureIndex NS_SWIFT_NAME(signatureHashMark(_:));

- (int)signatureKeyExpirationTime:(int)signatureIndex NS_SWIFT_NAME(signatureKeyExpirationTime(_:));

- (int)signatureKeyFlags:(int)signatureIndex NS_SWIFT_NAME(signatureKeyFlags(_:));

- (BOOL)signatureLegacyFormat:(int)signatureIndex NS_SWIFT_NAME(signatureLegacyFormat(_:));

- (NSString*)signaturePolicyURL:(int)signatureIndex NS_SWIFT_NAME(signaturePolicyURL(_:));

- (NSString*)signaturePreferredAlgorithms:(int)signatureIndex NS_SWIFT_NAME(signaturePreferredAlgorithms(_:));

- (BOOL)signaturePrimaryUserID:(int)signatureIndex NS_SWIFT_NAME(signaturePrimaryUserID(_:));

- (NSString*)signatureReasonForRevocation:(int)signatureIndex NS_SWIFT_NAME(signatureReasonForRevocation(_:));

- (BOOL)signatureRevocable:(int)signatureIndex NS_SWIFT_NAME(signatureRevocable(_:));

- (BOOL)signatureRevocation:(int)signatureIndex NS_SWIFT_NAME(signatureRevocation(_:));

- (int)signatureSignatureClass:(int)signatureIndex NS_SWIFT_NAME(signatureSignatureClass(_:));

- (NSString*)signatureSignerKeyID:(int)signatureIndex NS_SWIFT_NAME(signatureSignerKeyID(_:));

- (NSString*)signatureSignerUserID:(int)signatureIndex NS_SWIFT_NAME(signatureSignerUserID(_:));

- (BOOL)signatureStrictlyValid:(int)signatureIndex NS_SWIFT_NAME(signatureStrictlyValid(_:));

- (NSString*)signatureTarget:(int)signatureIndex NS_SWIFT_NAME(signatureTarget(_:));

- (BOOL)signatureTextSignature:(int)signatureIndex NS_SWIFT_NAME(signatureTextSignature(_:));

- (int)signatureTrustAmount:(int)signatureIndex NS_SWIFT_NAME(signatureTrustAmount(_:));

- (int)signatureTrustLevel:(int)signatureIndex NS_SWIFT_NAME(signatureTrustLevel(_:));

- (BOOL)signatureValidated:(int)signatureIndex NS_SWIFT_NAME(signatureValidated(_:));

- (int)signatureValidity:(int)signatureIndex NS_SWIFT_NAME(signatureValidity(_:));

- (int)signatureVersion:(int)signatureIndex NS_SWIFT_NAME(signatureVersion(_:));

@property (nonatomic,readonly,assign,getter=signingKeyBitsInKey) int signingKeyBitsInKey NS_SWIFT_NAME(signingKeyBitsInKey);

- (int)signingKeyBitsInKey NS_SWIFT_NAME(signingKeyBitsInKey());

@property (nonatomic,readonly,assign,getter=signingKeyCanEncrypt) BOOL signingKeyCanEncrypt NS_SWIFT_NAME(signingKeyCanEncrypt);

- (BOOL)signingKeyCanEncrypt NS_SWIFT_NAME(signingKeyCanEncrypt());

@property (nonatomic,readonly,assign,getter=signingKeyCanSign) BOOL signingKeyCanSign NS_SWIFT_NAME(signingKeyCanSign);

- (BOOL)signingKeyCanSign NS_SWIFT_NAME(signingKeyCanSign());

@property (nonatomic,readonly,assign,getter=signingKeyCurve) NSString* signingKeyCurve NS_SWIFT_NAME(signingKeyCurve);

- (NSString*)signingKeyCurve NS_SWIFT_NAME(signingKeyCurve());

@property (nonatomic,readwrite,assign,getter=signingKeyEnabled,setter=setSigningKeyEnabled:) BOOL signingKeyEnabled NS_SWIFT_NAME(signingKeyEnabled);

- (BOOL)signingKeyEnabled NS_SWIFT_NAME(signingKeyEnabled());
- (void)setSigningKeyEnabled :(BOOL)newSigningKeyEnabled NS_SWIFT_NAME(setSigningKeyEnabled(_:));

@property (nonatomic,readonly,assign,getter=signingKeyEncryptionAlgorithm) NSString* signingKeyEncryptionAlgorithm NS_SWIFT_NAME(signingKeyEncryptionAlgorithm);

- (NSString*)signingKeyEncryptionAlgorithm NS_SWIFT_NAME(signingKeyEncryptionAlgorithm());

@property (nonatomic,readwrite,assign,getter=signingKeyHandle,setter=setSigningKeyHandle:) long long signingKeyHandle NS_SWIFT_NAME(signingKeyHandle);

- (long long)signingKeyHandle NS_SWIFT_NAME(signingKeyHandle());
- (void)setSigningKeyHandle :(long long)newSigningKeyHandle NS_SWIFT_NAME(setSigningKeyHandle(_:));

@property (nonatomic,readonly,assign,getter=signingKeyIsPublic) BOOL signingKeyIsPublic NS_SWIFT_NAME(signingKeyIsPublic);

- (BOOL)signingKeyIsPublic NS_SWIFT_NAME(signingKeyIsPublic());

@property (nonatomic,readonly,assign,getter=signingKeyIsSecret) BOOL signingKeyIsSecret NS_SWIFT_NAME(signingKeyIsSecret);

- (BOOL)signingKeyIsSecret NS_SWIFT_NAME(signingKeyIsSecret());

@property (nonatomic,readonly,assign,getter=signingKeyIsSubkey) BOOL signingKeyIsSubkey NS_SWIFT_NAME(signingKeyIsSubkey);

- (BOOL)signingKeyIsSubkey NS_SWIFT_NAME(signingKeyIsSubkey());

@property (nonatomic,readonly,assign,getter=signingKeyKeyFP) NSString* signingKeyKeyFP NS_SWIFT_NAME(signingKeyKeyFP);

- (NSString*)signingKeyKeyFP NS_SWIFT_NAME(signingKeyKeyFP());

@property (nonatomic,readonly,assign,getter=signingKeyKeyID) NSString* signingKeyKeyID NS_SWIFT_NAME(signingKeyKeyID);

- (NSString*)signingKeyKeyID NS_SWIFT_NAME(signingKeyKeyID());

@property (nonatomic,readwrite,assign,getter=signingKeyPassphrase,setter=setSigningKeyPassphrase:) NSString* signingKeyPassphrase NS_SWIFT_NAME(signingKeyPassphrase);

- (NSString*)signingKeyPassphrase NS_SWIFT_NAME(signingKeyPassphrase());
- (void)setSigningKeyPassphrase :(NSString*)newSigningKeyPassphrase NS_SWIFT_NAME(setSigningKeyPassphrase(_:));

@property (nonatomic,readonly,assign,getter=signingKeyPassphraseValid) BOOL signingKeyPassphraseValid NS_SWIFT_NAME(signingKeyPassphraseValid);

- (BOOL)signingKeyPassphraseValid NS_SWIFT_NAME(signingKeyPassphraseValid());

@property (nonatomic,readonly,assign,getter=signingKeyPrimaryKeyID) NSString* signingKeyPrimaryKeyID NS_SWIFT_NAME(signingKeyPrimaryKeyID);

- (NSString*)signingKeyPrimaryKeyID NS_SWIFT_NAME(signingKeyPrimaryKeyID());

@property (nonatomic,readonly,assign,getter=signingKeyProtection) int signingKeyProtection NS_SWIFT_NAME(signingKeyProtection);

- (int)signingKeyProtection NS_SWIFT_NAME(signingKeyProtection());

@property (nonatomic,readonly,assign,getter=signingKeyPublicKeyAlgorithm) NSString* signingKeyPublicKeyAlgorithm NS_SWIFT_NAME(signingKeyPublicKeyAlgorithm);

- (NSString*)signingKeyPublicKeyAlgorithm NS_SWIFT_NAME(signingKeyPublicKeyAlgorithm());

@property (nonatomic,readonly,assign,getter=signingKeyQBits) int signingKeyQBits NS_SWIFT_NAME(signingKeyQBits);

- (int)signingKeyQBits NS_SWIFT_NAME(signingKeyQBits());

@property (nonatomic,readonly,assign,getter=signingKeyTimestamp) NSString* signingKeyTimestamp NS_SWIFT_NAME(signingKeyTimestamp);

- (NSString*)signingKeyTimestamp NS_SWIFT_NAME(signingKeyTimestamp());

@property (nonatomic,readonly,assign,getter=signingKeyUsername) NSString* signingKeyUsername NS_SWIFT_NAME(signingKeyUsername);

- (NSString*)signingKeyUsername NS_SWIFT_NAME(signingKeyUsername());

@property (nonatomic,readonly,assign,getter=signingKeyValidTo) NSString* signingKeyValidTo NS_SWIFT_NAME(signingKeyValidTo);

- (NSString*)signingKeyValidTo NS_SWIFT_NAME(signingKeyValidTo());

@property (nonatomic,readonly,assign,getter=signingKeyVersion) int signingKeyVersion NS_SWIFT_NAME(signingKeyVersion);

- (int)signingKeyVersion NS_SWIFT_NAME(signingKeyVersion());

@property (nonatomic,readonly,assign,getter=subkeyCount) int subkeyCount NS_SWIFT_NAME(subkeyCount);

- (int)subkeyCount NS_SWIFT_NAME(subkeyCount());

- (int)subkeyBitsInKey:(int)subkeyIndex NS_SWIFT_NAME(subkeyBitsInKey(_:));

- (BOOL)subkeyCanEncrypt:(int)subkeyIndex NS_SWIFT_NAME(subkeyCanEncrypt(_:));

- (BOOL)subkeyCanSign:(int)subkeyIndex NS_SWIFT_NAME(subkeyCanSign(_:));

- (NSString*)subkeyCurve:(int)subkeyIndex NS_SWIFT_NAME(subkeyCurve(_:));

- (BOOL)subkeyEnabled:(int)subkeyIndex NS_SWIFT_NAME(subkeyEnabled(_:));

- (NSString*)subkeyEncryptionAlgorithm:(int)subkeyIndex NS_SWIFT_NAME(subkeyEncryptionAlgorithm(_:));

- (long long)subkeyHandle:(int)subkeyIndex NS_SWIFT_NAME(subkeyHandle(_:));

- (BOOL)subkeyIsPublic:(int)subkeyIndex NS_SWIFT_NAME(subkeyIsPublic(_:));

- (BOOL)subkeyIsSecret:(int)subkeyIndex NS_SWIFT_NAME(subkeyIsSecret(_:));

- (BOOL)subkeyIsSubkey:(int)subkeyIndex NS_SWIFT_NAME(subkeyIsSubkey(_:));

- (NSString*)subkeyKeyFP:(int)subkeyIndex NS_SWIFT_NAME(subkeyKeyFP(_:));

- (NSString*)subkeyKeyID:(int)subkeyIndex NS_SWIFT_NAME(subkeyKeyID(_:));

- (NSString*)subkeyPassphrase:(int)subkeyIndex NS_SWIFT_NAME(subkeyPassphrase(_:));

- (BOOL)subkeyPassphraseValid:(int)subkeyIndex NS_SWIFT_NAME(subkeyPassphraseValid(_:));

- (NSString*)subkeyPrimaryKeyID:(int)subkeyIndex NS_SWIFT_NAME(subkeyPrimaryKeyID(_:));

- (int)subkeyProtection:(int)subkeyIndex NS_SWIFT_NAME(subkeyProtection(_:));

- (NSString*)subkeyPublicKeyAlgorithm:(int)subkeyIndex NS_SWIFT_NAME(subkeyPublicKeyAlgorithm(_:));

- (int)subkeyQBits:(int)subkeyIndex NS_SWIFT_NAME(subkeyQBits(_:));

- (NSString*)subkeyTimestamp:(int)subkeyIndex NS_SWIFT_NAME(subkeyTimestamp(_:));

- (NSString*)subkeyUsername:(int)subkeyIndex NS_SWIFT_NAME(subkeyUsername(_:));

- (NSString*)subkeyValidTo:(int)subkeyIndex NS_SWIFT_NAME(subkeyValidTo(_:));

- (int)subkeyVersion:(int)subkeyIndex NS_SWIFT_NAME(subkeyVersion(_:));

@property (nonatomic,readonly,assign,getter=userCount) int userCount NS_SWIFT_NAME(userCount);

- (int)userCount NS_SWIFT_NAME(userCount());

- (long long)userHandle:(int)userIndex NS_SWIFT_NAME(userHandle(_:));

- (NSString*)userUsername:(int)userIndex NS_SWIFT_NAME(userUsername(_:));

  /* Methods */

- (void)changePassphrase:(NSString*)oldPassphrase :(NSString*)newPassphrase NS_SWIFT_NAME(changePassphrase(_:_:));

- (void)changeProtection:(NSString*)oldPassphrase :(NSString*)newPassphrase :(int)protType :(NSString*)encAlgorithm :(NSString*)hashAlgorithm NS_SWIFT_NAME(changeProtection(_:_:_:_:_:));

- (BOOL)checkPassphrase:(NSString*)passphrase NS_SWIFT_NAME(checkPassphrase(_:));

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (void)createKey:(int)version :(NSString*)algorithm :(int)bits :(NSString*)validTo :(NSString*)password NS_SWIFT_NAME(createKey(_:_:_:_:_:));

- (void)createSubkey:(NSString*)algorithm :(int)bits :(NSString*)validTo :(NSString*)password NS_SWIFT_NAME(createSubkey(_:_:_:_:));

- (void)createUser:(NSString*)username NS_SWIFT_NAME(createUser(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (NSData*)exportBytes:(BOOL)secret NS_SWIFT_NAME(exportBytes(_:));

- (void)exportToFile:(NSString*)fileName :(BOOL)secret NS_SWIFT_NAME(exportToFile(_:_:));

- (void)generatePair:(int)version :(NSString*)username :(int)strength :(NSString*)validTo :(NSString*)password NS_SWIFT_NAME(generatePair(_:_:_:_:_:));

- (void)importBytes:(NSData*)key NS_SWIFT_NAME(importBytes(_:));

- (void)importFromFile:(NSString*)fileName NS_SWIFT_NAME(importFromFile(_:));

- (void)importPinned NS_SWIFT_NAME(importPinned());

- (void)removeSignature:(int)index NS_SWIFT_NAME(removeSignature(_:));

- (void)removeSubkey:(int)index NS_SWIFT_NAME(removeSubkey(_:));

- (void)removeUser:(int)index NS_SWIFT_NAME(removeUser(_:));

- (void)reset NS_SWIFT_NAME(reset());

- (void)revokeKey:(int)reason :(NSString*)comment NS_SWIFT_NAME(revokeKey(_:_:));

- (void)revokeSubkey:(int)index :(int)reason :(NSString*)comment NS_SWIFT_NAME(revokeSubkey(_:_:_:));

- (void)revokeUser:(int)index :(int)reason :(NSString*)comment NS_SWIFT_NAME(revokeUser(_:_:_:));

- (void)signKey:(NSString*)keyValidTo :(NSString*)hashAlgorithm :(NSString*)preferredAlgs :(int)keyFlags NS_SWIFT_NAME(signKey(_:_:_:_:));

- (void)signSubkey:(int)index :(NSString*)keyValidTo :(NSString*)hashAlgorithm :(NSString*)preferredAlgs :(int)keyFlags NS_SWIFT_NAME(signSubkey(_:_:_:_:_:));

- (void)signUser:(int)index :(NSString*)keyValidTo :(NSString*)hashAlgorithm :(BOOL)primary :(int)certType NS_SWIFT_NAME(signUser(_:_:_:_:_:));

- (BOOL)verify:(int)index NS_SWIFT_NAME(verify(_:));

@end

