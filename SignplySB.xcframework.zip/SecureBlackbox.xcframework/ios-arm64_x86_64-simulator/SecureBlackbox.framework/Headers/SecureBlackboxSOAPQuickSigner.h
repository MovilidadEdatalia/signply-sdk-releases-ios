/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//XMLCANONICALIZATIONMETHODS
#define CXCM_NONE                                          0

#define CXCM_CANON                                         1

#define CXCM_CANON_COMMENT                                 2

#define CXCM_EXCL_CANON                                    3

#define CXCM_EXCL_CANON_COMMENT                            4

#define CXCM_MIN_CANON                                     5

#define CXCM_CANON_V_1_1                                   6

#define CXCM_CANON_COMMENT_V_1_1                           7

//WSSEMBEDCERTIFICATEMETHODS
#define CWEC_IN_SIGNATURE                                  0

#define CWEC_IN_BINARY_SECURITY_TOKEN                      1

#define CWEC_IN_SIGNED_BINARY_SECURITY_TOKEN               2

#define CWEC_IN_BINARY_SECURITY_TOKEN_AND_SIGNATURE        3

#define CWEC_NONE                                          4

//ASYNCSIGNMETHODS
#define ASMD_PKCS1                                         0

#define ASMD_PKCS7                                         1

//EXTERNALCRYPTOMODES
#define ECM_DEFAULT                                        0

#define ECM_DISABLED                                       1

#define ECM_GENERIC                                        2

#define ECM_DCAUTH                                         3

#define ECM_DCAUTH_JSON                                    4

//XMLREFERENCETARGETTYPES
#define RTT_AUTO                                           0

#define RTT_XMLELEMENT                                     1

#define RTT_DATA                                           2

#define RTT_URI                                            3

//SOAPSIGNATURETYPES
#define SST_UNKNOWN                                        0

#define SST_WSSSIGNATURE                                   1

#define SST_SOAPSIGNATURE                                  2

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxSOAPQuickSignerDelegate <NSObject>
@optional
- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onExternalSign:(NSString*)operationId :(NSString*)hashAlgorithm :(NSString*)pars :(NSString*)data :(NSString**)signedData NS_SWIFT_NAME(onExternalSign(_:_:_:_:_:));

- (void)onFormatElement:(NSString**)startTagWhitespace :(NSString**)endTagWhitespace :(int)level :(NSString*)path :(BOOL)hasChildElements NS_SWIFT_NAME(onFormatElement(_:_:_:_:_:));

- (void)onFormatText:(NSString**)text :(int)textType :(int)level :(NSString*)path NS_SWIFT_NAME(onFormatText(_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onResolveReference:(int)referenceIndex :(NSString*)URI NS_SWIFT_NAME(onResolveReference(_:_:));

@end

@interface SecureBlackboxSOAPQuickSigner : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxSOAPQuickSignerDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasError;

  BOOL m_delegateHasExternalSign;

  BOOL m_delegateHasFormatElement;

  BOOL m_delegateHasFormatText;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasResolveReference;

}

+ (SecureBlackboxSOAPQuickSigner*)soapquicksigner;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxSOAPQuickSignerDelegate> delegate;
- (id <SecureBlackboxSOAPQuickSignerDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxSOAPQuickSignerDelegate>)anObject;

  /* Events */

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onExternalSign:(NSString*)operationId :(NSString*)hashAlgorithm :(NSString*)pars :(NSString*)data :(NSString**)signedData NS_SWIFT_NAME(onExternalSign(_:_:_:_:_:));

- (void)onFormatElement:(NSString**)startTagWhitespace :(NSString**)endTagWhitespace :(int)level :(NSString*)path :(BOOL)hasChildElements NS_SWIFT_NAME(onFormatElement(_:_:_:_:_:));

- (void)onFormatText:(NSString**)text :(int)textType :(int)level :(NSString*)path NS_SWIFT_NAME(onFormatText(_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onResolveReference:(int)referenceIndex :(NSString*)URI NS_SWIFT_NAME(onResolveReference(_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readwrite,assign,getter=canonicalizationMethod,setter=setCanonicalizationMethod:) int canonicalizationMethod NS_SWIFT_NAME(canonicalizationMethod);

- (int)canonicalizationMethod NS_SWIFT_NAME(canonicalizationMethod());
- (void)setCanonicalizationMethod :(int)newCanonicalizationMethod NS_SWIFT_NAME(setCanonicalizationMethod(_:));

@property (nonatomic,readwrite,assign,getter=embedCertificateMethod,setter=setEmbedCertificateMethod:) int embedCertificateMethod NS_SWIFT_NAME(embedCertificateMethod);

- (int)embedCertificateMethod NS_SWIFT_NAME(embedCertificateMethod());
- (void)setEmbedCertificateMethod :(int)newEmbedCertificateMethod NS_SWIFT_NAME(setEmbedCertificateMethod(_:));

@property (nonatomic,readwrite,assign,getter=encoding,setter=setEncoding:) NSString* encoding NS_SWIFT_NAME(encoding);

- (NSString*)encoding NS_SWIFT_NAME(encoding());
- (void)setEncoding :(NSString*)newEncoding NS_SWIFT_NAME(setEncoding(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoAsyncDocumentID,setter=setExternalCryptoAsyncDocumentID:) NSString* externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID);

- (NSString*)externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID());
- (void)setExternalCryptoAsyncDocumentID :(NSString*)newExternalCryptoAsyncDocumentID NS_SWIFT_NAME(setExternalCryptoAsyncDocumentID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoCustomParams,setter=setExternalCryptoCustomParams:) NSString* externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams);

- (NSString*)externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams());
- (void)setExternalCryptoCustomParams :(NSString*)newExternalCryptoCustomParams NS_SWIFT_NAME(setExternalCryptoCustomParams(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoData,setter=setExternalCryptoData:) NSString* externalCryptoData NS_SWIFT_NAME(externalCryptoData);

- (NSString*)externalCryptoData NS_SWIFT_NAME(externalCryptoData());
- (void)setExternalCryptoData :(NSString*)newExternalCryptoData NS_SWIFT_NAME(setExternalCryptoData(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoExternalHashCalculation,setter=setExternalCryptoExternalHashCalculation:) BOOL externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation);

- (BOOL)externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation());
- (void)setExternalCryptoExternalHashCalculation :(BOOL)newExternalCryptoExternalHashCalculation NS_SWIFT_NAME(setExternalCryptoExternalHashCalculation(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoHashAlgorithm,setter=setExternalCryptoHashAlgorithm:) NSString* externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm);

- (NSString*)externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm());
- (void)setExternalCryptoHashAlgorithm :(NSString*)newExternalCryptoHashAlgorithm NS_SWIFT_NAME(setExternalCryptoHashAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeyID,setter=setExternalCryptoKeyID:) NSString* externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID);

- (NSString*)externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID());
- (void)setExternalCryptoKeyID :(NSString*)newExternalCryptoKeyID NS_SWIFT_NAME(setExternalCryptoKeyID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeySecret,setter=setExternalCryptoKeySecret:) NSString* externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret);

- (NSString*)externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret());
- (void)setExternalCryptoKeySecret :(NSString*)newExternalCryptoKeySecret NS_SWIFT_NAME(setExternalCryptoKeySecret(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMethod,setter=setExternalCryptoMethod:) int externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod);

- (int)externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod());
- (void)setExternalCryptoMethod :(int)newExternalCryptoMethod NS_SWIFT_NAME(setExternalCryptoMethod(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMode,setter=setExternalCryptoMode:) int externalCryptoMode NS_SWIFT_NAME(externalCryptoMode);

- (int)externalCryptoMode NS_SWIFT_NAME(externalCryptoMode());
- (void)setExternalCryptoMode :(int)newExternalCryptoMode NS_SWIFT_NAME(setExternalCryptoMode(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoPublicKeyAlgorithm,setter=setExternalCryptoPublicKeyAlgorithm:) NSString* externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm);

- (NSString*)externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm());
- (void)setExternalCryptoPublicKeyAlgorithm :(NSString*)newExternalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(setExternalCryptoPublicKeyAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=hashAlgorithm,setter=setHashAlgorithm:) NSString* hashAlgorithm NS_SWIFT_NAME(hashAlgorithm);

- (NSString*)hashAlgorithm NS_SWIFT_NAME(hashAlgorithm());
- (void)setHashAlgorithm :(NSString*)newHashAlgorithm NS_SWIFT_NAME(setHashAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=inputFile,setter=setInputFile:) NSString* inputFile NS_SWIFT_NAME(inputFile);

- (NSString*)inputFile NS_SWIFT_NAME(inputFile());
- (void)setInputFile :(NSString*)newInputFile NS_SWIFT_NAME(setInputFile(_:));

@property (nonatomic,readwrite,assign,getter=outputFile,setter=setOutputFile:) NSString* outputFile NS_SWIFT_NAME(outputFile);

- (NSString*)outputFile NS_SWIFT_NAME(outputFile());
- (void)setOutputFile :(NSString*)newOutputFile NS_SWIFT_NAME(setOutputFile(_:));

@property (nonatomic,readwrite,assign,getter=referenceCount,setter=setReferenceCount:) int referenceCount NS_SWIFT_NAME(referenceCount);

- (int)referenceCount NS_SWIFT_NAME(referenceCount());
- (void)setReferenceCount :(int)newReferenceCount NS_SWIFT_NAME(setReferenceCount(_:));

- (BOOL)referenceAutoGenerateElementId:(int)referenceIndex NS_SWIFT_NAME(referenceAutoGenerateElementId(_:));
- (void)setReferenceAutoGenerateElementId:(int)referenceIndex :(BOOL)newReferenceAutoGenerateElementId NS_SWIFT_NAME(setReferenceAutoGenerateElementId(_:_:));

- (int)referenceCanonicalizationMethod:(int)referenceIndex NS_SWIFT_NAME(referenceCanonicalizationMethod(_:));
- (void)setReferenceCanonicalizationMethod:(int)referenceIndex :(int)newReferenceCanonicalizationMethod NS_SWIFT_NAME(setReferenceCanonicalizationMethod(_:_:));

- (NSString*)referenceCustomElementId:(int)referenceIndex NS_SWIFT_NAME(referenceCustomElementId(_:));
- (void)setReferenceCustomElementId:(int)referenceIndex :(NSString*)newReferenceCustomElementId NS_SWIFT_NAME(setReferenceCustomElementId(_:_:));

- (NSString*)referenceDataObjectDescription:(int)referenceIndex NS_SWIFT_NAME(referenceDataObjectDescription(_:));
- (void)setReferenceDataObjectDescription:(int)referenceIndex :(NSString*)newReferenceDataObjectDescription NS_SWIFT_NAME(setReferenceDataObjectDescription(_:_:));

- (NSString*)referenceDataObjectEncoding:(int)referenceIndex NS_SWIFT_NAME(referenceDataObjectEncoding(_:));
- (void)setReferenceDataObjectEncoding:(int)referenceIndex :(NSString*)newReferenceDataObjectEncoding NS_SWIFT_NAME(setReferenceDataObjectEncoding(_:_:));

- (NSString*)referenceDataObjectIdentifier:(int)referenceIndex NS_SWIFT_NAME(referenceDataObjectIdentifier(_:));
- (void)setReferenceDataObjectIdentifier:(int)referenceIndex :(NSString*)newReferenceDataObjectIdentifier NS_SWIFT_NAME(setReferenceDataObjectIdentifier(_:_:));

- (NSString*)referenceDataObjectMimeType:(int)referenceIndex NS_SWIFT_NAME(referenceDataObjectMimeType(_:));
- (void)setReferenceDataObjectMimeType:(int)referenceIndex :(NSString*)newReferenceDataObjectMimeType NS_SWIFT_NAME(setReferenceDataObjectMimeType(_:_:));

- (NSData*)referenceDigestValue:(int)referenceIndex NS_SWIFT_NAME(referenceDigestValue(_:));
- (void)setReferenceDigestValue:(int)referenceIndex :(NSData*)newReferenceDigestValue NS_SWIFT_NAME(setReferenceDigestValue(_:_:));

- (long long)referenceHandle:(int)referenceIndex NS_SWIFT_NAME(referenceHandle(_:));
- (void)setReferenceHandle:(int)referenceIndex :(long long)newReferenceHandle NS_SWIFT_NAME(setReferenceHandle(_:_:));

- (BOOL)referenceHasDataObjectFormat:(int)referenceIndex NS_SWIFT_NAME(referenceHasDataObjectFormat(_:));
- (void)setReferenceHasDataObjectFormat:(int)referenceIndex :(BOOL)newReferenceHasDataObjectFormat NS_SWIFT_NAME(setReferenceHasDataObjectFormat(_:_:));

- (NSString*)referenceHashAlgorithm:(int)referenceIndex NS_SWIFT_NAME(referenceHashAlgorithm(_:));
- (void)setReferenceHashAlgorithm:(int)referenceIndex :(NSString*)newReferenceHashAlgorithm NS_SWIFT_NAME(setReferenceHashAlgorithm(_:_:));

- (BOOL)referenceHasURI:(int)referenceIndex NS_SWIFT_NAME(referenceHasURI(_:));
- (void)setReferenceHasURI:(int)referenceIndex :(BOOL)newReferenceHasURI NS_SWIFT_NAME(setReferenceHasURI(_:_:));

- (NSString*)referenceID:(int)referenceIndex NS_SWIFT_NAME(referenceID(_:));
- (void)setReferenceID:(int)referenceIndex :(NSString*)newReferenceID NS_SWIFT_NAME(setReferenceID(_:_:));

- (NSString*)referenceInclusiveNamespacesPrefixList:(int)referenceIndex NS_SWIFT_NAME(referenceInclusiveNamespacesPrefixList(_:));
- (void)setReferenceInclusiveNamespacesPrefixList:(int)referenceIndex :(NSString*)newReferenceInclusiveNamespacesPrefixList NS_SWIFT_NAME(setReferenceInclusiveNamespacesPrefixList(_:_:));

- (NSString*)referenceReferenceType:(int)referenceIndex NS_SWIFT_NAME(referenceReferenceType(_:));
- (void)setReferenceReferenceType:(int)referenceIndex :(NSString*)newReferenceReferenceType NS_SWIFT_NAME(setReferenceReferenceType(_:_:));

- (NSData*)referenceTargetData:(int)referenceIndex NS_SWIFT_NAME(referenceTargetData(_:));
- (void)setReferenceTargetData:(int)referenceIndex :(NSData*)newReferenceTargetData NS_SWIFT_NAME(setReferenceTargetData(_:_:));

- (int)referenceTargetType:(int)referenceIndex NS_SWIFT_NAME(referenceTargetType(_:));
- (void)setReferenceTargetType:(int)referenceIndex :(int)newReferenceTargetType NS_SWIFT_NAME(setReferenceTargetType(_:_:));

- (NSString*)referenceTargetXMLElement:(int)referenceIndex NS_SWIFT_NAME(referenceTargetXMLElement(_:));
- (void)setReferenceTargetXMLElement:(int)referenceIndex :(NSString*)newReferenceTargetXMLElement NS_SWIFT_NAME(setReferenceTargetXMLElement(_:_:));

- (NSString*)referenceURI:(int)referenceIndex NS_SWIFT_NAME(referenceURI(_:));
- (void)setReferenceURI:(int)referenceIndex :(NSString*)newReferenceURI NS_SWIFT_NAME(setReferenceURI(_:_:));

- (BOOL)referenceUseBase64Transform:(int)referenceIndex NS_SWIFT_NAME(referenceUseBase64Transform(_:));
- (void)setReferenceUseBase64Transform:(int)referenceIndex :(BOOL)newReferenceUseBase64Transform NS_SWIFT_NAME(setReferenceUseBase64Transform(_:_:));

- (BOOL)referenceUseEnvelopedSignatureTransform:(int)referenceIndex NS_SWIFT_NAME(referenceUseEnvelopedSignatureTransform(_:));
- (void)setReferenceUseEnvelopedSignatureTransform:(int)referenceIndex :(BOOL)newReferenceUseEnvelopedSignatureTransform NS_SWIFT_NAME(setReferenceUseEnvelopedSignatureTransform(_:_:));

- (BOOL)referenceUseXPathFilter2Transform:(int)referenceIndex NS_SWIFT_NAME(referenceUseXPathFilter2Transform(_:));
- (void)setReferenceUseXPathFilter2Transform:(int)referenceIndex :(BOOL)newReferenceUseXPathFilter2Transform NS_SWIFT_NAME(setReferenceUseXPathFilter2Transform(_:_:));

- (BOOL)referenceUseXPathTransform:(int)referenceIndex NS_SWIFT_NAME(referenceUseXPathTransform(_:));
- (void)setReferenceUseXPathTransform:(int)referenceIndex :(BOOL)newReferenceUseXPathTransform NS_SWIFT_NAME(setReferenceUseXPathTransform(_:_:));

- (BOOL)referenceValidationResult:(int)referenceIndex NS_SWIFT_NAME(referenceValidationResult(_:));

- (NSString*)referenceXPathExpression:(int)referenceIndex NS_SWIFT_NAME(referenceXPathExpression(_:));
- (void)setReferenceXPathExpression:(int)referenceIndex :(NSString*)newReferenceXPathExpression NS_SWIFT_NAME(setReferenceXPathExpression(_:_:));

- (NSString*)referenceXPathFilter2Expressions:(int)referenceIndex NS_SWIFT_NAME(referenceXPathFilter2Expressions(_:));
- (void)setReferenceXPathFilter2Expressions:(int)referenceIndex :(NSString*)newReferenceXPathFilter2Expressions NS_SWIFT_NAME(setReferenceXPathFilter2Expressions(_:_:));

- (NSString*)referenceXPathFilter2Filters:(int)referenceIndex NS_SWIFT_NAME(referenceXPathFilter2Filters(_:));
- (void)setReferenceXPathFilter2Filters:(int)referenceIndex :(NSString*)newReferenceXPathFilter2Filters NS_SWIFT_NAME(setReferenceXPathFilter2Filters(_:_:));

- (NSString*)referenceXPathFilter2PrefixList:(int)referenceIndex NS_SWIFT_NAME(referenceXPathFilter2PrefixList(_:));
- (void)setReferenceXPathFilter2PrefixList:(int)referenceIndex :(NSString*)newReferenceXPathFilter2PrefixList NS_SWIFT_NAME(setReferenceXPathFilter2PrefixList(_:_:));

- (NSString*)referenceXPathPrefixList:(int)referenceIndex NS_SWIFT_NAME(referenceXPathPrefixList(_:));
- (void)setReferenceXPathPrefixList:(int)referenceIndex :(NSString*)newReferenceXPathPrefixList NS_SWIFT_NAME(setReferenceXPathPrefixList(_:_:));

@property (nonatomic,readwrite,assign,getter=securityHeaderIndex,setter=setSecurityHeaderIndex:) int securityHeaderIndex NS_SWIFT_NAME(securityHeaderIndex);

- (int)securityHeaderIndex NS_SWIFT_NAME(securityHeaderIndex());
- (void)setSecurityHeaderIndex :(int)newSecurityHeaderIndex NS_SWIFT_NAME(setSecurityHeaderIndex(_:));

@property (nonatomic,readwrite,assign,getter=signatureType,setter=setSignatureType:) int signatureType NS_SWIFT_NAME(signatureType);

- (int)signatureType NS_SWIFT_NAME(signatureType());
- (void)setSignatureType :(int)newSignatureType NS_SWIFT_NAME(setSignatureType(_:));

@property (nonatomic,readonly,assign,getter=signingCertBytes) NSData* signingCertBytes NS_SWIFT_NAME(signingCertBytes);

- (NSData*)signingCertBytes NS_SWIFT_NAME(signingCertBytes());

@property (nonatomic,readwrite,assign,getter=signingCertCA,setter=setSigningCertCA:) BOOL signingCertCA NS_SWIFT_NAME(signingCertCA);

- (BOOL)signingCertCA NS_SWIFT_NAME(signingCertCA());
- (void)setSigningCertCA :(BOOL)newSigningCertCA NS_SWIFT_NAME(setSigningCertCA(_:));

@property (nonatomic,readonly,assign,getter=signingCertCAKeyID) NSData* signingCertCAKeyID NS_SWIFT_NAME(signingCertCAKeyID);

- (NSData*)signingCertCAKeyID NS_SWIFT_NAME(signingCertCAKeyID());

@property (nonatomic,readonly,assign,getter=signingCertCertType) int signingCertCertType NS_SWIFT_NAME(signingCertCertType);

- (int)signingCertCertType NS_SWIFT_NAME(signingCertCertType());

@property (nonatomic,readwrite,assign,getter=signingCertCRLDistributionPoints,setter=setSigningCertCRLDistributionPoints:) NSString* signingCertCRLDistributionPoints NS_SWIFT_NAME(signingCertCRLDistributionPoints);

- (NSString*)signingCertCRLDistributionPoints NS_SWIFT_NAME(signingCertCRLDistributionPoints());
- (void)setSigningCertCRLDistributionPoints :(NSString*)newSigningCertCRLDistributionPoints NS_SWIFT_NAME(setSigningCertCRLDistributionPoints(_:));

@property (nonatomic,readwrite,assign,getter=signingCertCurve,setter=setSigningCertCurve:) NSString* signingCertCurve NS_SWIFT_NAME(signingCertCurve);

- (NSString*)signingCertCurve NS_SWIFT_NAME(signingCertCurve());
- (void)setSigningCertCurve :(NSString*)newSigningCertCurve NS_SWIFT_NAME(setSigningCertCurve(_:));

@property (nonatomic,readonly,assign,getter=signingCertFingerprint) NSString* signingCertFingerprint NS_SWIFT_NAME(signingCertFingerprint);

- (NSString*)signingCertFingerprint NS_SWIFT_NAME(signingCertFingerprint());

@property (nonatomic,readonly,assign,getter=signingCertFriendlyName) NSString* signingCertFriendlyName NS_SWIFT_NAME(signingCertFriendlyName);

- (NSString*)signingCertFriendlyName NS_SWIFT_NAME(signingCertFriendlyName());

@property (nonatomic,readwrite,assign,getter=signingCertHandle,setter=setSigningCertHandle:) long long signingCertHandle NS_SWIFT_NAME(signingCertHandle);

- (long long)signingCertHandle NS_SWIFT_NAME(signingCertHandle());
- (void)setSigningCertHandle :(long long)newSigningCertHandle NS_SWIFT_NAME(setSigningCertHandle(_:));

@property (nonatomic,readwrite,assign,getter=signingCertHashAlgorithm,setter=setSigningCertHashAlgorithm:) NSString* signingCertHashAlgorithm NS_SWIFT_NAME(signingCertHashAlgorithm);

- (NSString*)signingCertHashAlgorithm NS_SWIFT_NAME(signingCertHashAlgorithm());
- (void)setSigningCertHashAlgorithm :(NSString*)newSigningCertHashAlgorithm NS_SWIFT_NAME(setSigningCertHashAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=signingCertIssuer) NSString* signingCertIssuer NS_SWIFT_NAME(signingCertIssuer);

- (NSString*)signingCertIssuer NS_SWIFT_NAME(signingCertIssuer());

@property (nonatomic,readwrite,assign,getter=signingCertIssuerRDN,setter=setSigningCertIssuerRDN:) NSString* signingCertIssuerRDN NS_SWIFT_NAME(signingCertIssuerRDN);

- (NSString*)signingCertIssuerRDN NS_SWIFT_NAME(signingCertIssuerRDN());
- (void)setSigningCertIssuerRDN :(NSString*)newSigningCertIssuerRDN NS_SWIFT_NAME(setSigningCertIssuerRDN(_:));

@property (nonatomic,readwrite,assign,getter=signingCertKeyAlgorithm,setter=setSigningCertKeyAlgorithm:) NSString* signingCertKeyAlgorithm NS_SWIFT_NAME(signingCertKeyAlgorithm);

- (NSString*)signingCertKeyAlgorithm NS_SWIFT_NAME(signingCertKeyAlgorithm());
- (void)setSigningCertKeyAlgorithm :(NSString*)newSigningCertKeyAlgorithm NS_SWIFT_NAME(setSigningCertKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=signingCertKeyBits) int signingCertKeyBits NS_SWIFT_NAME(signingCertKeyBits);

- (int)signingCertKeyBits NS_SWIFT_NAME(signingCertKeyBits());

@property (nonatomic,readonly,assign,getter=signingCertKeyFingerprint) NSString* signingCertKeyFingerprint NS_SWIFT_NAME(signingCertKeyFingerprint);

- (NSString*)signingCertKeyFingerprint NS_SWIFT_NAME(signingCertKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=signingCertKeyUsage,setter=setSigningCertKeyUsage:) int signingCertKeyUsage NS_SWIFT_NAME(signingCertKeyUsage);

- (int)signingCertKeyUsage NS_SWIFT_NAME(signingCertKeyUsage());
- (void)setSigningCertKeyUsage :(int)newSigningCertKeyUsage NS_SWIFT_NAME(setSigningCertKeyUsage(_:));

@property (nonatomic,readonly,assign,getter=signingCertKeyValid) BOOL signingCertKeyValid NS_SWIFT_NAME(signingCertKeyValid);

- (BOOL)signingCertKeyValid NS_SWIFT_NAME(signingCertKeyValid());

@property (nonatomic,readwrite,assign,getter=signingCertOCSPLocations,setter=setSigningCertOCSPLocations:) NSString* signingCertOCSPLocations NS_SWIFT_NAME(signingCertOCSPLocations);

- (NSString*)signingCertOCSPLocations NS_SWIFT_NAME(signingCertOCSPLocations());
- (void)setSigningCertOCSPLocations :(NSString*)newSigningCertOCSPLocations NS_SWIFT_NAME(setSigningCertOCSPLocations(_:));

@property (nonatomic,readwrite,assign,getter=signingCertOCSPNoCheck,setter=setSigningCertOCSPNoCheck:) BOOL signingCertOCSPNoCheck NS_SWIFT_NAME(signingCertOCSPNoCheck);

- (BOOL)signingCertOCSPNoCheck NS_SWIFT_NAME(signingCertOCSPNoCheck());
- (void)setSigningCertOCSPNoCheck :(BOOL)newSigningCertOCSPNoCheck NS_SWIFT_NAME(setSigningCertOCSPNoCheck(_:));

@property (nonatomic,readonly,assign,getter=signingCertOrigin) int signingCertOrigin NS_SWIFT_NAME(signingCertOrigin);

- (int)signingCertOrigin NS_SWIFT_NAME(signingCertOrigin());

@property (nonatomic,readwrite,assign,getter=signingCertPolicyIDs,setter=setSigningCertPolicyIDs:) NSString* signingCertPolicyIDs NS_SWIFT_NAME(signingCertPolicyIDs);

- (NSString*)signingCertPolicyIDs NS_SWIFT_NAME(signingCertPolicyIDs());
- (void)setSigningCertPolicyIDs :(NSString*)newSigningCertPolicyIDs NS_SWIFT_NAME(setSigningCertPolicyIDs(_:));

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyBytes) NSData* signingCertPrivateKeyBytes NS_SWIFT_NAME(signingCertPrivateKeyBytes);

- (NSData*)signingCertPrivateKeyBytes NS_SWIFT_NAME(signingCertPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyExists) BOOL signingCertPrivateKeyExists NS_SWIFT_NAME(signingCertPrivateKeyExists);

- (BOOL)signingCertPrivateKeyExists NS_SWIFT_NAME(signingCertPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyExtractable) BOOL signingCertPrivateKeyExtractable NS_SWIFT_NAME(signingCertPrivateKeyExtractable);

- (BOOL)signingCertPrivateKeyExtractable NS_SWIFT_NAME(signingCertPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=signingCertPublicKeyBytes) NSData* signingCertPublicKeyBytes NS_SWIFT_NAME(signingCertPublicKeyBytes);

- (NSData*)signingCertPublicKeyBytes NS_SWIFT_NAME(signingCertPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=signingCertQualified) BOOL signingCertQualified NS_SWIFT_NAME(signingCertQualified);

- (BOOL)signingCertQualified NS_SWIFT_NAME(signingCertQualified());

@property (nonatomic,readwrite,assign,getter=signingCertQualifiedStatements,setter=setSigningCertQualifiedStatements:) int signingCertQualifiedStatements NS_SWIFT_NAME(signingCertQualifiedStatements);

- (int)signingCertQualifiedStatements NS_SWIFT_NAME(signingCertQualifiedStatements());
- (void)setSigningCertQualifiedStatements :(int)newSigningCertQualifiedStatements NS_SWIFT_NAME(setSigningCertQualifiedStatements(_:));

@property (nonatomic,readonly,assign,getter=signingCertQualifiers) NSString* signingCertQualifiers NS_SWIFT_NAME(signingCertQualifiers);

- (NSString*)signingCertQualifiers NS_SWIFT_NAME(signingCertQualifiers());

@property (nonatomic,readonly,assign,getter=signingCertSelfSigned) BOOL signingCertSelfSigned NS_SWIFT_NAME(signingCertSelfSigned);

- (BOOL)signingCertSelfSigned NS_SWIFT_NAME(signingCertSelfSigned());

@property (nonatomic,readwrite,assign,getter=signingCertSerialNumber,setter=setSigningCertSerialNumber:) NSData* signingCertSerialNumber NS_SWIFT_NAME(signingCertSerialNumber);

- (NSData*)signingCertSerialNumber NS_SWIFT_NAME(signingCertSerialNumber());
- (void)setSigningCertSerialNumber :(NSData*)newSigningCertSerialNumber NS_SWIFT_NAME(setSigningCertSerialNumber(_:));

@property (nonatomic,readonly,assign,getter=signingCertSigAlgorithm) NSString* signingCertSigAlgorithm NS_SWIFT_NAME(signingCertSigAlgorithm);

- (NSString*)signingCertSigAlgorithm NS_SWIFT_NAME(signingCertSigAlgorithm());

@property (nonatomic,readonly,assign,getter=signingCertSource) int signingCertSource NS_SWIFT_NAME(signingCertSource);

- (int)signingCertSource NS_SWIFT_NAME(signingCertSource());

@property (nonatomic,readonly,assign,getter=signingCertSubject) NSString* signingCertSubject NS_SWIFT_NAME(signingCertSubject);

- (NSString*)signingCertSubject NS_SWIFT_NAME(signingCertSubject());

@property (nonatomic,readwrite,assign,getter=signingCertSubjectAlternativeName,setter=setSigningCertSubjectAlternativeName:) NSString* signingCertSubjectAlternativeName NS_SWIFT_NAME(signingCertSubjectAlternativeName);

- (NSString*)signingCertSubjectAlternativeName NS_SWIFT_NAME(signingCertSubjectAlternativeName());
- (void)setSigningCertSubjectAlternativeName :(NSString*)newSigningCertSubjectAlternativeName NS_SWIFT_NAME(setSigningCertSubjectAlternativeName(_:));

@property (nonatomic,readwrite,assign,getter=signingCertSubjectKeyID,setter=setSigningCertSubjectKeyID:) NSData* signingCertSubjectKeyID NS_SWIFT_NAME(signingCertSubjectKeyID);

- (NSData*)signingCertSubjectKeyID NS_SWIFT_NAME(signingCertSubjectKeyID());
- (void)setSigningCertSubjectKeyID :(NSData*)newSigningCertSubjectKeyID NS_SWIFT_NAME(setSigningCertSubjectKeyID(_:));

@property (nonatomic,readwrite,assign,getter=signingCertSubjectRDN,setter=setSigningCertSubjectRDN:) NSString* signingCertSubjectRDN NS_SWIFT_NAME(signingCertSubjectRDN);

- (NSString*)signingCertSubjectRDN NS_SWIFT_NAME(signingCertSubjectRDN());
- (void)setSigningCertSubjectRDN :(NSString*)newSigningCertSubjectRDN NS_SWIFT_NAME(setSigningCertSubjectRDN(_:));

@property (nonatomic,readonly,assign,getter=signingCertValid) BOOL signingCertValid NS_SWIFT_NAME(signingCertValid);

- (BOOL)signingCertValid NS_SWIFT_NAME(signingCertValid());

@property (nonatomic,readwrite,assign,getter=signingCertValidFrom,setter=setSigningCertValidFrom:) NSString* signingCertValidFrom NS_SWIFT_NAME(signingCertValidFrom);

- (NSString*)signingCertValidFrom NS_SWIFT_NAME(signingCertValidFrom());
- (void)setSigningCertValidFrom :(NSString*)newSigningCertValidFrom NS_SWIFT_NAME(setSigningCertValidFrom(_:));

@property (nonatomic,readwrite,assign,getter=signingCertValidTo,setter=setSigningCertValidTo:) NSString* signingCertValidTo NS_SWIFT_NAME(signingCertValidTo);

- (NSString*)signingCertValidTo NS_SWIFT_NAME(signingCertValidTo());
- (void)setSigningCertValidTo :(NSString*)newSigningCertValidTo NS_SWIFT_NAME(setSigningCertValidTo(_:));

@property (nonatomic,readwrite,assign,getter=signingChainCount,setter=setSigningChainCount:) int signingChainCount NS_SWIFT_NAME(signingChainCount);

- (int)signingChainCount NS_SWIFT_NAME(signingChainCount());
- (void)setSigningChainCount :(int)newSigningChainCount NS_SWIFT_NAME(setSigningChainCount(_:));

- (NSData*)signingChainBytes:(int)signingChainIndex NS_SWIFT_NAME(signingChainBytes(_:));

- (BOOL)signingChainCA:(int)signingChainIndex NS_SWIFT_NAME(signingChainCA(_:));
- (void)setSigningChainCA:(int)signingChainIndex :(BOOL)newSigningChainCA NS_SWIFT_NAME(setSigningChainCA(_:_:));

- (NSData*)signingChainCAKeyID:(int)signingChainIndex NS_SWIFT_NAME(signingChainCAKeyID(_:));

- (int)signingChainCertType:(int)signingChainIndex NS_SWIFT_NAME(signingChainCertType(_:));

- (NSString*)signingChainCRLDistributionPoints:(int)signingChainIndex NS_SWIFT_NAME(signingChainCRLDistributionPoints(_:));
- (void)setSigningChainCRLDistributionPoints:(int)signingChainIndex :(NSString*)newSigningChainCRLDistributionPoints NS_SWIFT_NAME(setSigningChainCRLDistributionPoints(_:_:));

- (NSString*)signingChainCurve:(int)signingChainIndex NS_SWIFT_NAME(signingChainCurve(_:));
- (void)setSigningChainCurve:(int)signingChainIndex :(NSString*)newSigningChainCurve NS_SWIFT_NAME(setSigningChainCurve(_:_:));

- (NSString*)signingChainFingerprint:(int)signingChainIndex NS_SWIFT_NAME(signingChainFingerprint(_:));

- (NSString*)signingChainFriendlyName:(int)signingChainIndex NS_SWIFT_NAME(signingChainFriendlyName(_:));

- (long long)signingChainHandle:(int)signingChainIndex NS_SWIFT_NAME(signingChainHandle(_:));
- (void)setSigningChainHandle:(int)signingChainIndex :(long long)newSigningChainHandle NS_SWIFT_NAME(setSigningChainHandle(_:_:));

- (NSString*)signingChainHashAlgorithm:(int)signingChainIndex NS_SWIFT_NAME(signingChainHashAlgorithm(_:));
- (void)setSigningChainHashAlgorithm:(int)signingChainIndex :(NSString*)newSigningChainHashAlgorithm NS_SWIFT_NAME(setSigningChainHashAlgorithm(_:_:));

- (NSString*)signingChainIssuer:(int)signingChainIndex NS_SWIFT_NAME(signingChainIssuer(_:));

- (NSString*)signingChainIssuerRDN:(int)signingChainIndex NS_SWIFT_NAME(signingChainIssuerRDN(_:));
- (void)setSigningChainIssuerRDN:(int)signingChainIndex :(NSString*)newSigningChainIssuerRDN NS_SWIFT_NAME(setSigningChainIssuerRDN(_:_:));

- (NSString*)signingChainKeyAlgorithm:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyAlgorithm(_:));
- (void)setSigningChainKeyAlgorithm:(int)signingChainIndex :(NSString*)newSigningChainKeyAlgorithm NS_SWIFT_NAME(setSigningChainKeyAlgorithm(_:_:));

- (int)signingChainKeyBits:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyBits(_:));

- (NSString*)signingChainKeyFingerprint:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyFingerprint(_:));

- (int)signingChainKeyUsage:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyUsage(_:));
- (void)setSigningChainKeyUsage:(int)signingChainIndex :(int)newSigningChainKeyUsage NS_SWIFT_NAME(setSigningChainKeyUsage(_:_:));

- (BOOL)signingChainKeyValid:(int)signingChainIndex NS_SWIFT_NAME(signingChainKeyValid(_:));

- (NSString*)signingChainOCSPLocations:(int)signingChainIndex NS_SWIFT_NAME(signingChainOCSPLocations(_:));
- (void)setSigningChainOCSPLocations:(int)signingChainIndex :(NSString*)newSigningChainOCSPLocations NS_SWIFT_NAME(setSigningChainOCSPLocations(_:_:));

- (BOOL)signingChainOCSPNoCheck:(int)signingChainIndex NS_SWIFT_NAME(signingChainOCSPNoCheck(_:));
- (void)setSigningChainOCSPNoCheck:(int)signingChainIndex :(BOOL)newSigningChainOCSPNoCheck NS_SWIFT_NAME(setSigningChainOCSPNoCheck(_:_:));

- (int)signingChainOrigin:(int)signingChainIndex NS_SWIFT_NAME(signingChainOrigin(_:));

- (NSString*)signingChainPolicyIDs:(int)signingChainIndex NS_SWIFT_NAME(signingChainPolicyIDs(_:));
- (void)setSigningChainPolicyIDs:(int)signingChainIndex :(NSString*)newSigningChainPolicyIDs NS_SWIFT_NAME(setSigningChainPolicyIDs(_:_:));

- (NSData*)signingChainPrivateKeyBytes:(int)signingChainIndex NS_SWIFT_NAME(signingChainPrivateKeyBytes(_:));

- (BOOL)signingChainPrivateKeyExists:(int)signingChainIndex NS_SWIFT_NAME(signingChainPrivateKeyExists(_:));

- (BOOL)signingChainPrivateKeyExtractable:(int)signingChainIndex NS_SWIFT_NAME(signingChainPrivateKeyExtractable(_:));

- (NSData*)signingChainPublicKeyBytes:(int)signingChainIndex NS_SWIFT_NAME(signingChainPublicKeyBytes(_:));

- (BOOL)signingChainQualified:(int)signingChainIndex NS_SWIFT_NAME(signingChainQualified(_:));

- (int)signingChainQualifiedStatements:(int)signingChainIndex NS_SWIFT_NAME(signingChainQualifiedStatements(_:));
- (void)setSigningChainQualifiedStatements:(int)signingChainIndex :(int)newSigningChainQualifiedStatements NS_SWIFT_NAME(setSigningChainQualifiedStatements(_:_:));

- (NSString*)signingChainQualifiers:(int)signingChainIndex NS_SWIFT_NAME(signingChainQualifiers(_:));

- (BOOL)signingChainSelfSigned:(int)signingChainIndex NS_SWIFT_NAME(signingChainSelfSigned(_:));

- (NSData*)signingChainSerialNumber:(int)signingChainIndex NS_SWIFT_NAME(signingChainSerialNumber(_:));
- (void)setSigningChainSerialNumber:(int)signingChainIndex :(NSData*)newSigningChainSerialNumber NS_SWIFT_NAME(setSigningChainSerialNumber(_:_:));

- (NSString*)signingChainSigAlgorithm:(int)signingChainIndex NS_SWIFT_NAME(signingChainSigAlgorithm(_:));

- (int)signingChainSource:(int)signingChainIndex NS_SWIFT_NAME(signingChainSource(_:));

- (NSString*)signingChainSubject:(int)signingChainIndex NS_SWIFT_NAME(signingChainSubject(_:));

- (NSString*)signingChainSubjectAlternativeName:(int)signingChainIndex NS_SWIFT_NAME(signingChainSubjectAlternativeName(_:));
- (void)setSigningChainSubjectAlternativeName:(int)signingChainIndex :(NSString*)newSigningChainSubjectAlternativeName NS_SWIFT_NAME(setSigningChainSubjectAlternativeName(_:_:));

- (NSData*)signingChainSubjectKeyID:(int)signingChainIndex NS_SWIFT_NAME(signingChainSubjectKeyID(_:));
- (void)setSigningChainSubjectKeyID:(int)signingChainIndex :(NSData*)newSigningChainSubjectKeyID NS_SWIFT_NAME(setSigningChainSubjectKeyID(_:_:));

- (NSString*)signingChainSubjectRDN:(int)signingChainIndex NS_SWIFT_NAME(signingChainSubjectRDN(_:));
- (void)setSigningChainSubjectRDN:(int)signingChainIndex :(NSString*)newSigningChainSubjectRDN NS_SWIFT_NAME(setSigningChainSubjectRDN(_:_:));

- (BOOL)signingChainValid:(int)signingChainIndex NS_SWIFT_NAME(signingChainValid(_:));

- (NSString*)signingChainValidFrom:(int)signingChainIndex NS_SWIFT_NAME(signingChainValidFrom(_:));
- (void)setSigningChainValidFrom:(int)signingChainIndex :(NSString*)newSigningChainValidFrom NS_SWIFT_NAME(setSigningChainValidFrom(_:_:));

- (NSString*)signingChainValidTo:(int)signingChainIndex NS_SWIFT_NAME(signingChainValidTo(_:));
- (void)setSigningChainValidTo:(int)signingChainIndex :(NSString*)newSigningChainValidTo NS_SWIFT_NAME(setSigningChainValidTo(_:_:));

  /* Methods */

- (int)addBodyReference:(NSString*)customId :(BOOL)autoGenerateId NS_SWIFT_NAME(addBodyReference(_:_:));

- (int)addDataReference:(NSString*)dataURI :(NSData*)data NS_SWIFT_NAME(addDataReference(_:_:));

- (void)addKnownNamespace:(NSString*)prefix :(NSString*)URI NS_SWIFT_NAME(addKnownNamespace(_:_:));

- (int)addReference:(NSString*)targetXmlElement :(NSString*)customId :(BOOL)autoGenerateId NS_SWIFT_NAME(addReference(_:_:_:));

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (NSString*)extractAsyncData:(NSString*)asyncReply NS_SWIFT_NAME(extractAsyncData(_:));

- (NSString*)getInnerXML:(NSString*)XPath NS_SWIFT_NAME(getInnerXML(_:));

- (NSString*)getOuterXML:(NSString*)XPath NS_SWIFT_NAME(getOuterXML(_:));

- (NSString*)getTextContent:(NSString*)XPath NS_SWIFT_NAME(getTextContent(_:));

- (void)reset NS_SWIFT_NAME(reset());

- (void)setInnerXML:(NSString*)XPath :(NSString*)value NS_SWIFT_NAME(setInnerXML(_:_:));

- (void)setTextContent:(NSString*)XPath :(NSString*)value NS_SWIFT_NAME(setTextContent(_:_:));

- (void)sign NS_SWIFT_NAME(sign());

- (NSString*)signAsyncBegin NS_SWIFT_NAME(signAsyncBegin());

- (void)signAsyncEnd:(NSString*)asyncReply NS_SWIFT_NAME(signAsyncEnd(_:));

- (void)signExternal NS_SWIFT_NAME(signExternal());

@end

