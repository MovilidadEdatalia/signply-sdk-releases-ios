/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

//SIGNATUREVALIDITIES
#define SVT_VALID                                          0

#define SVT_UNKNOWN                                        1

#define SVT_CORRUPTED                                      2

#define SVT_SIGNER_NOT_FOUND                               3

#define SVT_FAILURE                                        4

#define SVT_REFERENCE_CORRUPTED                            5

//TIMESTAMPFORMATS
#define MTF_UNKNOWN                                        0

#define MTF_RFC5544                                        1

#define MTF_CMS                                            2

#define MTF_TSPREPLY                                       3

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxMessageTimestampVerifierDelegate <NSObject>
@optional
- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

@end

@interface SecureBlackboxMessageTimestampVerifier : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxMessageTimestampVerifierDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasError;

  BOOL m_delegateHasNotification;

}

+ (SecureBlackboxMessageTimestampVerifier*)messagetimestampverifier;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxMessageTimestampVerifierDelegate> delegate;
- (id <SecureBlackboxMessageTimestampVerifierDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxMessageTimestampVerifierDelegate>)anObject;

  /* Events */

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readonly,assign,getter=certCount) int certCount NS_SWIFT_NAME(certCount);

- (int)certCount NS_SWIFT_NAME(certCount());

- (NSData*)certBytes:(int)certIndex NS_SWIFT_NAME(certBytes(_:));

- (BOOL)certCA:(int)certIndex NS_SWIFT_NAME(certCA(_:));

- (NSData*)certCAKeyID:(int)certIndex NS_SWIFT_NAME(certCAKeyID(_:));

- (int)certCertType:(int)certIndex NS_SWIFT_NAME(certCertType(_:));

- (NSString*)certCRLDistributionPoints:(int)certIndex NS_SWIFT_NAME(certCRLDistributionPoints(_:));

- (NSString*)certCurve:(int)certIndex NS_SWIFT_NAME(certCurve(_:));

- (NSString*)certFingerprint:(int)certIndex NS_SWIFT_NAME(certFingerprint(_:));

- (NSString*)certFriendlyName:(int)certIndex NS_SWIFT_NAME(certFriendlyName(_:));

- (long long)certHandle:(int)certIndex NS_SWIFT_NAME(certHandle(_:));

- (NSString*)certHashAlgorithm:(int)certIndex NS_SWIFT_NAME(certHashAlgorithm(_:));

- (NSString*)certIssuer:(int)certIndex NS_SWIFT_NAME(certIssuer(_:));

- (NSString*)certIssuerRDN:(int)certIndex NS_SWIFT_NAME(certIssuerRDN(_:));

- (NSString*)certKeyAlgorithm:(int)certIndex NS_SWIFT_NAME(certKeyAlgorithm(_:));

- (int)certKeyBits:(int)certIndex NS_SWIFT_NAME(certKeyBits(_:));

- (NSString*)certKeyFingerprint:(int)certIndex NS_SWIFT_NAME(certKeyFingerprint(_:));

- (int)certKeyUsage:(int)certIndex NS_SWIFT_NAME(certKeyUsage(_:));

- (BOOL)certKeyValid:(int)certIndex NS_SWIFT_NAME(certKeyValid(_:));

- (NSString*)certOCSPLocations:(int)certIndex NS_SWIFT_NAME(certOCSPLocations(_:));

- (BOOL)certOCSPNoCheck:(int)certIndex NS_SWIFT_NAME(certOCSPNoCheck(_:));

- (int)certOrigin:(int)certIndex NS_SWIFT_NAME(certOrigin(_:));

- (NSString*)certPolicyIDs:(int)certIndex NS_SWIFT_NAME(certPolicyIDs(_:));

- (NSData*)certPrivateKeyBytes:(int)certIndex NS_SWIFT_NAME(certPrivateKeyBytes(_:));

- (BOOL)certPrivateKeyExists:(int)certIndex NS_SWIFT_NAME(certPrivateKeyExists(_:));

- (BOOL)certPrivateKeyExtractable:(int)certIndex NS_SWIFT_NAME(certPrivateKeyExtractable(_:));

- (NSData*)certPublicKeyBytes:(int)certIndex NS_SWIFT_NAME(certPublicKeyBytes(_:));

- (BOOL)certQualified:(int)certIndex NS_SWIFT_NAME(certQualified(_:));

- (int)certQualifiedStatements:(int)certIndex NS_SWIFT_NAME(certQualifiedStatements(_:));

- (NSString*)certQualifiers:(int)certIndex NS_SWIFT_NAME(certQualifiers(_:));

- (BOOL)certSelfSigned:(int)certIndex NS_SWIFT_NAME(certSelfSigned(_:));

- (NSData*)certSerialNumber:(int)certIndex NS_SWIFT_NAME(certSerialNumber(_:));

- (NSString*)certSigAlgorithm:(int)certIndex NS_SWIFT_NAME(certSigAlgorithm(_:));

- (int)certSource:(int)certIndex NS_SWIFT_NAME(certSource(_:));

- (NSString*)certSubject:(int)certIndex NS_SWIFT_NAME(certSubject(_:));

- (NSString*)certSubjectAlternativeName:(int)certIndex NS_SWIFT_NAME(certSubjectAlternativeName(_:));

- (NSData*)certSubjectKeyID:(int)certIndex NS_SWIFT_NAME(certSubjectKeyID(_:));

- (NSString*)certSubjectRDN:(int)certIndex NS_SWIFT_NAME(certSubjectRDN(_:));

- (BOOL)certValid:(int)certIndex NS_SWIFT_NAME(certValid(_:));

- (NSString*)certValidFrom:(int)certIndex NS_SWIFT_NAME(certValidFrom(_:));

- (NSString*)certValidTo:(int)certIndex NS_SWIFT_NAME(certValidTo(_:));

@property (nonatomic,readwrite,assign,getter=dataBytes,setter=setDataBytes:) NSData* dataBytes NS_SWIFT_NAME(dataBytes);

- (NSData*)dataBytes NS_SWIFT_NAME(dataBytes());
- (void)setDataBytes :(NSData*)newDataBytes NS_SWIFT_NAME(setDataBytes(_:));

@property (nonatomic,readwrite,assign,getter=dataFile,setter=setDataFile:) NSString* dataFile NS_SWIFT_NAME(dataFile);

- (NSString*)dataFile NS_SWIFT_NAME(dataFile());
- (void)setDataFile :(NSString*)newDataFile NS_SWIFT_NAME(setDataFile(_:));

@property (nonatomic,readonly,assign,getter=dataFileName) NSString* dataFileName NS_SWIFT_NAME(dataFileName);

- (NSString*)dataFileName NS_SWIFT_NAME(dataFileName());

@property (nonatomic,readonly,assign,getter=dataURI) NSString* dataURI NS_SWIFT_NAME(dataURI);

- (NSString*)dataURI NS_SWIFT_NAME(dataURI());

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=inputBytes,setter=setInputBytes:) NSData* inputBytes NS_SWIFT_NAME(inputBytes);

- (NSData*)inputBytes NS_SWIFT_NAME(inputBytes());
- (void)setInputBytes :(NSData*)newInputBytes NS_SWIFT_NAME(setInputBytes(_:));

@property (nonatomic,readwrite,assign,getter=inputFile,setter=setInputFile:) NSString* inputFile NS_SWIFT_NAME(inputFile);

- (NSString*)inputFile NS_SWIFT_NAME(inputFile());
- (void)setInputFile :(NSString*)newInputFile NS_SWIFT_NAME(setInputFile(_:));

@property (nonatomic,readonly,assign,getter=outputBytes) NSData* outputBytes NS_SWIFT_NAME(outputBytes);

- (NSData*)outputBytes NS_SWIFT_NAME(outputBytes());

@property (nonatomic,readwrite,assign,getter=outputFile,setter=setOutputFile:) NSString* outputFile NS_SWIFT_NAME(outputFile);

- (NSString*)outputFile NS_SWIFT_NAME(outputFile());
- (void)setOutputFile :(NSString*)newOutputFile NS_SWIFT_NAME(setOutputFile(_:));

@property (nonatomic,readonly,assign,getter=signatureValidationResult) int signatureValidationResult NS_SWIFT_NAME(signatureValidationResult);

- (int)signatureValidationResult NS_SWIFT_NAME(signatureValidationResult());

@property (nonatomic,readonly,assign,getter=signingCertBytes) NSData* signingCertBytes NS_SWIFT_NAME(signingCertBytes);

- (NSData*)signingCertBytes NS_SWIFT_NAME(signingCertBytes());

@property (nonatomic,readonly,assign,getter=signingCertCA) BOOL signingCertCA NS_SWIFT_NAME(signingCertCA);

- (BOOL)signingCertCA NS_SWIFT_NAME(signingCertCA());

@property (nonatomic,readonly,assign,getter=signingCertCAKeyID) NSData* signingCertCAKeyID NS_SWIFT_NAME(signingCertCAKeyID);

- (NSData*)signingCertCAKeyID NS_SWIFT_NAME(signingCertCAKeyID());

@property (nonatomic,readonly,assign,getter=signingCertCertType) int signingCertCertType NS_SWIFT_NAME(signingCertCertType);

- (int)signingCertCertType NS_SWIFT_NAME(signingCertCertType());

@property (nonatomic,readonly,assign,getter=signingCertCRLDistributionPoints) NSString* signingCertCRLDistributionPoints NS_SWIFT_NAME(signingCertCRLDistributionPoints);

- (NSString*)signingCertCRLDistributionPoints NS_SWIFT_NAME(signingCertCRLDistributionPoints());

@property (nonatomic,readonly,assign,getter=signingCertCurve) NSString* signingCertCurve NS_SWIFT_NAME(signingCertCurve);

- (NSString*)signingCertCurve NS_SWIFT_NAME(signingCertCurve());

@property (nonatomic,readonly,assign,getter=signingCertFingerprint) NSString* signingCertFingerprint NS_SWIFT_NAME(signingCertFingerprint);

- (NSString*)signingCertFingerprint NS_SWIFT_NAME(signingCertFingerprint());

@property (nonatomic,readonly,assign,getter=signingCertFriendlyName) NSString* signingCertFriendlyName NS_SWIFT_NAME(signingCertFriendlyName);

- (NSString*)signingCertFriendlyName NS_SWIFT_NAME(signingCertFriendlyName());

@property (nonatomic,readonly,assign,getter=signingCertHandle) long long signingCertHandle NS_SWIFT_NAME(signingCertHandle);

- (long long)signingCertHandle NS_SWIFT_NAME(signingCertHandle());

@property (nonatomic,readonly,assign,getter=signingCertHashAlgorithm) NSString* signingCertHashAlgorithm NS_SWIFT_NAME(signingCertHashAlgorithm);

- (NSString*)signingCertHashAlgorithm NS_SWIFT_NAME(signingCertHashAlgorithm());

@property (nonatomic,readonly,assign,getter=signingCertIssuer) NSString* signingCertIssuer NS_SWIFT_NAME(signingCertIssuer);

- (NSString*)signingCertIssuer NS_SWIFT_NAME(signingCertIssuer());

@property (nonatomic,readonly,assign,getter=signingCertIssuerRDN) NSString* signingCertIssuerRDN NS_SWIFT_NAME(signingCertIssuerRDN);

- (NSString*)signingCertIssuerRDN NS_SWIFT_NAME(signingCertIssuerRDN());

@property (nonatomic,readonly,assign,getter=signingCertKeyAlgorithm) NSString* signingCertKeyAlgorithm NS_SWIFT_NAME(signingCertKeyAlgorithm);

- (NSString*)signingCertKeyAlgorithm NS_SWIFT_NAME(signingCertKeyAlgorithm());

@property (nonatomic,readonly,assign,getter=signingCertKeyBits) int signingCertKeyBits NS_SWIFT_NAME(signingCertKeyBits);

- (int)signingCertKeyBits NS_SWIFT_NAME(signingCertKeyBits());

@property (nonatomic,readonly,assign,getter=signingCertKeyFingerprint) NSString* signingCertKeyFingerprint NS_SWIFT_NAME(signingCertKeyFingerprint);

- (NSString*)signingCertKeyFingerprint NS_SWIFT_NAME(signingCertKeyFingerprint());

@property (nonatomic,readonly,assign,getter=signingCertKeyUsage) int signingCertKeyUsage NS_SWIFT_NAME(signingCertKeyUsage);

- (int)signingCertKeyUsage NS_SWIFT_NAME(signingCertKeyUsage());

@property (nonatomic,readonly,assign,getter=signingCertKeyValid) BOOL signingCertKeyValid NS_SWIFT_NAME(signingCertKeyValid);

- (BOOL)signingCertKeyValid NS_SWIFT_NAME(signingCertKeyValid());

@property (nonatomic,readonly,assign,getter=signingCertOCSPLocations) NSString* signingCertOCSPLocations NS_SWIFT_NAME(signingCertOCSPLocations);

- (NSString*)signingCertOCSPLocations NS_SWIFT_NAME(signingCertOCSPLocations());

@property (nonatomic,readonly,assign,getter=signingCertOCSPNoCheck) BOOL signingCertOCSPNoCheck NS_SWIFT_NAME(signingCertOCSPNoCheck);

- (BOOL)signingCertOCSPNoCheck NS_SWIFT_NAME(signingCertOCSPNoCheck());

@property (nonatomic,readonly,assign,getter=signingCertOrigin) int signingCertOrigin NS_SWIFT_NAME(signingCertOrigin);

- (int)signingCertOrigin NS_SWIFT_NAME(signingCertOrigin());

@property (nonatomic,readonly,assign,getter=signingCertPolicyIDs) NSString* signingCertPolicyIDs NS_SWIFT_NAME(signingCertPolicyIDs);

- (NSString*)signingCertPolicyIDs NS_SWIFT_NAME(signingCertPolicyIDs());

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyBytes) NSData* signingCertPrivateKeyBytes NS_SWIFT_NAME(signingCertPrivateKeyBytes);

- (NSData*)signingCertPrivateKeyBytes NS_SWIFT_NAME(signingCertPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyExists) BOOL signingCertPrivateKeyExists NS_SWIFT_NAME(signingCertPrivateKeyExists);

- (BOOL)signingCertPrivateKeyExists NS_SWIFT_NAME(signingCertPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyExtractable) BOOL signingCertPrivateKeyExtractable NS_SWIFT_NAME(signingCertPrivateKeyExtractable);

- (BOOL)signingCertPrivateKeyExtractable NS_SWIFT_NAME(signingCertPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=signingCertPublicKeyBytes) NSData* signingCertPublicKeyBytes NS_SWIFT_NAME(signingCertPublicKeyBytes);

- (NSData*)signingCertPublicKeyBytes NS_SWIFT_NAME(signingCertPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=signingCertQualified) BOOL signingCertQualified NS_SWIFT_NAME(signingCertQualified);

- (BOOL)signingCertQualified NS_SWIFT_NAME(signingCertQualified());

@property (nonatomic,readonly,assign,getter=signingCertQualifiedStatements) int signingCertQualifiedStatements NS_SWIFT_NAME(signingCertQualifiedStatements);

- (int)signingCertQualifiedStatements NS_SWIFT_NAME(signingCertQualifiedStatements());

@property (nonatomic,readonly,assign,getter=signingCertQualifiers) NSString* signingCertQualifiers NS_SWIFT_NAME(signingCertQualifiers);

- (NSString*)signingCertQualifiers NS_SWIFT_NAME(signingCertQualifiers());

@property (nonatomic,readonly,assign,getter=signingCertSelfSigned) BOOL signingCertSelfSigned NS_SWIFT_NAME(signingCertSelfSigned);

- (BOOL)signingCertSelfSigned NS_SWIFT_NAME(signingCertSelfSigned());

@property (nonatomic,readonly,assign,getter=signingCertSerialNumber) NSData* signingCertSerialNumber NS_SWIFT_NAME(signingCertSerialNumber);

- (NSData*)signingCertSerialNumber NS_SWIFT_NAME(signingCertSerialNumber());

@property (nonatomic,readonly,assign,getter=signingCertSigAlgorithm) NSString* signingCertSigAlgorithm NS_SWIFT_NAME(signingCertSigAlgorithm);

- (NSString*)signingCertSigAlgorithm NS_SWIFT_NAME(signingCertSigAlgorithm());

@property (nonatomic,readonly,assign,getter=signingCertSource) int signingCertSource NS_SWIFT_NAME(signingCertSource);

- (int)signingCertSource NS_SWIFT_NAME(signingCertSource());

@property (nonatomic,readonly,assign,getter=signingCertSubject) NSString* signingCertSubject NS_SWIFT_NAME(signingCertSubject);

- (NSString*)signingCertSubject NS_SWIFT_NAME(signingCertSubject());

@property (nonatomic,readonly,assign,getter=signingCertSubjectAlternativeName) NSString* signingCertSubjectAlternativeName NS_SWIFT_NAME(signingCertSubjectAlternativeName);

- (NSString*)signingCertSubjectAlternativeName NS_SWIFT_NAME(signingCertSubjectAlternativeName());

@property (nonatomic,readonly,assign,getter=signingCertSubjectKeyID) NSData* signingCertSubjectKeyID NS_SWIFT_NAME(signingCertSubjectKeyID);

- (NSData*)signingCertSubjectKeyID NS_SWIFT_NAME(signingCertSubjectKeyID());

@property (nonatomic,readonly,assign,getter=signingCertSubjectRDN) NSString* signingCertSubjectRDN NS_SWIFT_NAME(signingCertSubjectRDN);

- (NSString*)signingCertSubjectRDN NS_SWIFT_NAME(signingCertSubjectRDN());

@property (nonatomic,readonly,assign,getter=signingCertValid) BOOL signingCertValid NS_SWIFT_NAME(signingCertValid);

- (BOOL)signingCertValid NS_SWIFT_NAME(signingCertValid());

@property (nonatomic,readonly,assign,getter=signingCertValidFrom) NSString* signingCertValidFrom NS_SWIFT_NAME(signingCertValidFrom);

- (NSString*)signingCertValidFrom NS_SWIFT_NAME(signingCertValidFrom());

@property (nonatomic,readonly,assign,getter=signingCertValidTo) NSString* signingCertValidTo NS_SWIFT_NAME(signingCertValidTo);

- (NSString*)signingCertValidTo NS_SWIFT_NAME(signingCertValidTo());

@property (nonatomic,readonly,assign,getter=timestampFormat) int timestampFormat NS_SWIFT_NAME(timestampFormat);

- (int)timestampFormat NS_SWIFT_NAME(timestampFormat());

@property (nonatomic,readonly,assign,getter=validatedSigningTime) NSString* validatedSigningTime NS_SWIFT_NAME(validatedSigningTime);

- (NSString*)validatedSigningTime NS_SWIFT_NAME(validatedSigningTime());

  /* Methods */

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (void)reset NS_SWIFT_NAME(reset());

- (void)verify NS_SWIFT_NAME(verify());

- (void)verifyDetached NS_SWIFT_NAME(verifyDetached());

@end

