/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxUtilsDelegate <NSObject>
@optional
- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

@end

@interface SecureBlackboxUtils : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxUtilsDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasError;

  BOOL m_delegateHasNotification;

}

+ (SecureBlackboxUtils*)utils;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxUtilsDelegate> delegate;
- (id <SecureBlackboxUtilsDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxUtilsDelegate>)anObject;

  /* Events */

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readwrite,assign,getter=multipartPartCount,setter=setMultipartPartCount:) int multipartPartCount NS_SWIFT_NAME(multipartPartCount);

- (int)multipartPartCount NS_SWIFT_NAME(multipartPartCount());
- (void)setMultipartPartCount :(int)newMultipartPartCount NS_SWIFT_NAME(setMultipartPartCount(_:));

- (NSString*)multipartPartContentDescription:(int)multipartPartIndex NS_SWIFT_NAME(multipartPartContentDescription(_:));
- (void)setMultipartPartContentDescription:(int)multipartPartIndex :(NSString*)newMultipartPartContentDescription NS_SWIFT_NAME(setMultipartPartContentDescription(_:_:));

- (NSString*)multipartPartContentDisposition:(int)multipartPartIndex NS_SWIFT_NAME(multipartPartContentDisposition(_:));
- (void)setMultipartPartContentDisposition:(int)multipartPartIndex :(NSString*)newMultipartPartContentDisposition NS_SWIFT_NAME(setMultipartPartContentDisposition(_:_:));

- (NSString*)multipartPartContentID:(int)multipartPartIndex NS_SWIFT_NAME(multipartPartContentID(_:));
- (void)setMultipartPartContentID:(int)multipartPartIndex :(NSString*)newMultipartPartContentID NS_SWIFT_NAME(setMultipartPartContentID(_:_:));

- (NSString*)multipartPartContentTransferEncoding:(int)multipartPartIndex NS_SWIFT_NAME(multipartPartContentTransferEncoding(_:));
- (void)setMultipartPartContentTransferEncoding:(int)multipartPartIndex :(NSString*)newMultipartPartContentTransferEncoding NS_SWIFT_NAME(setMultipartPartContentTransferEncoding(_:_:));

- (NSString*)multipartPartContentType:(int)multipartPartIndex NS_SWIFT_NAME(multipartPartContentType(_:));
- (void)setMultipartPartContentType:(int)multipartPartIndex :(NSString*)newMultipartPartContentType NS_SWIFT_NAME(setMultipartPartContentType(_:_:));

- (NSString*)multipartPartCustomHeaders:(int)multipartPartIndex NS_SWIFT_NAME(multipartPartCustomHeaders(_:));
- (void)setMultipartPartCustomHeaders:(int)multipartPartIndex :(NSString*)newMultipartPartCustomHeaders NS_SWIFT_NAME(setMultipartPartCustomHeaders(_:_:));

- (NSString*)multipartPartFieldName:(int)multipartPartIndex NS_SWIFT_NAME(multipartPartFieldName(_:));
- (void)setMultipartPartFieldName:(int)multipartPartIndex :(NSString*)newMultipartPartFieldName NS_SWIFT_NAME(setMultipartPartFieldName(_:_:));

- (NSString*)multipartPartFieldValue:(int)multipartPartIndex NS_SWIFT_NAME(multipartPartFieldValue(_:));
- (void)setMultipartPartFieldValue:(int)multipartPartIndex :(NSString*)newMultipartPartFieldValue NS_SWIFT_NAME(setMultipartPartFieldValue(_:_:));

- (NSString*)multipartPartFileName:(int)multipartPartIndex NS_SWIFT_NAME(multipartPartFileName(_:));
- (void)setMultipartPartFileName:(int)multipartPartIndex :(NSString*)newMultipartPartFileName NS_SWIFT_NAME(setMultipartPartFileName(_:_:));

- (long long)multipartPartHandle:(int)multipartPartIndex NS_SWIFT_NAME(multipartPartHandle(_:));
- (void)setMultipartPartHandle:(int)multipartPartIndex :(long long)newMultipartPartHandle NS_SWIFT_NAME(setMultipartPartHandle(_:_:));

@property (nonatomic,readwrite,assign,getter=nameValuePairCount,setter=setNameValuePairCount:) int nameValuePairCount NS_SWIFT_NAME(nameValuePairCount);

- (int)nameValuePairCount NS_SWIFT_NAME(nameValuePairCount());
- (void)setNameValuePairCount :(int)newNameValuePairCount NS_SWIFT_NAME(setNameValuePairCount(_:));

- (NSString*)nameValuePairCategory:(int)nameValuePairIndex NS_SWIFT_NAME(nameValuePairCategory(_:));
- (void)setNameValuePairCategory:(int)nameValuePairIndex :(NSString*)newNameValuePairCategory NS_SWIFT_NAME(setNameValuePairCategory(_:_:));

- (int)nameValuePairFormat:(int)nameValuePairIndex NS_SWIFT_NAME(nameValuePairFormat(_:));
- (void)setNameValuePairFormat:(int)nameValuePairIndex :(int)newNameValuePairFormat NS_SWIFT_NAME(setNameValuePairFormat(_:_:));

- (NSString*)nameValuePairName:(int)nameValuePairIndex NS_SWIFT_NAME(nameValuePairName(_:));
- (void)setNameValuePairName:(int)nameValuePairIndex :(NSString*)newNameValuePairName NS_SWIFT_NAME(setNameValuePairName(_:_:));

- (NSString*)nameValuePairValue:(int)nameValuePairIndex NS_SWIFT_NAME(nameValuePairValue(_:));
- (void)setNameValuePairValue:(int)nameValuePairIndex :(NSString*)newNameValuePairValue NS_SWIFT_NAME(setNameValuePairValue(_:_:));

  /* Methods */

- (int)addPartFromBytes:(NSData*)data NS_SWIFT_NAME(addPartFromBytes(_:));

- (int)addPartFromFile:(NSString*)fileName NS_SWIFT_NAME(addPartFromFile(_:));

- (NSData*)base64Decode:(NSString*)value :(BOOL)useURLEncoding NS_SWIFT_NAME(base64Decode(_:_:));

- (NSString*)base64Encode:(NSData*)bytes :(BOOL)useURLEncoding NS_SWIFT_NAME(base64Encode(_:_:));

- (NSString*)base64EncodeLines:(NSData*)bytes :(int)lineLen NS_SWIFT_NAME(base64EncodeLines(_:_:));

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)dateToString:(NSDate*)value NS_SWIFT_NAME(dateToString(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (NSString*)getErrorDescription:(int)errorCode NS_SWIFT_NAME(getErrorDescription(_:));

- (NSString*)getLocalDNSName NS_SWIFT_NAME(getLocalDNSName());

- (NSString*)getLocalIP:(BOOL)IPv6 NS_SWIFT_NAME(getLocalIP(_:));

- (NSString*)getLocalIPs:(BOOL)IPv4 :(BOOL)IPv6 NS_SWIFT_NAME(getLocalIPs(_:_:));

- (NSData*)getPartToBytes:(int)index NS_SWIFT_NAME(getPartToBytes(_:));

- (void)getPartToFile:(int)index :(NSString*)fileName NS_SWIFT_NAME(getPartToFile(_:_:));

- (NSString*)getRemoteIP:(NSString*)hostName :(BOOL)IPv6 :(int)DNSMode :(NSString*)DNSServers :(int)timeout NS_SWIFT_NAME(getRemoteIP(_:_:_:_:_:));

- (NSString*)getRemoteIPs:(NSString*)hostName :(BOOL)IPv4 :(BOOL)IPv6 :(int)DNSMode :(NSString*)DNSServers :(int)timeout NS_SWIFT_NAME(getRemoteIPs(_:_:_:_:_:_:));

- (NSString*)getValueByName:(NSString*)name NS_SWIFT_NAME(getValueByName(_:));

- (NSData*)hexDecode:(NSString*)value NS_SWIFT_NAME(hexDecode(_:));

- (NSString*)hexEncode:(NSData*)bytes NS_SWIFT_NAME(hexEncode(_:));

- (int)indexOfName:(NSString*)name NS_SWIFT_NAME(indexOfName(_:));

- (void)loadMultipartFromBytes:(NSString*)contentType :(NSData*)data NS_SWIFT_NAME(loadMultipartFromBytes(_:_:));

- (void)loadMultipartFromFile:(NSString*)contentType :(NSString*)fileName NS_SWIFT_NAME(loadMultipartFromFile(_:_:));

- (void)loadNameValuePairs:(NSString*)data :(NSString*)format :(NSString*)nameValueSeparator :(NSString*)pairSeparator :(BOOL)trimValues NS_SWIFT_NAME(loadNameValuePairs(_:_:_:_:_:));

- (NSString*)oidToString:(NSData*)bytes NS_SWIFT_NAME(oidToString(_:));

- (BOOL)removeNameValuePair:(NSString*)name NS_SWIFT_NAME(removeNameValuePair(_:));

- (void)reset NS_SWIFT_NAME(reset());

- (NSString*)saveMultipartContentType NS_SWIFT_NAME(saveMultipartContentType());

- (NSData*)saveMultipartToBytes:(int)multipartMode NS_SWIFT_NAME(saveMultipartToBytes(_:));

- (void)saveMultipartToFile:(int)multipartMode :(NSString*)fileName NS_SWIFT_NAME(saveMultipartToFile(_:_:));

- (NSString*)saveNameValuePairs:(NSString*)format :(NSString*)nameValueSeparator :(NSString*)pairSeparator NS_SWIFT_NAME(saveNameValuePairs(_:_:_:));

- (int)setValueByName:(NSString*)name :(NSString*)value NS_SWIFT_NAME(setValueByName(_:_:));

- (NSString*)stringDecode:(NSData*)bytes :(NSString*)encoding NS_SWIFT_NAME(stringDecode(_:_:));

- (NSData*)stringEncode:(NSString*)value :(NSString*)encoding NS_SWIFT_NAME(stringEncode(_:_:));

- (NSDate*)stringToDate:(NSString*)value NS_SWIFT_NAME(stringToDate(_:));

- (NSData*)stringToOid:(NSString*)value NS_SWIFT_NAME(stringToOid(_:));

- (NSString*)urlDecode:(NSString*)value NS_SWIFT_NAME(urlDecode(_:));

- (NSString*)urlEncode:(NSString*)value NS_SWIFT_NAME(urlEncode(_:));

@end

