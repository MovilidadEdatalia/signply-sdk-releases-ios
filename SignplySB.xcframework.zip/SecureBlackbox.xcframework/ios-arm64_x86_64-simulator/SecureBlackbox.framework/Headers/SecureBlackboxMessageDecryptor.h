/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

//MESSAGEENCRYPTIONTYPES
#define MET_UNKNOWN                                        0

#define MET_CERT_ENCRYPTED                                 1

#define MET_KEY_ENCRYPTED                                  2

#define MET_CERT_ENCRYPTED_AND_AUTHENTICATED               3

//ASYNCSIGNMETHODS
#define ASMD_PKCS1                                         0

#define ASMD_PKCS7                                         1

//EXTERNALCRYPTOMODES
#define ECM_DEFAULT                                        0

#define ECM_DISABLED                                       1

#define ECM_GENERIC                                        2

#define ECM_DCAUTH                                         3

#define ECM_DCAUTH_JSON                                    4

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxMessageDecryptorDelegate <NSObject>
@optional
- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onExternalDecrypt:(NSString*)operationId :(NSString*)algorithm :(NSString*)pars :(NSString*)encryptedData :(NSString**)data NS_SWIFT_NAME(onExternalDecrypt(_:_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onRecipientFound:(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(BOOL)certFound NS_SWIFT_NAME(onRecipientFound(_:_:_:_:));

@end

@interface SecureBlackboxMessageDecryptor : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxMessageDecryptorDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasError;

  BOOL m_delegateHasExternalDecrypt;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasRecipientFound;

}

+ (SecureBlackboxMessageDecryptor*)messagedecryptor;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxMessageDecryptorDelegate> delegate;
- (id <SecureBlackboxMessageDecryptorDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxMessageDecryptorDelegate>)anObject;

  /* Events */

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onExternalDecrypt:(NSString*)operationId :(NSString*)algorithm :(NSString*)pars :(NSString*)encryptedData :(NSString**)data NS_SWIFT_NAME(onExternalDecrypt(_:_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onRecipientFound:(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(BOOL)certFound NS_SWIFT_NAME(onRecipientFound(_:_:_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readonly,assign,getter=certificateIndex) int certificateIndex NS_SWIFT_NAME(certificateIndex);

- (int)certificateIndex NS_SWIFT_NAME(certificateIndex());

@property (nonatomic,readwrite,assign,getter=certCount,setter=setCertCount:) int certCount NS_SWIFT_NAME(certCount);

- (int)certCount NS_SWIFT_NAME(certCount());
- (void)setCertCount :(int)newCertCount NS_SWIFT_NAME(setCertCount(_:));

- (NSData*)certBytes:(int)certIndex NS_SWIFT_NAME(certBytes(_:));

- (BOOL)certCA:(int)certIndex NS_SWIFT_NAME(certCA(_:));
- (void)setCertCA:(int)certIndex :(BOOL)newCertCA NS_SWIFT_NAME(setCertCA(_:_:));

- (NSData*)certCAKeyID:(int)certIndex NS_SWIFT_NAME(certCAKeyID(_:));

- (int)certCertType:(int)certIndex NS_SWIFT_NAME(certCertType(_:));

- (NSString*)certCRLDistributionPoints:(int)certIndex NS_SWIFT_NAME(certCRLDistributionPoints(_:));
- (void)setCertCRLDistributionPoints:(int)certIndex :(NSString*)newCertCRLDistributionPoints NS_SWIFT_NAME(setCertCRLDistributionPoints(_:_:));

- (NSString*)certCurve:(int)certIndex NS_SWIFT_NAME(certCurve(_:));
- (void)setCertCurve:(int)certIndex :(NSString*)newCertCurve NS_SWIFT_NAME(setCertCurve(_:_:));

- (NSString*)certFingerprint:(int)certIndex NS_SWIFT_NAME(certFingerprint(_:));

- (NSString*)certFriendlyName:(int)certIndex NS_SWIFT_NAME(certFriendlyName(_:));

- (long long)certHandle:(int)certIndex NS_SWIFT_NAME(certHandle(_:));
- (void)setCertHandle:(int)certIndex :(long long)newCertHandle NS_SWIFT_NAME(setCertHandle(_:_:));

- (NSString*)certHashAlgorithm:(int)certIndex NS_SWIFT_NAME(certHashAlgorithm(_:));
- (void)setCertHashAlgorithm:(int)certIndex :(NSString*)newCertHashAlgorithm NS_SWIFT_NAME(setCertHashAlgorithm(_:_:));

- (NSString*)certIssuer:(int)certIndex NS_SWIFT_NAME(certIssuer(_:));

- (NSString*)certIssuerRDN:(int)certIndex NS_SWIFT_NAME(certIssuerRDN(_:));
- (void)setCertIssuerRDN:(int)certIndex :(NSString*)newCertIssuerRDN NS_SWIFT_NAME(setCertIssuerRDN(_:_:));

- (NSString*)certKeyAlgorithm:(int)certIndex NS_SWIFT_NAME(certKeyAlgorithm(_:));
- (void)setCertKeyAlgorithm:(int)certIndex :(NSString*)newCertKeyAlgorithm NS_SWIFT_NAME(setCertKeyAlgorithm(_:_:));

- (int)certKeyBits:(int)certIndex NS_SWIFT_NAME(certKeyBits(_:));

- (NSString*)certKeyFingerprint:(int)certIndex NS_SWIFT_NAME(certKeyFingerprint(_:));

- (int)certKeyUsage:(int)certIndex NS_SWIFT_NAME(certKeyUsage(_:));
- (void)setCertKeyUsage:(int)certIndex :(int)newCertKeyUsage NS_SWIFT_NAME(setCertKeyUsage(_:_:));

- (BOOL)certKeyValid:(int)certIndex NS_SWIFT_NAME(certKeyValid(_:));

- (NSString*)certOCSPLocations:(int)certIndex NS_SWIFT_NAME(certOCSPLocations(_:));
- (void)setCertOCSPLocations:(int)certIndex :(NSString*)newCertOCSPLocations NS_SWIFT_NAME(setCertOCSPLocations(_:_:));

- (BOOL)certOCSPNoCheck:(int)certIndex NS_SWIFT_NAME(certOCSPNoCheck(_:));
- (void)setCertOCSPNoCheck:(int)certIndex :(BOOL)newCertOCSPNoCheck NS_SWIFT_NAME(setCertOCSPNoCheck(_:_:));

- (int)certOrigin:(int)certIndex NS_SWIFT_NAME(certOrigin(_:));

- (NSString*)certPolicyIDs:(int)certIndex NS_SWIFT_NAME(certPolicyIDs(_:));
- (void)setCertPolicyIDs:(int)certIndex :(NSString*)newCertPolicyIDs NS_SWIFT_NAME(setCertPolicyIDs(_:_:));

- (NSData*)certPrivateKeyBytes:(int)certIndex NS_SWIFT_NAME(certPrivateKeyBytes(_:));

- (BOOL)certPrivateKeyExists:(int)certIndex NS_SWIFT_NAME(certPrivateKeyExists(_:));

- (BOOL)certPrivateKeyExtractable:(int)certIndex NS_SWIFT_NAME(certPrivateKeyExtractable(_:));

- (NSData*)certPublicKeyBytes:(int)certIndex NS_SWIFT_NAME(certPublicKeyBytes(_:));

- (BOOL)certQualified:(int)certIndex NS_SWIFT_NAME(certQualified(_:));

- (int)certQualifiedStatements:(int)certIndex NS_SWIFT_NAME(certQualifiedStatements(_:));
- (void)setCertQualifiedStatements:(int)certIndex :(int)newCertQualifiedStatements NS_SWIFT_NAME(setCertQualifiedStatements(_:_:));

- (NSString*)certQualifiers:(int)certIndex NS_SWIFT_NAME(certQualifiers(_:));

- (BOOL)certSelfSigned:(int)certIndex NS_SWIFT_NAME(certSelfSigned(_:));

- (NSData*)certSerialNumber:(int)certIndex NS_SWIFT_NAME(certSerialNumber(_:));
- (void)setCertSerialNumber:(int)certIndex :(NSData*)newCertSerialNumber NS_SWIFT_NAME(setCertSerialNumber(_:_:));

- (NSString*)certSigAlgorithm:(int)certIndex NS_SWIFT_NAME(certSigAlgorithm(_:));

- (int)certSource:(int)certIndex NS_SWIFT_NAME(certSource(_:));

- (NSString*)certSubject:(int)certIndex NS_SWIFT_NAME(certSubject(_:));

- (NSString*)certSubjectAlternativeName:(int)certIndex NS_SWIFT_NAME(certSubjectAlternativeName(_:));
- (void)setCertSubjectAlternativeName:(int)certIndex :(NSString*)newCertSubjectAlternativeName NS_SWIFT_NAME(setCertSubjectAlternativeName(_:_:));

- (NSData*)certSubjectKeyID:(int)certIndex NS_SWIFT_NAME(certSubjectKeyID(_:));
- (void)setCertSubjectKeyID:(int)certIndex :(NSData*)newCertSubjectKeyID NS_SWIFT_NAME(setCertSubjectKeyID(_:_:));

- (NSString*)certSubjectRDN:(int)certIndex NS_SWIFT_NAME(certSubjectRDN(_:));
- (void)setCertSubjectRDN:(int)certIndex :(NSString*)newCertSubjectRDN NS_SWIFT_NAME(setCertSubjectRDN(_:_:));

- (BOOL)certValid:(int)certIndex NS_SWIFT_NAME(certValid(_:));

- (NSString*)certValidFrom:(int)certIndex NS_SWIFT_NAME(certValidFrom(_:));
- (void)setCertValidFrom:(int)certIndex :(NSString*)newCertValidFrom NS_SWIFT_NAME(setCertValidFrom(_:_:));

- (NSString*)certValidTo:(int)certIndex NS_SWIFT_NAME(certValidTo(_:));
- (void)setCertValidTo:(int)certIndex :(NSString*)newCertValidTo NS_SWIFT_NAME(setCertValidTo(_:_:));

@property (nonatomic,readonly,assign,getter=encryptionAlgorithm) NSString* encryptionAlgorithm NS_SWIFT_NAME(encryptionAlgorithm);

- (NSString*)encryptionAlgorithm NS_SWIFT_NAME(encryptionAlgorithm());

@property (nonatomic,readonly,assign,getter=encryptionType) int encryptionType NS_SWIFT_NAME(encryptionType);

- (int)encryptionType NS_SWIFT_NAME(encryptionType());

@property (nonatomic,readwrite,assign,getter=externalCryptoAsyncDocumentID,setter=setExternalCryptoAsyncDocumentID:) NSString* externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID);

- (NSString*)externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID());
- (void)setExternalCryptoAsyncDocumentID :(NSString*)newExternalCryptoAsyncDocumentID NS_SWIFT_NAME(setExternalCryptoAsyncDocumentID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoCustomParams,setter=setExternalCryptoCustomParams:) NSString* externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams);

- (NSString*)externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams());
- (void)setExternalCryptoCustomParams :(NSString*)newExternalCryptoCustomParams NS_SWIFT_NAME(setExternalCryptoCustomParams(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoData,setter=setExternalCryptoData:) NSString* externalCryptoData NS_SWIFT_NAME(externalCryptoData);

- (NSString*)externalCryptoData NS_SWIFT_NAME(externalCryptoData());
- (void)setExternalCryptoData :(NSString*)newExternalCryptoData NS_SWIFT_NAME(setExternalCryptoData(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoExternalHashCalculation,setter=setExternalCryptoExternalHashCalculation:) BOOL externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation);

- (BOOL)externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation());
- (void)setExternalCryptoExternalHashCalculation :(BOOL)newExternalCryptoExternalHashCalculation NS_SWIFT_NAME(setExternalCryptoExternalHashCalculation(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoHashAlgorithm,setter=setExternalCryptoHashAlgorithm:) NSString* externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm);

- (NSString*)externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm());
- (void)setExternalCryptoHashAlgorithm :(NSString*)newExternalCryptoHashAlgorithm NS_SWIFT_NAME(setExternalCryptoHashAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeyID,setter=setExternalCryptoKeyID:) NSString* externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID);

- (NSString*)externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID());
- (void)setExternalCryptoKeyID :(NSString*)newExternalCryptoKeyID NS_SWIFT_NAME(setExternalCryptoKeyID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeySecret,setter=setExternalCryptoKeySecret:) NSString* externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret);

- (NSString*)externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret());
- (void)setExternalCryptoKeySecret :(NSString*)newExternalCryptoKeySecret NS_SWIFT_NAME(setExternalCryptoKeySecret(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMethod,setter=setExternalCryptoMethod:) int externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod);

- (int)externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod());
- (void)setExternalCryptoMethod :(int)newExternalCryptoMethod NS_SWIFT_NAME(setExternalCryptoMethod(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMode,setter=setExternalCryptoMode:) int externalCryptoMode NS_SWIFT_NAME(externalCryptoMode);

- (int)externalCryptoMode NS_SWIFT_NAME(externalCryptoMode());
- (void)setExternalCryptoMode :(int)newExternalCryptoMode NS_SWIFT_NAME(setExternalCryptoMode(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoPublicKeyAlgorithm,setter=setExternalCryptoPublicKeyAlgorithm:) NSString* externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm);

- (NSString*)externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm());
- (void)setExternalCryptoPublicKeyAlgorithm :(NSString*)newExternalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(setExternalCryptoPublicKeyAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=inputBytes,setter=setInputBytes:) NSData* inputBytes NS_SWIFT_NAME(inputBytes);

- (NSData*)inputBytes NS_SWIFT_NAME(inputBytes());
- (void)setInputBytes :(NSData*)newInputBytes NS_SWIFT_NAME(setInputBytes(_:));

@property (nonatomic,readwrite,assign,getter=inputFile,setter=setInputFile:) NSString* inputFile NS_SWIFT_NAME(inputFile);

- (NSString*)inputFile NS_SWIFT_NAME(inputFile());
- (void)setInputFile :(NSString*)newInputFile NS_SWIFT_NAME(setInputFile(_:));

@property (nonatomic,readwrite,assign,getter=key,setter=setKey:) NSData* key NS_SWIFT_NAME(key);

- (NSData*)key NS_SWIFT_NAME(key());
- (void)setKey :(NSData*)newKey NS_SWIFT_NAME(setKey(_:));

@property (nonatomic,readonly,assign,getter=outputBytes) NSData* outputBytes NS_SWIFT_NAME(outputBytes);

- (NSData*)outputBytes NS_SWIFT_NAME(outputBytes());

@property (nonatomic,readwrite,assign,getter=outputFile,setter=setOutputFile:) NSString* outputFile NS_SWIFT_NAME(outputFile);

- (NSString*)outputFile NS_SWIFT_NAME(outputFile());
- (void)setOutputFile :(NSString*)newOutputFile NS_SWIFT_NAME(setOutputFile(_:));

@property (nonatomic,readonly,assign,getter=signedAttributeCount) int signedAttributeCount NS_SWIFT_NAME(signedAttributeCount);

- (int)signedAttributeCount NS_SWIFT_NAME(signedAttributeCount());

- (NSString*)signedAttributeOID:(int)signedAttributeIndex NS_SWIFT_NAME(signedAttributeOID(_:));

- (NSData*)signedAttributeValue:(int)signedAttributeIndex NS_SWIFT_NAME(signedAttributeValue(_:));

@property (nonatomic,readonly,assign,getter=unsignedAttributeCount) int unsignedAttributeCount NS_SWIFT_NAME(unsignedAttributeCount);

- (int)unsignedAttributeCount NS_SWIFT_NAME(unsignedAttributeCount());

- (NSString*)unsignedAttributeOID:(int)unsignedAttributeIndex NS_SWIFT_NAME(unsignedAttributeOID(_:));

- (NSData*)unsignedAttributeValue:(int)unsignedAttributeIndex NS_SWIFT_NAME(unsignedAttributeValue(_:));

  /* Methods */

- (int)checkEncryptionType NS_SWIFT_NAME(checkEncryptionType());

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (void)decrypt NS_SWIFT_NAME(decrypt());

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (void)reset NS_SWIFT_NAME(reset());

@end

