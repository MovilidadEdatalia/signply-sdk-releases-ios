/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

//PDFENCRYPTIONTYPES
#define PET_NONE                                           0

#define PET_PASSWORD                                       1

#define PET_CERTIFICATE                                    2

//ASYNCSIGNMETHODS
#define ASMD_PKCS1                                         0

#define ASMD_PKCS7                                         1

//EXTERNALCRYPTOMODES
#define ECM_DEFAULT                                        0

#define ECM_DISABLED                                       1

#define ECM_GENERIC                                        2

#define ECM_DCAUTH                                         3

#define ECM_DCAUTH_JSON                                    4

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxPDFDecryptorDelegate <NSObject>
@optional
- (void)onDocumentLoaded:(int*)cancel NS_SWIFT_NAME(onDocumentLoaded(_:));

- (void)onEncrypted:(BOOL)certUsed :(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(BOOL)needCredential :(int*)skipThis NS_SWIFT_NAME(onEncrypted(_:_:_:_:_:_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onExternalDecrypt:(NSString*)operationId :(NSString*)algorithm :(NSString*)pars :(NSString*)encryptedData :(NSString**)data NS_SWIFT_NAME(onExternalDecrypt(_:_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

@end

@interface SecureBlackboxPDFDecryptor : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxPDFDecryptorDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasDocumentLoaded;

  BOOL m_delegateHasEncrypted;

  BOOL m_delegateHasError;

  BOOL m_delegateHasExternalDecrypt;

  BOOL m_delegateHasNotification;

}

+ (SecureBlackboxPDFDecryptor*)pdfdecryptor;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxPDFDecryptorDelegate> delegate;
- (id <SecureBlackboxPDFDecryptorDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxPDFDecryptorDelegate>)anObject;

  /* Events */

- (void)onDocumentLoaded:(int*)cancel NS_SWIFT_NAME(onDocumentLoaded(_:));

- (void)onEncrypted:(BOOL)certUsed :(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(BOOL)needCredential :(int*)skipThis NS_SWIFT_NAME(onEncrypted(_:_:_:_:_:_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onExternalDecrypt:(NSString*)operationId :(NSString*)algorithm :(NSString*)pars :(NSString*)encryptedData :(NSString**)data NS_SWIFT_NAME(onExternalDecrypt(_:_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readonly,assign,getter=decryptionCertificateBytes) NSData* decryptionCertificateBytes NS_SWIFT_NAME(decryptionCertificateBytes);

- (NSData*)decryptionCertificateBytes NS_SWIFT_NAME(decryptionCertificateBytes());

@property (nonatomic,readwrite,assign,getter=decryptionCertificateCA,setter=setDecryptionCertificateCA:) BOOL decryptionCertificateCA NS_SWIFT_NAME(decryptionCertificateCA);

- (BOOL)decryptionCertificateCA NS_SWIFT_NAME(decryptionCertificateCA());
- (void)setDecryptionCertificateCA :(BOOL)newDecryptionCertificateCA NS_SWIFT_NAME(setDecryptionCertificateCA(_:));

@property (nonatomic,readonly,assign,getter=decryptionCertificateCAKeyID) NSData* decryptionCertificateCAKeyID NS_SWIFT_NAME(decryptionCertificateCAKeyID);

- (NSData*)decryptionCertificateCAKeyID NS_SWIFT_NAME(decryptionCertificateCAKeyID());

@property (nonatomic,readonly,assign,getter=decryptionCertificateCertType) int decryptionCertificateCertType NS_SWIFT_NAME(decryptionCertificateCertType);

- (int)decryptionCertificateCertType NS_SWIFT_NAME(decryptionCertificateCertType());

@property (nonatomic,readwrite,assign,getter=decryptionCertificateCRLDistributionPoints,setter=setDecryptionCertificateCRLDistributionPoints:) NSString* decryptionCertificateCRLDistributionPoints NS_SWIFT_NAME(decryptionCertificateCRLDistributionPoints);

- (NSString*)decryptionCertificateCRLDistributionPoints NS_SWIFT_NAME(decryptionCertificateCRLDistributionPoints());
- (void)setDecryptionCertificateCRLDistributionPoints :(NSString*)newDecryptionCertificateCRLDistributionPoints NS_SWIFT_NAME(setDecryptionCertificateCRLDistributionPoints(_:));

@property (nonatomic,readwrite,assign,getter=decryptionCertificateCurve,setter=setDecryptionCertificateCurve:) NSString* decryptionCertificateCurve NS_SWIFT_NAME(decryptionCertificateCurve);

- (NSString*)decryptionCertificateCurve NS_SWIFT_NAME(decryptionCertificateCurve());
- (void)setDecryptionCertificateCurve :(NSString*)newDecryptionCertificateCurve NS_SWIFT_NAME(setDecryptionCertificateCurve(_:));

@property (nonatomic,readonly,assign,getter=decryptionCertificateFingerprint) NSString* decryptionCertificateFingerprint NS_SWIFT_NAME(decryptionCertificateFingerprint);

- (NSString*)decryptionCertificateFingerprint NS_SWIFT_NAME(decryptionCertificateFingerprint());

@property (nonatomic,readonly,assign,getter=decryptionCertificateFriendlyName) NSString* decryptionCertificateFriendlyName NS_SWIFT_NAME(decryptionCertificateFriendlyName);

- (NSString*)decryptionCertificateFriendlyName NS_SWIFT_NAME(decryptionCertificateFriendlyName());

@property (nonatomic,readwrite,assign,getter=decryptionCertificateHandle,setter=setDecryptionCertificateHandle:) long long decryptionCertificateHandle NS_SWIFT_NAME(decryptionCertificateHandle);

- (long long)decryptionCertificateHandle NS_SWIFT_NAME(decryptionCertificateHandle());
- (void)setDecryptionCertificateHandle :(long long)newDecryptionCertificateHandle NS_SWIFT_NAME(setDecryptionCertificateHandle(_:));

@property (nonatomic,readwrite,assign,getter=decryptionCertificateHashAlgorithm,setter=setDecryptionCertificateHashAlgorithm:) NSString* decryptionCertificateHashAlgorithm NS_SWIFT_NAME(decryptionCertificateHashAlgorithm);

- (NSString*)decryptionCertificateHashAlgorithm NS_SWIFT_NAME(decryptionCertificateHashAlgorithm());
- (void)setDecryptionCertificateHashAlgorithm :(NSString*)newDecryptionCertificateHashAlgorithm NS_SWIFT_NAME(setDecryptionCertificateHashAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=decryptionCertificateIssuer) NSString* decryptionCertificateIssuer NS_SWIFT_NAME(decryptionCertificateIssuer);

- (NSString*)decryptionCertificateIssuer NS_SWIFT_NAME(decryptionCertificateIssuer());

@property (nonatomic,readwrite,assign,getter=decryptionCertificateIssuerRDN,setter=setDecryptionCertificateIssuerRDN:) NSString* decryptionCertificateIssuerRDN NS_SWIFT_NAME(decryptionCertificateIssuerRDN);

- (NSString*)decryptionCertificateIssuerRDN NS_SWIFT_NAME(decryptionCertificateIssuerRDN());
- (void)setDecryptionCertificateIssuerRDN :(NSString*)newDecryptionCertificateIssuerRDN NS_SWIFT_NAME(setDecryptionCertificateIssuerRDN(_:));

@property (nonatomic,readwrite,assign,getter=decryptionCertificateKeyAlgorithm,setter=setDecryptionCertificateKeyAlgorithm:) NSString* decryptionCertificateKeyAlgorithm NS_SWIFT_NAME(decryptionCertificateKeyAlgorithm);

- (NSString*)decryptionCertificateKeyAlgorithm NS_SWIFT_NAME(decryptionCertificateKeyAlgorithm());
- (void)setDecryptionCertificateKeyAlgorithm :(NSString*)newDecryptionCertificateKeyAlgorithm NS_SWIFT_NAME(setDecryptionCertificateKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=decryptionCertificateKeyBits) int decryptionCertificateKeyBits NS_SWIFT_NAME(decryptionCertificateKeyBits);

- (int)decryptionCertificateKeyBits NS_SWIFT_NAME(decryptionCertificateKeyBits());

@property (nonatomic,readonly,assign,getter=decryptionCertificateKeyFingerprint) NSString* decryptionCertificateKeyFingerprint NS_SWIFT_NAME(decryptionCertificateKeyFingerprint);

- (NSString*)decryptionCertificateKeyFingerprint NS_SWIFT_NAME(decryptionCertificateKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=decryptionCertificateKeyUsage,setter=setDecryptionCertificateKeyUsage:) int decryptionCertificateKeyUsage NS_SWIFT_NAME(decryptionCertificateKeyUsage);

- (int)decryptionCertificateKeyUsage NS_SWIFT_NAME(decryptionCertificateKeyUsage());
- (void)setDecryptionCertificateKeyUsage :(int)newDecryptionCertificateKeyUsage NS_SWIFT_NAME(setDecryptionCertificateKeyUsage(_:));

@property (nonatomic,readonly,assign,getter=decryptionCertificateKeyValid) BOOL decryptionCertificateKeyValid NS_SWIFT_NAME(decryptionCertificateKeyValid);

- (BOOL)decryptionCertificateKeyValid NS_SWIFT_NAME(decryptionCertificateKeyValid());

@property (nonatomic,readwrite,assign,getter=decryptionCertificateOCSPLocations,setter=setDecryptionCertificateOCSPLocations:) NSString* decryptionCertificateOCSPLocations NS_SWIFT_NAME(decryptionCertificateOCSPLocations);

- (NSString*)decryptionCertificateOCSPLocations NS_SWIFT_NAME(decryptionCertificateOCSPLocations());
- (void)setDecryptionCertificateOCSPLocations :(NSString*)newDecryptionCertificateOCSPLocations NS_SWIFT_NAME(setDecryptionCertificateOCSPLocations(_:));

@property (nonatomic,readwrite,assign,getter=decryptionCertificateOCSPNoCheck,setter=setDecryptionCertificateOCSPNoCheck:) BOOL decryptionCertificateOCSPNoCheck NS_SWIFT_NAME(decryptionCertificateOCSPNoCheck);

- (BOOL)decryptionCertificateOCSPNoCheck NS_SWIFT_NAME(decryptionCertificateOCSPNoCheck());
- (void)setDecryptionCertificateOCSPNoCheck :(BOOL)newDecryptionCertificateOCSPNoCheck NS_SWIFT_NAME(setDecryptionCertificateOCSPNoCheck(_:));

@property (nonatomic,readonly,assign,getter=decryptionCertificateOrigin) int decryptionCertificateOrigin NS_SWIFT_NAME(decryptionCertificateOrigin);

- (int)decryptionCertificateOrigin NS_SWIFT_NAME(decryptionCertificateOrigin());

@property (nonatomic,readwrite,assign,getter=decryptionCertificatePolicyIDs,setter=setDecryptionCertificatePolicyIDs:) NSString* decryptionCertificatePolicyIDs NS_SWIFT_NAME(decryptionCertificatePolicyIDs);

- (NSString*)decryptionCertificatePolicyIDs NS_SWIFT_NAME(decryptionCertificatePolicyIDs());
- (void)setDecryptionCertificatePolicyIDs :(NSString*)newDecryptionCertificatePolicyIDs NS_SWIFT_NAME(setDecryptionCertificatePolicyIDs(_:));

@property (nonatomic,readonly,assign,getter=decryptionCertificatePrivateKeyBytes) NSData* decryptionCertificatePrivateKeyBytes NS_SWIFT_NAME(decryptionCertificatePrivateKeyBytes);

- (NSData*)decryptionCertificatePrivateKeyBytes NS_SWIFT_NAME(decryptionCertificatePrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=decryptionCertificatePrivateKeyExists) BOOL decryptionCertificatePrivateKeyExists NS_SWIFT_NAME(decryptionCertificatePrivateKeyExists);

- (BOOL)decryptionCertificatePrivateKeyExists NS_SWIFT_NAME(decryptionCertificatePrivateKeyExists());

@property (nonatomic,readonly,assign,getter=decryptionCertificatePrivateKeyExtractable) BOOL decryptionCertificatePrivateKeyExtractable NS_SWIFT_NAME(decryptionCertificatePrivateKeyExtractable);

- (BOOL)decryptionCertificatePrivateKeyExtractable NS_SWIFT_NAME(decryptionCertificatePrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=decryptionCertificatePublicKeyBytes) NSData* decryptionCertificatePublicKeyBytes NS_SWIFT_NAME(decryptionCertificatePublicKeyBytes);

- (NSData*)decryptionCertificatePublicKeyBytes NS_SWIFT_NAME(decryptionCertificatePublicKeyBytes());

@property (nonatomic,readonly,assign,getter=decryptionCertificateQualified) BOOL decryptionCertificateQualified NS_SWIFT_NAME(decryptionCertificateQualified);

- (BOOL)decryptionCertificateQualified NS_SWIFT_NAME(decryptionCertificateQualified());

@property (nonatomic,readwrite,assign,getter=decryptionCertificateQualifiedStatements,setter=setDecryptionCertificateQualifiedStatements:) int decryptionCertificateQualifiedStatements NS_SWIFT_NAME(decryptionCertificateQualifiedStatements);

- (int)decryptionCertificateQualifiedStatements NS_SWIFT_NAME(decryptionCertificateQualifiedStatements());
- (void)setDecryptionCertificateQualifiedStatements :(int)newDecryptionCertificateQualifiedStatements NS_SWIFT_NAME(setDecryptionCertificateQualifiedStatements(_:));

@property (nonatomic,readonly,assign,getter=decryptionCertificateQualifiers) NSString* decryptionCertificateQualifiers NS_SWIFT_NAME(decryptionCertificateQualifiers);

- (NSString*)decryptionCertificateQualifiers NS_SWIFT_NAME(decryptionCertificateQualifiers());

@property (nonatomic,readonly,assign,getter=decryptionCertificateSelfSigned) BOOL decryptionCertificateSelfSigned NS_SWIFT_NAME(decryptionCertificateSelfSigned);

- (BOOL)decryptionCertificateSelfSigned NS_SWIFT_NAME(decryptionCertificateSelfSigned());

@property (nonatomic,readwrite,assign,getter=decryptionCertificateSerialNumber,setter=setDecryptionCertificateSerialNumber:) NSData* decryptionCertificateSerialNumber NS_SWIFT_NAME(decryptionCertificateSerialNumber);

- (NSData*)decryptionCertificateSerialNumber NS_SWIFT_NAME(decryptionCertificateSerialNumber());
- (void)setDecryptionCertificateSerialNumber :(NSData*)newDecryptionCertificateSerialNumber NS_SWIFT_NAME(setDecryptionCertificateSerialNumber(_:));

@property (nonatomic,readonly,assign,getter=decryptionCertificateSigAlgorithm) NSString* decryptionCertificateSigAlgorithm NS_SWIFT_NAME(decryptionCertificateSigAlgorithm);

- (NSString*)decryptionCertificateSigAlgorithm NS_SWIFT_NAME(decryptionCertificateSigAlgorithm());

@property (nonatomic,readonly,assign,getter=decryptionCertificateSource) int decryptionCertificateSource NS_SWIFT_NAME(decryptionCertificateSource);

- (int)decryptionCertificateSource NS_SWIFT_NAME(decryptionCertificateSource());

@property (nonatomic,readonly,assign,getter=decryptionCertificateSubject) NSString* decryptionCertificateSubject NS_SWIFT_NAME(decryptionCertificateSubject);

- (NSString*)decryptionCertificateSubject NS_SWIFT_NAME(decryptionCertificateSubject());

@property (nonatomic,readwrite,assign,getter=decryptionCertificateSubjectAlternativeName,setter=setDecryptionCertificateSubjectAlternativeName:) NSString* decryptionCertificateSubjectAlternativeName NS_SWIFT_NAME(decryptionCertificateSubjectAlternativeName);

- (NSString*)decryptionCertificateSubjectAlternativeName NS_SWIFT_NAME(decryptionCertificateSubjectAlternativeName());
- (void)setDecryptionCertificateSubjectAlternativeName :(NSString*)newDecryptionCertificateSubjectAlternativeName NS_SWIFT_NAME(setDecryptionCertificateSubjectAlternativeName(_:));

@property (nonatomic,readwrite,assign,getter=decryptionCertificateSubjectKeyID,setter=setDecryptionCertificateSubjectKeyID:) NSData* decryptionCertificateSubjectKeyID NS_SWIFT_NAME(decryptionCertificateSubjectKeyID);

- (NSData*)decryptionCertificateSubjectKeyID NS_SWIFT_NAME(decryptionCertificateSubjectKeyID());
- (void)setDecryptionCertificateSubjectKeyID :(NSData*)newDecryptionCertificateSubjectKeyID NS_SWIFT_NAME(setDecryptionCertificateSubjectKeyID(_:));

@property (nonatomic,readwrite,assign,getter=decryptionCertificateSubjectRDN,setter=setDecryptionCertificateSubjectRDN:) NSString* decryptionCertificateSubjectRDN NS_SWIFT_NAME(decryptionCertificateSubjectRDN);

- (NSString*)decryptionCertificateSubjectRDN NS_SWIFT_NAME(decryptionCertificateSubjectRDN());
- (void)setDecryptionCertificateSubjectRDN :(NSString*)newDecryptionCertificateSubjectRDN NS_SWIFT_NAME(setDecryptionCertificateSubjectRDN(_:));

@property (nonatomic,readonly,assign,getter=decryptionCertificateValid) BOOL decryptionCertificateValid NS_SWIFT_NAME(decryptionCertificateValid);

- (BOOL)decryptionCertificateValid NS_SWIFT_NAME(decryptionCertificateValid());

@property (nonatomic,readwrite,assign,getter=decryptionCertificateValidFrom,setter=setDecryptionCertificateValidFrom:) NSString* decryptionCertificateValidFrom NS_SWIFT_NAME(decryptionCertificateValidFrom);

- (NSString*)decryptionCertificateValidFrom NS_SWIFT_NAME(decryptionCertificateValidFrom());
- (void)setDecryptionCertificateValidFrom :(NSString*)newDecryptionCertificateValidFrom NS_SWIFT_NAME(setDecryptionCertificateValidFrom(_:));

@property (nonatomic,readwrite,assign,getter=decryptionCertificateValidTo,setter=setDecryptionCertificateValidTo:) NSString* decryptionCertificateValidTo NS_SWIFT_NAME(decryptionCertificateValidTo);

- (NSString*)decryptionCertificateValidTo NS_SWIFT_NAME(decryptionCertificateValidTo());
- (void)setDecryptionCertificateValidTo :(NSString*)newDecryptionCertificateValidTo NS_SWIFT_NAME(setDecryptionCertificateValidTo(_:));

@property (nonatomic,readonly,assign,getter=documentInfoEncryptionAlgorithm) NSString* documentInfoEncryptionAlgorithm NS_SWIFT_NAME(documentInfoEncryptionAlgorithm);

- (NSString*)documentInfoEncryptionAlgorithm NS_SWIFT_NAME(documentInfoEncryptionAlgorithm());

@property (nonatomic,readonly,assign,getter=documentInfoEncryptionType) int documentInfoEncryptionType NS_SWIFT_NAME(documentInfoEncryptionType);

- (int)documentInfoEncryptionType NS_SWIFT_NAME(documentInfoEncryptionType());

@property (nonatomic,readonly,assign,getter=documentInfoMetadataEncrypted) BOOL documentInfoMetadataEncrypted NS_SWIFT_NAME(documentInfoMetadataEncrypted);

- (BOOL)documentInfoMetadataEncrypted NS_SWIFT_NAME(documentInfoMetadataEncrypted());

@property (nonatomic,readonly,assign,getter=documentInfoPermissions) int documentInfoPermissions NS_SWIFT_NAME(documentInfoPermissions);

- (int)documentInfoPermissions NS_SWIFT_NAME(documentInfoPermissions());

@property (nonatomic,readwrite,assign,getter=externalCryptoAsyncDocumentID,setter=setExternalCryptoAsyncDocumentID:) NSString* externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID);

- (NSString*)externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID());
- (void)setExternalCryptoAsyncDocumentID :(NSString*)newExternalCryptoAsyncDocumentID NS_SWIFT_NAME(setExternalCryptoAsyncDocumentID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoCustomParams,setter=setExternalCryptoCustomParams:) NSString* externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams);

- (NSString*)externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams());
- (void)setExternalCryptoCustomParams :(NSString*)newExternalCryptoCustomParams NS_SWIFT_NAME(setExternalCryptoCustomParams(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoData,setter=setExternalCryptoData:) NSString* externalCryptoData NS_SWIFT_NAME(externalCryptoData);

- (NSString*)externalCryptoData NS_SWIFT_NAME(externalCryptoData());
- (void)setExternalCryptoData :(NSString*)newExternalCryptoData NS_SWIFT_NAME(setExternalCryptoData(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoExternalHashCalculation,setter=setExternalCryptoExternalHashCalculation:) BOOL externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation);

- (BOOL)externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation());
- (void)setExternalCryptoExternalHashCalculation :(BOOL)newExternalCryptoExternalHashCalculation NS_SWIFT_NAME(setExternalCryptoExternalHashCalculation(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoHashAlgorithm,setter=setExternalCryptoHashAlgorithm:) NSString* externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm);

- (NSString*)externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm());
- (void)setExternalCryptoHashAlgorithm :(NSString*)newExternalCryptoHashAlgorithm NS_SWIFT_NAME(setExternalCryptoHashAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeyID,setter=setExternalCryptoKeyID:) NSString* externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID);

- (NSString*)externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID());
- (void)setExternalCryptoKeyID :(NSString*)newExternalCryptoKeyID NS_SWIFT_NAME(setExternalCryptoKeyID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeySecret,setter=setExternalCryptoKeySecret:) NSString* externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret);

- (NSString*)externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret());
- (void)setExternalCryptoKeySecret :(NSString*)newExternalCryptoKeySecret NS_SWIFT_NAME(setExternalCryptoKeySecret(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMethod,setter=setExternalCryptoMethod:) int externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod);

- (int)externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod());
- (void)setExternalCryptoMethod :(int)newExternalCryptoMethod NS_SWIFT_NAME(setExternalCryptoMethod(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMode,setter=setExternalCryptoMode:) int externalCryptoMode NS_SWIFT_NAME(externalCryptoMode);

- (int)externalCryptoMode NS_SWIFT_NAME(externalCryptoMode());
- (void)setExternalCryptoMode :(int)newExternalCryptoMode NS_SWIFT_NAME(setExternalCryptoMode(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoPublicKeyAlgorithm,setter=setExternalCryptoPublicKeyAlgorithm:) NSString* externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm);

- (NSString*)externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm());
- (void)setExternalCryptoPublicKeyAlgorithm :(NSString*)newExternalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(setExternalCryptoPublicKeyAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=inputBytes,setter=setInputBytes:) NSData* inputBytes NS_SWIFT_NAME(inputBytes);

- (NSData*)inputBytes NS_SWIFT_NAME(inputBytes());
- (void)setInputBytes :(NSData*)newInputBytes NS_SWIFT_NAME(setInputBytes(_:));

@property (nonatomic,readwrite,assign,getter=inputFile,setter=setInputFile:) NSString* inputFile NS_SWIFT_NAME(inputFile);

- (NSString*)inputFile NS_SWIFT_NAME(inputFile());
- (void)setInputFile :(NSString*)newInputFile NS_SWIFT_NAME(setInputFile(_:));

@property (nonatomic,readonly,assign,getter=outputBytes) NSData* outputBytes NS_SWIFT_NAME(outputBytes);

- (NSData*)outputBytes NS_SWIFT_NAME(outputBytes());

@property (nonatomic,readwrite,assign,getter=outputFile,setter=setOutputFile:) NSString* outputFile NS_SWIFT_NAME(outputFile);

- (NSString*)outputFile NS_SWIFT_NAME(outputFile());
- (void)setOutputFile :(NSString*)newOutputFile NS_SWIFT_NAME(setOutputFile(_:));

@property (nonatomic,readwrite,assign,getter=password,setter=setPassword:) NSString* password NS_SWIFT_NAME(password);

- (NSString*)password NS_SWIFT_NAME(password());
- (void)setPassword :(NSString*)newPassword NS_SWIFT_NAME(setPassword(_:));

  /* Methods */

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (void)decrypt NS_SWIFT_NAME(decrypt());

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (void)reset NS_SWIFT_NAME(reset());

@end

