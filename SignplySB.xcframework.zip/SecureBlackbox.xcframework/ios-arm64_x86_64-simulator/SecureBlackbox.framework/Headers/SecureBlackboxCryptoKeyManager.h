/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxCryptoKeyManagerDelegate <NSObject>
@optional
- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onPasswordNeeded:(NSString*)neededFor :(NSString**)password :(int*)cancel NS_SWIFT_NAME(onPasswordNeeded(_:_:_:));

@end

@interface SecureBlackboxCryptoKeyManager : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxCryptoKeyManagerDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasError;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasPasswordNeeded;

}

+ (SecureBlackboxCryptoKeyManager*)cryptokeymanager;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxCryptoKeyManagerDelegate> delegate;
- (id <SecureBlackboxCryptoKeyManagerDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxCryptoKeyManagerDelegate>)anObject;

  /* Events */

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onPasswordNeeded:(NSString*)neededFor :(NSString**)password :(int*)cancel NS_SWIFT_NAME(onPasswordNeeded(_:_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readonly,assign,getter=certBytes) NSData* certBytes NS_SWIFT_NAME(certBytes);

- (NSData*)certBytes NS_SWIFT_NAME(certBytes());

@property (nonatomic,readwrite,assign,getter=certCA,setter=setCertCA:) BOOL certCA NS_SWIFT_NAME(certCA);

- (BOOL)certCA NS_SWIFT_NAME(certCA());
- (void)setCertCA :(BOOL)newCertCA NS_SWIFT_NAME(setCertCA(_:));

@property (nonatomic,readonly,assign,getter=certCAKeyID) NSData* certCAKeyID NS_SWIFT_NAME(certCAKeyID);

- (NSData*)certCAKeyID NS_SWIFT_NAME(certCAKeyID());

@property (nonatomic,readonly,assign,getter=certCertType) int certCertType NS_SWIFT_NAME(certCertType);

- (int)certCertType NS_SWIFT_NAME(certCertType());

@property (nonatomic,readwrite,assign,getter=certCRLDistributionPoints,setter=setCertCRLDistributionPoints:) NSString* certCRLDistributionPoints NS_SWIFT_NAME(certCRLDistributionPoints);

- (NSString*)certCRLDistributionPoints NS_SWIFT_NAME(certCRLDistributionPoints());
- (void)setCertCRLDistributionPoints :(NSString*)newCertCRLDistributionPoints NS_SWIFT_NAME(setCertCRLDistributionPoints(_:));

@property (nonatomic,readwrite,assign,getter=certCurve,setter=setCertCurve:) NSString* certCurve NS_SWIFT_NAME(certCurve);

- (NSString*)certCurve NS_SWIFT_NAME(certCurve());
- (void)setCertCurve :(NSString*)newCertCurve NS_SWIFT_NAME(setCertCurve(_:));

@property (nonatomic,readonly,assign,getter=certFingerprint) NSString* certFingerprint NS_SWIFT_NAME(certFingerprint);

- (NSString*)certFingerprint NS_SWIFT_NAME(certFingerprint());

@property (nonatomic,readonly,assign,getter=certFriendlyName) NSString* certFriendlyName NS_SWIFT_NAME(certFriendlyName);

- (NSString*)certFriendlyName NS_SWIFT_NAME(certFriendlyName());

@property (nonatomic,readwrite,assign,getter=certHandle,setter=setCertHandle:) long long certHandle NS_SWIFT_NAME(certHandle);

- (long long)certHandle NS_SWIFT_NAME(certHandle());
- (void)setCertHandle :(long long)newCertHandle NS_SWIFT_NAME(setCertHandle(_:));

@property (nonatomic,readwrite,assign,getter=certHashAlgorithm,setter=setCertHashAlgorithm:) NSString* certHashAlgorithm NS_SWIFT_NAME(certHashAlgorithm);

- (NSString*)certHashAlgorithm NS_SWIFT_NAME(certHashAlgorithm());
- (void)setCertHashAlgorithm :(NSString*)newCertHashAlgorithm NS_SWIFT_NAME(setCertHashAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=certIssuer) NSString* certIssuer NS_SWIFT_NAME(certIssuer);

- (NSString*)certIssuer NS_SWIFT_NAME(certIssuer());

@property (nonatomic,readwrite,assign,getter=certIssuerRDN,setter=setCertIssuerRDN:) NSString* certIssuerRDN NS_SWIFT_NAME(certIssuerRDN);

- (NSString*)certIssuerRDN NS_SWIFT_NAME(certIssuerRDN());
- (void)setCertIssuerRDN :(NSString*)newCertIssuerRDN NS_SWIFT_NAME(setCertIssuerRDN(_:));

@property (nonatomic,readwrite,assign,getter=certKeyAlgorithm,setter=setCertKeyAlgorithm:) NSString* certKeyAlgorithm NS_SWIFT_NAME(certKeyAlgorithm);

- (NSString*)certKeyAlgorithm NS_SWIFT_NAME(certKeyAlgorithm());
- (void)setCertKeyAlgorithm :(NSString*)newCertKeyAlgorithm NS_SWIFT_NAME(setCertKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=certKeyBits) int certKeyBits NS_SWIFT_NAME(certKeyBits);

- (int)certKeyBits NS_SWIFT_NAME(certKeyBits());

@property (nonatomic,readonly,assign,getter=certKeyFingerprint) NSString* certKeyFingerprint NS_SWIFT_NAME(certKeyFingerprint);

- (NSString*)certKeyFingerprint NS_SWIFT_NAME(certKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=certKeyUsage,setter=setCertKeyUsage:) int certKeyUsage NS_SWIFT_NAME(certKeyUsage);

- (int)certKeyUsage NS_SWIFT_NAME(certKeyUsage());
- (void)setCertKeyUsage :(int)newCertKeyUsage NS_SWIFT_NAME(setCertKeyUsage(_:));

@property (nonatomic,readonly,assign,getter=certKeyValid) BOOL certKeyValid NS_SWIFT_NAME(certKeyValid);

- (BOOL)certKeyValid NS_SWIFT_NAME(certKeyValid());

@property (nonatomic,readwrite,assign,getter=certOCSPLocations,setter=setCertOCSPLocations:) NSString* certOCSPLocations NS_SWIFT_NAME(certOCSPLocations);

- (NSString*)certOCSPLocations NS_SWIFT_NAME(certOCSPLocations());
- (void)setCertOCSPLocations :(NSString*)newCertOCSPLocations NS_SWIFT_NAME(setCertOCSPLocations(_:));

@property (nonatomic,readwrite,assign,getter=certOCSPNoCheck,setter=setCertOCSPNoCheck:) BOOL certOCSPNoCheck NS_SWIFT_NAME(certOCSPNoCheck);

- (BOOL)certOCSPNoCheck NS_SWIFT_NAME(certOCSPNoCheck());
- (void)setCertOCSPNoCheck :(BOOL)newCertOCSPNoCheck NS_SWIFT_NAME(setCertOCSPNoCheck(_:));

@property (nonatomic,readonly,assign,getter=certOrigin) int certOrigin NS_SWIFT_NAME(certOrigin);

- (int)certOrigin NS_SWIFT_NAME(certOrigin());

@property (nonatomic,readwrite,assign,getter=certPolicyIDs,setter=setCertPolicyIDs:) NSString* certPolicyIDs NS_SWIFT_NAME(certPolicyIDs);

- (NSString*)certPolicyIDs NS_SWIFT_NAME(certPolicyIDs());
- (void)setCertPolicyIDs :(NSString*)newCertPolicyIDs NS_SWIFT_NAME(setCertPolicyIDs(_:));

@property (nonatomic,readonly,assign,getter=certPrivateKeyBytes) NSData* certPrivateKeyBytes NS_SWIFT_NAME(certPrivateKeyBytes);

- (NSData*)certPrivateKeyBytes NS_SWIFT_NAME(certPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=certPrivateKeyExists) BOOL certPrivateKeyExists NS_SWIFT_NAME(certPrivateKeyExists);

- (BOOL)certPrivateKeyExists NS_SWIFT_NAME(certPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=certPrivateKeyExtractable) BOOL certPrivateKeyExtractable NS_SWIFT_NAME(certPrivateKeyExtractable);

- (BOOL)certPrivateKeyExtractable NS_SWIFT_NAME(certPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=certPublicKeyBytes) NSData* certPublicKeyBytes NS_SWIFT_NAME(certPublicKeyBytes);

- (NSData*)certPublicKeyBytes NS_SWIFT_NAME(certPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=certQualified) BOOL certQualified NS_SWIFT_NAME(certQualified);

- (BOOL)certQualified NS_SWIFT_NAME(certQualified());

@property (nonatomic,readwrite,assign,getter=certQualifiedStatements,setter=setCertQualifiedStatements:) int certQualifiedStatements NS_SWIFT_NAME(certQualifiedStatements);

- (int)certQualifiedStatements NS_SWIFT_NAME(certQualifiedStatements());
- (void)setCertQualifiedStatements :(int)newCertQualifiedStatements NS_SWIFT_NAME(setCertQualifiedStatements(_:));

@property (nonatomic,readonly,assign,getter=certQualifiers) NSString* certQualifiers NS_SWIFT_NAME(certQualifiers);

- (NSString*)certQualifiers NS_SWIFT_NAME(certQualifiers());

@property (nonatomic,readonly,assign,getter=certSelfSigned) BOOL certSelfSigned NS_SWIFT_NAME(certSelfSigned);

- (BOOL)certSelfSigned NS_SWIFT_NAME(certSelfSigned());

@property (nonatomic,readwrite,assign,getter=certSerialNumber,setter=setCertSerialNumber:) NSData* certSerialNumber NS_SWIFT_NAME(certSerialNumber);

- (NSData*)certSerialNumber NS_SWIFT_NAME(certSerialNumber());
- (void)setCertSerialNumber :(NSData*)newCertSerialNumber NS_SWIFT_NAME(setCertSerialNumber(_:));

@property (nonatomic,readonly,assign,getter=certSigAlgorithm) NSString* certSigAlgorithm NS_SWIFT_NAME(certSigAlgorithm);

- (NSString*)certSigAlgorithm NS_SWIFT_NAME(certSigAlgorithm());

@property (nonatomic,readonly,assign,getter=certSource) int certSource NS_SWIFT_NAME(certSource);

- (int)certSource NS_SWIFT_NAME(certSource());

@property (nonatomic,readonly,assign,getter=certSubject) NSString* certSubject NS_SWIFT_NAME(certSubject);

- (NSString*)certSubject NS_SWIFT_NAME(certSubject());

@property (nonatomic,readwrite,assign,getter=certSubjectAlternativeName,setter=setCertSubjectAlternativeName:) NSString* certSubjectAlternativeName NS_SWIFT_NAME(certSubjectAlternativeName);

- (NSString*)certSubjectAlternativeName NS_SWIFT_NAME(certSubjectAlternativeName());
- (void)setCertSubjectAlternativeName :(NSString*)newCertSubjectAlternativeName NS_SWIFT_NAME(setCertSubjectAlternativeName(_:));

@property (nonatomic,readwrite,assign,getter=certSubjectKeyID,setter=setCertSubjectKeyID:) NSData* certSubjectKeyID NS_SWIFT_NAME(certSubjectKeyID);

- (NSData*)certSubjectKeyID NS_SWIFT_NAME(certSubjectKeyID());
- (void)setCertSubjectKeyID :(NSData*)newCertSubjectKeyID NS_SWIFT_NAME(setCertSubjectKeyID(_:));

@property (nonatomic,readwrite,assign,getter=certSubjectRDN,setter=setCertSubjectRDN:) NSString* certSubjectRDN NS_SWIFT_NAME(certSubjectRDN);

- (NSString*)certSubjectRDN NS_SWIFT_NAME(certSubjectRDN());
- (void)setCertSubjectRDN :(NSString*)newCertSubjectRDN NS_SWIFT_NAME(setCertSubjectRDN(_:));

@property (nonatomic,readonly,assign,getter=certValid) BOOL certValid NS_SWIFT_NAME(certValid);

- (BOOL)certValid NS_SWIFT_NAME(certValid());

@property (nonatomic,readwrite,assign,getter=certValidFrom,setter=setCertValidFrom:) NSString* certValidFrom NS_SWIFT_NAME(certValidFrom);

- (NSString*)certValidFrom NS_SWIFT_NAME(certValidFrom());
- (void)setCertValidFrom :(NSString*)newCertValidFrom NS_SWIFT_NAME(setCertValidFrom(_:));

@property (nonatomic,readwrite,assign,getter=certValidTo,setter=setCertValidTo:) NSString* certValidTo NS_SWIFT_NAME(certValidTo);

- (NSString*)certValidTo NS_SWIFT_NAME(certValidTo());
- (void)setCertValidTo :(NSString*)newCertValidTo NS_SWIFT_NAME(setCertValidTo(_:));

@property (nonatomic,readwrite,assign,getter=derivationAlgorithm,setter=setDerivationAlgorithm:) NSString* derivationAlgorithm NS_SWIFT_NAME(derivationAlgorithm);

- (NSString*)derivationAlgorithm NS_SWIFT_NAME(derivationAlgorithm());
- (void)setDerivationAlgorithm :(NSString*)newDerivationAlgorithm NS_SWIFT_NAME(setDerivationAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=deriveIterations,setter=setDeriveIterations:) int deriveIterations NS_SWIFT_NAME(deriveIterations);

- (int)deriveIterations NS_SWIFT_NAME(deriveIterations());
- (void)setDeriveIterations :(int)newDeriveIterations NS_SWIFT_NAME(setDeriveIterations(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=HMACAlgorithm,setter=setHMACAlgorithm:) NSString* HMACAlgorithm NS_SWIFT_NAME(HMACAlgorithm);

- (NSString*)HMACAlgorithm NS_SWIFT_NAME(HMACAlgorithm());
- (void)setHMACAlgorithm :(NSString*)newHMACAlgorithm NS_SWIFT_NAME(setHMACAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=keyAlgorithm,setter=setKeyAlgorithm:) NSString* keyAlgorithm NS_SWIFT_NAME(keyAlgorithm);

- (NSString*)keyAlgorithm NS_SWIFT_NAME(keyAlgorithm());
- (void)setKeyAlgorithm :(NSString*)newKeyAlgorithm NS_SWIFT_NAME(setKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=keyBits) int keyBits NS_SWIFT_NAME(keyBits);

- (int)keyBits NS_SWIFT_NAME(keyBits());

@property (nonatomic,readwrite,assign,getter=keyCurve,setter=setKeyCurve:) NSString* keyCurve NS_SWIFT_NAME(keyCurve);

- (NSString*)keyCurve NS_SWIFT_NAME(keyCurve());
- (void)setKeyCurve :(NSString*)newKeyCurve NS_SWIFT_NAME(setKeyCurve(_:));

@property (nonatomic,readonly,assign,getter=keyExportable) BOOL keyExportable NS_SWIFT_NAME(keyExportable);

- (BOOL)keyExportable NS_SWIFT_NAME(keyExportable());

@property (nonatomic,readonly,assign,getter=keyFingerprint) NSString* keyFingerprint NS_SWIFT_NAME(keyFingerprint);

- (NSString*)keyFingerprint NS_SWIFT_NAME(keyFingerprint());

@property (nonatomic,readwrite,assign,getter=keyHandle,setter=setKeyHandle:) long long keyHandle NS_SWIFT_NAME(keyHandle);

- (long long)keyHandle NS_SWIFT_NAME(keyHandle());
- (void)setKeyHandle :(long long)newKeyHandle NS_SWIFT_NAME(setKeyHandle(_:));

@property (nonatomic,readwrite,assign,getter=keyID,setter=setKeyID:) NSData* keyID NS_SWIFT_NAME(keyID);

- (NSData*)keyID NS_SWIFT_NAME(keyID());
- (void)setKeyID :(NSData*)newKeyID NS_SWIFT_NAME(setKeyID(_:));

@property (nonatomic,readwrite,assign,getter=keyIV,setter=setKeyIV:) NSData* keyIV NS_SWIFT_NAME(keyIV);

- (NSData*)keyIV NS_SWIFT_NAME(keyIV());
- (void)setKeyIV :(NSData*)newKeyIV NS_SWIFT_NAME(setKeyIV(_:));

@property (nonatomic,readonly,assign,getter=keyKey) NSData* keyKey NS_SWIFT_NAME(keyKey);

- (NSData*)keyKey NS_SWIFT_NAME(keyKey());

@property (nonatomic,readwrite,assign,getter=keyNonce,setter=setKeyNonce:) NSData* keyNonce NS_SWIFT_NAME(keyNonce);

- (NSData*)keyNonce NS_SWIFT_NAME(keyNonce());
- (void)setKeyNonce :(NSData*)newKeyNonce NS_SWIFT_NAME(setKeyNonce(_:));

@property (nonatomic,readonly,assign,getter=keyPrivate) BOOL keyPrivate NS_SWIFT_NAME(keyPrivate);

- (BOOL)keyPrivate NS_SWIFT_NAME(keyPrivate());

@property (nonatomic,readonly,assign,getter=keyPublic) BOOL keyPublic NS_SWIFT_NAME(keyPublic);

- (BOOL)keyPublic NS_SWIFT_NAME(keyPublic());

@property (nonatomic,readwrite,assign,getter=keySubject,setter=setKeySubject:) NSData* keySubject NS_SWIFT_NAME(keySubject);

- (NSData*)keySubject NS_SWIFT_NAME(keySubject());
- (void)setKeySubject :(NSData*)newKeySubject NS_SWIFT_NAME(setKeySubject(_:));

@property (nonatomic,readonly,assign,getter=keySymmetric) BOOL keySymmetric NS_SWIFT_NAME(keySymmetric);

- (BOOL)keySymmetric NS_SWIFT_NAME(keySymmetric());

@property (nonatomic,readonly,assign,getter=keyValid) BOOL keyValid NS_SWIFT_NAME(keyValid);

- (BOOL)keyValid NS_SWIFT_NAME(keyValid());

  /* Methods */

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (void)createNew NS_SWIFT_NAME(createNew());

- (void)deriveKey:(int)keyBits :(NSString*)password :(NSString*)salt NS_SWIFT_NAME(deriveKey(_:_:_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (NSData*)exportBytes:(int)format :(int)keyType :(NSString*)password NS_SWIFT_NAME(exportBytes(_:_:_:));

- (void)exportToCert NS_SWIFT_NAME(exportToCert());

- (void)exportToFile:(NSString*)fileName :(int)format :(int)keyType :(NSString*)password NS_SWIFT_NAME(exportToFile(_:_:_:_:));

- (void)generate:(NSString*)keyAlgorithm :(NSString*)scheme :(NSString*)schemeParams :(int)keyBits NS_SWIFT_NAME(generate(_:_:_:_:));

- (NSData*)getKeyParam:(NSString*)name NS_SWIFT_NAME(getKeyParam(_:));

- (NSString*)getKeyParamStr:(NSString*)name NS_SWIFT_NAME(getKeyParamStr(_:));

- (void)importBytes:(NSData*)value :(int)format :(NSString*)keyAlgorithm :(NSString*)scheme :(NSString*)schemeParams :(int)keyType :(NSString*)password NS_SWIFT_NAME(importBytes(_:_:_:_:_:_:_:));

- (void)importFromCert NS_SWIFT_NAME(importFromCert());

- (void)importFromFile:(NSString*)fileName :(int)format :(NSString*)keyAlgorithm :(NSString*)scheme :(NSString*)schemeParams :(int)keyType :(NSString*)password NS_SWIFT_NAME(importFromFile(_:_:_:_:_:_:_:));

- (void)reset NS_SWIFT_NAME(reset());

- (void)setKeyParam:(NSString*)name :(NSData*)value NS_SWIFT_NAME(setKeyParam(_:_:));

- (void)setKeyParamStr:(NSString*)name :(NSString*)valueStr NS_SWIFT_NAME(setKeyParamStr(_:_:));

@end

