/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//PGPPROTECTIONTYPES
#define PPT_NONE                                           0

#define PPT_LOW                                            1

#define PPT_NORMAL                                         2

#define PPT_HIGH                                           3

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxPGPKeyringDelegate <NSObject>
@optional
- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

@end

@interface SecureBlackboxPGPKeyring : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxPGPKeyringDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasError;

  BOOL m_delegateHasNotification;

}

+ (SecureBlackboxPGPKeyring*)pgpkeyring;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxPGPKeyringDelegate> delegate;
- (id <SecureBlackboxPGPKeyringDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxPGPKeyringDelegate>)anObject;

  /* Events */

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readonly,assign,getter=keyCount) int keyCount NS_SWIFT_NAME(keyCount);

- (int)keyCount NS_SWIFT_NAME(keyCount());

- (int)keyBitsInKey:(int)keyIndex NS_SWIFT_NAME(keyBitsInKey(_:));

- (BOOL)keyCanEncrypt:(int)keyIndex NS_SWIFT_NAME(keyCanEncrypt(_:));

- (BOOL)keyCanSign:(int)keyIndex NS_SWIFT_NAME(keyCanSign(_:));

- (NSString*)keyCurve:(int)keyIndex NS_SWIFT_NAME(keyCurve(_:));

- (BOOL)keyEnabled:(int)keyIndex NS_SWIFT_NAME(keyEnabled(_:));

- (NSString*)keyEncryptionAlgorithm:(int)keyIndex NS_SWIFT_NAME(keyEncryptionAlgorithm(_:));

- (long long)keyHandle:(int)keyIndex NS_SWIFT_NAME(keyHandle(_:));

- (BOOL)keyIsPublic:(int)keyIndex NS_SWIFT_NAME(keyIsPublic(_:));

- (BOOL)keyIsSecret:(int)keyIndex NS_SWIFT_NAME(keyIsSecret(_:));

- (BOOL)keyIsSubkey:(int)keyIndex NS_SWIFT_NAME(keyIsSubkey(_:));

- (NSString*)keyKeyFP:(int)keyIndex NS_SWIFT_NAME(keyKeyFP(_:));

- (NSString*)keyKeyID:(int)keyIndex NS_SWIFT_NAME(keyKeyID(_:));

- (NSString*)keyPassphrase:(int)keyIndex NS_SWIFT_NAME(keyPassphrase(_:));

- (BOOL)keyPassphraseValid:(int)keyIndex NS_SWIFT_NAME(keyPassphraseValid(_:));

- (NSString*)keyPrimaryKeyID:(int)keyIndex NS_SWIFT_NAME(keyPrimaryKeyID(_:));

- (int)keyProtection:(int)keyIndex NS_SWIFT_NAME(keyProtection(_:));

- (NSString*)keyPublicKeyAlgorithm:(int)keyIndex NS_SWIFT_NAME(keyPublicKeyAlgorithm(_:));

- (int)keyQBits:(int)keyIndex NS_SWIFT_NAME(keyQBits(_:));

- (NSString*)keyTimestamp:(int)keyIndex NS_SWIFT_NAME(keyTimestamp(_:));

- (NSString*)keyUsername:(int)keyIndex NS_SWIFT_NAME(keyUsername(_:));

- (NSString*)keyValidTo:(int)keyIndex NS_SWIFT_NAME(keyValidTo(_:));

- (int)keyVersion:(int)keyIndex NS_SWIFT_NAME(keyVersion(_:));

@property (nonatomic,readonly,assign,getter=pinnedKeyBitsInKey) int pinnedKeyBitsInKey NS_SWIFT_NAME(pinnedKeyBitsInKey);

- (int)pinnedKeyBitsInKey NS_SWIFT_NAME(pinnedKeyBitsInKey());

@property (nonatomic,readonly,assign,getter=pinnedKeyCanEncrypt) BOOL pinnedKeyCanEncrypt NS_SWIFT_NAME(pinnedKeyCanEncrypt);

- (BOOL)pinnedKeyCanEncrypt NS_SWIFT_NAME(pinnedKeyCanEncrypt());

@property (nonatomic,readonly,assign,getter=pinnedKeyCanSign) BOOL pinnedKeyCanSign NS_SWIFT_NAME(pinnedKeyCanSign);

- (BOOL)pinnedKeyCanSign NS_SWIFT_NAME(pinnedKeyCanSign());

@property (nonatomic,readonly,assign,getter=pinnedKeyCurve) NSString* pinnedKeyCurve NS_SWIFT_NAME(pinnedKeyCurve);

- (NSString*)pinnedKeyCurve NS_SWIFT_NAME(pinnedKeyCurve());

@property (nonatomic,readwrite,assign,getter=pinnedKeyEnabled,setter=setPinnedKeyEnabled:) BOOL pinnedKeyEnabled NS_SWIFT_NAME(pinnedKeyEnabled);

- (BOOL)pinnedKeyEnabled NS_SWIFT_NAME(pinnedKeyEnabled());
- (void)setPinnedKeyEnabled :(BOOL)newPinnedKeyEnabled NS_SWIFT_NAME(setPinnedKeyEnabled(_:));

@property (nonatomic,readonly,assign,getter=pinnedKeyEncryptionAlgorithm) NSString* pinnedKeyEncryptionAlgorithm NS_SWIFT_NAME(pinnedKeyEncryptionAlgorithm);

- (NSString*)pinnedKeyEncryptionAlgorithm NS_SWIFT_NAME(pinnedKeyEncryptionAlgorithm());

@property (nonatomic,readwrite,assign,getter=pinnedKeyHandle,setter=setPinnedKeyHandle:) long long pinnedKeyHandle NS_SWIFT_NAME(pinnedKeyHandle);

- (long long)pinnedKeyHandle NS_SWIFT_NAME(pinnedKeyHandle());
- (void)setPinnedKeyHandle :(long long)newPinnedKeyHandle NS_SWIFT_NAME(setPinnedKeyHandle(_:));

@property (nonatomic,readonly,assign,getter=pinnedKeyIsPublic) BOOL pinnedKeyIsPublic NS_SWIFT_NAME(pinnedKeyIsPublic);

- (BOOL)pinnedKeyIsPublic NS_SWIFT_NAME(pinnedKeyIsPublic());

@property (nonatomic,readonly,assign,getter=pinnedKeyIsSecret) BOOL pinnedKeyIsSecret NS_SWIFT_NAME(pinnedKeyIsSecret);

- (BOOL)pinnedKeyIsSecret NS_SWIFT_NAME(pinnedKeyIsSecret());

@property (nonatomic,readonly,assign,getter=pinnedKeyIsSubkey) BOOL pinnedKeyIsSubkey NS_SWIFT_NAME(pinnedKeyIsSubkey);

- (BOOL)pinnedKeyIsSubkey NS_SWIFT_NAME(pinnedKeyIsSubkey());

@property (nonatomic,readonly,assign,getter=pinnedKeyKeyFP) NSString* pinnedKeyKeyFP NS_SWIFT_NAME(pinnedKeyKeyFP);

- (NSString*)pinnedKeyKeyFP NS_SWIFT_NAME(pinnedKeyKeyFP());

@property (nonatomic,readonly,assign,getter=pinnedKeyKeyID) NSString* pinnedKeyKeyID NS_SWIFT_NAME(pinnedKeyKeyID);

- (NSString*)pinnedKeyKeyID NS_SWIFT_NAME(pinnedKeyKeyID());

@property (nonatomic,readwrite,assign,getter=pinnedKeyPassphrase,setter=setPinnedKeyPassphrase:) NSString* pinnedKeyPassphrase NS_SWIFT_NAME(pinnedKeyPassphrase);

- (NSString*)pinnedKeyPassphrase NS_SWIFT_NAME(pinnedKeyPassphrase());
- (void)setPinnedKeyPassphrase :(NSString*)newPinnedKeyPassphrase NS_SWIFT_NAME(setPinnedKeyPassphrase(_:));

@property (nonatomic,readonly,assign,getter=pinnedKeyPassphraseValid) BOOL pinnedKeyPassphraseValid NS_SWIFT_NAME(pinnedKeyPassphraseValid);

- (BOOL)pinnedKeyPassphraseValid NS_SWIFT_NAME(pinnedKeyPassphraseValid());

@property (nonatomic,readonly,assign,getter=pinnedKeyPrimaryKeyID) NSString* pinnedKeyPrimaryKeyID NS_SWIFT_NAME(pinnedKeyPrimaryKeyID);

- (NSString*)pinnedKeyPrimaryKeyID NS_SWIFT_NAME(pinnedKeyPrimaryKeyID());

@property (nonatomic,readonly,assign,getter=pinnedKeyProtection) int pinnedKeyProtection NS_SWIFT_NAME(pinnedKeyProtection);

- (int)pinnedKeyProtection NS_SWIFT_NAME(pinnedKeyProtection());

@property (nonatomic,readonly,assign,getter=pinnedKeyPublicKeyAlgorithm) NSString* pinnedKeyPublicKeyAlgorithm NS_SWIFT_NAME(pinnedKeyPublicKeyAlgorithm);

- (NSString*)pinnedKeyPublicKeyAlgorithm NS_SWIFT_NAME(pinnedKeyPublicKeyAlgorithm());

@property (nonatomic,readonly,assign,getter=pinnedKeyQBits) int pinnedKeyQBits NS_SWIFT_NAME(pinnedKeyQBits);

- (int)pinnedKeyQBits NS_SWIFT_NAME(pinnedKeyQBits());

@property (nonatomic,readonly,assign,getter=pinnedKeyTimestamp) NSString* pinnedKeyTimestamp NS_SWIFT_NAME(pinnedKeyTimestamp);

- (NSString*)pinnedKeyTimestamp NS_SWIFT_NAME(pinnedKeyTimestamp());

@property (nonatomic,readonly,assign,getter=pinnedKeyUsername) NSString* pinnedKeyUsername NS_SWIFT_NAME(pinnedKeyUsername);

- (NSString*)pinnedKeyUsername NS_SWIFT_NAME(pinnedKeyUsername());

@property (nonatomic,readonly,assign,getter=pinnedKeyValidTo) NSString* pinnedKeyValidTo NS_SWIFT_NAME(pinnedKeyValidTo);

- (NSString*)pinnedKeyValidTo NS_SWIFT_NAME(pinnedKeyValidTo());

@property (nonatomic,readonly,assign,getter=pinnedKeyVersion) int pinnedKeyVersion NS_SWIFT_NAME(pinnedKeyVersion);

- (int)pinnedKeyVersion NS_SWIFT_NAME(pinnedKeyVersion());

@property (nonatomic,readonly,assign,getter=selectedKeyCount) int selectedKeyCount NS_SWIFT_NAME(selectedKeyCount);

- (int)selectedKeyCount NS_SWIFT_NAME(selectedKeyCount());

- (int)selectedKeyBitsInKey:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyBitsInKey(_:));

- (BOOL)selectedKeyCanEncrypt:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyCanEncrypt(_:));

- (BOOL)selectedKeyCanSign:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyCanSign(_:));

- (NSString*)selectedKeyCurve:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyCurve(_:));

- (BOOL)selectedKeyEnabled:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyEnabled(_:));

- (NSString*)selectedKeyEncryptionAlgorithm:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyEncryptionAlgorithm(_:));

- (long long)selectedKeyHandle:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyHandle(_:));

- (BOOL)selectedKeyIsPublic:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyIsPublic(_:));

- (BOOL)selectedKeyIsSecret:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyIsSecret(_:));

- (BOOL)selectedKeyIsSubkey:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyIsSubkey(_:));

- (NSString*)selectedKeyKeyFP:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyKeyFP(_:));

- (NSString*)selectedKeyKeyID:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyKeyID(_:));

- (NSString*)selectedKeyPassphrase:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyPassphrase(_:));

- (BOOL)selectedKeyPassphraseValid:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyPassphraseValid(_:));

- (NSString*)selectedKeyPrimaryKeyID:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyPrimaryKeyID(_:));

- (int)selectedKeyProtection:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyProtection(_:));

- (NSString*)selectedKeyPublicKeyAlgorithm:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyPublicKeyAlgorithm(_:));

- (int)selectedKeyQBits:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyQBits(_:));

- (NSString*)selectedKeyTimestamp:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyTimestamp(_:));

- (NSString*)selectedKeyUsername:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyUsername(_:));

- (NSString*)selectedKeyValidTo:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyValidTo(_:));

- (int)selectedKeyVersion:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyVersion(_:));

  /* Methods */

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (NSData*)exportBytes:(BOOL)secret NS_SWIFT_NAME(exportBytes(_:));

- (void)exportToFile:(NSString*)fileName :(BOOL)secret NS_SWIFT_NAME(exportToFile(_:_:));

- (void)importBytes:(NSData*)keyring NS_SWIFT_NAME(importBytes(_:));

- (void)importFromFile:(NSString*)keyringFile NS_SWIFT_NAME(importFromFile(_:));

- (void)importPinned NS_SWIFT_NAME(importPinned());

- (void)remove:(int)index NS_SWIFT_NAME(remove(_:));

- (void)removeByID:(NSString*)keyID NS_SWIFT_NAME(removeByID(_:));

- (void)reset NS_SWIFT_NAME(reset());

- (void)select:(NSString*)filter :(BOOL)secretOnly :(int)maxCount NS_SWIFT_NAME(select(_:_:_:));

- (void)updatePinned NS_SWIFT_NAME(updatePinned());

@end

