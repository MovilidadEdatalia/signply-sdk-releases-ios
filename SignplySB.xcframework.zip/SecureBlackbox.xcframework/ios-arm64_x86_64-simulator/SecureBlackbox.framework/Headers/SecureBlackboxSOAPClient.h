/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

//CHAINVALIDITIES
#define CVT_VALID                                          0

#define CVT_VALID_BUT_UNTRUSTED                            1

#define CVT_INVALID                                        2

#define CVT_CANT_BE_ESTABLISHED                            3

//ASYNCSIGNMETHODS
#define ASMD_PKCS1                                         0

#define ASMD_PKCS7                                         1

//EXTERNALCRYPTOMODES
#define ECM_DEFAULT                                        0

#define ECM_DISABLED                                       1

#define ECM_GENERIC                                        2

#define ECM_DCAUTH                                         3

#define ECM_DCAUTH_JSON                                    4

//KEEPALIVEPOLICYTYPES
#define CKAP_STANDARD_DEFINED                              0

#define CKAP_PREFER_KEEP_ALIVE                             1

#define CKAP_RELY_ON_SERVER                                2

#define CKAP_KEEP_ALIVES_DISABLED                          3

//PROXYAUTHTYPES
#define PAT_NO_AUTHENTICATION                              0

#define PAT_BASIC                                          1

#define PAT_DIGEST                                         2

#define PAT_NTLM                                           3

//PROXYTYPES
#define CPT_NONE                                           0

#define CPT_SOCKS_4                                        1

#define CPT_SOCKS_5                                        2

#define CPT_WEB_TUNNEL                                     3

#define CPT_HTTP                                           4

//HTTPVERSIONS
#define CHV_HTTP10                                         0

#define CHV_HTTP11                                         1

//SOAPRESPONSETYPES
#define SRT_UNKNOWN                                        0

#define SRT_BINARY                                         1

#define SRT_XMLDOCUMENT                                    2

#define SRT_SOAPMESSAGE                                    3

//SOAPPROTOCOLVERSIONS
#define SPV_AUTO                                           0

#define SPV_11                                             1

#define SPV_12                                             2

//DNSRESOLVEMODES
#define DM_AUTO                                            0

#define DM_PLATFORM                                        1

#define DM_OWN                                             2

#define DM_OWN_SECURE                                      3

//SECURETRANSPORTPREDEFINEDCONFIGURATIONS
#define STPC_DEFAULT                                       0

#define STPC_COMPATIBLE                                    1

#define STPC_COMPREHENSIVE_INSECURE                        2

#define STPC_HIGHLY_SECURE                                 3

//CLIENTAUTHTYPES
#define CCAT_NO_AUTH                                       0

#define CCAT_REQUEST_CERT                                  1

#define CCAT_REQUIRE_CERT                                  2

//RENEGOTIATIONATTACKPREVENTIONMODES
#define CRAPM_COMPATIBLE                                   0

#define CRAPM_STRICT                                       1

#define CRAPM_AUTO                                         2

//REVOCATIONCHECKKINDS
#define CRC_NONE                                           0

#define CRC_AUTO                                           1

#define CRC_ALL_CRL                                        2

#define CRC_ALL_OCSP                                       3

#define CRC_ALL_CRLAND_OCSP                                4

#define CRC_ANY_CRL                                        5

#define CRC_ANY_OCSP                                       6

#define CRC_ANY_CRLOR_OCSP                                 7

#define CRC_ANY_OCSPOR_CRL                                 8

//SSLMODES
#define SM_DEFAULT                                         0

#define SM_NO_TLS                                          1

#define SM_EXPLICIT_TLS                                    2

#define SM_IMPLICIT_TLS                                    3

#define SM_MIXED_TLS                                       4

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxSOAPClientDelegate <NSObject>
@optional
- (void)onBeforeReceiveAttachment NS_SWIFT_NAME(onBeforeReceiveAttachment());

- (void)onBeforeSendAttachment:(int*)lastAttachment NS_SWIFT_NAME(onBeforeSendAttachment(_:));

- (void)onCookie:(NSString*)cookieText NS_SWIFT_NAME(onCookie(_:));

- (void)onDocumentBegin NS_SWIFT_NAME(onDocumentBegin());

- (void)onDocumentEnd NS_SWIFT_NAME(onDocumentEnd());

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onExternalSign:(NSString*)operationId :(NSString*)hashAlgorithm :(NSString*)pars :(NSString*)data :(NSString**)signedData NS_SWIFT_NAME(onExternalSign(_:_:_:_:_:));

- (void)onHeadersPrepared NS_SWIFT_NAME(onHeadersPrepared());

- (void)onHeadersReceived NS_SWIFT_NAME(onHeadersReceived());

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onProgress:(long long)total :(long long)current :(int*)cancel NS_SWIFT_NAME(onProgress(_:_:_:));

- (void)onRedirection:(NSString*)oldURL :(NSString**)newURL :(int*)allowRedirection NS_SWIFT_NAME(onRedirection(_:_:_:));

- (void)onTLSCertNeeded:(NSString*)host :(NSString*)CANames NS_SWIFT_NAME(onTLSCertNeeded(_:_:));

- (void)onTLSCertValidate:(NSString*)serverHost :(NSString*)serverIP :(int*)accept NS_SWIFT_NAME(onTLSCertValidate(_:_:_:));

- (void)onTLSEstablished:(NSString*)host :(NSString*)version :(NSString*)ciphersuite :(NSData*)connectionId :(int*)abort NS_SWIFT_NAME(onTLSEstablished(_:_:_:_:_:));

- (void)onTLSHandshake:(NSString*)host :(int*)abort NS_SWIFT_NAME(onTLSHandshake(_:_:));

- (void)onTLSPSK:(NSString*)host :(NSString*)hint NS_SWIFT_NAME(onTLSPSK(_:_:));

- (void)onTLSShutdown:(NSString*)host NS_SWIFT_NAME(onTLSShutdown(_:));

@end

@interface SecureBlackboxSOAPClient : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxSOAPClientDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasBeforeReceiveAttachment;

  BOOL m_delegateHasBeforeSendAttachment;

  BOOL m_delegateHasCookie;

  BOOL m_delegateHasDocumentBegin;

  BOOL m_delegateHasDocumentEnd;

  BOOL m_delegateHasError;

  BOOL m_delegateHasExternalSign;

  BOOL m_delegateHasHeadersPrepared;

  BOOL m_delegateHasHeadersReceived;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasProgress;

  BOOL m_delegateHasRedirection;

  BOOL m_delegateHasTLSCertNeeded;

  BOOL m_delegateHasTLSCertValidate;

  BOOL m_delegateHasTLSEstablished;

  BOOL m_delegateHasTLSHandshake;

  BOOL m_delegateHasTLSPSK;

  BOOL m_delegateHasTLSShutdown;

}

+ (SecureBlackboxSOAPClient*)soapclient;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxSOAPClientDelegate> delegate;
- (id <SecureBlackboxSOAPClientDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxSOAPClientDelegate>)anObject;

  /* Events */

- (void)onBeforeReceiveAttachment NS_SWIFT_NAME(onBeforeReceiveAttachment());

- (void)onBeforeSendAttachment:(int*)lastAttachment NS_SWIFT_NAME(onBeforeSendAttachment(_:));

- (void)onCookie:(NSString*)cookieText NS_SWIFT_NAME(onCookie(_:));

- (void)onDocumentBegin NS_SWIFT_NAME(onDocumentBegin());

- (void)onDocumentEnd NS_SWIFT_NAME(onDocumentEnd());

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onExternalSign:(NSString*)operationId :(NSString*)hashAlgorithm :(NSString*)pars :(NSString*)data :(NSString**)signedData NS_SWIFT_NAME(onExternalSign(_:_:_:_:_:));

- (void)onHeadersPrepared NS_SWIFT_NAME(onHeadersPrepared());

- (void)onHeadersReceived NS_SWIFT_NAME(onHeadersReceived());

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onProgress:(long long)total :(long long)current :(int*)cancel NS_SWIFT_NAME(onProgress(_:_:_:));

- (void)onRedirection:(NSString*)oldURL :(NSString**)newURL :(int*)allowRedirection NS_SWIFT_NAME(onRedirection(_:_:_:));

- (void)onTLSCertNeeded:(NSString*)host :(NSString*)CANames NS_SWIFT_NAME(onTLSCertNeeded(_:_:));

- (void)onTLSCertValidate:(NSString*)serverHost :(NSString*)serverIP :(int*)accept NS_SWIFT_NAME(onTLSCertValidate(_:_:_:));

- (void)onTLSEstablished:(NSString*)host :(NSString*)version :(NSString*)ciphersuite :(NSData*)connectionId :(int*)abort NS_SWIFT_NAME(onTLSEstablished(_:_:_:_:_:));

- (void)onTLSHandshake:(NSString*)host :(int*)abort NS_SWIFT_NAME(onTLSHandshake(_:_:));

- (void)onTLSPSK:(NSString*)host :(NSString*)hint NS_SWIFT_NAME(onTLSPSK(_:_:));

- (void)onTLSShutdown:(NSString*)host NS_SWIFT_NAME(onTLSShutdown(_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readwrite,assign,getter=attachmentBytes,setter=setAttachmentBytes:) NSData* attachmentBytes NS_SWIFT_NAME(attachmentBytes);

- (NSData*)attachmentBytes NS_SWIFT_NAME(attachmentBytes());
- (void)setAttachmentBytes :(NSData*)newAttachmentBytes NS_SWIFT_NAME(setAttachmentBytes(_:));

@property (nonatomic,readwrite,assign,getter=attachmentFile,setter=setAttachmentFile:) NSString* attachmentFile NS_SWIFT_NAME(attachmentFile);

- (NSString*)attachmentFile NS_SWIFT_NAME(attachmentFile());
- (void)setAttachmentFile :(NSString*)newAttachmentFile NS_SWIFT_NAME(setAttachmentFile(_:));

@property (nonatomic,readwrite,assign,getter=authTypes,setter=setAuthTypes:) int authTypes NS_SWIFT_NAME(authTypes);

- (int)authTypes NS_SWIFT_NAME(authTypes());
- (void)setAuthTypes :(int)newAuthTypes NS_SWIFT_NAME(setAuthTypes(_:));

@property (nonatomic,readwrite,assign,getter=blockedCertCount,setter=setBlockedCertCount:) int blockedCertCount NS_SWIFT_NAME(blockedCertCount);

- (int)blockedCertCount NS_SWIFT_NAME(blockedCertCount());
- (void)setBlockedCertCount :(int)newBlockedCertCount NS_SWIFT_NAME(setBlockedCertCount(_:));

- (NSData*)blockedCertBytes:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertBytes(_:));

- (BOOL)blockedCertCA:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertCA(_:));
- (void)setBlockedCertCA:(int)blockedCertIndex :(BOOL)newBlockedCertCA NS_SWIFT_NAME(setBlockedCertCA(_:_:));

- (NSData*)blockedCertCAKeyID:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertCAKeyID(_:));

- (int)blockedCertCertType:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertCertType(_:));

- (NSString*)blockedCertCRLDistributionPoints:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertCRLDistributionPoints(_:));
- (void)setBlockedCertCRLDistributionPoints:(int)blockedCertIndex :(NSString*)newBlockedCertCRLDistributionPoints NS_SWIFT_NAME(setBlockedCertCRLDistributionPoints(_:_:));

- (NSString*)blockedCertCurve:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertCurve(_:));
- (void)setBlockedCertCurve:(int)blockedCertIndex :(NSString*)newBlockedCertCurve NS_SWIFT_NAME(setBlockedCertCurve(_:_:));

- (NSString*)blockedCertFingerprint:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertFingerprint(_:));

- (NSString*)blockedCertFriendlyName:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertFriendlyName(_:));

- (long long)blockedCertHandle:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertHandle(_:));
- (void)setBlockedCertHandle:(int)blockedCertIndex :(long long)newBlockedCertHandle NS_SWIFT_NAME(setBlockedCertHandle(_:_:));

- (NSString*)blockedCertHashAlgorithm:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertHashAlgorithm(_:));
- (void)setBlockedCertHashAlgorithm:(int)blockedCertIndex :(NSString*)newBlockedCertHashAlgorithm NS_SWIFT_NAME(setBlockedCertHashAlgorithm(_:_:));

- (NSString*)blockedCertIssuer:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertIssuer(_:));

- (NSString*)blockedCertIssuerRDN:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertIssuerRDN(_:));
- (void)setBlockedCertIssuerRDN:(int)blockedCertIndex :(NSString*)newBlockedCertIssuerRDN NS_SWIFT_NAME(setBlockedCertIssuerRDN(_:_:));

- (NSString*)blockedCertKeyAlgorithm:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertKeyAlgorithm(_:));
- (void)setBlockedCertKeyAlgorithm:(int)blockedCertIndex :(NSString*)newBlockedCertKeyAlgorithm NS_SWIFT_NAME(setBlockedCertKeyAlgorithm(_:_:));

- (int)blockedCertKeyBits:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertKeyBits(_:));

- (NSString*)blockedCertKeyFingerprint:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertKeyFingerprint(_:));

- (int)blockedCertKeyUsage:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertKeyUsage(_:));
- (void)setBlockedCertKeyUsage:(int)blockedCertIndex :(int)newBlockedCertKeyUsage NS_SWIFT_NAME(setBlockedCertKeyUsage(_:_:));

- (BOOL)blockedCertKeyValid:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertKeyValid(_:));

- (NSString*)blockedCertOCSPLocations:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertOCSPLocations(_:));
- (void)setBlockedCertOCSPLocations:(int)blockedCertIndex :(NSString*)newBlockedCertOCSPLocations NS_SWIFT_NAME(setBlockedCertOCSPLocations(_:_:));

- (BOOL)blockedCertOCSPNoCheck:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertOCSPNoCheck(_:));
- (void)setBlockedCertOCSPNoCheck:(int)blockedCertIndex :(BOOL)newBlockedCertOCSPNoCheck NS_SWIFT_NAME(setBlockedCertOCSPNoCheck(_:_:));

- (int)blockedCertOrigin:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertOrigin(_:));

- (NSString*)blockedCertPolicyIDs:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertPolicyIDs(_:));
- (void)setBlockedCertPolicyIDs:(int)blockedCertIndex :(NSString*)newBlockedCertPolicyIDs NS_SWIFT_NAME(setBlockedCertPolicyIDs(_:_:));

- (NSData*)blockedCertPrivateKeyBytes:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertPrivateKeyBytes(_:));

- (BOOL)blockedCertPrivateKeyExists:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertPrivateKeyExists(_:));

- (BOOL)blockedCertPrivateKeyExtractable:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertPrivateKeyExtractable(_:));

- (NSData*)blockedCertPublicKeyBytes:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertPublicKeyBytes(_:));

- (BOOL)blockedCertQualified:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertQualified(_:));

- (int)blockedCertQualifiedStatements:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertQualifiedStatements(_:));
- (void)setBlockedCertQualifiedStatements:(int)blockedCertIndex :(int)newBlockedCertQualifiedStatements NS_SWIFT_NAME(setBlockedCertQualifiedStatements(_:_:));

- (NSString*)blockedCertQualifiers:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertQualifiers(_:));

- (BOOL)blockedCertSelfSigned:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSelfSigned(_:));

- (NSData*)blockedCertSerialNumber:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSerialNumber(_:));
- (void)setBlockedCertSerialNumber:(int)blockedCertIndex :(NSData*)newBlockedCertSerialNumber NS_SWIFT_NAME(setBlockedCertSerialNumber(_:_:));

- (NSString*)blockedCertSigAlgorithm:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSigAlgorithm(_:));

- (int)blockedCertSource:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSource(_:));

- (NSString*)blockedCertSubject:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSubject(_:));

- (NSString*)blockedCertSubjectAlternativeName:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSubjectAlternativeName(_:));
- (void)setBlockedCertSubjectAlternativeName:(int)blockedCertIndex :(NSString*)newBlockedCertSubjectAlternativeName NS_SWIFT_NAME(setBlockedCertSubjectAlternativeName(_:_:));

- (NSData*)blockedCertSubjectKeyID:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSubjectKeyID(_:));
- (void)setBlockedCertSubjectKeyID:(int)blockedCertIndex :(NSData*)newBlockedCertSubjectKeyID NS_SWIFT_NAME(setBlockedCertSubjectKeyID(_:_:));

- (NSString*)blockedCertSubjectRDN:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSubjectRDN(_:));
- (void)setBlockedCertSubjectRDN:(int)blockedCertIndex :(NSString*)newBlockedCertSubjectRDN NS_SWIFT_NAME(setBlockedCertSubjectRDN(_:_:));

- (BOOL)blockedCertValid:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertValid(_:));

- (NSString*)blockedCertValidFrom:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertValidFrom(_:));
- (void)setBlockedCertValidFrom:(int)blockedCertIndex :(NSString*)newBlockedCertValidFrom NS_SWIFT_NAME(setBlockedCertValidFrom(_:_:));

- (NSString*)blockedCertValidTo:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertValidTo(_:));
- (void)setBlockedCertValidTo:(int)blockedCertIndex :(NSString*)newBlockedCertValidTo NS_SWIFT_NAME(setBlockedCertValidTo(_:_:));

@property (nonatomic,readonly,assign,getter=connInfoAEADCipher) BOOL connInfoAEADCipher NS_SWIFT_NAME(connInfoAEADCipher);

- (BOOL)connInfoAEADCipher NS_SWIFT_NAME(connInfoAEADCipher());

@property (nonatomic,readonly,assign,getter=connInfoChainValidationDetails) int connInfoChainValidationDetails NS_SWIFT_NAME(connInfoChainValidationDetails);

- (int)connInfoChainValidationDetails NS_SWIFT_NAME(connInfoChainValidationDetails());

@property (nonatomic,readonly,assign,getter=connInfoChainValidationResult) int connInfoChainValidationResult NS_SWIFT_NAME(connInfoChainValidationResult);

- (int)connInfoChainValidationResult NS_SWIFT_NAME(connInfoChainValidationResult());

@property (nonatomic,readonly,assign,getter=connInfoCiphersuite) NSString* connInfoCiphersuite NS_SWIFT_NAME(connInfoCiphersuite);

- (NSString*)connInfoCiphersuite NS_SWIFT_NAME(connInfoCiphersuite());

@property (nonatomic,readonly,assign,getter=connInfoClientAuthenticated) BOOL connInfoClientAuthenticated NS_SWIFT_NAME(connInfoClientAuthenticated);

- (BOOL)connInfoClientAuthenticated NS_SWIFT_NAME(connInfoClientAuthenticated());

@property (nonatomic,readonly,assign,getter=connInfoClientAuthRequested) BOOL connInfoClientAuthRequested NS_SWIFT_NAME(connInfoClientAuthRequested);

- (BOOL)connInfoClientAuthRequested NS_SWIFT_NAME(connInfoClientAuthRequested());

@property (nonatomic,readonly,assign,getter=connInfoConnectionEstablished) BOOL connInfoConnectionEstablished NS_SWIFT_NAME(connInfoConnectionEstablished);

- (BOOL)connInfoConnectionEstablished NS_SWIFT_NAME(connInfoConnectionEstablished());

@property (nonatomic,readonly,assign,getter=connInfoConnectionID) NSData* connInfoConnectionID NS_SWIFT_NAME(connInfoConnectionID);

- (NSData*)connInfoConnectionID NS_SWIFT_NAME(connInfoConnectionID());

@property (nonatomic,readonly,assign,getter=connInfoDigestAlgorithm) NSString* connInfoDigestAlgorithm NS_SWIFT_NAME(connInfoDigestAlgorithm);

- (NSString*)connInfoDigestAlgorithm NS_SWIFT_NAME(connInfoDigestAlgorithm());

@property (nonatomic,readonly,assign,getter=connInfoEncryptionAlgorithm) NSString* connInfoEncryptionAlgorithm NS_SWIFT_NAME(connInfoEncryptionAlgorithm);

- (NSString*)connInfoEncryptionAlgorithm NS_SWIFT_NAME(connInfoEncryptionAlgorithm());

@property (nonatomic,readonly,assign,getter=connInfoExportable) BOOL connInfoExportable NS_SWIFT_NAME(connInfoExportable);

- (BOOL)connInfoExportable NS_SWIFT_NAME(connInfoExportable());

@property (nonatomic,readonly,assign,getter=connInfoID) long long connInfoID NS_SWIFT_NAME(connInfoID);

- (long long)connInfoID NS_SWIFT_NAME(connInfoID());

@property (nonatomic,readonly,assign,getter=connInfoKeyExchangeAlgorithm) NSString* connInfoKeyExchangeAlgorithm NS_SWIFT_NAME(connInfoKeyExchangeAlgorithm);

- (NSString*)connInfoKeyExchangeAlgorithm NS_SWIFT_NAME(connInfoKeyExchangeAlgorithm());

@property (nonatomic,readonly,assign,getter=connInfoKeyExchangeKeyBits) int connInfoKeyExchangeKeyBits NS_SWIFT_NAME(connInfoKeyExchangeKeyBits);

- (int)connInfoKeyExchangeKeyBits NS_SWIFT_NAME(connInfoKeyExchangeKeyBits());

@property (nonatomic,readonly,assign,getter=connInfoNamedECCurve) NSString* connInfoNamedECCurve NS_SWIFT_NAME(connInfoNamedECCurve);

- (NSString*)connInfoNamedECCurve NS_SWIFT_NAME(connInfoNamedECCurve());

@property (nonatomic,readonly,assign,getter=connInfoPFSCipher) BOOL connInfoPFSCipher NS_SWIFT_NAME(connInfoPFSCipher);

- (BOOL)connInfoPFSCipher NS_SWIFT_NAME(connInfoPFSCipher());

@property (nonatomic,readonly,assign,getter=connInfoPreSharedIdentity) NSString* connInfoPreSharedIdentity NS_SWIFT_NAME(connInfoPreSharedIdentity);

- (NSString*)connInfoPreSharedIdentity NS_SWIFT_NAME(connInfoPreSharedIdentity());

@property (nonatomic,readonly,assign,getter=connInfoPreSharedIdentityHint) NSString* connInfoPreSharedIdentityHint NS_SWIFT_NAME(connInfoPreSharedIdentityHint);

- (NSString*)connInfoPreSharedIdentityHint NS_SWIFT_NAME(connInfoPreSharedIdentityHint());

@property (nonatomic,readonly,assign,getter=connInfoPublicKeyBits) int connInfoPublicKeyBits NS_SWIFT_NAME(connInfoPublicKeyBits);

- (int)connInfoPublicKeyBits NS_SWIFT_NAME(connInfoPublicKeyBits());

@property (nonatomic,readonly,assign,getter=connInfoRemoteAddress) NSString* connInfoRemoteAddress NS_SWIFT_NAME(connInfoRemoteAddress);

- (NSString*)connInfoRemoteAddress NS_SWIFT_NAME(connInfoRemoteAddress());

@property (nonatomic,readonly,assign,getter=connInfoRemotePort) int connInfoRemotePort NS_SWIFT_NAME(connInfoRemotePort);

- (int)connInfoRemotePort NS_SWIFT_NAME(connInfoRemotePort());

@property (nonatomic,readonly,assign,getter=connInfoResumedSession) BOOL connInfoResumedSession NS_SWIFT_NAME(connInfoResumedSession);

- (BOOL)connInfoResumedSession NS_SWIFT_NAME(connInfoResumedSession());

@property (nonatomic,readonly,assign,getter=connInfoSecureConnection) BOOL connInfoSecureConnection NS_SWIFT_NAME(connInfoSecureConnection);

- (BOOL)connInfoSecureConnection NS_SWIFT_NAME(connInfoSecureConnection());

@property (nonatomic,readonly,assign,getter=connInfoServerAuthenticated) BOOL connInfoServerAuthenticated NS_SWIFT_NAME(connInfoServerAuthenticated);

- (BOOL)connInfoServerAuthenticated NS_SWIFT_NAME(connInfoServerAuthenticated());

@property (nonatomic,readonly,assign,getter=connInfoSignatureAlgorithm) NSString* connInfoSignatureAlgorithm NS_SWIFT_NAME(connInfoSignatureAlgorithm);

- (NSString*)connInfoSignatureAlgorithm NS_SWIFT_NAME(connInfoSignatureAlgorithm());

@property (nonatomic,readonly,assign,getter=connInfoSymmetricBlockSize) int connInfoSymmetricBlockSize NS_SWIFT_NAME(connInfoSymmetricBlockSize);

- (int)connInfoSymmetricBlockSize NS_SWIFT_NAME(connInfoSymmetricBlockSize());

@property (nonatomic,readonly,assign,getter=connInfoSymmetricKeyBits) int connInfoSymmetricKeyBits NS_SWIFT_NAME(connInfoSymmetricKeyBits);

- (int)connInfoSymmetricKeyBits NS_SWIFT_NAME(connInfoSymmetricKeyBits());

@property (nonatomic,readonly,assign,getter=connInfoTotalBytesReceived) long long connInfoTotalBytesReceived NS_SWIFT_NAME(connInfoTotalBytesReceived);

- (long long)connInfoTotalBytesReceived NS_SWIFT_NAME(connInfoTotalBytesReceived());

@property (nonatomic,readonly,assign,getter=connInfoTotalBytesSent) long long connInfoTotalBytesSent NS_SWIFT_NAME(connInfoTotalBytesSent);

- (long long)connInfoTotalBytesSent NS_SWIFT_NAME(connInfoTotalBytesSent());

@property (nonatomic,readonly,assign,getter=connInfoValidationLog) NSString* connInfoValidationLog NS_SWIFT_NAME(connInfoValidationLog);

- (NSString*)connInfoValidationLog NS_SWIFT_NAME(connInfoValidationLog());

@property (nonatomic,readonly,assign,getter=connInfoVersion) NSString* connInfoVersion NS_SWIFT_NAME(connInfoVersion);

- (NSString*)connInfoVersion NS_SWIFT_NAME(connInfoVersion());

@property (nonatomic,readwrite,assign,getter=encoding,setter=setEncoding:) NSString* encoding NS_SWIFT_NAME(encoding);

- (NSString*)encoding NS_SWIFT_NAME(encoding());
- (void)setEncoding :(NSString*)newEncoding NS_SWIFT_NAME(setEncoding(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoAsyncDocumentID,setter=setExternalCryptoAsyncDocumentID:) NSString* externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID);

- (NSString*)externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID());
- (void)setExternalCryptoAsyncDocumentID :(NSString*)newExternalCryptoAsyncDocumentID NS_SWIFT_NAME(setExternalCryptoAsyncDocumentID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoCustomParams,setter=setExternalCryptoCustomParams:) NSString* externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams);

- (NSString*)externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams());
- (void)setExternalCryptoCustomParams :(NSString*)newExternalCryptoCustomParams NS_SWIFT_NAME(setExternalCryptoCustomParams(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoData,setter=setExternalCryptoData:) NSString* externalCryptoData NS_SWIFT_NAME(externalCryptoData);

- (NSString*)externalCryptoData NS_SWIFT_NAME(externalCryptoData());
- (void)setExternalCryptoData :(NSString*)newExternalCryptoData NS_SWIFT_NAME(setExternalCryptoData(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoExternalHashCalculation,setter=setExternalCryptoExternalHashCalculation:) BOOL externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation);

- (BOOL)externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation());
- (void)setExternalCryptoExternalHashCalculation :(BOOL)newExternalCryptoExternalHashCalculation NS_SWIFT_NAME(setExternalCryptoExternalHashCalculation(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoHashAlgorithm,setter=setExternalCryptoHashAlgorithm:) NSString* externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm);

- (NSString*)externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm());
- (void)setExternalCryptoHashAlgorithm :(NSString*)newExternalCryptoHashAlgorithm NS_SWIFT_NAME(setExternalCryptoHashAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeyID,setter=setExternalCryptoKeyID:) NSString* externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID);

- (NSString*)externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID());
- (void)setExternalCryptoKeyID :(NSString*)newExternalCryptoKeyID NS_SWIFT_NAME(setExternalCryptoKeyID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeySecret,setter=setExternalCryptoKeySecret:) NSString* externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret);

- (NSString*)externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret());
- (void)setExternalCryptoKeySecret :(NSString*)newExternalCryptoKeySecret NS_SWIFT_NAME(setExternalCryptoKeySecret(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMethod,setter=setExternalCryptoMethod:) int externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod);

- (int)externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod());
- (void)setExternalCryptoMethod :(int)newExternalCryptoMethod NS_SWIFT_NAME(setExternalCryptoMethod(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMode,setter=setExternalCryptoMode:) int externalCryptoMode NS_SWIFT_NAME(externalCryptoMode);

- (int)externalCryptoMode NS_SWIFT_NAME(externalCryptoMode());
- (void)setExternalCryptoMode :(int)newExternalCryptoMode NS_SWIFT_NAME(setExternalCryptoMode(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoPublicKeyAlgorithm,setter=setExternalCryptoPublicKeyAlgorithm:) NSString* externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm);

- (NSString*)externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm());
- (void)setExternalCryptoPublicKeyAlgorithm :(NSString*)newExternalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(setExternalCryptoPublicKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=faultActor) NSString* faultActor NS_SWIFT_NAME(faultActor);

- (NSString*)faultActor NS_SWIFT_NAME(faultActor());

@property (nonatomic,readonly,assign,getter=faultCode) NSString* faultCode NS_SWIFT_NAME(faultCode);

- (NSString*)faultCode NS_SWIFT_NAME(faultCode());

@property (nonatomic,readonly,assign,getter=faultDetail) NSString* faultDetail NS_SWIFT_NAME(faultDetail);

- (NSString*)faultDetail NS_SWIFT_NAME(faultDetail());

@property (nonatomic,readonly,assign,getter=faultString) NSString* faultString NS_SWIFT_NAME(faultString);

- (NSString*)faultString NS_SWIFT_NAME(faultString());

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=inputBytes,setter=setInputBytes:) NSData* inputBytes NS_SWIFT_NAME(inputBytes);

- (NSData*)inputBytes NS_SWIFT_NAME(inputBytes());
- (void)setInputBytes :(NSData*)newInputBytes NS_SWIFT_NAME(setInputBytes(_:));

@property (nonatomic,readwrite,assign,getter=inputFile,setter=setInputFile:) NSString* inputFile NS_SWIFT_NAME(inputFile);

- (NSString*)inputFile NS_SWIFT_NAME(inputFile());
- (void)setInputFile :(NSString*)newInputFile NS_SWIFT_NAME(setInputFile(_:));

@property (nonatomic,readwrite,assign,getter=keepAlivePolicy,setter=setKeepAlivePolicy:) int keepAlivePolicy NS_SWIFT_NAME(keepAlivePolicy);

- (int)keepAlivePolicy NS_SWIFT_NAME(keepAlivePolicy());
- (void)setKeepAlivePolicy :(int)newKeepAlivePolicy NS_SWIFT_NAME(setKeepAlivePolicy(_:));

@property (nonatomic,readwrite,assign,getter=knownCertCount,setter=setKnownCertCount:) int knownCertCount NS_SWIFT_NAME(knownCertCount);

- (int)knownCertCount NS_SWIFT_NAME(knownCertCount());
- (void)setKnownCertCount :(int)newKnownCertCount NS_SWIFT_NAME(setKnownCertCount(_:));

- (NSData*)knownCertBytes:(int)knownCertIndex NS_SWIFT_NAME(knownCertBytes(_:));

- (BOOL)knownCertCA:(int)knownCertIndex NS_SWIFT_NAME(knownCertCA(_:));
- (void)setKnownCertCA:(int)knownCertIndex :(BOOL)newKnownCertCA NS_SWIFT_NAME(setKnownCertCA(_:_:));

- (NSData*)knownCertCAKeyID:(int)knownCertIndex NS_SWIFT_NAME(knownCertCAKeyID(_:));

- (int)knownCertCertType:(int)knownCertIndex NS_SWIFT_NAME(knownCertCertType(_:));

- (NSString*)knownCertCRLDistributionPoints:(int)knownCertIndex NS_SWIFT_NAME(knownCertCRLDistributionPoints(_:));
- (void)setKnownCertCRLDistributionPoints:(int)knownCertIndex :(NSString*)newKnownCertCRLDistributionPoints NS_SWIFT_NAME(setKnownCertCRLDistributionPoints(_:_:));

- (NSString*)knownCertCurve:(int)knownCertIndex NS_SWIFT_NAME(knownCertCurve(_:));
- (void)setKnownCertCurve:(int)knownCertIndex :(NSString*)newKnownCertCurve NS_SWIFT_NAME(setKnownCertCurve(_:_:));

- (NSString*)knownCertFingerprint:(int)knownCertIndex NS_SWIFT_NAME(knownCertFingerprint(_:));

- (NSString*)knownCertFriendlyName:(int)knownCertIndex NS_SWIFT_NAME(knownCertFriendlyName(_:));

- (long long)knownCertHandle:(int)knownCertIndex NS_SWIFT_NAME(knownCertHandle(_:));
- (void)setKnownCertHandle:(int)knownCertIndex :(long long)newKnownCertHandle NS_SWIFT_NAME(setKnownCertHandle(_:_:));

- (NSString*)knownCertHashAlgorithm:(int)knownCertIndex NS_SWIFT_NAME(knownCertHashAlgorithm(_:));
- (void)setKnownCertHashAlgorithm:(int)knownCertIndex :(NSString*)newKnownCertHashAlgorithm NS_SWIFT_NAME(setKnownCertHashAlgorithm(_:_:));

- (NSString*)knownCertIssuer:(int)knownCertIndex NS_SWIFT_NAME(knownCertIssuer(_:));

- (NSString*)knownCertIssuerRDN:(int)knownCertIndex NS_SWIFT_NAME(knownCertIssuerRDN(_:));
- (void)setKnownCertIssuerRDN:(int)knownCertIndex :(NSString*)newKnownCertIssuerRDN NS_SWIFT_NAME(setKnownCertIssuerRDN(_:_:));

- (NSString*)knownCertKeyAlgorithm:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyAlgorithm(_:));
- (void)setKnownCertKeyAlgorithm:(int)knownCertIndex :(NSString*)newKnownCertKeyAlgorithm NS_SWIFT_NAME(setKnownCertKeyAlgorithm(_:_:));

- (int)knownCertKeyBits:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyBits(_:));

- (NSString*)knownCertKeyFingerprint:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyFingerprint(_:));

- (int)knownCertKeyUsage:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyUsage(_:));
- (void)setKnownCertKeyUsage:(int)knownCertIndex :(int)newKnownCertKeyUsage NS_SWIFT_NAME(setKnownCertKeyUsage(_:_:));

- (BOOL)knownCertKeyValid:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyValid(_:));

- (NSString*)knownCertOCSPLocations:(int)knownCertIndex NS_SWIFT_NAME(knownCertOCSPLocations(_:));
- (void)setKnownCertOCSPLocations:(int)knownCertIndex :(NSString*)newKnownCertOCSPLocations NS_SWIFT_NAME(setKnownCertOCSPLocations(_:_:));

- (BOOL)knownCertOCSPNoCheck:(int)knownCertIndex NS_SWIFT_NAME(knownCertOCSPNoCheck(_:));
- (void)setKnownCertOCSPNoCheck:(int)knownCertIndex :(BOOL)newKnownCertOCSPNoCheck NS_SWIFT_NAME(setKnownCertOCSPNoCheck(_:_:));

- (int)knownCertOrigin:(int)knownCertIndex NS_SWIFT_NAME(knownCertOrigin(_:));

- (NSString*)knownCertPolicyIDs:(int)knownCertIndex NS_SWIFT_NAME(knownCertPolicyIDs(_:));
- (void)setKnownCertPolicyIDs:(int)knownCertIndex :(NSString*)newKnownCertPolicyIDs NS_SWIFT_NAME(setKnownCertPolicyIDs(_:_:));

- (NSData*)knownCertPrivateKeyBytes:(int)knownCertIndex NS_SWIFT_NAME(knownCertPrivateKeyBytes(_:));

- (BOOL)knownCertPrivateKeyExists:(int)knownCertIndex NS_SWIFT_NAME(knownCertPrivateKeyExists(_:));

- (BOOL)knownCertPrivateKeyExtractable:(int)knownCertIndex NS_SWIFT_NAME(knownCertPrivateKeyExtractable(_:));

- (NSData*)knownCertPublicKeyBytes:(int)knownCertIndex NS_SWIFT_NAME(knownCertPublicKeyBytes(_:));

- (BOOL)knownCertQualified:(int)knownCertIndex NS_SWIFT_NAME(knownCertQualified(_:));

- (int)knownCertQualifiedStatements:(int)knownCertIndex NS_SWIFT_NAME(knownCertQualifiedStatements(_:));
- (void)setKnownCertQualifiedStatements:(int)knownCertIndex :(int)newKnownCertQualifiedStatements NS_SWIFT_NAME(setKnownCertQualifiedStatements(_:_:));

- (NSString*)knownCertQualifiers:(int)knownCertIndex NS_SWIFT_NAME(knownCertQualifiers(_:));

- (BOOL)knownCertSelfSigned:(int)knownCertIndex NS_SWIFT_NAME(knownCertSelfSigned(_:));

- (NSData*)knownCertSerialNumber:(int)knownCertIndex NS_SWIFT_NAME(knownCertSerialNumber(_:));
- (void)setKnownCertSerialNumber:(int)knownCertIndex :(NSData*)newKnownCertSerialNumber NS_SWIFT_NAME(setKnownCertSerialNumber(_:_:));

- (NSString*)knownCertSigAlgorithm:(int)knownCertIndex NS_SWIFT_NAME(knownCertSigAlgorithm(_:));

- (int)knownCertSource:(int)knownCertIndex NS_SWIFT_NAME(knownCertSource(_:));

- (NSString*)knownCertSubject:(int)knownCertIndex NS_SWIFT_NAME(knownCertSubject(_:));

- (NSString*)knownCertSubjectAlternativeName:(int)knownCertIndex NS_SWIFT_NAME(knownCertSubjectAlternativeName(_:));
- (void)setKnownCertSubjectAlternativeName:(int)knownCertIndex :(NSString*)newKnownCertSubjectAlternativeName NS_SWIFT_NAME(setKnownCertSubjectAlternativeName(_:_:));

- (NSData*)knownCertSubjectKeyID:(int)knownCertIndex NS_SWIFT_NAME(knownCertSubjectKeyID(_:));
- (void)setKnownCertSubjectKeyID:(int)knownCertIndex :(NSData*)newKnownCertSubjectKeyID NS_SWIFT_NAME(setKnownCertSubjectKeyID(_:_:));

- (NSString*)knownCertSubjectRDN:(int)knownCertIndex NS_SWIFT_NAME(knownCertSubjectRDN(_:));
- (void)setKnownCertSubjectRDN:(int)knownCertIndex :(NSString*)newKnownCertSubjectRDN NS_SWIFT_NAME(setKnownCertSubjectRDN(_:_:));

- (BOOL)knownCertValid:(int)knownCertIndex NS_SWIFT_NAME(knownCertValid(_:));

- (NSString*)knownCertValidFrom:(int)knownCertIndex NS_SWIFT_NAME(knownCertValidFrom(_:));
- (void)setKnownCertValidFrom:(int)knownCertIndex :(NSString*)newKnownCertValidFrom NS_SWIFT_NAME(setKnownCertValidFrom(_:_:));

- (NSString*)knownCertValidTo:(int)knownCertIndex NS_SWIFT_NAME(knownCertValidTo(_:));
- (void)setKnownCertValidTo:(int)knownCertIndex :(NSString*)newKnownCertValidTo NS_SWIFT_NAME(setKnownCertValidTo(_:_:));

@property (nonatomic,readwrite,assign,getter=knownCRLCount,setter=setKnownCRLCount:) int knownCRLCount NS_SWIFT_NAME(knownCRLCount);

- (int)knownCRLCount NS_SWIFT_NAME(knownCRLCount());
- (void)setKnownCRLCount :(int)newKnownCRLCount NS_SWIFT_NAME(setKnownCRLCount(_:));

- (NSData*)knownCRLBytes:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLBytes(_:));

- (NSData*)knownCRLCAKeyID:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLCAKeyID(_:));
- (void)setKnownCRLCAKeyID:(int)knownCRLIndex :(NSData*)newKnownCRLCAKeyID NS_SWIFT_NAME(setKnownCRLCAKeyID(_:_:));

- (int)knownCRLEntryCount:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLEntryCount(_:));

- (long long)knownCRLHandle:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLHandle(_:));
- (void)setKnownCRLHandle:(int)knownCRLIndex :(long long)newKnownCRLHandle NS_SWIFT_NAME(setKnownCRLHandle(_:_:));

- (NSString*)knownCRLIssuer:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLIssuer(_:));

- (NSString*)knownCRLIssuerRDN:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLIssuerRDN(_:));

- (NSString*)knownCRLLocation:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLLocation(_:));

- (NSString*)knownCRLNextUpdate:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLNextUpdate(_:));
- (void)setKnownCRLNextUpdate:(int)knownCRLIndex :(NSString*)newKnownCRLNextUpdate NS_SWIFT_NAME(setKnownCRLNextUpdate(_:_:));

- (NSString*)knownCRLSigAlgorithm:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLSigAlgorithm(_:));
- (void)setKnownCRLSigAlgorithm:(int)knownCRLIndex :(NSString*)newKnownCRLSigAlgorithm NS_SWIFT_NAME(setKnownCRLSigAlgorithm(_:_:));

- (int)knownCRLSource:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLSource(_:));

- (NSData*)knownCRLTBS:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLTBS(_:));

- (NSString*)knownCRLThisUpdate:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLThisUpdate(_:));
- (void)setKnownCRLThisUpdate:(int)knownCRLIndex :(NSString*)newKnownCRLThisUpdate NS_SWIFT_NAME(setKnownCRLThisUpdate(_:_:));

@property (nonatomic,readwrite,assign,getter=knownOCSPCount,setter=setKnownOCSPCount:) int knownOCSPCount NS_SWIFT_NAME(knownOCSPCount);

- (int)knownOCSPCount NS_SWIFT_NAME(knownOCSPCount());
- (void)setKnownOCSPCount :(int)newKnownOCSPCount NS_SWIFT_NAME(setKnownOCSPCount(_:));

- (NSData*)knownOCSPBytes:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPBytes(_:));

- (int)knownOCSPEntryCount:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPEntryCount(_:));

- (long long)knownOCSPHandle:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPHandle(_:));
- (void)setKnownOCSPHandle:(int)knownOCSPIndex :(long long)newKnownOCSPHandle NS_SWIFT_NAME(setKnownOCSPHandle(_:_:));

- (NSString*)knownOCSPIssuer:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPIssuer(_:));

- (NSString*)knownOCSPIssuerRDN:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPIssuerRDN(_:));

- (NSString*)knownOCSPLocation:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPLocation(_:));

- (NSString*)knownOCSPProducedAt:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPProducedAt(_:));
- (void)setKnownOCSPProducedAt:(int)knownOCSPIndex :(NSString*)newKnownOCSPProducedAt NS_SWIFT_NAME(setKnownOCSPProducedAt(_:_:));

- (NSString*)knownOCSPSigAlgorithm:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPSigAlgorithm(_:));
- (void)setKnownOCSPSigAlgorithm:(int)knownOCSPIndex :(NSString*)newKnownOCSPSigAlgorithm NS_SWIFT_NAME(setKnownOCSPSigAlgorithm(_:_:));

- (int)knownOCSPSource:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPSource(_:));

@property (nonatomic,readwrite,assign,getter=mimeType,setter=setMimeType:) NSString* mimeType NS_SWIFT_NAME(mimeType);

- (NSString*)mimeType NS_SWIFT_NAME(mimeType());
- (void)setMimeType :(NSString*)newMimeType NS_SWIFT_NAME(setMimeType(_:));

@property (nonatomic,readwrite,assign,getter=operationName,setter=setOperationName:) NSString* operationName NS_SWIFT_NAME(operationName);

- (NSString*)operationName NS_SWIFT_NAME(operationName());
- (void)setOperationName :(NSString*)newOperationName NS_SWIFT_NAME(setOperationName(_:));

@property (nonatomic,readwrite,assign,getter=operationNamespaceURI,setter=setOperationNamespaceURI:) NSString* operationNamespaceURI NS_SWIFT_NAME(operationNamespaceURI);

- (NSString*)operationNamespaceURI NS_SWIFT_NAME(operationNamespaceURI());
- (void)setOperationNamespaceURI :(NSString*)newOperationNamespaceURI NS_SWIFT_NAME(setOperationNamespaceURI(_:));

@property (nonatomic,readonly,assign,getter=operationResponseName) NSString* operationResponseName NS_SWIFT_NAME(operationResponseName);

- (NSString*)operationResponseName NS_SWIFT_NAME(operationResponseName());

@property (nonatomic,readonly,assign,getter=operationResponseNamespaceURI) NSString* operationResponseNamespaceURI NS_SWIFT_NAME(operationResponseNamespaceURI);

- (NSString*)operationResponseNamespaceURI NS_SWIFT_NAME(operationResponseNamespaceURI());

@property (nonatomic,readonly,assign,getter=operationResponseTextContent) NSString* operationResponseTextContent NS_SWIFT_NAME(operationResponseTextContent);

- (NSString*)operationResponseTextContent NS_SWIFT_NAME(operationResponseTextContent());

@property (nonatomic,readonly,assign,getter=operationResponseXML) NSString* operationResponseXML NS_SWIFT_NAME(operationResponseXML);

- (NSString*)operationResponseXML NS_SWIFT_NAME(operationResponseXML());

@property (nonatomic,readonly,assign,getter=outputAttachmentBytes) NSData* outputAttachmentBytes NS_SWIFT_NAME(outputAttachmentBytes);

- (NSData*)outputAttachmentBytes NS_SWIFT_NAME(outputAttachmentBytes());

@property (nonatomic,readwrite,assign,getter=outputAttachmentFile,setter=setOutputAttachmentFile:) NSString* outputAttachmentFile NS_SWIFT_NAME(outputAttachmentFile);

- (NSString*)outputAttachmentFile NS_SWIFT_NAME(outputAttachmentFile());
- (void)setOutputAttachmentFile :(NSString*)newOutputAttachmentFile NS_SWIFT_NAME(setOutputAttachmentFile(_:));

@property (nonatomic,readonly,assign,getter=outputBytes) NSData* outputBytes NS_SWIFT_NAME(outputBytes);

- (NSData*)outputBytes NS_SWIFT_NAME(outputBytes());

@property (nonatomic,readwrite,assign,getter=outputFile,setter=setOutputFile:) NSString* outputFile NS_SWIFT_NAME(outputFile);

- (NSString*)outputFile NS_SWIFT_NAME(outputFile());
- (void)setOutputFile :(NSString*)newOutputFile NS_SWIFT_NAME(setOutputFile(_:));

@property (nonatomic,readwrite,assign,getter=proxyAddress,setter=setProxyAddress:) NSString* proxyAddress NS_SWIFT_NAME(proxyAddress);

- (NSString*)proxyAddress NS_SWIFT_NAME(proxyAddress());
- (void)setProxyAddress :(NSString*)newProxyAddress NS_SWIFT_NAME(setProxyAddress(_:));

@property (nonatomic,readwrite,assign,getter=proxyAuthentication,setter=setProxyAuthentication:) int proxyAuthentication NS_SWIFT_NAME(proxyAuthentication);

- (int)proxyAuthentication NS_SWIFT_NAME(proxyAuthentication());
- (void)setProxyAuthentication :(int)newProxyAuthentication NS_SWIFT_NAME(setProxyAuthentication(_:));

@property (nonatomic,readwrite,assign,getter=proxyPassword,setter=setProxyPassword:) NSString* proxyPassword NS_SWIFT_NAME(proxyPassword);

- (NSString*)proxyPassword NS_SWIFT_NAME(proxyPassword());
- (void)setProxyPassword :(NSString*)newProxyPassword NS_SWIFT_NAME(setProxyPassword(_:));

@property (nonatomic,readwrite,assign,getter=proxyPort,setter=setProxyPort:) int proxyPort NS_SWIFT_NAME(proxyPort);

- (int)proxyPort NS_SWIFT_NAME(proxyPort());
- (void)setProxyPort :(int)newProxyPort NS_SWIFT_NAME(setProxyPort(_:));

@property (nonatomic,readwrite,assign,getter=proxyProxyType,setter=setProxyProxyType:) int proxyProxyType NS_SWIFT_NAME(proxyProxyType);

- (int)proxyProxyType NS_SWIFT_NAME(proxyProxyType());
- (void)setProxyProxyType :(int)newProxyProxyType NS_SWIFT_NAME(setProxyProxyType(_:));

@property (nonatomic,readwrite,assign,getter=proxyRequestHeaders,setter=setProxyRequestHeaders:) NSString* proxyRequestHeaders NS_SWIFT_NAME(proxyRequestHeaders);

- (NSString*)proxyRequestHeaders NS_SWIFT_NAME(proxyRequestHeaders());
- (void)setProxyRequestHeaders :(NSString*)newProxyRequestHeaders NS_SWIFT_NAME(setProxyRequestHeaders(_:));

@property (nonatomic,readwrite,assign,getter=proxyResponseBody,setter=setProxyResponseBody:) NSString* proxyResponseBody NS_SWIFT_NAME(proxyResponseBody);

- (NSString*)proxyResponseBody NS_SWIFT_NAME(proxyResponseBody());
- (void)setProxyResponseBody :(NSString*)newProxyResponseBody NS_SWIFT_NAME(setProxyResponseBody(_:));

@property (nonatomic,readwrite,assign,getter=proxyResponseHeaders,setter=setProxyResponseHeaders:) NSString* proxyResponseHeaders NS_SWIFT_NAME(proxyResponseHeaders);

- (NSString*)proxyResponseHeaders NS_SWIFT_NAME(proxyResponseHeaders());
- (void)setProxyResponseHeaders :(NSString*)newProxyResponseHeaders NS_SWIFT_NAME(setProxyResponseHeaders(_:));

@property (nonatomic,readwrite,assign,getter=proxyUseIPv6,setter=setProxyUseIPv6:) BOOL proxyUseIPv6 NS_SWIFT_NAME(proxyUseIPv6);

- (BOOL)proxyUseIPv6 NS_SWIFT_NAME(proxyUseIPv6());
- (void)setProxyUseIPv6 :(BOOL)newProxyUseIPv6 NS_SWIFT_NAME(setProxyUseIPv6(_:));

@property (nonatomic,readwrite,assign,getter=proxyUsername,setter=setProxyUsername:) NSString* proxyUsername NS_SWIFT_NAME(proxyUsername);

- (NSString*)proxyUsername NS_SWIFT_NAME(proxyUsername());
- (void)setProxyUsername :(NSString*)newProxyUsername NS_SWIFT_NAME(setProxyUsername(_:));

@property (nonatomic,readonly,assign,getter=reasonPhrase) NSString* reasonPhrase NS_SWIFT_NAME(reasonPhrase);

- (NSString*)reasonPhrase NS_SWIFT_NAME(reasonPhrase());

@property (nonatomic,readwrite,assign,getter=reqHeaderCount,setter=setReqHeaderCount:) int reqHeaderCount NS_SWIFT_NAME(reqHeaderCount);

- (int)reqHeaderCount NS_SWIFT_NAME(reqHeaderCount());
- (void)setReqHeaderCount :(int)newReqHeaderCount NS_SWIFT_NAME(setReqHeaderCount(_:));

- (NSString*)reqHeaderCategory:(int)reqHeaderIndex NS_SWIFT_NAME(reqHeaderCategory(_:));
- (void)setReqHeaderCategory:(int)reqHeaderIndex :(NSString*)newReqHeaderCategory NS_SWIFT_NAME(setReqHeaderCategory(_:_:));

- (int)reqHeaderFormat:(int)reqHeaderIndex NS_SWIFT_NAME(reqHeaderFormat(_:));
- (void)setReqHeaderFormat:(int)reqHeaderIndex :(int)newReqHeaderFormat NS_SWIFT_NAME(setReqHeaderFormat(_:_:));

- (NSString*)reqHeaderName:(int)reqHeaderIndex NS_SWIFT_NAME(reqHeaderName(_:));
- (void)setReqHeaderName:(int)reqHeaderIndex :(NSString*)newReqHeaderName NS_SWIFT_NAME(setReqHeaderName(_:_:));

- (NSString*)reqHeaderValue:(int)reqHeaderIndex NS_SWIFT_NAME(reqHeaderValue(_:));
- (void)setReqHeaderValue:(int)reqHeaderIndex :(NSString*)newReqHeaderValue NS_SWIFT_NAME(setReqHeaderValue(_:_:));

@property (nonatomic,readwrite,assign,getter=reqParamsAccept,setter=setReqParamsAccept:) NSString* reqParamsAccept NS_SWIFT_NAME(reqParamsAccept);

- (NSString*)reqParamsAccept NS_SWIFT_NAME(reqParamsAccept());
- (void)setReqParamsAccept :(NSString*)newReqParamsAccept NS_SWIFT_NAME(setReqParamsAccept(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsAcceptCharset,setter=setReqParamsAcceptCharset:) NSString* reqParamsAcceptCharset NS_SWIFT_NAME(reqParamsAcceptCharset);

- (NSString*)reqParamsAcceptCharset NS_SWIFT_NAME(reqParamsAcceptCharset());
- (void)setReqParamsAcceptCharset :(NSString*)newReqParamsAcceptCharset NS_SWIFT_NAME(setReqParamsAcceptCharset(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsAcceptLanguage,setter=setReqParamsAcceptLanguage:) NSString* reqParamsAcceptLanguage NS_SWIFT_NAME(reqParamsAcceptLanguage);

- (NSString*)reqParamsAcceptLanguage NS_SWIFT_NAME(reqParamsAcceptLanguage());
- (void)setReqParamsAcceptLanguage :(NSString*)newReqParamsAcceptLanguage NS_SWIFT_NAME(setReqParamsAcceptLanguage(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsAcceptRangeEnd,setter=setReqParamsAcceptRangeEnd:) long long reqParamsAcceptRangeEnd NS_SWIFT_NAME(reqParamsAcceptRangeEnd);

- (long long)reqParamsAcceptRangeEnd NS_SWIFT_NAME(reqParamsAcceptRangeEnd());
- (void)setReqParamsAcceptRangeEnd :(long long)newReqParamsAcceptRangeEnd NS_SWIFT_NAME(setReqParamsAcceptRangeEnd(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsAcceptRangeStart,setter=setReqParamsAcceptRangeStart:) long long reqParamsAcceptRangeStart NS_SWIFT_NAME(reqParamsAcceptRangeStart);

- (long long)reqParamsAcceptRangeStart NS_SWIFT_NAME(reqParamsAcceptRangeStart());
- (void)setReqParamsAcceptRangeStart :(long long)newReqParamsAcceptRangeStart NS_SWIFT_NAME(setReqParamsAcceptRangeStart(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsAuthorization,setter=setReqParamsAuthorization:) NSString* reqParamsAuthorization NS_SWIFT_NAME(reqParamsAuthorization);

- (NSString*)reqParamsAuthorization NS_SWIFT_NAME(reqParamsAuthorization());
- (void)setReqParamsAuthorization :(NSString*)newReqParamsAuthorization NS_SWIFT_NAME(setReqParamsAuthorization(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsConnection,setter=setReqParamsConnection:) NSString* reqParamsConnection NS_SWIFT_NAME(reqParamsConnection);

- (NSString*)reqParamsConnection NS_SWIFT_NAME(reqParamsConnection());
- (void)setReqParamsConnection :(NSString*)newReqParamsConnection NS_SWIFT_NAME(setReqParamsConnection(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsContentLength,setter=setReqParamsContentLength:) long long reqParamsContentLength NS_SWIFT_NAME(reqParamsContentLength);

- (long long)reqParamsContentLength NS_SWIFT_NAME(reqParamsContentLength());
- (void)setReqParamsContentLength :(long long)newReqParamsContentLength NS_SWIFT_NAME(setReqParamsContentLength(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsContentRangeEnd,setter=setReqParamsContentRangeEnd:) long long reqParamsContentRangeEnd NS_SWIFT_NAME(reqParamsContentRangeEnd);

- (long long)reqParamsContentRangeEnd NS_SWIFT_NAME(reqParamsContentRangeEnd());
- (void)setReqParamsContentRangeEnd :(long long)newReqParamsContentRangeEnd NS_SWIFT_NAME(setReqParamsContentRangeEnd(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsContentRangeFullSize,setter=setReqParamsContentRangeFullSize:) long long reqParamsContentRangeFullSize NS_SWIFT_NAME(reqParamsContentRangeFullSize);

- (long long)reqParamsContentRangeFullSize NS_SWIFT_NAME(reqParamsContentRangeFullSize());
- (void)setReqParamsContentRangeFullSize :(long long)newReqParamsContentRangeFullSize NS_SWIFT_NAME(setReqParamsContentRangeFullSize(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsContentRangeStart,setter=setReqParamsContentRangeStart:) long long reqParamsContentRangeStart NS_SWIFT_NAME(reqParamsContentRangeStart);

- (long long)reqParamsContentRangeStart NS_SWIFT_NAME(reqParamsContentRangeStart());
- (void)setReqParamsContentRangeStart :(long long)newReqParamsContentRangeStart NS_SWIFT_NAME(setReqParamsContentRangeStart(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsContentType,setter=setReqParamsContentType:) NSString* reqParamsContentType NS_SWIFT_NAME(reqParamsContentType);

- (NSString*)reqParamsContentType NS_SWIFT_NAME(reqParamsContentType());
- (void)setReqParamsContentType :(NSString*)newReqParamsContentType NS_SWIFT_NAME(setReqParamsContentType(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsCookie,setter=setReqParamsCookie:) NSString* reqParamsCookie NS_SWIFT_NAME(reqParamsCookie);

- (NSString*)reqParamsCookie NS_SWIFT_NAME(reqParamsCookie());
- (void)setReqParamsCookie :(NSString*)newReqParamsCookie NS_SWIFT_NAME(setReqParamsCookie(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsCustomHeaders,setter=setReqParamsCustomHeaders:) NSString* reqParamsCustomHeaders NS_SWIFT_NAME(reqParamsCustomHeaders);

- (NSString*)reqParamsCustomHeaders NS_SWIFT_NAME(reqParamsCustomHeaders());
- (void)setReqParamsCustomHeaders :(NSString*)newReqParamsCustomHeaders NS_SWIFT_NAME(setReqParamsCustomHeaders(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsDate,setter=setReqParamsDate:) NSString* reqParamsDate NS_SWIFT_NAME(reqParamsDate);

- (NSString*)reqParamsDate NS_SWIFT_NAME(reqParamsDate());
- (void)setReqParamsDate :(NSString*)newReqParamsDate NS_SWIFT_NAME(setReqParamsDate(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsFrom,setter=setReqParamsFrom:) NSString* reqParamsFrom NS_SWIFT_NAME(reqParamsFrom);

- (NSString*)reqParamsFrom NS_SWIFT_NAME(reqParamsFrom());
- (void)setReqParamsFrom :(NSString*)newReqParamsFrom NS_SWIFT_NAME(setReqParamsFrom(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsHost,setter=setReqParamsHost:) NSString* reqParamsHost NS_SWIFT_NAME(reqParamsHost);

- (NSString*)reqParamsHost NS_SWIFT_NAME(reqParamsHost());
- (void)setReqParamsHost :(NSString*)newReqParamsHost NS_SWIFT_NAME(setReqParamsHost(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsHTTPVersion,setter=setReqParamsHTTPVersion:) int reqParamsHTTPVersion NS_SWIFT_NAME(reqParamsHTTPVersion);

- (int)reqParamsHTTPVersion NS_SWIFT_NAME(reqParamsHTTPVersion());
- (void)setReqParamsHTTPVersion :(int)newReqParamsHTTPVersion NS_SWIFT_NAME(setReqParamsHTTPVersion(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsIfMatch,setter=setReqParamsIfMatch:) NSString* reqParamsIfMatch NS_SWIFT_NAME(reqParamsIfMatch);

- (NSString*)reqParamsIfMatch NS_SWIFT_NAME(reqParamsIfMatch());
- (void)setReqParamsIfMatch :(NSString*)newReqParamsIfMatch NS_SWIFT_NAME(setReqParamsIfMatch(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsIfModifiedSince,setter=setReqParamsIfModifiedSince:) NSString* reqParamsIfModifiedSince NS_SWIFT_NAME(reqParamsIfModifiedSince);

- (NSString*)reqParamsIfModifiedSince NS_SWIFT_NAME(reqParamsIfModifiedSince());
- (void)setReqParamsIfModifiedSince :(NSString*)newReqParamsIfModifiedSince NS_SWIFT_NAME(setReqParamsIfModifiedSince(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsIfNoneMatch,setter=setReqParamsIfNoneMatch:) NSString* reqParamsIfNoneMatch NS_SWIFT_NAME(reqParamsIfNoneMatch);

- (NSString*)reqParamsIfNoneMatch NS_SWIFT_NAME(reqParamsIfNoneMatch());
- (void)setReqParamsIfNoneMatch :(NSString*)newReqParamsIfNoneMatch NS_SWIFT_NAME(setReqParamsIfNoneMatch(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsIfUnmodifiedSince,setter=setReqParamsIfUnmodifiedSince:) NSString* reqParamsIfUnmodifiedSince NS_SWIFT_NAME(reqParamsIfUnmodifiedSince);

- (NSString*)reqParamsIfUnmodifiedSince NS_SWIFT_NAME(reqParamsIfUnmodifiedSince());
- (void)setReqParamsIfUnmodifiedSince :(NSString*)newReqParamsIfUnmodifiedSince NS_SWIFT_NAME(setReqParamsIfUnmodifiedSince(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsPassword,setter=setReqParamsPassword:) NSString* reqParamsPassword NS_SWIFT_NAME(reqParamsPassword);

- (NSString*)reqParamsPassword NS_SWIFT_NAME(reqParamsPassword());
- (void)setReqParamsPassword :(NSString*)newReqParamsPassword NS_SWIFT_NAME(setReqParamsPassword(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsReferer,setter=setReqParamsReferer:) NSString* reqParamsReferer NS_SWIFT_NAME(reqParamsReferer);

- (NSString*)reqParamsReferer NS_SWIFT_NAME(reqParamsReferer());
- (void)setReqParamsReferer :(NSString*)newReqParamsReferer NS_SWIFT_NAME(setReqParamsReferer(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsUserAgent,setter=setReqParamsUserAgent:) NSString* reqParamsUserAgent NS_SWIFT_NAME(reqParamsUserAgent);

- (NSString*)reqParamsUserAgent NS_SWIFT_NAME(reqParamsUserAgent());
- (void)setReqParamsUserAgent :(NSString*)newReqParamsUserAgent NS_SWIFT_NAME(setReqParamsUserAgent(_:));

@property (nonatomic,readwrite,assign,getter=reqParamsUsername,setter=setReqParamsUsername:) NSString* reqParamsUsername NS_SWIFT_NAME(reqParamsUsername);

- (NSString*)reqParamsUsername NS_SWIFT_NAME(reqParamsUsername());
- (void)setReqParamsUsername :(NSString*)newReqParamsUsername NS_SWIFT_NAME(setReqParamsUsername(_:));

@property (nonatomic,readonly,assign,getter=respHeaderCount) int respHeaderCount NS_SWIFT_NAME(respHeaderCount);

- (int)respHeaderCount NS_SWIFT_NAME(respHeaderCount());

- (NSString*)respHeaderCategory:(int)respHeaderIndex NS_SWIFT_NAME(respHeaderCategory(_:));

- (int)respHeaderFormat:(int)respHeaderIndex NS_SWIFT_NAME(respHeaderFormat(_:));

- (NSString*)respHeaderName:(int)respHeaderIndex NS_SWIFT_NAME(respHeaderName(_:));

- (NSString*)respHeaderValue:(int)respHeaderIndex NS_SWIFT_NAME(respHeaderValue(_:));

@property (nonatomic,readonly,assign,getter=respParamsContentLength) long long respParamsContentLength NS_SWIFT_NAME(respParamsContentLength);

- (long long)respParamsContentLength NS_SWIFT_NAME(respParamsContentLength());

@property (nonatomic,readonly,assign,getter=respParamsDate) NSString* respParamsDate NS_SWIFT_NAME(respParamsDate);

- (NSString*)respParamsDate NS_SWIFT_NAME(respParamsDate());

@property (nonatomic,readonly,assign,getter=respParamsReasonPhrase) NSString* respParamsReasonPhrase NS_SWIFT_NAME(respParamsReasonPhrase);

- (NSString*)respParamsReasonPhrase NS_SWIFT_NAME(respParamsReasonPhrase());

@property (nonatomic,readonly,assign,getter=respParamsStatusCode) int respParamsStatusCode NS_SWIFT_NAME(respParamsStatusCode);

- (int)respParamsStatusCode NS_SWIFT_NAME(respParamsStatusCode());

@property (nonatomic,readwrite,assign,getter=SOAPAction,setter=setSOAPAction:) NSString* SOAPAction NS_SWIFT_NAME(SOAPAction);

- (NSString*)SOAPAction NS_SWIFT_NAME(SOAPAction());
- (void)setSOAPAction :(NSString*)newSOAPAction NS_SWIFT_NAME(setSOAPAction(_:));

@property (nonatomic,readonly,assign,getter=SOAPResponseType) int SOAPResponseType NS_SWIFT_NAME(SOAPResponseType);

- (int)SOAPResponseType NS_SWIFT_NAME(SOAPResponseType());

@property (nonatomic,readwrite,assign,getter=SOAPVersion,setter=setSOAPVersion:) int SOAPVersion NS_SWIFT_NAME(SOAPVersion);

- (int)SOAPVersion NS_SWIFT_NAME(SOAPVersion());
- (void)setSOAPVersion :(int)newSOAPVersion NS_SWIFT_NAME(setSOAPVersion(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSMode,setter=setSocketDNSMode:) int socketDNSMode NS_SWIFT_NAME(socketDNSMode);

- (int)socketDNSMode NS_SWIFT_NAME(socketDNSMode());
- (void)setSocketDNSMode :(int)newSocketDNSMode NS_SWIFT_NAME(setSocketDNSMode(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSPort,setter=setSocketDNSPort:) int socketDNSPort NS_SWIFT_NAME(socketDNSPort);

- (int)socketDNSPort NS_SWIFT_NAME(socketDNSPort());
- (void)setSocketDNSPort :(int)newSocketDNSPort NS_SWIFT_NAME(setSocketDNSPort(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSQueryTimeout,setter=setSocketDNSQueryTimeout:) int socketDNSQueryTimeout NS_SWIFT_NAME(socketDNSQueryTimeout);

- (int)socketDNSQueryTimeout NS_SWIFT_NAME(socketDNSQueryTimeout());
- (void)setSocketDNSQueryTimeout :(int)newSocketDNSQueryTimeout NS_SWIFT_NAME(setSocketDNSQueryTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSServers,setter=setSocketDNSServers:) NSString* socketDNSServers NS_SWIFT_NAME(socketDNSServers);

- (NSString*)socketDNSServers NS_SWIFT_NAME(socketDNSServers());
- (void)setSocketDNSServers :(NSString*)newSocketDNSServers NS_SWIFT_NAME(setSocketDNSServers(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSTotalTimeout,setter=setSocketDNSTotalTimeout:) int socketDNSTotalTimeout NS_SWIFT_NAME(socketDNSTotalTimeout);

- (int)socketDNSTotalTimeout NS_SWIFT_NAME(socketDNSTotalTimeout());
- (void)setSocketDNSTotalTimeout :(int)newSocketDNSTotalTimeout NS_SWIFT_NAME(setSocketDNSTotalTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketIncomingSpeedLimit,setter=setSocketIncomingSpeedLimit:) int socketIncomingSpeedLimit NS_SWIFT_NAME(socketIncomingSpeedLimit);

- (int)socketIncomingSpeedLimit NS_SWIFT_NAME(socketIncomingSpeedLimit());
- (void)setSocketIncomingSpeedLimit :(int)newSocketIncomingSpeedLimit NS_SWIFT_NAME(setSocketIncomingSpeedLimit(_:));

@property (nonatomic,readwrite,assign,getter=socketLocalAddress,setter=setSocketLocalAddress:) NSString* socketLocalAddress NS_SWIFT_NAME(socketLocalAddress);

- (NSString*)socketLocalAddress NS_SWIFT_NAME(socketLocalAddress());
- (void)setSocketLocalAddress :(NSString*)newSocketLocalAddress NS_SWIFT_NAME(setSocketLocalAddress(_:));

@property (nonatomic,readwrite,assign,getter=socketLocalPort,setter=setSocketLocalPort:) int socketLocalPort NS_SWIFT_NAME(socketLocalPort);

- (int)socketLocalPort NS_SWIFT_NAME(socketLocalPort());
- (void)setSocketLocalPort :(int)newSocketLocalPort NS_SWIFT_NAME(setSocketLocalPort(_:));

@property (nonatomic,readwrite,assign,getter=socketOutgoingSpeedLimit,setter=setSocketOutgoingSpeedLimit:) int socketOutgoingSpeedLimit NS_SWIFT_NAME(socketOutgoingSpeedLimit);

- (int)socketOutgoingSpeedLimit NS_SWIFT_NAME(socketOutgoingSpeedLimit());
- (void)setSocketOutgoingSpeedLimit :(int)newSocketOutgoingSpeedLimit NS_SWIFT_NAME(setSocketOutgoingSpeedLimit(_:));

@property (nonatomic,readwrite,assign,getter=socketTimeout,setter=setSocketTimeout:) int socketTimeout NS_SWIFT_NAME(socketTimeout);

- (int)socketTimeout NS_SWIFT_NAME(socketTimeout());
- (void)setSocketTimeout :(int)newSocketTimeout NS_SWIFT_NAME(setSocketTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketUseIPv6,setter=setSocketUseIPv6:) BOOL socketUseIPv6 NS_SWIFT_NAME(socketUseIPv6);

- (BOOL)socketUseIPv6 NS_SWIFT_NAME(socketUseIPv6());
- (void)setSocketUseIPv6 :(BOOL)newSocketUseIPv6 NS_SWIFT_NAME(setSocketUseIPv6(_:));

@property (nonatomic,readonly,assign,getter=statusCode) int statusCode NS_SWIFT_NAME(statusCode);

- (int)statusCode NS_SWIFT_NAME(statusCode());

@property (nonatomic,readwrite,assign,getter=TLSClientCertCount,setter=setTLSClientCertCount:) int TLSClientCertCount NS_SWIFT_NAME(TLSClientCertCount);

- (int)TLSClientCertCount NS_SWIFT_NAME(TLSClientCertCount());
- (void)setTLSClientCertCount :(int)newTLSClientCertCount NS_SWIFT_NAME(setTLSClientCertCount(_:));

- (NSData*)TLSClientCertBytes:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertBytes(_:));

- (BOOL)TLSClientCertCA:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCA(_:));
- (void)setTLSClientCertCA:(int)tLSClientCertIndex :(BOOL)newTLSClientCertCA NS_SWIFT_NAME(setTLSClientCertCA(_:_:));

- (NSData*)TLSClientCertCAKeyID:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCAKeyID(_:));

- (int)TLSClientCertCertType:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCertType(_:));

- (NSString*)TLSClientCertCRLDistributionPoints:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCRLDistributionPoints(_:));
- (void)setTLSClientCertCRLDistributionPoints:(int)tLSClientCertIndex :(NSString*)newTLSClientCertCRLDistributionPoints NS_SWIFT_NAME(setTLSClientCertCRLDistributionPoints(_:_:));

- (NSString*)TLSClientCertCurve:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCurve(_:));
- (void)setTLSClientCertCurve:(int)tLSClientCertIndex :(NSString*)newTLSClientCertCurve NS_SWIFT_NAME(setTLSClientCertCurve(_:_:));

- (NSString*)TLSClientCertFingerprint:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertFingerprint(_:));

- (NSString*)TLSClientCertFriendlyName:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertFriendlyName(_:));

- (long long)TLSClientCertHandle:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertHandle(_:));
- (void)setTLSClientCertHandle:(int)tLSClientCertIndex :(long long)newTLSClientCertHandle NS_SWIFT_NAME(setTLSClientCertHandle(_:_:));

- (NSString*)TLSClientCertHashAlgorithm:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertHashAlgorithm(_:));
- (void)setTLSClientCertHashAlgorithm:(int)tLSClientCertIndex :(NSString*)newTLSClientCertHashAlgorithm NS_SWIFT_NAME(setTLSClientCertHashAlgorithm(_:_:));

- (NSString*)TLSClientCertIssuer:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertIssuer(_:));

- (NSString*)TLSClientCertIssuerRDN:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertIssuerRDN(_:));
- (void)setTLSClientCertIssuerRDN:(int)tLSClientCertIndex :(NSString*)newTLSClientCertIssuerRDN NS_SWIFT_NAME(setTLSClientCertIssuerRDN(_:_:));

- (NSString*)TLSClientCertKeyAlgorithm:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyAlgorithm(_:));
- (void)setTLSClientCertKeyAlgorithm:(int)tLSClientCertIndex :(NSString*)newTLSClientCertKeyAlgorithm NS_SWIFT_NAME(setTLSClientCertKeyAlgorithm(_:_:));

- (int)TLSClientCertKeyBits:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyBits(_:));

- (NSString*)TLSClientCertKeyFingerprint:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyFingerprint(_:));

- (int)TLSClientCertKeyUsage:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyUsage(_:));
- (void)setTLSClientCertKeyUsage:(int)tLSClientCertIndex :(int)newTLSClientCertKeyUsage NS_SWIFT_NAME(setTLSClientCertKeyUsage(_:_:));

- (BOOL)TLSClientCertKeyValid:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyValid(_:));

- (NSString*)TLSClientCertOCSPLocations:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertOCSPLocations(_:));
- (void)setTLSClientCertOCSPLocations:(int)tLSClientCertIndex :(NSString*)newTLSClientCertOCSPLocations NS_SWIFT_NAME(setTLSClientCertOCSPLocations(_:_:));

- (BOOL)TLSClientCertOCSPNoCheck:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertOCSPNoCheck(_:));
- (void)setTLSClientCertOCSPNoCheck:(int)tLSClientCertIndex :(BOOL)newTLSClientCertOCSPNoCheck NS_SWIFT_NAME(setTLSClientCertOCSPNoCheck(_:_:));

- (int)TLSClientCertOrigin:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertOrigin(_:));

- (NSString*)TLSClientCertPolicyIDs:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPolicyIDs(_:));
- (void)setTLSClientCertPolicyIDs:(int)tLSClientCertIndex :(NSString*)newTLSClientCertPolicyIDs NS_SWIFT_NAME(setTLSClientCertPolicyIDs(_:_:));

- (NSData*)TLSClientCertPrivateKeyBytes:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPrivateKeyBytes(_:));

- (BOOL)TLSClientCertPrivateKeyExists:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPrivateKeyExists(_:));

- (BOOL)TLSClientCertPrivateKeyExtractable:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPrivateKeyExtractable(_:));

- (NSData*)TLSClientCertPublicKeyBytes:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPublicKeyBytes(_:));

- (BOOL)TLSClientCertQualified:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertQualified(_:));

- (int)TLSClientCertQualifiedStatements:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertQualifiedStatements(_:));
- (void)setTLSClientCertQualifiedStatements:(int)tLSClientCertIndex :(int)newTLSClientCertQualifiedStatements NS_SWIFT_NAME(setTLSClientCertQualifiedStatements(_:_:));

- (NSString*)TLSClientCertQualifiers:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertQualifiers(_:));

- (BOOL)TLSClientCertSelfSigned:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSelfSigned(_:));

- (NSData*)TLSClientCertSerialNumber:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSerialNumber(_:));
- (void)setTLSClientCertSerialNumber:(int)tLSClientCertIndex :(NSData*)newTLSClientCertSerialNumber NS_SWIFT_NAME(setTLSClientCertSerialNumber(_:_:));

- (NSString*)TLSClientCertSigAlgorithm:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSigAlgorithm(_:));

- (int)TLSClientCertSource:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSource(_:));

- (NSString*)TLSClientCertSubject:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSubject(_:));

- (NSString*)TLSClientCertSubjectAlternativeName:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSubjectAlternativeName(_:));
- (void)setTLSClientCertSubjectAlternativeName:(int)tLSClientCertIndex :(NSString*)newTLSClientCertSubjectAlternativeName NS_SWIFT_NAME(setTLSClientCertSubjectAlternativeName(_:_:));

- (NSData*)TLSClientCertSubjectKeyID:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSubjectKeyID(_:));
- (void)setTLSClientCertSubjectKeyID:(int)tLSClientCertIndex :(NSData*)newTLSClientCertSubjectKeyID NS_SWIFT_NAME(setTLSClientCertSubjectKeyID(_:_:));

- (NSString*)TLSClientCertSubjectRDN:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSubjectRDN(_:));
- (void)setTLSClientCertSubjectRDN:(int)tLSClientCertIndex :(NSString*)newTLSClientCertSubjectRDN NS_SWIFT_NAME(setTLSClientCertSubjectRDN(_:_:));

- (BOOL)TLSClientCertValid:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertValid(_:));

- (NSString*)TLSClientCertValidFrom:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertValidFrom(_:));
- (void)setTLSClientCertValidFrom:(int)tLSClientCertIndex :(NSString*)newTLSClientCertValidFrom NS_SWIFT_NAME(setTLSClientCertValidFrom(_:_:));

- (NSString*)TLSClientCertValidTo:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertValidTo(_:));
- (void)setTLSClientCertValidTo:(int)tLSClientCertIndex :(NSString*)newTLSClientCertValidTo NS_SWIFT_NAME(setTLSClientCertValidTo(_:_:));

@property (nonatomic,readonly,assign,getter=TLSServerCertCount) int TLSServerCertCount NS_SWIFT_NAME(TLSServerCertCount);

- (int)TLSServerCertCount NS_SWIFT_NAME(TLSServerCertCount());

- (NSData*)TLSServerCertBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertBytes(_:));

- (BOOL)TLSServerCertCA:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCA(_:));

- (NSData*)TLSServerCertCAKeyID:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCAKeyID(_:));

- (int)TLSServerCertCertType:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCertType(_:));

- (NSString*)TLSServerCertCRLDistributionPoints:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCRLDistributionPoints(_:));

- (NSString*)TLSServerCertCurve:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCurve(_:));

- (NSString*)TLSServerCertFingerprint:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertFingerprint(_:));

- (NSString*)TLSServerCertFriendlyName:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertFriendlyName(_:));

- (long long)TLSServerCertHandle:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertHandle(_:));

- (NSString*)TLSServerCertHashAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertHashAlgorithm(_:));

- (NSString*)TLSServerCertIssuer:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertIssuer(_:));

- (NSString*)TLSServerCertIssuerRDN:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertIssuerRDN(_:));

- (NSString*)TLSServerCertKeyAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyAlgorithm(_:));

- (int)TLSServerCertKeyBits:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyBits(_:));

- (NSString*)TLSServerCertKeyFingerprint:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyFingerprint(_:));

- (int)TLSServerCertKeyUsage:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyUsage(_:));

- (BOOL)TLSServerCertKeyValid:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyValid(_:));

- (NSString*)TLSServerCertOCSPLocations:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOCSPLocations(_:));

- (BOOL)TLSServerCertOCSPNoCheck:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOCSPNoCheck(_:));

- (int)TLSServerCertOrigin:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOrigin(_:));

- (NSString*)TLSServerCertPolicyIDs:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPolicyIDs(_:));

- (NSData*)TLSServerCertPrivateKeyBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyBytes(_:));

- (BOOL)TLSServerCertPrivateKeyExists:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyExists(_:));

- (BOOL)TLSServerCertPrivateKeyExtractable:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyExtractable(_:));

- (NSData*)TLSServerCertPublicKeyBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPublicKeyBytes(_:));

- (BOOL)TLSServerCertQualified:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualified(_:));

- (int)TLSServerCertQualifiedStatements:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualifiedStatements(_:));

- (NSString*)TLSServerCertQualifiers:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualifiers(_:));

- (BOOL)TLSServerCertSelfSigned:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSelfSigned(_:));

- (NSData*)TLSServerCertSerialNumber:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSerialNumber(_:));

- (NSString*)TLSServerCertSigAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSigAlgorithm(_:));

- (int)TLSServerCertSource:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSource(_:));

- (NSString*)TLSServerCertSubject:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubject(_:));

- (NSString*)TLSServerCertSubjectAlternativeName:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectAlternativeName(_:));

- (NSData*)TLSServerCertSubjectKeyID:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectKeyID(_:));

- (NSString*)TLSServerCertSubjectRDN:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectRDN(_:));

- (BOOL)TLSServerCertValid:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValid(_:));

- (NSString*)TLSServerCertValidFrom:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValidFrom(_:));

- (NSString*)TLSServerCertValidTo:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValidTo(_:));

@property (nonatomic,readwrite,assign,getter=TLSAutoValidateCertificates,setter=setTLSAutoValidateCertificates:) BOOL TLSAutoValidateCertificates NS_SWIFT_NAME(TLSAutoValidateCertificates);

- (BOOL)TLSAutoValidateCertificates NS_SWIFT_NAME(TLSAutoValidateCertificates());
- (void)setTLSAutoValidateCertificates :(BOOL)newTLSAutoValidateCertificates NS_SWIFT_NAME(setTLSAutoValidateCertificates(_:));

@property (nonatomic,readwrite,assign,getter=TLSBaseConfiguration,setter=setTLSBaseConfiguration:) int TLSBaseConfiguration NS_SWIFT_NAME(TLSBaseConfiguration);

- (int)TLSBaseConfiguration NS_SWIFT_NAME(TLSBaseConfiguration());
- (void)setTLSBaseConfiguration :(int)newTLSBaseConfiguration NS_SWIFT_NAME(setTLSBaseConfiguration(_:));

@property (nonatomic,readwrite,assign,getter=TLSCiphersuites,setter=setTLSCiphersuites:) NSString* TLSCiphersuites NS_SWIFT_NAME(TLSCiphersuites);

- (NSString*)TLSCiphersuites NS_SWIFT_NAME(TLSCiphersuites());
- (void)setTLSCiphersuites :(NSString*)newTLSCiphersuites NS_SWIFT_NAME(setTLSCiphersuites(_:));

@property (nonatomic,readwrite,assign,getter=TLSClientAuth,setter=setTLSClientAuth:) int TLSClientAuth NS_SWIFT_NAME(TLSClientAuth);

- (int)TLSClientAuth NS_SWIFT_NAME(TLSClientAuth());
- (void)setTLSClientAuth :(int)newTLSClientAuth NS_SWIFT_NAME(setTLSClientAuth(_:));

@property (nonatomic,readwrite,assign,getter=TLSECCurves,setter=setTLSECCurves:) NSString* TLSECCurves NS_SWIFT_NAME(TLSECCurves);

- (NSString*)TLSECCurves NS_SWIFT_NAME(TLSECCurves());
- (void)setTLSECCurves :(NSString*)newTLSECCurves NS_SWIFT_NAME(setTLSECCurves(_:));

@property (nonatomic,readwrite,assign,getter=TLSExtensions,setter=setTLSExtensions:) NSString* TLSExtensions NS_SWIFT_NAME(TLSExtensions);

- (NSString*)TLSExtensions NS_SWIFT_NAME(TLSExtensions());
- (void)setTLSExtensions :(NSString*)newTLSExtensions NS_SWIFT_NAME(setTLSExtensions(_:));

@property (nonatomic,readwrite,assign,getter=TLSForceResumeIfDestinationChanges,setter=setTLSForceResumeIfDestinationChanges:) BOOL TLSForceResumeIfDestinationChanges NS_SWIFT_NAME(TLSForceResumeIfDestinationChanges);

- (BOOL)TLSForceResumeIfDestinationChanges NS_SWIFT_NAME(TLSForceResumeIfDestinationChanges());
- (void)setTLSForceResumeIfDestinationChanges :(BOOL)newTLSForceResumeIfDestinationChanges NS_SWIFT_NAME(setTLSForceResumeIfDestinationChanges(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedIdentity,setter=setTLSPreSharedIdentity:) NSString* TLSPreSharedIdentity NS_SWIFT_NAME(TLSPreSharedIdentity);

- (NSString*)TLSPreSharedIdentity NS_SWIFT_NAME(TLSPreSharedIdentity());
- (void)setTLSPreSharedIdentity :(NSString*)newTLSPreSharedIdentity NS_SWIFT_NAME(setTLSPreSharedIdentity(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedKey,setter=setTLSPreSharedKey:) NSString* TLSPreSharedKey NS_SWIFT_NAME(TLSPreSharedKey);

- (NSString*)TLSPreSharedKey NS_SWIFT_NAME(TLSPreSharedKey());
- (void)setTLSPreSharedKey :(NSString*)newTLSPreSharedKey NS_SWIFT_NAME(setTLSPreSharedKey(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedKeyCiphersuite,setter=setTLSPreSharedKeyCiphersuite:) NSString* TLSPreSharedKeyCiphersuite NS_SWIFT_NAME(TLSPreSharedKeyCiphersuite);

- (NSString*)TLSPreSharedKeyCiphersuite NS_SWIFT_NAME(TLSPreSharedKeyCiphersuite());
- (void)setTLSPreSharedKeyCiphersuite :(NSString*)newTLSPreSharedKeyCiphersuite NS_SWIFT_NAME(setTLSPreSharedKeyCiphersuite(_:));

@property (nonatomic,readwrite,assign,getter=TLSRenegotiationAttackPreventionMode,setter=setTLSRenegotiationAttackPreventionMode:) int TLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(TLSRenegotiationAttackPreventionMode);

- (int)TLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(TLSRenegotiationAttackPreventionMode());
- (void)setTLSRenegotiationAttackPreventionMode :(int)newTLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(setTLSRenegotiationAttackPreventionMode(_:));

@property (nonatomic,readwrite,assign,getter=TLSRevocationCheck,setter=setTLSRevocationCheck:) int TLSRevocationCheck NS_SWIFT_NAME(TLSRevocationCheck);

- (int)TLSRevocationCheck NS_SWIFT_NAME(TLSRevocationCheck());
- (void)setTLSRevocationCheck :(int)newTLSRevocationCheck NS_SWIFT_NAME(setTLSRevocationCheck(_:));

@property (nonatomic,readwrite,assign,getter=TLSSSLOptions,setter=setTLSSSLOptions:) int TLSSSLOptions NS_SWIFT_NAME(TLSSSLOptions);

- (int)TLSSSLOptions NS_SWIFT_NAME(TLSSSLOptions());
- (void)setTLSSSLOptions :(int)newTLSSSLOptions NS_SWIFT_NAME(setTLSSSLOptions(_:));

@property (nonatomic,readwrite,assign,getter=TLSTLSMode,setter=setTLSTLSMode:) int TLSTLSMode NS_SWIFT_NAME(TLSTLSMode);

- (int)TLSTLSMode NS_SWIFT_NAME(TLSTLSMode());
- (void)setTLSTLSMode :(int)newTLSTLSMode NS_SWIFT_NAME(setTLSTLSMode(_:));

@property (nonatomic,readwrite,assign,getter=TLSUseExtendedMasterSecret,setter=setTLSUseExtendedMasterSecret:) BOOL TLSUseExtendedMasterSecret NS_SWIFT_NAME(TLSUseExtendedMasterSecret);

- (BOOL)TLSUseExtendedMasterSecret NS_SWIFT_NAME(TLSUseExtendedMasterSecret());
- (void)setTLSUseExtendedMasterSecret :(BOOL)newTLSUseExtendedMasterSecret NS_SWIFT_NAME(setTLSUseExtendedMasterSecret(_:));

@property (nonatomic,readwrite,assign,getter=TLSUseSessionResumption,setter=setTLSUseSessionResumption:) BOOL TLSUseSessionResumption NS_SWIFT_NAME(TLSUseSessionResumption);

- (BOOL)TLSUseSessionResumption NS_SWIFT_NAME(TLSUseSessionResumption());
- (void)setTLSUseSessionResumption :(BOOL)newTLSUseSessionResumption NS_SWIFT_NAME(setTLSUseSessionResumption(_:));

@property (nonatomic,readwrite,assign,getter=TLSVersions,setter=setTLSVersions:) int TLSVersions NS_SWIFT_NAME(TLSVersions);

- (int)TLSVersions NS_SWIFT_NAME(TLSVersions());
- (void)setTLSVersions :(int)newTLSVersions NS_SWIFT_NAME(setTLSVersions(_:));

@property (nonatomic,readwrite,assign,getter=trustedCertCount,setter=setTrustedCertCount:) int trustedCertCount NS_SWIFT_NAME(trustedCertCount);

- (int)trustedCertCount NS_SWIFT_NAME(trustedCertCount());
- (void)setTrustedCertCount :(int)newTrustedCertCount NS_SWIFT_NAME(setTrustedCertCount(_:));

- (NSData*)trustedCertBytes:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertBytes(_:));

- (BOOL)trustedCertCA:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertCA(_:));
- (void)setTrustedCertCA:(int)trustedCertIndex :(BOOL)newTrustedCertCA NS_SWIFT_NAME(setTrustedCertCA(_:_:));

- (NSData*)trustedCertCAKeyID:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertCAKeyID(_:));

- (int)trustedCertCertType:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertCertType(_:));

- (NSString*)trustedCertCRLDistributionPoints:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertCRLDistributionPoints(_:));
- (void)setTrustedCertCRLDistributionPoints:(int)trustedCertIndex :(NSString*)newTrustedCertCRLDistributionPoints NS_SWIFT_NAME(setTrustedCertCRLDistributionPoints(_:_:));

- (NSString*)trustedCertCurve:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertCurve(_:));
- (void)setTrustedCertCurve:(int)trustedCertIndex :(NSString*)newTrustedCertCurve NS_SWIFT_NAME(setTrustedCertCurve(_:_:));

- (NSString*)trustedCertFingerprint:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertFingerprint(_:));

- (NSString*)trustedCertFriendlyName:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertFriendlyName(_:));

- (long long)trustedCertHandle:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertHandle(_:));
- (void)setTrustedCertHandle:(int)trustedCertIndex :(long long)newTrustedCertHandle NS_SWIFT_NAME(setTrustedCertHandle(_:_:));

- (NSString*)trustedCertHashAlgorithm:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertHashAlgorithm(_:));
- (void)setTrustedCertHashAlgorithm:(int)trustedCertIndex :(NSString*)newTrustedCertHashAlgorithm NS_SWIFT_NAME(setTrustedCertHashAlgorithm(_:_:));

- (NSString*)trustedCertIssuer:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertIssuer(_:));

- (NSString*)trustedCertIssuerRDN:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertIssuerRDN(_:));
- (void)setTrustedCertIssuerRDN:(int)trustedCertIndex :(NSString*)newTrustedCertIssuerRDN NS_SWIFT_NAME(setTrustedCertIssuerRDN(_:_:));

- (NSString*)trustedCertKeyAlgorithm:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertKeyAlgorithm(_:));
- (void)setTrustedCertKeyAlgorithm:(int)trustedCertIndex :(NSString*)newTrustedCertKeyAlgorithm NS_SWIFT_NAME(setTrustedCertKeyAlgorithm(_:_:));

- (int)trustedCertKeyBits:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertKeyBits(_:));

- (NSString*)trustedCertKeyFingerprint:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertKeyFingerprint(_:));

- (int)trustedCertKeyUsage:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertKeyUsage(_:));
- (void)setTrustedCertKeyUsage:(int)trustedCertIndex :(int)newTrustedCertKeyUsage NS_SWIFT_NAME(setTrustedCertKeyUsage(_:_:));

- (BOOL)trustedCertKeyValid:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertKeyValid(_:));

- (NSString*)trustedCertOCSPLocations:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertOCSPLocations(_:));
- (void)setTrustedCertOCSPLocations:(int)trustedCertIndex :(NSString*)newTrustedCertOCSPLocations NS_SWIFT_NAME(setTrustedCertOCSPLocations(_:_:));

- (BOOL)trustedCertOCSPNoCheck:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertOCSPNoCheck(_:));
- (void)setTrustedCertOCSPNoCheck:(int)trustedCertIndex :(BOOL)newTrustedCertOCSPNoCheck NS_SWIFT_NAME(setTrustedCertOCSPNoCheck(_:_:));

- (int)trustedCertOrigin:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertOrigin(_:));

- (NSString*)trustedCertPolicyIDs:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertPolicyIDs(_:));
- (void)setTrustedCertPolicyIDs:(int)trustedCertIndex :(NSString*)newTrustedCertPolicyIDs NS_SWIFT_NAME(setTrustedCertPolicyIDs(_:_:));

- (NSData*)trustedCertPrivateKeyBytes:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertPrivateKeyBytes(_:));

- (BOOL)trustedCertPrivateKeyExists:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertPrivateKeyExists(_:));

- (BOOL)trustedCertPrivateKeyExtractable:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertPrivateKeyExtractable(_:));

- (NSData*)trustedCertPublicKeyBytes:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertPublicKeyBytes(_:));

- (BOOL)trustedCertQualified:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertQualified(_:));

- (int)trustedCertQualifiedStatements:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertQualifiedStatements(_:));
- (void)setTrustedCertQualifiedStatements:(int)trustedCertIndex :(int)newTrustedCertQualifiedStatements NS_SWIFT_NAME(setTrustedCertQualifiedStatements(_:_:));

- (NSString*)trustedCertQualifiers:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertQualifiers(_:));

- (BOOL)trustedCertSelfSigned:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSelfSigned(_:));

- (NSData*)trustedCertSerialNumber:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSerialNumber(_:));
- (void)setTrustedCertSerialNumber:(int)trustedCertIndex :(NSData*)newTrustedCertSerialNumber NS_SWIFT_NAME(setTrustedCertSerialNumber(_:_:));

- (NSString*)trustedCertSigAlgorithm:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSigAlgorithm(_:));

- (int)trustedCertSource:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSource(_:));

- (NSString*)trustedCertSubject:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSubject(_:));

- (NSString*)trustedCertSubjectAlternativeName:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSubjectAlternativeName(_:));
- (void)setTrustedCertSubjectAlternativeName:(int)trustedCertIndex :(NSString*)newTrustedCertSubjectAlternativeName NS_SWIFT_NAME(setTrustedCertSubjectAlternativeName(_:_:));

- (NSData*)trustedCertSubjectKeyID:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSubjectKeyID(_:));
- (void)setTrustedCertSubjectKeyID:(int)trustedCertIndex :(NSData*)newTrustedCertSubjectKeyID NS_SWIFT_NAME(setTrustedCertSubjectKeyID(_:_:));

- (NSString*)trustedCertSubjectRDN:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSubjectRDN(_:));
- (void)setTrustedCertSubjectRDN:(int)trustedCertIndex :(NSString*)newTrustedCertSubjectRDN NS_SWIFT_NAME(setTrustedCertSubjectRDN(_:_:));

- (BOOL)trustedCertValid:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertValid(_:));

- (NSString*)trustedCertValidFrom:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertValidFrom(_:));
- (void)setTrustedCertValidFrom:(int)trustedCertIndex :(NSString*)newTrustedCertValidFrom NS_SWIFT_NAME(setTrustedCertValidFrom(_:_:));

- (NSString*)trustedCertValidTo:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertValidTo(_:));
- (void)setTrustedCertValidTo:(int)trustedCertIndex :(NSString*)newTrustedCertValidTo NS_SWIFT_NAME(setTrustedCertValidTo(_:_:));

  /* Methods */

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (void)reset NS_SWIFT_NAME(reset());

- (void)sendMessage:(NSString*)url NS_SWIFT_NAME(sendMessage(_:));

- (void)sendMessageWithAttachments:(NSString*)url :(NSString*)primaryMessageId NS_SWIFT_NAME(sendMessageWithAttachments(_:_:));

@end

