/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxCertificateStorageDelegate <NSObject>
@optional
- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onPasswordNeeded:(NSString*)neededFor :(NSString**)password :(int*)cancel NS_SWIFT_NAME(onPasswordNeeded(_:_:_:));

@end

@interface SecureBlackboxCertificateStorage : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxCertificateStorageDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasError;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasPasswordNeeded;

}

+ (SecureBlackboxCertificateStorage*)certificatestorage;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxCertificateStorageDelegate> delegate;
- (id <SecureBlackboxCertificateStorageDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxCertificateStorageDelegate>)anObject;

  /* Events */

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onPasswordNeeded:(NSString*)neededFor :(NSString**)password :(int*)cancel NS_SWIFT_NAME(onPasswordNeeded(_:_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readonly,assign,getter=certCount) int certCount NS_SWIFT_NAME(certCount);

- (int)certCount NS_SWIFT_NAME(certCount());

- (NSData*)certBytes:(int)certIndex NS_SWIFT_NAME(certBytes(_:));

- (BOOL)certCA:(int)certIndex NS_SWIFT_NAME(certCA(_:));

- (NSData*)certCAKeyID:(int)certIndex NS_SWIFT_NAME(certCAKeyID(_:));

- (int)certCertType:(int)certIndex NS_SWIFT_NAME(certCertType(_:));

- (NSString*)certCRLDistributionPoints:(int)certIndex NS_SWIFT_NAME(certCRLDistributionPoints(_:));

- (NSString*)certCurve:(int)certIndex NS_SWIFT_NAME(certCurve(_:));

- (NSString*)certFingerprint:(int)certIndex NS_SWIFT_NAME(certFingerprint(_:));

- (NSString*)certFriendlyName:(int)certIndex NS_SWIFT_NAME(certFriendlyName(_:));

- (long long)certHandle:(int)certIndex NS_SWIFT_NAME(certHandle(_:));

- (NSString*)certHashAlgorithm:(int)certIndex NS_SWIFT_NAME(certHashAlgorithm(_:));

- (NSString*)certIssuer:(int)certIndex NS_SWIFT_NAME(certIssuer(_:));

- (NSString*)certIssuerRDN:(int)certIndex NS_SWIFT_NAME(certIssuerRDN(_:));

- (NSString*)certKeyAlgorithm:(int)certIndex NS_SWIFT_NAME(certKeyAlgorithm(_:));

- (int)certKeyBits:(int)certIndex NS_SWIFT_NAME(certKeyBits(_:));

- (NSString*)certKeyFingerprint:(int)certIndex NS_SWIFT_NAME(certKeyFingerprint(_:));

- (int)certKeyUsage:(int)certIndex NS_SWIFT_NAME(certKeyUsage(_:));

- (BOOL)certKeyValid:(int)certIndex NS_SWIFT_NAME(certKeyValid(_:));

- (NSString*)certOCSPLocations:(int)certIndex NS_SWIFT_NAME(certOCSPLocations(_:));

- (BOOL)certOCSPNoCheck:(int)certIndex NS_SWIFT_NAME(certOCSPNoCheck(_:));

- (int)certOrigin:(int)certIndex NS_SWIFT_NAME(certOrigin(_:));

- (NSString*)certPolicyIDs:(int)certIndex NS_SWIFT_NAME(certPolicyIDs(_:));

- (NSData*)certPrivateKeyBytes:(int)certIndex NS_SWIFT_NAME(certPrivateKeyBytes(_:));

- (BOOL)certPrivateKeyExists:(int)certIndex NS_SWIFT_NAME(certPrivateKeyExists(_:));

- (BOOL)certPrivateKeyExtractable:(int)certIndex NS_SWIFT_NAME(certPrivateKeyExtractable(_:));

- (NSData*)certPublicKeyBytes:(int)certIndex NS_SWIFT_NAME(certPublicKeyBytes(_:));

- (BOOL)certQualified:(int)certIndex NS_SWIFT_NAME(certQualified(_:));

- (int)certQualifiedStatements:(int)certIndex NS_SWIFT_NAME(certQualifiedStatements(_:));

- (NSString*)certQualifiers:(int)certIndex NS_SWIFT_NAME(certQualifiers(_:));

- (BOOL)certSelfSigned:(int)certIndex NS_SWIFT_NAME(certSelfSigned(_:));

- (NSData*)certSerialNumber:(int)certIndex NS_SWIFT_NAME(certSerialNumber(_:));

- (NSString*)certSigAlgorithm:(int)certIndex NS_SWIFT_NAME(certSigAlgorithm(_:));

- (int)certSource:(int)certIndex NS_SWIFT_NAME(certSource(_:));

- (NSString*)certSubject:(int)certIndex NS_SWIFT_NAME(certSubject(_:));

- (NSString*)certSubjectAlternativeName:(int)certIndex NS_SWIFT_NAME(certSubjectAlternativeName(_:));

- (NSData*)certSubjectKeyID:(int)certIndex NS_SWIFT_NAME(certSubjectKeyID(_:));

- (NSString*)certSubjectRDN:(int)certIndex NS_SWIFT_NAME(certSubjectRDN(_:));

- (BOOL)certValid:(int)certIndex NS_SWIFT_NAME(certValid(_:));

- (NSString*)certValidFrom:(int)certIndex NS_SWIFT_NAME(certValidFrom(_:));

- (NSString*)certValidTo:(int)certIndex NS_SWIFT_NAME(certValidTo(_:));

@property (nonatomic,readonly,assign,getter=CRLCount) int CRLCount NS_SWIFT_NAME(CRLCount);

- (int)CRLCount NS_SWIFT_NAME(CRLCount());

- (NSData*)CRLBytes:(int)cRLIndex NS_SWIFT_NAME(CRLBytes(_:));

- (NSData*)CRLCAKeyID:(int)cRLIndex NS_SWIFT_NAME(CRLCAKeyID(_:));

- (int)CRLEntryCount:(int)cRLIndex NS_SWIFT_NAME(CRLEntryCount(_:));

- (long long)CRLHandle:(int)cRLIndex NS_SWIFT_NAME(CRLHandle(_:));

- (NSString*)CRLIssuer:(int)cRLIndex NS_SWIFT_NAME(CRLIssuer(_:));

- (NSString*)CRLIssuerRDN:(int)cRLIndex NS_SWIFT_NAME(CRLIssuerRDN(_:));

- (NSString*)CRLLocation:(int)cRLIndex NS_SWIFT_NAME(CRLLocation(_:));

- (NSString*)CRLNextUpdate:(int)cRLIndex NS_SWIFT_NAME(CRLNextUpdate(_:));

- (NSString*)CRLSigAlgorithm:(int)cRLIndex NS_SWIFT_NAME(CRLSigAlgorithm(_:));

- (int)CRLSource:(int)cRLIndex NS_SWIFT_NAME(CRLSource(_:));

- (NSData*)CRLTBS:(int)cRLIndex NS_SWIFT_NAME(CRLTBS(_:));

- (NSString*)CRLThisUpdate:(int)cRLIndex NS_SWIFT_NAME(CRLThisUpdate(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readonly,assign,getter=OCSPCount) int OCSPCount NS_SWIFT_NAME(OCSPCount);

- (int)OCSPCount NS_SWIFT_NAME(OCSPCount());

- (NSData*)OCSPBytes:(int)oCSPIndex NS_SWIFT_NAME(OCSPBytes(_:));

- (int)OCSPEntryCount:(int)oCSPIndex NS_SWIFT_NAME(OCSPEntryCount(_:));

- (long long)OCSPHandle:(int)oCSPIndex NS_SWIFT_NAME(OCSPHandle(_:));

- (NSString*)OCSPIssuer:(int)oCSPIndex NS_SWIFT_NAME(OCSPIssuer(_:));

- (NSString*)OCSPIssuerRDN:(int)oCSPIndex NS_SWIFT_NAME(OCSPIssuerRDN(_:));

- (NSString*)OCSPLocation:(int)oCSPIndex NS_SWIFT_NAME(OCSPLocation(_:));

- (NSString*)OCSPProducedAt:(int)oCSPIndex NS_SWIFT_NAME(OCSPProducedAt(_:));

- (NSString*)OCSPSigAlgorithm:(int)oCSPIndex NS_SWIFT_NAME(OCSPSigAlgorithm(_:));

- (int)OCSPSource:(int)oCSPIndex NS_SWIFT_NAME(OCSPSource(_:));

@property (nonatomic,readonly,assign,getter=opened) BOOL opened NS_SWIFT_NAME(opened);

- (BOOL)opened NS_SWIFT_NAME(opened());

@property (nonatomic,readonly,assign,getter=pinnedCertBytes) NSData* pinnedCertBytes NS_SWIFT_NAME(pinnedCertBytes);

- (NSData*)pinnedCertBytes NS_SWIFT_NAME(pinnedCertBytes());

@property (nonatomic,readwrite,assign,getter=pinnedCertCA,setter=setPinnedCertCA:) BOOL pinnedCertCA NS_SWIFT_NAME(pinnedCertCA);

- (BOOL)pinnedCertCA NS_SWIFT_NAME(pinnedCertCA());
- (void)setPinnedCertCA :(BOOL)newPinnedCertCA NS_SWIFT_NAME(setPinnedCertCA(_:));

@property (nonatomic,readonly,assign,getter=pinnedCertCAKeyID) NSData* pinnedCertCAKeyID NS_SWIFT_NAME(pinnedCertCAKeyID);

- (NSData*)pinnedCertCAKeyID NS_SWIFT_NAME(pinnedCertCAKeyID());

@property (nonatomic,readonly,assign,getter=pinnedCertCertType) int pinnedCertCertType NS_SWIFT_NAME(pinnedCertCertType);

- (int)pinnedCertCertType NS_SWIFT_NAME(pinnedCertCertType());

@property (nonatomic,readwrite,assign,getter=pinnedCertCRLDistributionPoints,setter=setPinnedCertCRLDistributionPoints:) NSString* pinnedCertCRLDistributionPoints NS_SWIFT_NAME(pinnedCertCRLDistributionPoints);

- (NSString*)pinnedCertCRLDistributionPoints NS_SWIFT_NAME(pinnedCertCRLDistributionPoints());
- (void)setPinnedCertCRLDistributionPoints :(NSString*)newPinnedCertCRLDistributionPoints NS_SWIFT_NAME(setPinnedCertCRLDistributionPoints(_:));

@property (nonatomic,readwrite,assign,getter=pinnedCertCurve,setter=setPinnedCertCurve:) NSString* pinnedCertCurve NS_SWIFT_NAME(pinnedCertCurve);

- (NSString*)pinnedCertCurve NS_SWIFT_NAME(pinnedCertCurve());
- (void)setPinnedCertCurve :(NSString*)newPinnedCertCurve NS_SWIFT_NAME(setPinnedCertCurve(_:));

@property (nonatomic,readonly,assign,getter=pinnedCertFingerprint) NSString* pinnedCertFingerprint NS_SWIFT_NAME(pinnedCertFingerprint);

- (NSString*)pinnedCertFingerprint NS_SWIFT_NAME(pinnedCertFingerprint());

@property (nonatomic,readonly,assign,getter=pinnedCertFriendlyName) NSString* pinnedCertFriendlyName NS_SWIFT_NAME(pinnedCertFriendlyName);

- (NSString*)pinnedCertFriendlyName NS_SWIFT_NAME(pinnedCertFriendlyName());

@property (nonatomic,readwrite,assign,getter=pinnedCertHandle,setter=setPinnedCertHandle:) long long pinnedCertHandle NS_SWIFT_NAME(pinnedCertHandle);

- (long long)pinnedCertHandle NS_SWIFT_NAME(pinnedCertHandle());
- (void)setPinnedCertHandle :(long long)newPinnedCertHandle NS_SWIFT_NAME(setPinnedCertHandle(_:));

@property (nonatomic,readwrite,assign,getter=pinnedCertHashAlgorithm,setter=setPinnedCertHashAlgorithm:) NSString* pinnedCertHashAlgorithm NS_SWIFT_NAME(pinnedCertHashAlgorithm);

- (NSString*)pinnedCertHashAlgorithm NS_SWIFT_NAME(pinnedCertHashAlgorithm());
- (void)setPinnedCertHashAlgorithm :(NSString*)newPinnedCertHashAlgorithm NS_SWIFT_NAME(setPinnedCertHashAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=pinnedCertIssuer) NSString* pinnedCertIssuer NS_SWIFT_NAME(pinnedCertIssuer);

- (NSString*)pinnedCertIssuer NS_SWIFT_NAME(pinnedCertIssuer());

@property (nonatomic,readwrite,assign,getter=pinnedCertIssuerRDN,setter=setPinnedCertIssuerRDN:) NSString* pinnedCertIssuerRDN NS_SWIFT_NAME(pinnedCertIssuerRDN);

- (NSString*)pinnedCertIssuerRDN NS_SWIFT_NAME(pinnedCertIssuerRDN());
- (void)setPinnedCertIssuerRDN :(NSString*)newPinnedCertIssuerRDN NS_SWIFT_NAME(setPinnedCertIssuerRDN(_:));

@property (nonatomic,readwrite,assign,getter=pinnedCertKeyAlgorithm,setter=setPinnedCertKeyAlgorithm:) NSString* pinnedCertKeyAlgorithm NS_SWIFT_NAME(pinnedCertKeyAlgorithm);

- (NSString*)pinnedCertKeyAlgorithm NS_SWIFT_NAME(pinnedCertKeyAlgorithm());
- (void)setPinnedCertKeyAlgorithm :(NSString*)newPinnedCertKeyAlgorithm NS_SWIFT_NAME(setPinnedCertKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=pinnedCertKeyBits) int pinnedCertKeyBits NS_SWIFT_NAME(pinnedCertKeyBits);

- (int)pinnedCertKeyBits NS_SWIFT_NAME(pinnedCertKeyBits());

@property (nonatomic,readonly,assign,getter=pinnedCertKeyFingerprint) NSString* pinnedCertKeyFingerprint NS_SWIFT_NAME(pinnedCertKeyFingerprint);

- (NSString*)pinnedCertKeyFingerprint NS_SWIFT_NAME(pinnedCertKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=pinnedCertKeyUsage,setter=setPinnedCertKeyUsage:) int pinnedCertKeyUsage NS_SWIFT_NAME(pinnedCertKeyUsage);

- (int)pinnedCertKeyUsage NS_SWIFT_NAME(pinnedCertKeyUsage());
- (void)setPinnedCertKeyUsage :(int)newPinnedCertKeyUsage NS_SWIFT_NAME(setPinnedCertKeyUsage(_:));

@property (nonatomic,readonly,assign,getter=pinnedCertKeyValid) BOOL pinnedCertKeyValid NS_SWIFT_NAME(pinnedCertKeyValid);

- (BOOL)pinnedCertKeyValid NS_SWIFT_NAME(pinnedCertKeyValid());

@property (nonatomic,readwrite,assign,getter=pinnedCertOCSPLocations,setter=setPinnedCertOCSPLocations:) NSString* pinnedCertOCSPLocations NS_SWIFT_NAME(pinnedCertOCSPLocations);

- (NSString*)pinnedCertOCSPLocations NS_SWIFT_NAME(pinnedCertOCSPLocations());
- (void)setPinnedCertOCSPLocations :(NSString*)newPinnedCertOCSPLocations NS_SWIFT_NAME(setPinnedCertOCSPLocations(_:));

@property (nonatomic,readwrite,assign,getter=pinnedCertOCSPNoCheck,setter=setPinnedCertOCSPNoCheck:) BOOL pinnedCertOCSPNoCheck NS_SWIFT_NAME(pinnedCertOCSPNoCheck);

- (BOOL)pinnedCertOCSPNoCheck NS_SWIFT_NAME(pinnedCertOCSPNoCheck());
- (void)setPinnedCertOCSPNoCheck :(BOOL)newPinnedCertOCSPNoCheck NS_SWIFT_NAME(setPinnedCertOCSPNoCheck(_:));

@property (nonatomic,readonly,assign,getter=pinnedCertOrigin) int pinnedCertOrigin NS_SWIFT_NAME(pinnedCertOrigin);

- (int)pinnedCertOrigin NS_SWIFT_NAME(pinnedCertOrigin());

@property (nonatomic,readwrite,assign,getter=pinnedCertPolicyIDs,setter=setPinnedCertPolicyIDs:) NSString* pinnedCertPolicyIDs NS_SWIFT_NAME(pinnedCertPolicyIDs);

- (NSString*)pinnedCertPolicyIDs NS_SWIFT_NAME(pinnedCertPolicyIDs());
- (void)setPinnedCertPolicyIDs :(NSString*)newPinnedCertPolicyIDs NS_SWIFT_NAME(setPinnedCertPolicyIDs(_:));

@property (nonatomic,readonly,assign,getter=pinnedCertPrivateKeyBytes) NSData* pinnedCertPrivateKeyBytes NS_SWIFT_NAME(pinnedCertPrivateKeyBytes);

- (NSData*)pinnedCertPrivateKeyBytes NS_SWIFT_NAME(pinnedCertPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=pinnedCertPrivateKeyExists) BOOL pinnedCertPrivateKeyExists NS_SWIFT_NAME(pinnedCertPrivateKeyExists);

- (BOOL)pinnedCertPrivateKeyExists NS_SWIFT_NAME(pinnedCertPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=pinnedCertPrivateKeyExtractable) BOOL pinnedCertPrivateKeyExtractable NS_SWIFT_NAME(pinnedCertPrivateKeyExtractable);

- (BOOL)pinnedCertPrivateKeyExtractable NS_SWIFT_NAME(pinnedCertPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=pinnedCertPublicKeyBytes) NSData* pinnedCertPublicKeyBytes NS_SWIFT_NAME(pinnedCertPublicKeyBytes);

- (NSData*)pinnedCertPublicKeyBytes NS_SWIFT_NAME(pinnedCertPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=pinnedCertQualified) BOOL pinnedCertQualified NS_SWIFT_NAME(pinnedCertQualified);

- (BOOL)pinnedCertQualified NS_SWIFT_NAME(pinnedCertQualified());

@property (nonatomic,readwrite,assign,getter=pinnedCertQualifiedStatements,setter=setPinnedCertQualifiedStatements:) int pinnedCertQualifiedStatements NS_SWIFT_NAME(pinnedCertQualifiedStatements);

- (int)pinnedCertQualifiedStatements NS_SWIFT_NAME(pinnedCertQualifiedStatements());
- (void)setPinnedCertQualifiedStatements :(int)newPinnedCertQualifiedStatements NS_SWIFT_NAME(setPinnedCertQualifiedStatements(_:));

@property (nonatomic,readonly,assign,getter=pinnedCertQualifiers) NSString* pinnedCertQualifiers NS_SWIFT_NAME(pinnedCertQualifiers);

- (NSString*)pinnedCertQualifiers NS_SWIFT_NAME(pinnedCertQualifiers());

@property (nonatomic,readonly,assign,getter=pinnedCertSelfSigned) BOOL pinnedCertSelfSigned NS_SWIFT_NAME(pinnedCertSelfSigned);

- (BOOL)pinnedCertSelfSigned NS_SWIFT_NAME(pinnedCertSelfSigned());

@property (nonatomic,readwrite,assign,getter=pinnedCertSerialNumber,setter=setPinnedCertSerialNumber:) NSData* pinnedCertSerialNumber NS_SWIFT_NAME(pinnedCertSerialNumber);

- (NSData*)pinnedCertSerialNumber NS_SWIFT_NAME(pinnedCertSerialNumber());
- (void)setPinnedCertSerialNumber :(NSData*)newPinnedCertSerialNumber NS_SWIFT_NAME(setPinnedCertSerialNumber(_:));

@property (nonatomic,readonly,assign,getter=pinnedCertSigAlgorithm) NSString* pinnedCertSigAlgorithm NS_SWIFT_NAME(pinnedCertSigAlgorithm);

- (NSString*)pinnedCertSigAlgorithm NS_SWIFT_NAME(pinnedCertSigAlgorithm());

@property (nonatomic,readonly,assign,getter=pinnedCertSource) int pinnedCertSource NS_SWIFT_NAME(pinnedCertSource);

- (int)pinnedCertSource NS_SWIFT_NAME(pinnedCertSource());

@property (nonatomic,readonly,assign,getter=pinnedCertSubject) NSString* pinnedCertSubject NS_SWIFT_NAME(pinnedCertSubject);

- (NSString*)pinnedCertSubject NS_SWIFT_NAME(pinnedCertSubject());

@property (nonatomic,readwrite,assign,getter=pinnedCertSubjectAlternativeName,setter=setPinnedCertSubjectAlternativeName:) NSString* pinnedCertSubjectAlternativeName NS_SWIFT_NAME(pinnedCertSubjectAlternativeName);

- (NSString*)pinnedCertSubjectAlternativeName NS_SWIFT_NAME(pinnedCertSubjectAlternativeName());
- (void)setPinnedCertSubjectAlternativeName :(NSString*)newPinnedCertSubjectAlternativeName NS_SWIFT_NAME(setPinnedCertSubjectAlternativeName(_:));

@property (nonatomic,readwrite,assign,getter=pinnedCertSubjectKeyID,setter=setPinnedCertSubjectKeyID:) NSData* pinnedCertSubjectKeyID NS_SWIFT_NAME(pinnedCertSubjectKeyID);

- (NSData*)pinnedCertSubjectKeyID NS_SWIFT_NAME(pinnedCertSubjectKeyID());
- (void)setPinnedCertSubjectKeyID :(NSData*)newPinnedCertSubjectKeyID NS_SWIFT_NAME(setPinnedCertSubjectKeyID(_:));

@property (nonatomic,readwrite,assign,getter=pinnedCertSubjectRDN,setter=setPinnedCertSubjectRDN:) NSString* pinnedCertSubjectRDN NS_SWIFT_NAME(pinnedCertSubjectRDN);

- (NSString*)pinnedCertSubjectRDN NS_SWIFT_NAME(pinnedCertSubjectRDN());
- (void)setPinnedCertSubjectRDN :(NSString*)newPinnedCertSubjectRDN NS_SWIFT_NAME(setPinnedCertSubjectRDN(_:));

@property (nonatomic,readonly,assign,getter=pinnedCertValid) BOOL pinnedCertValid NS_SWIFT_NAME(pinnedCertValid);

- (BOOL)pinnedCertValid NS_SWIFT_NAME(pinnedCertValid());

@property (nonatomic,readwrite,assign,getter=pinnedCertValidFrom,setter=setPinnedCertValidFrom:) NSString* pinnedCertValidFrom NS_SWIFT_NAME(pinnedCertValidFrom);

- (NSString*)pinnedCertValidFrom NS_SWIFT_NAME(pinnedCertValidFrom());
- (void)setPinnedCertValidFrom :(NSString*)newPinnedCertValidFrom NS_SWIFT_NAME(setPinnedCertValidFrom(_:));

@property (nonatomic,readwrite,assign,getter=pinnedCertValidTo,setter=setPinnedCertValidTo:) NSString* pinnedCertValidTo NS_SWIFT_NAME(pinnedCertValidTo);

- (NSString*)pinnedCertValidTo NS_SWIFT_NAME(pinnedCertValidTo());
- (void)setPinnedCertValidTo :(NSString*)newPinnedCertValidTo NS_SWIFT_NAME(setPinnedCertValidTo(_:));

@property (nonatomic,readonly,assign,getter=pinnedCRLBytes) NSData* pinnedCRLBytes NS_SWIFT_NAME(pinnedCRLBytes);

- (NSData*)pinnedCRLBytes NS_SWIFT_NAME(pinnedCRLBytes());

@property (nonatomic,readwrite,assign,getter=pinnedCRLCAKeyID,setter=setPinnedCRLCAKeyID:) NSData* pinnedCRLCAKeyID NS_SWIFT_NAME(pinnedCRLCAKeyID);

- (NSData*)pinnedCRLCAKeyID NS_SWIFT_NAME(pinnedCRLCAKeyID());
- (void)setPinnedCRLCAKeyID :(NSData*)newPinnedCRLCAKeyID NS_SWIFT_NAME(setPinnedCRLCAKeyID(_:));

@property (nonatomic,readonly,assign,getter=pinnedCRLEntryCount) int pinnedCRLEntryCount NS_SWIFT_NAME(pinnedCRLEntryCount);

- (int)pinnedCRLEntryCount NS_SWIFT_NAME(pinnedCRLEntryCount());

@property (nonatomic,readwrite,assign,getter=pinnedCRLHandle,setter=setPinnedCRLHandle:) long long pinnedCRLHandle NS_SWIFT_NAME(pinnedCRLHandle);

- (long long)pinnedCRLHandle NS_SWIFT_NAME(pinnedCRLHandle());
- (void)setPinnedCRLHandle :(long long)newPinnedCRLHandle NS_SWIFT_NAME(setPinnedCRLHandle(_:));

@property (nonatomic,readonly,assign,getter=pinnedCRLIssuer) NSString* pinnedCRLIssuer NS_SWIFT_NAME(pinnedCRLIssuer);

- (NSString*)pinnedCRLIssuer NS_SWIFT_NAME(pinnedCRLIssuer());

@property (nonatomic,readonly,assign,getter=pinnedCRLIssuerRDN) NSString* pinnedCRLIssuerRDN NS_SWIFT_NAME(pinnedCRLIssuerRDN);

- (NSString*)pinnedCRLIssuerRDN NS_SWIFT_NAME(pinnedCRLIssuerRDN());

@property (nonatomic,readonly,assign,getter=pinnedCRLLocation) NSString* pinnedCRLLocation NS_SWIFT_NAME(pinnedCRLLocation);

- (NSString*)pinnedCRLLocation NS_SWIFT_NAME(pinnedCRLLocation());

@property (nonatomic,readwrite,assign,getter=pinnedCRLNextUpdate,setter=setPinnedCRLNextUpdate:) NSString* pinnedCRLNextUpdate NS_SWIFT_NAME(pinnedCRLNextUpdate);

- (NSString*)pinnedCRLNextUpdate NS_SWIFT_NAME(pinnedCRLNextUpdate());
- (void)setPinnedCRLNextUpdate :(NSString*)newPinnedCRLNextUpdate NS_SWIFT_NAME(setPinnedCRLNextUpdate(_:));

@property (nonatomic,readwrite,assign,getter=pinnedCRLSigAlgorithm,setter=setPinnedCRLSigAlgorithm:) NSString* pinnedCRLSigAlgorithm NS_SWIFT_NAME(pinnedCRLSigAlgorithm);

- (NSString*)pinnedCRLSigAlgorithm NS_SWIFT_NAME(pinnedCRLSigAlgorithm());
- (void)setPinnedCRLSigAlgorithm :(NSString*)newPinnedCRLSigAlgorithm NS_SWIFT_NAME(setPinnedCRLSigAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=pinnedCRLSource) int pinnedCRLSource NS_SWIFT_NAME(pinnedCRLSource);

- (int)pinnedCRLSource NS_SWIFT_NAME(pinnedCRLSource());

@property (nonatomic,readonly,assign,getter=pinnedCRLTBS) NSData* pinnedCRLTBS NS_SWIFT_NAME(pinnedCRLTBS);

- (NSData*)pinnedCRLTBS NS_SWIFT_NAME(pinnedCRLTBS());

@property (nonatomic,readwrite,assign,getter=pinnedCRLThisUpdate,setter=setPinnedCRLThisUpdate:) NSString* pinnedCRLThisUpdate NS_SWIFT_NAME(pinnedCRLThisUpdate);

- (NSString*)pinnedCRLThisUpdate NS_SWIFT_NAME(pinnedCRLThisUpdate());
- (void)setPinnedCRLThisUpdate :(NSString*)newPinnedCRLThisUpdate NS_SWIFT_NAME(setPinnedCRLThisUpdate(_:));

@property (nonatomic,readonly,assign,getter=pinnedOCSPBytes) NSData* pinnedOCSPBytes NS_SWIFT_NAME(pinnedOCSPBytes);

- (NSData*)pinnedOCSPBytes NS_SWIFT_NAME(pinnedOCSPBytes());

@property (nonatomic,readonly,assign,getter=pinnedOCSPEntryCount) int pinnedOCSPEntryCount NS_SWIFT_NAME(pinnedOCSPEntryCount);

- (int)pinnedOCSPEntryCount NS_SWIFT_NAME(pinnedOCSPEntryCount());

@property (nonatomic,readwrite,assign,getter=pinnedOCSPHandle,setter=setPinnedOCSPHandle:) long long pinnedOCSPHandle NS_SWIFT_NAME(pinnedOCSPHandle);

- (long long)pinnedOCSPHandle NS_SWIFT_NAME(pinnedOCSPHandle());
- (void)setPinnedOCSPHandle :(long long)newPinnedOCSPHandle NS_SWIFT_NAME(setPinnedOCSPHandle(_:));

@property (nonatomic,readonly,assign,getter=pinnedOCSPIssuer) NSString* pinnedOCSPIssuer NS_SWIFT_NAME(pinnedOCSPIssuer);

- (NSString*)pinnedOCSPIssuer NS_SWIFT_NAME(pinnedOCSPIssuer());

@property (nonatomic,readonly,assign,getter=pinnedOCSPIssuerRDN) NSString* pinnedOCSPIssuerRDN NS_SWIFT_NAME(pinnedOCSPIssuerRDN);

- (NSString*)pinnedOCSPIssuerRDN NS_SWIFT_NAME(pinnedOCSPIssuerRDN());

@property (nonatomic,readonly,assign,getter=pinnedOCSPLocation) NSString* pinnedOCSPLocation NS_SWIFT_NAME(pinnedOCSPLocation);

- (NSString*)pinnedOCSPLocation NS_SWIFT_NAME(pinnedOCSPLocation());

@property (nonatomic,readwrite,assign,getter=pinnedOCSPProducedAt,setter=setPinnedOCSPProducedAt:) NSString* pinnedOCSPProducedAt NS_SWIFT_NAME(pinnedOCSPProducedAt);

- (NSString*)pinnedOCSPProducedAt NS_SWIFT_NAME(pinnedOCSPProducedAt());
- (void)setPinnedOCSPProducedAt :(NSString*)newPinnedOCSPProducedAt NS_SWIFT_NAME(setPinnedOCSPProducedAt(_:));

@property (nonatomic,readwrite,assign,getter=pinnedOCSPSigAlgorithm,setter=setPinnedOCSPSigAlgorithm:) NSString* pinnedOCSPSigAlgorithm NS_SWIFT_NAME(pinnedOCSPSigAlgorithm);

- (NSString*)pinnedOCSPSigAlgorithm NS_SWIFT_NAME(pinnedOCSPSigAlgorithm());
- (void)setPinnedOCSPSigAlgorithm :(NSString*)newPinnedOCSPSigAlgorithm NS_SWIFT_NAME(setPinnedOCSPSigAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=pinnedOCSPSource) int pinnedOCSPSource NS_SWIFT_NAME(pinnedOCSPSource);

- (int)pinnedOCSPSource NS_SWIFT_NAME(pinnedOCSPSource());

@property (nonatomic,readonly,assign,getter=selectedCertCount) int selectedCertCount NS_SWIFT_NAME(selectedCertCount);

- (int)selectedCertCount NS_SWIFT_NAME(selectedCertCount());

- (NSData*)selectedCertBytes:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertBytes(_:));

- (BOOL)selectedCertCA:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertCA(_:));

- (NSData*)selectedCertCAKeyID:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertCAKeyID(_:));

- (int)selectedCertCertType:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertCertType(_:));

- (NSString*)selectedCertCRLDistributionPoints:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertCRLDistributionPoints(_:));

- (NSString*)selectedCertCurve:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertCurve(_:));

- (NSString*)selectedCertFingerprint:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertFingerprint(_:));

- (NSString*)selectedCertFriendlyName:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertFriendlyName(_:));

- (long long)selectedCertHandle:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertHandle(_:));

- (NSString*)selectedCertHashAlgorithm:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertHashAlgorithm(_:));

- (NSString*)selectedCertIssuer:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertIssuer(_:));

- (NSString*)selectedCertIssuerRDN:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertIssuerRDN(_:));

- (NSString*)selectedCertKeyAlgorithm:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertKeyAlgorithm(_:));

- (int)selectedCertKeyBits:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertKeyBits(_:));

- (NSString*)selectedCertKeyFingerprint:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertKeyFingerprint(_:));

- (int)selectedCertKeyUsage:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertKeyUsage(_:));

- (BOOL)selectedCertKeyValid:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertKeyValid(_:));

- (NSString*)selectedCertOCSPLocations:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertOCSPLocations(_:));

- (BOOL)selectedCertOCSPNoCheck:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertOCSPNoCheck(_:));

- (int)selectedCertOrigin:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertOrigin(_:));

- (NSString*)selectedCertPolicyIDs:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertPolicyIDs(_:));

- (NSData*)selectedCertPrivateKeyBytes:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertPrivateKeyBytes(_:));

- (BOOL)selectedCertPrivateKeyExists:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertPrivateKeyExists(_:));

- (BOOL)selectedCertPrivateKeyExtractable:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertPrivateKeyExtractable(_:));

- (NSData*)selectedCertPublicKeyBytes:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertPublicKeyBytes(_:));

- (BOOL)selectedCertQualified:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertQualified(_:));

- (int)selectedCertQualifiedStatements:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertQualifiedStatements(_:));

- (NSString*)selectedCertQualifiers:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertQualifiers(_:));

- (BOOL)selectedCertSelfSigned:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertSelfSigned(_:));

- (NSData*)selectedCertSerialNumber:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertSerialNumber(_:));

- (NSString*)selectedCertSigAlgorithm:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertSigAlgorithm(_:));

- (int)selectedCertSource:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertSource(_:));

- (NSString*)selectedCertSubject:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertSubject(_:));

- (NSString*)selectedCertSubjectAlternativeName:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertSubjectAlternativeName(_:));

- (NSData*)selectedCertSubjectKeyID:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertSubjectKeyID(_:));

- (NSString*)selectedCertSubjectRDN:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertSubjectRDN(_:));

- (BOOL)selectedCertValid:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertValid(_:));

- (NSString*)selectedCertValidFrom:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertValidFrom(_:));

- (NSString*)selectedCertValidTo:(int)selectedCertIndex NS_SWIFT_NAME(selectedCertValidTo(_:));

@property (nonatomic,readonly,assign,getter=storageID) NSString* storageID NS_SWIFT_NAME(storageID);

- (NSString*)storageID NS_SWIFT_NAME(storageID());

@property (nonatomic,readonly,assign,getter=storageLocation) NSString* storageLocation NS_SWIFT_NAME(storageLocation);

- (NSString*)storageLocation NS_SWIFT_NAME(storageLocation());

  /* Methods */

- (void)clear NS_SWIFT_NAME(clear());

- (void)close:(BOOL)save NS_SWIFT_NAME(close(_:));

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (void)createNew:(NSString*)storageLocation :(NSString*)storageID NS_SWIFT_NAME(createNew(_:_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (NSData*)exportBytes:(int)what :(int)format :(NSString*)password NS_SWIFT_NAME(exportBytes(_:_:_:));

- (void)exportToFile:(int)what :(NSString*)fileName :(int)format :(NSString*)password NS_SWIFT_NAME(exportToFile(_:_:_:_:));

- (NSString*)getStorageProperty:(NSString*)name NS_SWIFT_NAME(getStorageProperty(_:));

- (void)importBytes:(NSData*)certBytes :(NSString*)password :(BOOL)clear NS_SWIFT_NAME(importBytes(_:_:_:));

- (void)importFromFile:(NSString*)path :(NSString*)password :(BOOL)clear NS_SWIFT_NAME(importFromFile(_:_:_:));

- (void)importPinned:(BOOL)clear NS_SWIFT_NAME(importPinned(_:));

- (NSString*)listStores NS_SWIFT_NAME(listStores());

- (void)login:(int)sessionType :(NSString*)pin :(BOOL)readOnly NS_SWIFT_NAME(login(_:_:_:));

- (void)logout:(BOOL)closeSesion NS_SWIFT_NAME(logout(_:));

- (void)open:(NSString*)storageID NS_SWIFT_NAME(open(_:));

- (void)refresh NS_SWIFT_NAME(refresh());

- (void)remove:(int)index NS_SWIFT_NAME(remove(_:));

- (void)removeCRL:(int)index NS_SWIFT_NAME(removeCRL(_:));

- (void)removeOCSP:(int)index NS_SWIFT_NAME(removeOCSP(_:));

- (void)reset NS_SWIFT_NAME(reset());

- (void)select:(NSString*)filter :(BOOL)privateKeyNeeded :(int)maxCount NS_SWIFT_NAME(select(_:_:_:));

- (void)selectChain:(int)index NS_SWIFT_NAME(selectChain(_:));

- (void)setStorageProperty:(NSString*)name :(NSString*)value NS_SWIFT_NAME(setStorageProperty(_:_:));

@end

