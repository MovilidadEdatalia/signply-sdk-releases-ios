/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//CRYPTOENCODINGTYPES
#define CET_DEFAULT                                        0

#define CET_BINARY                                         1

#define CET_BASE_64                                        2

#define CET_COMPACT                                        3

#define CET_JSON                                           4

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxHashFunctionDelegate <NSObject>
@optional
- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

@end

@interface SecureBlackboxHashFunction : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxHashFunctionDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasError;

  BOOL m_delegateHasNotification;

}

+ (SecureBlackboxHashFunction*)hashfunction;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxHashFunctionDelegate> delegate;
- (id <SecureBlackboxHashFunctionDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxHashFunctionDelegate>)anObject;

  /* Events */

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readwrite,assign,getter=algorithm,setter=setAlgorithm:) NSString* algorithm NS_SWIFT_NAME(algorithm);

- (NSString*)algorithm NS_SWIFT_NAME(algorithm());
- (void)setAlgorithm :(NSString*)newAlgorithm NS_SWIFT_NAME(setAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=jsonKeyHeaderParams,setter=setJsonKeyHeaderParams:) NSString* jsonKeyHeaderParams NS_SWIFT_NAME(jsonKeyHeaderParams);

- (NSString*)jsonKeyHeaderParams NS_SWIFT_NAME(jsonKeyHeaderParams());
- (void)setJsonKeyHeaderParams :(NSString*)newJsonKeyHeaderParams NS_SWIFT_NAME(setJsonKeyHeaderParams(_:));

@property (nonatomic,readwrite,assign,getter=jsonProtectedHeader,setter=setJsonProtectedHeader:) NSString* jsonProtectedHeader NS_SWIFT_NAME(jsonProtectedHeader);

- (NSString*)jsonProtectedHeader NS_SWIFT_NAME(jsonProtectedHeader());
- (void)setJsonProtectedHeader :(NSString*)newJsonProtectedHeader NS_SWIFT_NAME(setJsonProtectedHeader(_:));

@property (nonatomic,readwrite,assign,getter=jsonUnprotectedHeader,setter=setJsonUnprotectedHeader:) NSString* jsonUnprotectedHeader NS_SWIFT_NAME(jsonUnprotectedHeader);

- (NSString*)jsonUnprotectedHeader NS_SWIFT_NAME(jsonUnprotectedHeader());
- (void)setJsonUnprotectedHeader :(NSString*)newJsonUnprotectedHeader NS_SWIFT_NAME(setJsonUnprotectedHeader(_:));

@property (nonatomic,readwrite,assign,getter=jsonUnprotectedHeaderParams,setter=setJsonUnprotectedHeaderParams:) NSString* jsonUnprotectedHeaderParams NS_SWIFT_NAME(jsonUnprotectedHeaderParams);

- (NSString*)jsonUnprotectedHeaderParams NS_SWIFT_NAME(jsonUnprotectedHeaderParams());
- (void)setJsonUnprotectedHeaderParams :(NSString*)newJsonUnprotectedHeaderParams NS_SWIFT_NAME(setJsonUnprotectedHeaderParams(_:));

@property (nonatomic,readwrite,assign,getter=keyAlgorithm,setter=setKeyAlgorithm:) NSString* keyAlgorithm NS_SWIFT_NAME(keyAlgorithm);

- (NSString*)keyAlgorithm NS_SWIFT_NAME(keyAlgorithm());
- (void)setKeyAlgorithm :(NSString*)newKeyAlgorithm NS_SWIFT_NAME(setKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=keyBits) int keyBits NS_SWIFT_NAME(keyBits);

- (int)keyBits NS_SWIFT_NAME(keyBits());

@property (nonatomic,readwrite,assign,getter=keyCurve,setter=setKeyCurve:) NSString* keyCurve NS_SWIFT_NAME(keyCurve);

- (NSString*)keyCurve NS_SWIFT_NAME(keyCurve());
- (void)setKeyCurve :(NSString*)newKeyCurve NS_SWIFT_NAME(setKeyCurve(_:));

@property (nonatomic,readonly,assign,getter=keyExportable) BOOL keyExportable NS_SWIFT_NAME(keyExportable);

- (BOOL)keyExportable NS_SWIFT_NAME(keyExportable());

@property (nonatomic,readonly,assign,getter=keyFingerprint) NSString* keyFingerprint NS_SWIFT_NAME(keyFingerprint);

- (NSString*)keyFingerprint NS_SWIFT_NAME(keyFingerprint());

@property (nonatomic,readwrite,assign,getter=keyHandle,setter=setKeyHandle:) long long keyHandle NS_SWIFT_NAME(keyHandle);

- (long long)keyHandle NS_SWIFT_NAME(keyHandle());
- (void)setKeyHandle :(long long)newKeyHandle NS_SWIFT_NAME(setKeyHandle(_:));

@property (nonatomic,readwrite,assign,getter=keyID,setter=setKeyID:) NSData* keyID NS_SWIFT_NAME(keyID);

- (NSData*)keyID NS_SWIFT_NAME(keyID());
- (void)setKeyID :(NSData*)newKeyID NS_SWIFT_NAME(setKeyID(_:));

@property (nonatomic,readwrite,assign,getter=keyIV,setter=setKeyIV:) NSData* keyIV NS_SWIFT_NAME(keyIV);

- (NSData*)keyIV NS_SWIFT_NAME(keyIV());
- (void)setKeyIV :(NSData*)newKeyIV NS_SWIFT_NAME(setKeyIV(_:));

@property (nonatomic,readonly,assign,getter=keyKey) NSData* keyKey NS_SWIFT_NAME(keyKey);

- (NSData*)keyKey NS_SWIFT_NAME(keyKey());

@property (nonatomic,readwrite,assign,getter=keyNonce,setter=setKeyNonce:) NSData* keyNonce NS_SWIFT_NAME(keyNonce);

- (NSData*)keyNonce NS_SWIFT_NAME(keyNonce());
- (void)setKeyNonce :(NSData*)newKeyNonce NS_SWIFT_NAME(setKeyNonce(_:));

@property (nonatomic,readonly,assign,getter=keyPrivate) BOOL keyPrivate NS_SWIFT_NAME(keyPrivate);

- (BOOL)keyPrivate NS_SWIFT_NAME(keyPrivate());

@property (nonatomic,readonly,assign,getter=keyPublic) BOOL keyPublic NS_SWIFT_NAME(keyPublic);

- (BOOL)keyPublic NS_SWIFT_NAME(keyPublic());

@property (nonatomic,readwrite,assign,getter=keySubject,setter=setKeySubject:) NSData* keySubject NS_SWIFT_NAME(keySubject);

- (NSData*)keySubject NS_SWIFT_NAME(keySubject());
- (void)setKeySubject :(NSData*)newKeySubject NS_SWIFT_NAME(setKeySubject(_:));

@property (nonatomic,readonly,assign,getter=keySymmetric) BOOL keySymmetric NS_SWIFT_NAME(keySymmetric);

- (BOOL)keySymmetric NS_SWIFT_NAME(keySymmetric());

@property (nonatomic,readonly,assign,getter=keyValid) BOOL keyValid NS_SWIFT_NAME(keyValid);

- (BOOL)keyValid NS_SWIFT_NAME(keyValid());

@property (nonatomic,readwrite,assign,getter=outputEncoding,setter=setOutputEncoding:) int outputEncoding NS_SWIFT_NAME(outputEncoding);

- (int)outputEncoding NS_SWIFT_NAME(outputEncoding());
- (void)setOutputEncoding :(int)newOutputEncoding NS_SWIFT_NAME(setOutputEncoding(_:));

  /* Methods */

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (NSData*)finish NS_SWIFT_NAME(finish());

- (NSData*)hash:(NSData*)buffer NS_SWIFT_NAME(hash(_:));

- (NSData*)hashFile:(NSString*)sourceFile NS_SWIFT_NAME(hashFile(_:));

- (NSData*)hashStream NS_SWIFT_NAME(hashStream());

- (void)reset NS_SWIFT_NAME(reset());

- (void)update:(NSData*)buffer NS_SWIFT_NAME(update(_:));

- (void)updateFile:(NSString*)sourceFile NS_SWIFT_NAME(updateFile(_:));

- (void)updateStream NS_SWIFT_NAME(updateStream());

@end

