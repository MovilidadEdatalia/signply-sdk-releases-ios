/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//ASYNCSIGNMETHODS
#define ASMD_PKCS1                                         0

#define ASMD_PKCS7                                         1

//EXTERNALCRYPTOMODES
#define ECM_DEFAULT                                        0

#define ECM_DISABLED                                       1

#define ECM_GENERIC                                        2

#define ECM_DCAUTH                                         3

#define ECM_DCAUTH_JSON                                    4

//CHAINVALIDITIES
#define CVT_VALID                                          0

#define CVT_VALID_BUT_UNTRUSTED                            1

#define CVT_INVALID                                        2

#define CVT_CANT_BE_ESTABLISHED                            3

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

//DNSRESOLVEMODES
#define DM_AUTO                                            0

#define DM_PLATFORM                                        1

#define DM_OWN                                             2

#define DM_OWN_SECURE                                      3

//SECURETRANSPORTPREDEFINEDCONFIGURATIONS
#define STPC_DEFAULT                                       0

#define STPC_COMPATIBLE                                    1

#define STPC_COMPREHENSIVE_INSECURE                        2

#define STPC_HIGHLY_SECURE                                 3

//CLIENTAUTHTYPES
#define CCAT_NO_AUTH                                       0

#define CCAT_REQUEST_CERT                                  1

#define CCAT_REQUIRE_CERT                                  2

//RENEGOTIATIONATTACKPREVENTIONMODES
#define CRAPM_COMPATIBLE                                   0

#define CRAPM_STRICT                                       1

#define CRAPM_AUTO                                         2

//REVOCATIONCHECKKINDS
#define CRC_NONE                                           0

#define CRC_AUTO                                           1

#define CRC_ALL_CRL                                        2

#define CRC_ALL_OCSP                                       3

#define CRC_ALL_CRLAND_OCSP                                4

#define CRC_ANY_CRL                                        5

#define CRC_ANY_OCSP                                       6

#define CRC_ANY_CRLOR_OCSP                                 7

#define CRC_ANY_OCSPOR_CRL                                 8

//SSLMODES
#define SM_DEFAULT                                         0

#define SM_NO_TLS                                          1

#define SM_EXPLICIT_TLS                                    2

#define SM_IMPLICIT_TLS                                    3

#define SM_MIXED_TLS                                       4

//OTPALGORITHMS
#define OA_NONE                                            0

#define OA_HMAC                                            1

#define OA_TIME                                            2

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxWebDAVServerDelegate <NSObject>
@optional
- (void)onAccept:(NSString*)remoteAddress :(int)remotePort :(int*)accept NS_SWIFT_NAME(onAccept(_:_:_:));

- (void)onAfterBrowse:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterBrowse(_:_:_:));

- (void)onAfterCopyObject:(long long)connectionID :(NSString*)oldPath :(NSString*)newPath :(int*)operationStatus NS_SWIFT_NAME(onAfterCopyObject(_:_:_:_:));

- (void)onAfterCreateCalendar:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterCreateCalendar(_:_:_:));

- (void)onAfterCreateCollection:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterCreateCollection(_:_:_:));

- (void)onAfterCustomRequest:(long long)connectionID :(NSString*)requestMethod :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterCustomRequest(_:_:_:_:));

- (void)onAfterLockObject:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterLockObject(_:_:_:));

- (void)onAfterRefreshLock:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterRefreshLock(_:_:_:));

- (void)onAfterRemoveObject:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterRemoveObject(_:_:_:));

- (void)onAfterRenameObject:(long long)connectionID :(NSString*)oldPath :(NSString*)newPath :(int*)operationStatus NS_SWIFT_NAME(onAfterRenameObject(_:_:_:_:));

- (void)onAfterSetAttributes:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterSetAttributes(_:_:_:));

- (void)onAfterUnlockObject:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterUnlockObject(_:_:_:));

- (void)onAuthAttempt:(long long)connectionID :(NSString*)HTTPMethod :(NSString*)URI :(NSString*)authMethod :(NSString*)username :(NSString*)password :(int*)allow NS_SWIFT_NAME(onAuthAttempt(_:_:_:_:_:_:_:));

- (void)onBeforeBrowse:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeBrowse(_:_:_:));

- (void)onBeforeCopyObject:(long long)connectionID :(NSString*)oldPath :(NSString*)newPath :(int*)action NS_SWIFT_NAME(onBeforeCopyObject(_:_:_:_:));

- (void)onBeforeCreateCalendar:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeCreateCalendar(_:_:_:));

- (void)onBeforeCreateCollection:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeCreateCollection(_:_:_:));

- (void)onBeforeCustomRequest:(long long)connectionID :(NSString*)requestMethod :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeCustomRequest(_:_:_:_:));

- (void)onBeforeDownloadObject:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeDownloadObject(_:_:_:));

- (void)onBeforeLockObject:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeLockObject(_:_:_:));

- (void)onBeforeRefreshLock:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeRefreshLock(_:_:_:));

- (void)onBeforeRemoveObject:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeRemoveObject(_:_:_:));

- (void)onBeforeRenameObject:(long long)connectionID :(NSString*)oldPath :(NSString*)newPath :(int*)action NS_SWIFT_NAME(onBeforeRenameObject(_:_:_:_:));

- (void)onBeforeRequest:(long long)connectionID :(NSString*)HTTPMethod :(NSString*)URL :(int*)accept NS_SWIFT_NAME(onBeforeRequest(_:_:_:_:));

- (void)onBeforeSetAttributes:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeSetAttributes(_:_:_:));

- (void)onBeforeUnlockObject:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeUnlockObject(_:_:_:));

- (void)onBeforeUploadObject:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeUploadObject(_:_:_:));

- (void)onClearAttribute:(long long)connectionID :(NSString*)path :(NSString*)NS :(NSString*)name :(int*)operationStatus NS_SWIFT_NAME(onClearAttribute(_:_:_:_:_:));

- (void)onConnect:(long long)connectionID :(NSString*)remoteAddress :(int)remotePort NS_SWIFT_NAME(onConnect(_:_:_:));

- (void)onCopyObject:(long long)connectionID :(NSString*)oldPath :(NSString*)newPath :(BOOL)overwrite :(int)depth :(int*)operationStatus NS_SWIFT_NAME(onCopyObject(_:_:_:_:_:_:));

- (void)onCreateCalendar:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onCreateCalendar(_:_:_:));

- (void)onCreateCollection:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onCreateCollection(_:_:_:));

- (void)onCustomRequest:(long long)connectionID :(NSString*)requestMethod :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onCustomRequest(_:_:_:_:));

- (void)onData:(long long)connectionID :(NSData*)buffer NS_SWIFT_NAME(onData(_:_:));

- (void)onDisconnect:(long long)connectionID NS_SWIFT_NAME(onDisconnect(_:));

- (void)onDownloadObject:(long long)connectionID :(NSString*)path :(long long)restartAt :(int*)operationStatus NS_SWIFT_NAME(onDownloadObject(_:_:_:_:));

- (void)onDownloadObjectCompleted:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onDownloadObjectCompleted(_:_:_:));

- (void)onError:(long long)connectionID :(int)errorCode :(BOOL)fatal :(BOOL)remote :(NSString*)description NS_SWIFT_NAME(onError(_:_:_:_:_:));

- (void)onExternalSign:(long long)connectionID :(NSString*)operationId :(NSString*)hashAlgorithm :(NSString*)pars :(NSString*)data :(NSString**)signedData NS_SWIFT_NAME(onExternalSign(_:_:_:_:_:_:));

- (void)onFileError:(long long)connectionID :(NSString*)fileName :(int)errorCode NS_SWIFT_NAME(onFileError(_:_:_:));

- (void)onHeadersPrepared:(long long)connectionID NS_SWIFT_NAME(onHeadersPrepared(_:));

- (void)onListAttributes:(long long)connectionID :(NSString*)path :(NSString**)attributes NS_SWIFT_NAME(onListAttributes(_:_:_:));

- (void)onListSubObjects:(long long)connectionID :(NSString*)path :(BOOL)recursive :(NSString**)objects :(int*)operationStatus NS_SWIFT_NAME(onListSubObjects(_:_:_:_:_:));

- (void)onLockObject:(long long)connectionID :(NSString*)path :(NSString*)owner :(BOOL)exclusive :(int)depth :(long long)timeout :(NSString**)token NS_SWIFT_NAME(onLockObject(_:_:_:_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onQueryQuota:(long long)connectionID :(NSString*)username :(long long*)available :(long long*)used NS_SWIFT_NAME(onQueryQuota(_:_:_:_:));

- (void)onReadAttribute:(long long)connectionID :(NSString*)path :(NSString*)NS :(NSString*)name :(NSString**)value :(int*)operationStatus NS_SWIFT_NAME(onReadAttribute(_:_:_:_:_:_:));

- (void)onReadObject:(long long)connectionID :(int)size :(int*)operationStatus NS_SWIFT_NAME(onReadObject(_:_:_:));

- (void)onRefreshLock:(long long)connectionID :(NSString*)path :(NSString*)token :(long long)timeout :(int*)lockFound NS_SWIFT_NAME(onRefreshLock(_:_:_:_:_:));

- (void)onRemoveObject:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onRemoveObject(_:_:_:));

- (void)onRenameObject:(long long)connectionID :(NSString*)oldPath :(NSString*)newPath :(BOOL)overwrite :(int*)operationStatus NS_SWIFT_NAME(onRenameObject(_:_:_:_:_:));

- (void)onResourceAccess:(long long)connectionID :(NSString*)HTTPMethod :(NSString*)URI :(int*)allow :(NSString**)redirectURI NS_SWIFT_NAME(onResourceAccess(_:_:_:_:_:));

- (void)onSetAttribute:(long long)connectionID :(NSString*)path :(NSString*)NS :(NSString*)name :(NSString*)value :(int*)operationStatus NS_SWIFT_NAME(onSetAttribute(_:_:_:_:_:_:));

- (void)onTLSCertValidate:(long long)connectionID :(int*)accept NS_SWIFT_NAME(onTLSCertValidate(_:_:));

- (void)onTLSEstablished:(long long)connectionID NS_SWIFT_NAME(onTLSEstablished(_:));

- (void)onTLSHandshake:(long long)connectionID :(NSString*)serverName :(int*)abort NS_SWIFT_NAME(onTLSHandshake(_:_:_:));

- (void)onTLSPSK:(long long)connectionID :(NSString*)identity :(NSString**)PSK :(NSString**)ciphersuite NS_SWIFT_NAME(onTLSPSK(_:_:_:_:));

- (void)onTLSShutdown:(long long)connectionID NS_SWIFT_NAME(onTLSShutdown(_:));

- (void)onUnlockObject:(long long)connectionID :(NSString*)path :(NSString*)token :(int*)lockFound NS_SWIFT_NAME(onUnlockObject(_:_:_:_:));

- (void)onUploadObject:(long long)connectionID :(NSString*)path :(long long)restartAt :(BOOL)append :(int*)operationStatus NS_SWIFT_NAME(onUploadObject(_:_:_:_:_:));

- (void)onUploadObjectCompleted:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onUploadObjectCompleted(_:_:_:));

- (void)onWriteObject:(long long)connectionID :(int*)operationStatus NS_SWIFT_NAME(onWriteObject(_:_:));

@end

@interface SecureBlackboxWebDAVServer : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxWebDAVServerDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasAccept;

  BOOL m_delegateHasAfterBrowse;

  BOOL m_delegateHasAfterCopyObject;

  BOOL m_delegateHasAfterCreateCalendar;

  BOOL m_delegateHasAfterCreateCollection;

  BOOL m_delegateHasAfterCustomRequest;

  BOOL m_delegateHasAfterLockObject;

  BOOL m_delegateHasAfterRefreshLock;

  BOOL m_delegateHasAfterRemoveObject;

  BOOL m_delegateHasAfterRenameObject;

  BOOL m_delegateHasAfterSetAttributes;

  BOOL m_delegateHasAfterUnlockObject;

  BOOL m_delegateHasAuthAttempt;

  BOOL m_delegateHasBeforeBrowse;

  BOOL m_delegateHasBeforeCopyObject;

  BOOL m_delegateHasBeforeCreateCalendar;

  BOOL m_delegateHasBeforeCreateCollection;

  BOOL m_delegateHasBeforeCustomRequest;

  BOOL m_delegateHasBeforeDownloadObject;

  BOOL m_delegateHasBeforeLockObject;

  BOOL m_delegateHasBeforeRefreshLock;

  BOOL m_delegateHasBeforeRemoveObject;

  BOOL m_delegateHasBeforeRenameObject;

  BOOL m_delegateHasBeforeRequest;

  BOOL m_delegateHasBeforeSetAttributes;

  BOOL m_delegateHasBeforeUnlockObject;

  BOOL m_delegateHasBeforeUploadObject;

  BOOL m_delegateHasClearAttribute;

  BOOL m_delegateHasConnect;

  BOOL m_delegateHasCopyObject;

  BOOL m_delegateHasCreateCalendar;

  BOOL m_delegateHasCreateCollection;

  BOOL m_delegateHasCustomRequest;

  BOOL m_delegateHasData;

  BOOL m_delegateHasDisconnect;

  BOOL m_delegateHasDownloadObject;

  BOOL m_delegateHasDownloadObjectCompleted;

  BOOL m_delegateHasError;

  BOOL m_delegateHasExternalSign;

  BOOL m_delegateHasFileError;

  BOOL m_delegateHasHeadersPrepared;

  BOOL m_delegateHasListAttributes;

  BOOL m_delegateHasListSubObjects;

  BOOL m_delegateHasLockObject;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasQueryQuota;

  BOOL m_delegateHasReadAttribute;

  BOOL m_delegateHasReadObject;

  BOOL m_delegateHasRefreshLock;

  BOOL m_delegateHasRemoveObject;

  BOOL m_delegateHasRenameObject;

  BOOL m_delegateHasResourceAccess;

  BOOL m_delegateHasSetAttribute;

  BOOL m_delegateHasTLSCertValidate;

  BOOL m_delegateHasTLSEstablished;

  BOOL m_delegateHasTLSHandshake;

  BOOL m_delegateHasTLSPSK;

  BOOL m_delegateHasTLSShutdown;

  BOOL m_delegateHasUnlockObject;

  BOOL m_delegateHasUploadObject;

  BOOL m_delegateHasUploadObjectCompleted;

  BOOL m_delegateHasWriteObject;

}

+ (SecureBlackboxWebDAVServer*)webdavserver;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxWebDAVServerDelegate> delegate;
- (id <SecureBlackboxWebDAVServerDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxWebDAVServerDelegate>)anObject;

  /* Events */

- (void)onAccept:(NSString*)remoteAddress :(int)remotePort :(int*)accept NS_SWIFT_NAME(onAccept(_:_:_:));

- (void)onAfterBrowse:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterBrowse(_:_:_:));

- (void)onAfterCopyObject:(long long)connectionID :(NSString*)oldPath :(NSString*)newPath :(int*)operationStatus NS_SWIFT_NAME(onAfterCopyObject(_:_:_:_:));

- (void)onAfterCreateCalendar:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterCreateCalendar(_:_:_:));

- (void)onAfterCreateCollection:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterCreateCollection(_:_:_:));

- (void)onAfterCustomRequest:(long long)connectionID :(NSString*)requestMethod :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterCustomRequest(_:_:_:_:));

- (void)onAfterLockObject:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterLockObject(_:_:_:));

- (void)onAfterRefreshLock:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterRefreshLock(_:_:_:));

- (void)onAfterRemoveObject:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterRemoveObject(_:_:_:));

- (void)onAfterRenameObject:(long long)connectionID :(NSString*)oldPath :(NSString*)newPath :(int*)operationStatus NS_SWIFT_NAME(onAfterRenameObject(_:_:_:_:));

- (void)onAfterSetAttributes:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterSetAttributes(_:_:_:));

- (void)onAfterUnlockObject:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onAfterUnlockObject(_:_:_:));

- (void)onAuthAttempt:(long long)connectionID :(NSString*)HTTPMethod :(NSString*)URI :(NSString*)authMethod :(NSString*)username :(NSString*)password :(int*)allow NS_SWIFT_NAME(onAuthAttempt(_:_:_:_:_:_:_:));

- (void)onBeforeBrowse:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeBrowse(_:_:_:));

- (void)onBeforeCopyObject:(long long)connectionID :(NSString*)oldPath :(NSString*)newPath :(int*)action NS_SWIFT_NAME(onBeforeCopyObject(_:_:_:_:));

- (void)onBeforeCreateCalendar:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeCreateCalendar(_:_:_:));

- (void)onBeforeCreateCollection:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeCreateCollection(_:_:_:));

- (void)onBeforeCustomRequest:(long long)connectionID :(NSString*)requestMethod :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeCustomRequest(_:_:_:_:));

- (void)onBeforeDownloadObject:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeDownloadObject(_:_:_:));

- (void)onBeforeLockObject:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeLockObject(_:_:_:));

- (void)onBeforeRefreshLock:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeRefreshLock(_:_:_:));

- (void)onBeforeRemoveObject:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeRemoveObject(_:_:_:));

- (void)onBeforeRenameObject:(long long)connectionID :(NSString*)oldPath :(NSString*)newPath :(int*)action NS_SWIFT_NAME(onBeforeRenameObject(_:_:_:_:));

- (void)onBeforeRequest:(long long)connectionID :(NSString*)HTTPMethod :(NSString*)URL :(int*)accept NS_SWIFT_NAME(onBeforeRequest(_:_:_:_:));

- (void)onBeforeSetAttributes:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeSetAttributes(_:_:_:));

- (void)onBeforeUnlockObject:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeUnlockObject(_:_:_:));

- (void)onBeforeUploadObject:(long long)connectionID :(NSString*)path :(int*)action NS_SWIFT_NAME(onBeforeUploadObject(_:_:_:));

- (void)onClearAttribute:(long long)connectionID :(NSString*)path :(NSString*)NS :(NSString*)name :(int*)operationStatus NS_SWIFT_NAME(onClearAttribute(_:_:_:_:_:));

- (void)onConnect:(long long)connectionID :(NSString*)remoteAddress :(int)remotePort NS_SWIFT_NAME(onConnect(_:_:_:));

- (void)onCopyObject:(long long)connectionID :(NSString*)oldPath :(NSString*)newPath :(BOOL)overwrite :(int)depth :(int*)operationStatus NS_SWIFT_NAME(onCopyObject(_:_:_:_:_:_:));

- (void)onCreateCalendar:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onCreateCalendar(_:_:_:));

- (void)onCreateCollection:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onCreateCollection(_:_:_:));

- (void)onCustomRequest:(long long)connectionID :(NSString*)requestMethod :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onCustomRequest(_:_:_:_:));

- (void)onData:(long long)connectionID :(NSData*)buffer NS_SWIFT_NAME(onData(_:_:));

- (void)onDisconnect:(long long)connectionID NS_SWIFT_NAME(onDisconnect(_:));

- (void)onDownloadObject:(long long)connectionID :(NSString*)path :(long long)restartAt :(int*)operationStatus NS_SWIFT_NAME(onDownloadObject(_:_:_:_:));

- (void)onDownloadObjectCompleted:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onDownloadObjectCompleted(_:_:_:));

- (void)onError:(long long)connectionID :(int)errorCode :(BOOL)fatal :(BOOL)remote :(NSString*)description NS_SWIFT_NAME(onError(_:_:_:_:_:));

- (void)onExternalSign:(long long)connectionID :(NSString*)operationId :(NSString*)hashAlgorithm :(NSString*)pars :(NSString*)data :(NSString**)signedData NS_SWIFT_NAME(onExternalSign(_:_:_:_:_:_:));

- (void)onFileError:(long long)connectionID :(NSString*)fileName :(int)errorCode NS_SWIFT_NAME(onFileError(_:_:_:));

- (void)onHeadersPrepared:(long long)connectionID NS_SWIFT_NAME(onHeadersPrepared(_:));

- (void)onListAttributes:(long long)connectionID :(NSString*)path :(NSString**)attributes NS_SWIFT_NAME(onListAttributes(_:_:_:));

- (void)onListSubObjects:(long long)connectionID :(NSString*)path :(BOOL)recursive :(NSString**)objects :(int*)operationStatus NS_SWIFT_NAME(onListSubObjects(_:_:_:_:_:));

- (void)onLockObject:(long long)connectionID :(NSString*)path :(NSString*)owner :(BOOL)exclusive :(int)depth :(long long)timeout :(NSString**)token NS_SWIFT_NAME(onLockObject(_:_:_:_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onQueryQuota:(long long)connectionID :(NSString*)username :(long long*)available :(long long*)used NS_SWIFT_NAME(onQueryQuota(_:_:_:_:));

- (void)onReadAttribute:(long long)connectionID :(NSString*)path :(NSString*)NS :(NSString*)name :(NSString**)value :(int*)operationStatus NS_SWIFT_NAME(onReadAttribute(_:_:_:_:_:_:));

- (void)onReadObject:(long long)connectionID :(int)size :(int*)operationStatus NS_SWIFT_NAME(onReadObject(_:_:_:));

- (void)onRefreshLock:(long long)connectionID :(NSString*)path :(NSString*)token :(long long)timeout :(int*)lockFound NS_SWIFT_NAME(onRefreshLock(_:_:_:_:_:));

- (void)onRemoveObject:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onRemoveObject(_:_:_:));

- (void)onRenameObject:(long long)connectionID :(NSString*)oldPath :(NSString*)newPath :(BOOL)overwrite :(int*)operationStatus NS_SWIFT_NAME(onRenameObject(_:_:_:_:_:));

- (void)onResourceAccess:(long long)connectionID :(NSString*)HTTPMethod :(NSString*)URI :(int*)allow :(NSString**)redirectURI NS_SWIFT_NAME(onResourceAccess(_:_:_:_:_:));

- (void)onSetAttribute:(long long)connectionID :(NSString*)path :(NSString*)NS :(NSString*)name :(NSString*)value :(int*)operationStatus NS_SWIFT_NAME(onSetAttribute(_:_:_:_:_:_:));

- (void)onTLSCertValidate:(long long)connectionID :(int*)accept NS_SWIFT_NAME(onTLSCertValidate(_:_:));

- (void)onTLSEstablished:(long long)connectionID NS_SWIFT_NAME(onTLSEstablished(_:));

- (void)onTLSHandshake:(long long)connectionID :(NSString*)serverName :(int*)abort NS_SWIFT_NAME(onTLSHandshake(_:_:_:));

- (void)onTLSPSK:(long long)connectionID :(NSString*)identity :(NSString**)PSK :(NSString**)ciphersuite NS_SWIFT_NAME(onTLSPSK(_:_:_:_:));

- (void)onTLSShutdown:(long long)connectionID NS_SWIFT_NAME(onTLSShutdown(_:));

- (void)onUnlockObject:(long long)connectionID :(NSString*)path :(NSString*)token :(int*)lockFound NS_SWIFT_NAME(onUnlockObject(_:_:_:_:));

- (void)onUploadObject:(long long)connectionID :(NSString*)path :(long long)restartAt :(BOOL)append :(int*)operationStatus NS_SWIFT_NAME(onUploadObject(_:_:_:_:_:));

- (void)onUploadObjectCompleted:(long long)connectionID :(NSString*)path :(int*)operationStatus NS_SWIFT_NAME(onUploadObjectCompleted(_:_:_:));

- (void)onWriteObject:(long long)connectionID :(int*)operationStatus NS_SWIFT_NAME(onWriteObject(_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readonly,assign,getter=active) BOOL active NS_SWIFT_NAME(active);

- (BOOL)active NS_SWIFT_NAME(active());

@property (nonatomic,readwrite,assign,getter=authRealm,setter=setAuthRealm:) NSString* authRealm NS_SWIFT_NAME(authRealm);

- (NSString*)authRealm NS_SWIFT_NAME(authRealm());
- (void)setAuthRealm :(NSString*)newAuthRealm NS_SWIFT_NAME(setAuthRealm(_:));

@property (nonatomic,readwrite,assign,getter=authTypes,setter=setAuthTypes:) int authTypes NS_SWIFT_NAME(authTypes);

- (int)authTypes NS_SWIFT_NAME(authTypes());
- (void)setAuthTypes :(int)newAuthTypes NS_SWIFT_NAME(setAuthTypes(_:));

@property (nonatomic,readonly,assign,getter=boundPort) int boundPort NS_SWIFT_NAME(boundPort);

- (int)boundPort NS_SWIFT_NAME(boundPort());

@property (nonatomic,readwrite,assign,getter=clientFileEntryATime,setter=setClientFileEntryATime:) NSString* clientFileEntryATime NS_SWIFT_NAME(clientFileEntryATime);

- (NSString*)clientFileEntryATime NS_SWIFT_NAME(clientFileEntryATime());
- (void)setClientFileEntryATime :(NSString*)newClientFileEntryATime NS_SWIFT_NAME(setClientFileEntryATime(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntryContentType,setter=setClientFileEntryContentType:) NSString* clientFileEntryContentType NS_SWIFT_NAME(clientFileEntryContentType);

- (NSString*)clientFileEntryContentType NS_SWIFT_NAME(clientFileEntryContentType());
- (void)setClientFileEntryContentType :(NSString*)newClientFileEntryContentType NS_SWIFT_NAME(setClientFileEntryContentType(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntryCTime,setter=setClientFileEntryCTime:) NSString* clientFileEntryCTime NS_SWIFT_NAME(clientFileEntryCTime);

- (NSString*)clientFileEntryCTime NS_SWIFT_NAME(clientFileEntryCTime());
- (void)setClientFileEntryCTime :(NSString*)newClientFileEntryCTime NS_SWIFT_NAME(setClientFileEntryCTime(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntryDirectory,setter=setClientFileEntryDirectory:) BOOL clientFileEntryDirectory NS_SWIFT_NAME(clientFileEntryDirectory);

- (BOOL)clientFileEntryDirectory NS_SWIFT_NAME(clientFileEntryDirectory());
- (void)setClientFileEntryDirectory :(BOOL)newClientFileEntryDirectory NS_SWIFT_NAME(setClientFileEntryDirectory(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntryDisplayName,setter=setClientFileEntryDisplayName:) NSString* clientFileEntryDisplayName NS_SWIFT_NAME(clientFileEntryDisplayName);

- (NSString*)clientFileEntryDisplayName NS_SWIFT_NAME(clientFileEntryDisplayName());
- (void)setClientFileEntryDisplayName :(NSString*)newClientFileEntryDisplayName NS_SWIFT_NAME(setClientFileEntryDisplayName(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntryETag,setter=setClientFileEntryETag:) NSString* clientFileEntryETag NS_SWIFT_NAME(clientFileEntryETag);

- (NSString*)clientFileEntryETag NS_SWIFT_NAME(clientFileEntryETag());
- (void)setClientFileEntryETag :(NSString*)newClientFileEntryETag NS_SWIFT_NAME(setClientFileEntryETag(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntryFullURL,setter=setClientFileEntryFullURL:) NSString* clientFileEntryFullURL NS_SWIFT_NAME(clientFileEntryFullURL);

- (NSString*)clientFileEntryFullURL NS_SWIFT_NAME(clientFileEntryFullURL());
- (void)setClientFileEntryFullURL :(NSString*)newClientFileEntryFullURL NS_SWIFT_NAME(setClientFileEntryFullURL(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntryMTime,setter=setClientFileEntryMTime:) NSString* clientFileEntryMTime NS_SWIFT_NAME(clientFileEntryMTime);

- (NSString*)clientFileEntryMTime NS_SWIFT_NAME(clientFileEntryMTime());
- (void)setClientFileEntryMTime :(NSString*)newClientFileEntryMTime NS_SWIFT_NAME(setClientFileEntryMTime(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntryParentURL,setter=setClientFileEntryParentURL:) NSString* clientFileEntryParentURL NS_SWIFT_NAME(clientFileEntryParentURL);

- (NSString*)clientFileEntryParentURL NS_SWIFT_NAME(clientFileEntryParentURL());
- (void)setClientFileEntryParentURL :(NSString*)newClientFileEntryParentURL NS_SWIFT_NAME(setClientFileEntryParentURL(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntrySize,setter=setClientFileEntrySize:) long long clientFileEntrySize NS_SWIFT_NAME(clientFileEntrySize);

- (long long)clientFileEntrySize NS_SWIFT_NAME(clientFileEntrySize());
- (void)setClientFileEntrySize :(long long)newClientFileEntrySize NS_SWIFT_NAME(setClientFileEntrySize(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntrySupportsExclusiveLock,setter=setClientFileEntrySupportsExclusiveLock:) BOOL clientFileEntrySupportsExclusiveLock NS_SWIFT_NAME(clientFileEntrySupportsExclusiveLock);

- (BOOL)clientFileEntrySupportsExclusiveLock NS_SWIFT_NAME(clientFileEntrySupportsExclusiveLock());
- (void)setClientFileEntrySupportsExclusiveLock :(BOOL)newClientFileEntrySupportsExclusiveLock NS_SWIFT_NAME(setClientFileEntrySupportsExclusiveLock(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntrySupportsSharedLock,setter=setClientFileEntrySupportsSharedLock:) BOOL clientFileEntrySupportsSharedLock NS_SWIFT_NAME(clientFileEntrySupportsSharedLock);

- (BOOL)clientFileEntrySupportsSharedLock NS_SWIFT_NAME(clientFileEntrySupportsSharedLock());
- (void)setClientFileEntrySupportsSharedLock :(BOOL)newClientFileEntrySupportsSharedLock NS_SWIFT_NAME(setClientFileEntrySupportsSharedLock(_:));

@property (nonatomic,readwrite,assign,getter=clientFileEntryURL,setter=setClientFileEntryURL:) NSString* clientFileEntryURL NS_SWIFT_NAME(clientFileEntryURL);

- (NSString*)clientFileEntryURL NS_SWIFT_NAME(clientFileEntryURL());
- (void)setClientFileEntryURL :(NSString*)newClientFileEntryURL NS_SWIFT_NAME(setClientFileEntryURL(_:));

@property (nonatomic,readwrite,assign,getter=documentRoot,setter=setDocumentRoot:) NSString* documentRoot NS_SWIFT_NAME(documentRoot);

- (NSString*)documentRoot NS_SWIFT_NAME(documentRoot());
- (void)setDocumentRoot :(NSString*)newDocumentRoot NS_SWIFT_NAME(setDocumentRoot(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoAsyncDocumentID,setter=setExternalCryptoAsyncDocumentID:) NSString* externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID);

- (NSString*)externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID());
- (void)setExternalCryptoAsyncDocumentID :(NSString*)newExternalCryptoAsyncDocumentID NS_SWIFT_NAME(setExternalCryptoAsyncDocumentID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoCustomParams,setter=setExternalCryptoCustomParams:) NSString* externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams);

- (NSString*)externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams());
- (void)setExternalCryptoCustomParams :(NSString*)newExternalCryptoCustomParams NS_SWIFT_NAME(setExternalCryptoCustomParams(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoData,setter=setExternalCryptoData:) NSString* externalCryptoData NS_SWIFT_NAME(externalCryptoData);

- (NSString*)externalCryptoData NS_SWIFT_NAME(externalCryptoData());
- (void)setExternalCryptoData :(NSString*)newExternalCryptoData NS_SWIFT_NAME(setExternalCryptoData(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoExternalHashCalculation,setter=setExternalCryptoExternalHashCalculation:) BOOL externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation);

- (BOOL)externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation());
- (void)setExternalCryptoExternalHashCalculation :(BOOL)newExternalCryptoExternalHashCalculation NS_SWIFT_NAME(setExternalCryptoExternalHashCalculation(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoHashAlgorithm,setter=setExternalCryptoHashAlgorithm:) NSString* externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm);

- (NSString*)externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm());
- (void)setExternalCryptoHashAlgorithm :(NSString*)newExternalCryptoHashAlgorithm NS_SWIFT_NAME(setExternalCryptoHashAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeyID,setter=setExternalCryptoKeyID:) NSString* externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID);

- (NSString*)externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID());
- (void)setExternalCryptoKeyID :(NSString*)newExternalCryptoKeyID NS_SWIFT_NAME(setExternalCryptoKeyID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeySecret,setter=setExternalCryptoKeySecret:) NSString* externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret);

- (NSString*)externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret());
- (void)setExternalCryptoKeySecret :(NSString*)newExternalCryptoKeySecret NS_SWIFT_NAME(setExternalCryptoKeySecret(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMethod,setter=setExternalCryptoMethod:) int externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod);

- (int)externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod());
- (void)setExternalCryptoMethod :(int)newExternalCryptoMethod NS_SWIFT_NAME(setExternalCryptoMethod(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMode,setter=setExternalCryptoMode:) int externalCryptoMode NS_SWIFT_NAME(externalCryptoMode);

- (int)externalCryptoMode NS_SWIFT_NAME(externalCryptoMode());
- (void)setExternalCryptoMode :(int)newExternalCryptoMode NS_SWIFT_NAME(setExternalCryptoMode(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoPublicKeyAlgorithm,setter=setExternalCryptoPublicKeyAlgorithm:) NSString* externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm);

- (NSString*)externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm());
- (void)setExternalCryptoPublicKeyAlgorithm :(NSString*)newExternalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(setExternalCryptoPublicKeyAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=host,setter=setHost:) NSString* host NS_SWIFT_NAME(host);

- (NSString*)host NS_SWIFT_NAME(host());
- (void)setHost :(NSString*)newHost NS_SWIFT_NAME(setHost(_:));

@property (nonatomic,readwrite,assign,getter=metadataFlushTimeout,setter=setMetadataFlushTimeout:) int metadataFlushTimeout NS_SWIFT_NAME(metadataFlushTimeout);

- (int)metadataFlushTimeout NS_SWIFT_NAME(metadataFlushTimeout());
- (void)setMetadataFlushTimeout :(int)newMetadataFlushTimeout NS_SWIFT_NAME(setMetadataFlushTimeout(_:));

@property (nonatomic,readwrite,assign,getter=metadataRoot,setter=setMetadataRoot:) NSString* metadataRoot NS_SWIFT_NAME(metadataRoot);

- (NSString*)metadataRoot NS_SWIFT_NAME(metadataRoot());
- (void)setMetadataRoot :(NSString*)newMetadataRoot NS_SWIFT_NAME(setMetadataRoot(_:));

@property (nonatomic,readonly,assign,getter=pinnedClientAEADCipher) BOOL pinnedClientAEADCipher NS_SWIFT_NAME(pinnedClientAEADCipher);

- (BOOL)pinnedClientAEADCipher NS_SWIFT_NAME(pinnedClientAEADCipher());

@property (nonatomic,readonly,assign,getter=pinnedClientChainValidationDetails) int pinnedClientChainValidationDetails NS_SWIFT_NAME(pinnedClientChainValidationDetails);

- (int)pinnedClientChainValidationDetails NS_SWIFT_NAME(pinnedClientChainValidationDetails());

@property (nonatomic,readonly,assign,getter=pinnedClientChainValidationResult) int pinnedClientChainValidationResult NS_SWIFT_NAME(pinnedClientChainValidationResult);

- (int)pinnedClientChainValidationResult NS_SWIFT_NAME(pinnedClientChainValidationResult());

@property (nonatomic,readonly,assign,getter=pinnedClientCiphersuite) NSString* pinnedClientCiphersuite NS_SWIFT_NAME(pinnedClientCiphersuite);

- (NSString*)pinnedClientCiphersuite NS_SWIFT_NAME(pinnedClientCiphersuite());

@property (nonatomic,readonly,assign,getter=pinnedClientClientAuthenticated) BOOL pinnedClientClientAuthenticated NS_SWIFT_NAME(pinnedClientClientAuthenticated);

- (BOOL)pinnedClientClientAuthenticated NS_SWIFT_NAME(pinnedClientClientAuthenticated());

@property (nonatomic,readonly,assign,getter=pinnedClientClientAuthRequested) BOOL pinnedClientClientAuthRequested NS_SWIFT_NAME(pinnedClientClientAuthRequested);

- (BOOL)pinnedClientClientAuthRequested NS_SWIFT_NAME(pinnedClientClientAuthRequested());

@property (nonatomic,readonly,assign,getter=pinnedClientConnectionEstablished) BOOL pinnedClientConnectionEstablished NS_SWIFT_NAME(pinnedClientConnectionEstablished);

- (BOOL)pinnedClientConnectionEstablished NS_SWIFT_NAME(pinnedClientConnectionEstablished());

@property (nonatomic,readonly,assign,getter=pinnedClientConnectionID) NSData* pinnedClientConnectionID NS_SWIFT_NAME(pinnedClientConnectionID);

- (NSData*)pinnedClientConnectionID NS_SWIFT_NAME(pinnedClientConnectionID());

@property (nonatomic,readonly,assign,getter=pinnedClientDigestAlgorithm) NSString* pinnedClientDigestAlgorithm NS_SWIFT_NAME(pinnedClientDigestAlgorithm);

- (NSString*)pinnedClientDigestAlgorithm NS_SWIFT_NAME(pinnedClientDigestAlgorithm());

@property (nonatomic,readonly,assign,getter=pinnedClientEncryptionAlgorithm) NSString* pinnedClientEncryptionAlgorithm NS_SWIFT_NAME(pinnedClientEncryptionAlgorithm);

- (NSString*)pinnedClientEncryptionAlgorithm NS_SWIFT_NAME(pinnedClientEncryptionAlgorithm());

@property (nonatomic,readonly,assign,getter=pinnedClientExportable) BOOL pinnedClientExportable NS_SWIFT_NAME(pinnedClientExportable);

- (BOOL)pinnedClientExportable NS_SWIFT_NAME(pinnedClientExportable());

@property (nonatomic,readonly,assign,getter=pinnedClientID) long long pinnedClientID NS_SWIFT_NAME(pinnedClientID);

- (long long)pinnedClientID NS_SWIFT_NAME(pinnedClientID());

@property (nonatomic,readonly,assign,getter=pinnedClientKeyExchangeAlgorithm) NSString* pinnedClientKeyExchangeAlgorithm NS_SWIFT_NAME(pinnedClientKeyExchangeAlgorithm);

- (NSString*)pinnedClientKeyExchangeAlgorithm NS_SWIFT_NAME(pinnedClientKeyExchangeAlgorithm());

@property (nonatomic,readonly,assign,getter=pinnedClientKeyExchangeKeyBits) int pinnedClientKeyExchangeKeyBits NS_SWIFT_NAME(pinnedClientKeyExchangeKeyBits);

- (int)pinnedClientKeyExchangeKeyBits NS_SWIFT_NAME(pinnedClientKeyExchangeKeyBits());

@property (nonatomic,readonly,assign,getter=pinnedClientNamedECCurve) NSString* pinnedClientNamedECCurve NS_SWIFT_NAME(pinnedClientNamedECCurve);

- (NSString*)pinnedClientNamedECCurve NS_SWIFT_NAME(pinnedClientNamedECCurve());

@property (nonatomic,readonly,assign,getter=pinnedClientPFSCipher) BOOL pinnedClientPFSCipher NS_SWIFT_NAME(pinnedClientPFSCipher);

- (BOOL)pinnedClientPFSCipher NS_SWIFT_NAME(pinnedClientPFSCipher());

@property (nonatomic,readonly,assign,getter=pinnedClientPreSharedIdentity) NSString* pinnedClientPreSharedIdentity NS_SWIFT_NAME(pinnedClientPreSharedIdentity);

- (NSString*)pinnedClientPreSharedIdentity NS_SWIFT_NAME(pinnedClientPreSharedIdentity());

@property (nonatomic,readonly,assign,getter=pinnedClientPreSharedIdentityHint) NSString* pinnedClientPreSharedIdentityHint NS_SWIFT_NAME(pinnedClientPreSharedIdentityHint);

- (NSString*)pinnedClientPreSharedIdentityHint NS_SWIFT_NAME(pinnedClientPreSharedIdentityHint());

@property (nonatomic,readonly,assign,getter=pinnedClientPublicKeyBits) int pinnedClientPublicKeyBits NS_SWIFT_NAME(pinnedClientPublicKeyBits);

- (int)pinnedClientPublicKeyBits NS_SWIFT_NAME(pinnedClientPublicKeyBits());

@property (nonatomic,readonly,assign,getter=pinnedClientRemoteAddress) NSString* pinnedClientRemoteAddress NS_SWIFT_NAME(pinnedClientRemoteAddress);

- (NSString*)pinnedClientRemoteAddress NS_SWIFT_NAME(pinnedClientRemoteAddress());

@property (nonatomic,readonly,assign,getter=pinnedClientRemotePort) int pinnedClientRemotePort NS_SWIFT_NAME(pinnedClientRemotePort);

- (int)pinnedClientRemotePort NS_SWIFT_NAME(pinnedClientRemotePort());

@property (nonatomic,readonly,assign,getter=pinnedClientResumedSession) BOOL pinnedClientResumedSession NS_SWIFT_NAME(pinnedClientResumedSession);

- (BOOL)pinnedClientResumedSession NS_SWIFT_NAME(pinnedClientResumedSession());

@property (nonatomic,readonly,assign,getter=pinnedClientSecureConnection) BOOL pinnedClientSecureConnection NS_SWIFT_NAME(pinnedClientSecureConnection);

- (BOOL)pinnedClientSecureConnection NS_SWIFT_NAME(pinnedClientSecureConnection());

@property (nonatomic,readonly,assign,getter=pinnedClientServerAuthenticated) BOOL pinnedClientServerAuthenticated NS_SWIFT_NAME(pinnedClientServerAuthenticated);

- (BOOL)pinnedClientServerAuthenticated NS_SWIFT_NAME(pinnedClientServerAuthenticated());

@property (nonatomic,readonly,assign,getter=pinnedClientSignatureAlgorithm) NSString* pinnedClientSignatureAlgorithm NS_SWIFT_NAME(pinnedClientSignatureAlgorithm);

- (NSString*)pinnedClientSignatureAlgorithm NS_SWIFT_NAME(pinnedClientSignatureAlgorithm());

@property (nonatomic,readonly,assign,getter=pinnedClientSymmetricBlockSize) int pinnedClientSymmetricBlockSize NS_SWIFT_NAME(pinnedClientSymmetricBlockSize);

- (int)pinnedClientSymmetricBlockSize NS_SWIFT_NAME(pinnedClientSymmetricBlockSize());

@property (nonatomic,readonly,assign,getter=pinnedClientSymmetricKeyBits) int pinnedClientSymmetricKeyBits NS_SWIFT_NAME(pinnedClientSymmetricKeyBits);

- (int)pinnedClientSymmetricKeyBits NS_SWIFT_NAME(pinnedClientSymmetricKeyBits());

@property (nonatomic,readonly,assign,getter=pinnedClientTotalBytesReceived) long long pinnedClientTotalBytesReceived NS_SWIFT_NAME(pinnedClientTotalBytesReceived);

- (long long)pinnedClientTotalBytesReceived NS_SWIFT_NAME(pinnedClientTotalBytesReceived());

@property (nonatomic,readonly,assign,getter=pinnedClientTotalBytesSent) long long pinnedClientTotalBytesSent NS_SWIFT_NAME(pinnedClientTotalBytesSent);

- (long long)pinnedClientTotalBytesSent NS_SWIFT_NAME(pinnedClientTotalBytesSent());

@property (nonatomic,readonly,assign,getter=pinnedClientValidationLog) NSString* pinnedClientValidationLog NS_SWIFT_NAME(pinnedClientValidationLog);

- (NSString*)pinnedClientValidationLog NS_SWIFT_NAME(pinnedClientValidationLog());

@property (nonatomic,readonly,assign,getter=pinnedClientVersion) NSString* pinnedClientVersion NS_SWIFT_NAME(pinnedClientVersion);

- (NSString*)pinnedClientVersion NS_SWIFT_NAME(pinnedClientVersion());

@property (nonatomic,readonly,assign,getter=pinnedClientCertCount) int pinnedClientCertCount NS_SWIFT_NAME(pinnedClientCertCount);

- (int)pinnedClientCertCount NS_SWIFT_NAME(pinnedClientCertCount());

- (NSData*)pinnedClientCertBytes:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertBytes(_:));

- (BOOL)pinnedClientCertCA:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertCA(_:));

- (NSData*)pinnedClientCertCAKeyID:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertCAKeyID(_:));

- (int)pinnedClientCertCertType:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertCertType(_:));

- (NSString*)pinnedClientCertCRLDistributionPoints:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertCRLDistributionPoints(_:));

- (NSString*)pinnedClientCertCurve:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertCurve(_:));

- (NSString*)pinnedClientCertFingerprint:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertFingerprint(_:));

- (NSString*)pinnedClientCertFriendlyName:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertFriendlyName(_:));

- (long long)pinnedClientCertHandle:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertHandle(_:));

- (NSString*)pinnedClientCertHashAlgorithm:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertHashAlgorithm(_:));

- (NSString*)pinnedClientCertIssuer:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertIssuer(_:));

- (NSString*)pinnedClientCertIssuerRDN:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertIssuerRDN(_:));

- (NSString*)pinnedClientCertKeyAlgorithm:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertKeyAlgorithm(_:));

- (int)pinnedClientCertKeyBits:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertKeyBits(_:));

- (NSString*)pinnedClientCertKeyFingerprint:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertKeyFingerprint(_:));

- (int)pinnedClientCertKeyUsage:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertKeyUsage(_:));

- (BOOL)pinnedClientCertKeyValid:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertKeyValid(_:));

- (NSString*)pinnedClientCertOCSPLocations:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertOCSPLocations(_:));

- (BOOL)pinnedClientCertOCSPNoCheck:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertOCSPNoCheck(_:));

- (int)pinnedClientCertOrigin:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertOrigin(_:));

- (NSString*)pinnedClientCertPolicyIDs:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertPolicyIDs(_:));

- (NSData*)pinnedClientCertPrivateKeyBytes:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertPrivateKeyBytes(_:));

- (BOOL)pinnedClientCertPrivateKeyExists:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertPrivateKeyExists(_:));

- (BOOL)pinnedClientCertPrivateKeyExtractable:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertPrivateKeyExtractable(_:));

- (NSData*)pinnedClientCertPublicKeyBytes:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertPublicKeyBytes(_:));

- (BOOL)pinnedClientCertQualified:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertQualified(_:));

- (int)pinnedClientCertQualifiedStatements:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertQualifiedStatements(_:));

- (NSString*)pinnedClientCertQualifiers:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertQualifiers(_:));

- (BOOL)pinnedClientCertSelfSigned:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSelfSigned(_:));

- (NSData*)pinnedClientCertSerialNumber:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSerialNumber(_:));

- (NSString*)pinnedClientCertSigAlgorithm:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSigAlgorithm(_:));

- (int)pinnedClientCertSource:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSource(_:));

- (NSString*)pinnedClientCertSubject:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSubject(_:));

- (NSString*)pinnedClientCertSubjectAlternativeName:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSubjectAlternativeName(_:));

- (NSData*)pinnedClientCertSubjectKeyID:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSubjectKeyID(_:));

- (NSString*)pinnedClientCertSubjectRDN:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSubjectRDN(_:));

- (BOOL)pinnedClientCertValid:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertValid(_:));

- (NSString*)pinnedClientCertValidFrom:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertValidFrom(_:));

- (NSString*)pinnedClientCertValidTo:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertValidTo(_:));

@property (nonatomic,readwrite,assign,getter=port,setter=setPort:) int port NS_SWIFT_NAME(port);

- (int)port NS_SWIFT_NAME(port());
- (void)setPort :(int)newPort NS_SWIFT_NAME(setPort(_:));

@property (nonatomic,readwrite,assign,getter=portRangeFrom,setter=setPortRangeFrom:) int portRangeFrom NS_SWIFT_NAME(portRangeFrom);

- (int)portRangeFrom NS_SWIFT_NAME(portRangeFrom());
- (void)setPortRangeFrom :(int)newPortRangeFrom NS_SWIFT_NAME(setPortRangeFrom(_:));

@property (nonatomic,readwrite,assign,getter=portRangeTo,setter=setPortRangeTo:) int portRangeTo NS_SWIFT_NAME(portRangeTo);

- (int)portRangeTo NS_SWIFT_NAME(portRangeTo());
- (void)setPortRangeTo :(int)newPortRangeTo NS_SWIFT_NAME(setPortRangeTo(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSMode,setter=setSocketDNSMode:) int socketDNSMode NS_SWIFT_NAME(socketDNSMode);

- (int)socketDNSMode NS_SWIFT_NAME(socketDNSMode());
- (void)setSocketDNSMode :(int)newSocketDNSMode NS_SWIFT_NAME(setSocketDNSMode(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSPort,setter=setSocketDNSPort:) int socketDNSPort NS_SWIFT_NAME(socketDNSPort);

- (int)socketDNSPort NS_SWIFT_NAME(socketDNSPort());
- (void)setSocketDNSPort :(int)newSocketDNSPort NS_SWIFT_NAME(setSocketDNSPort(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSQueryTimeout,setter=setSocketDNSQueryTimeout:) int socketDNSQueryTimeout NS_SWIFT_NAME(socketDNSQueryTimeout);

- (int)socketDNSQueryTimeout NS_SWIFT_NAME(socketDNSQueryTimeout());
- (void)setSocketDNSQueryTimeout :(int)newSocketDNSQueryTimeout NS_SWIFT_NAME(setSocketDNSQueryTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSServers,setter=setSocketDNSServers:) NSString* socketDNSServers NS_SWIFT_NAME(socketDNSServers);

- (NSString*)socketDNSServers NS_SWIFT_NAME(socketDNSServers());
- (void)setSocketDNSServers :(NSString*)newSocketDNSServers NS_SWIFT_NAME(setSocketDNSServers(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSTotalTimeout,setter=setSocketDNSTotalTimeout:) int socketDNSTotalTimeout NS_SWIFT_NAME(socketDNSTotalTimeout);

- (int)socketDNSTotalTimeout NS_SWIFT_NAME(socketDNSTotalTimeout());
- (void)setSocketDNSTotalTimeout :(int)newSocketDNSTotalTimeout NS_SWIFT_NAME(setSocketDNSTotalTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketIncomingSpeedLimit,setter=setSocketIncomingSpeedLimit:) int socketIncomingSpeedLimit NS_SWIFT_NAME(socketIncomingSpeedLimit);

- (int)socketIncomingSpeedLimit NS_SWIFT_NAME(socketIncomingSpeedLimit());
- (void)setSocketIncomingSpeedLimit :(int)newSocketIncomingSpeedLimit NS_SWIFT_NAME(setSocketIncomingSpeedLimit(_:));

@property (nonatomic,readwrite,assign,getter=socketLocalAddress,setter=setSocketLocalAddress:) NSString* socketLocalAddress NS_SWIFT_NAME(socketLocalAddress);

- (NSString*)socketLocalAddress NS_SWIFT_NAME(socketLocalAddress());
- (void)setSocketLocalAddress :(NSString*)newSocketLocalAddress NS_SWIFT_NAME(setSocketLocalAddress(_:));

@property (nonatomic,readwrite,assign,getter=socketLocalPort,setter=setSocketLocalPort:) int socketLocalPort NS_SWIFT_NAME(socketLocalPort);

- (int)socketLocalPort NS_SWIFT_NAME(socketLocalPort());
- (void)setSocketLocalPort :(int)newSocketLocalPort NS_SWIFT_NAME(setSocketLocalPort(_:));

@property (nonatomic,readwrite,assign,getter=socketOutgoingSpeedLimit,setter=setSocketOutgoingSpeedLimit:) int socketOutgoingSpeedLimit NS_SWIFT_NAME(socketOutgoingSpeedLimit);

- (int)socketOutgoingSpeedLimit NS_SWIFT_NAME(socketOutgoingSpeedLimit());
- (void)setSocketOutgoingSpeedLimit :(int)newSocketOutgoingSpeedLimit NS_SWIFT_NAME(setSocketOutgoingSpeedLimit(_:));

@property (nonatomic,readwrite,assign,getter=socketTimeout,setter=setSocketTimeout:) int socketTimeout NS_SWIFT_NAME(socketTimeout);

- (int)socketTimeout NS_SWIFT_NAME(socketTimeout());
- (void)setSocketTimeout :(int)newSocketTimeout NS_SWIFT_NAME(setSocketTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketUseIPv6,setter=setSocketUseIPv6:) BOOL socketUseIPv6 NS_SWIFT_NAME(socketUseIPv6);

- (BOOL)socketUseIPv6 NS_SWIFT_NAME(socketUseIPv6());
- (void)setSocketUseIPv6 :(BOOL)newSocketUseIPv6 NS_SWIFT_NAME(setSocketUseIPv6(_:));

@property (nonatomic,readwrite,assign,getter=TLSServerCertCount,setter=setTLSServerCertCount:) int TLSServerCertCount NS_SWIFT_NAME(TLSServerCertCount);

- (int)TLSServerCertCount NS_SWIFT_NAME(TLSServerCertCount());
- (void)setTLSServerCertCount :(int)newTLSServerCertCount NS_SWIFT_NAME(setTLSServerCertCount(_:));

- (NSData*)TLSServerCertBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertBytes(_:));

- (BOOL)TLSServerCertCA:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCA(_:));
- (void)setTLSServerCertCA:(int)tLSServerCertIndex :(BOOL)newTLSServerCertCA NS_SWIFT_NAME(setTLSServerCertCA(_:_:));

- (NSData*)TLSServerCertCAKeyID:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCAKeyID(_:));

- (int)TLSServerCertCertType:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCertType(_:));

- (NSString*)TLSServerCertCRLDistributionPoints:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCRLDistributionPoints(_:));
- (void)setTLSServerCertCRLDistributionPoints:(int)tLSServerCertIndex :(NSString*)newTLSServerCertCRLDistributionPoints NS_SWIFT_NAME(setTLSServerCertCRLDistributionPoints(_:_:));

- (NSString*)TLSServerCertCurve:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCurve(_:));
- (void)setTLSServerCertCurve:(int)tLSServerCertIndex :(NSString*)newTLSServerCertCurve NS_SWIFT_NAME(setTLSServerCertCurve(_:_:));

- (NSString*)TLSServerCertFingerprint:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertFingerprint(_:));

- (NSString*)TLSServerCertFriendlyName:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertFriendlyName(_:));

- (long long)TLSServerCertHandle:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertHandle(_:));
- (void)setTLSServerCertHandle:(int)tLSServerCertIndex :(long long)newTLSServerCertHandle NS_SWIFT_NAME(setTLSServerCertHandle(_:_:));

- (NSString*)TLSServerCertHashAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertHashAlgorithm(_:));
- (void)setTLSServerCertHashAlgorithm:(int)tLSServerCertIndex :(NSString*)newTLSServerCertHashAlgorithm NS_SWIFT_NAME(setTLSServerCertHashAlgorithm(_:_:));

- (NSString*)TLSServerCertIssuer:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertIssuer(_:));

- (NSString*)TLSServerCertIssuerRDN:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertIssuerRDN(_:));
- (void)setTLSServerCertIssuerRDN:(int)tLSServerCertIndex :(NSString*)newTLSServerCertIssuerRDN NS_SWIFT_NAME(setTLSServerCertIssuerRDN(_:_:));

- (NSString*)TLSServerCertKeyAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyAlgorithm(_:));
- (void)setTLSServerCertKeyAlgorithm:(int)tLSServerCertIndex :(NSString*)newTLSServerCertKeyAlgorithm NS_SWIFT_NAME(setTLSServerCertKeyAlgorithm(_:_:));

- (int)TLSServerCertKeyBits:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyBits(_:));

- (NSString*)TLSServerCertKeyFingerprint:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyFingerprint(_:));

- (int)TLSServerCertKeyUsage:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyUsage(_:));
- (void)setTLSServerCertKeyUsage:(int)tLSServerCertIndex :(int)newTLSServerCertKeyUsage NS_SWIFT_NAME(setTLSServerCertKeyUsage(_:_:));

- (BOOL)TLSServerCertKeyValid:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyValid(_:));

- (NSString*)TLSServerCertOCSPLocations:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOCSPLocations(_:));
- (void)setTLSServerCertOCSPLocations:(int)tLSServerCertIndex :(NSString*)newTLSServerCertOCSPLocations NS_SWIFT_NAME(setTLSServerCertOCSPLocations(_:_:));

- (BOOL)TLSServerCertOCSPNoCheck:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOCSPNoCheck(_:));
- (void)setTLSServerCertOCSPNoCheck:(int)tLSServerCertIndex :(BOOL)newTLSServerCertOCSPNoCheck NS_SWIFT_NAME(setTLSServerCertOCSPNoCheck(_:_:));

- (int)TLSServerCertOrigin:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOrigin(_:));

- (NSString*)TLSServerCertPolicyIDs:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPolicyIDs(_:));
- (void)setTLSServerCertPolicyIDs:(int)tLSServerCertIndex :(NSString*)newTLSServerCertPolicyIDs NS_SWIFT_NAME(setTLSServerCertPolicyIDs(_:_:));

- (NSData*)TLSServerCertPrivateKeyBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyBytes(_:));

- (BOOL)TLSServerCertPrivateKeyExists:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyExists(_:));

- (BOOL)TLSServerCertPrivateKeyExtractable:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyExtractable(_:));

- (NSData*)TLSServerCertPublicKeyBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPublicKeyBytes(_:));

- (BOOL)TLSServerCertQualified:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualified(_:));

- (int)TLSServerCertQualifiedStatements:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualifiedStatements(_:));
- (void)setTLSServerCertQualifiedStatements:(int)tLSServerCertIndex :(int)newTLSServerCertQualifiedStatements NS_SWIFT_NAME(setTLSServerCertQualifiedStatements(_:_:));

- (NSString*)TLSServerCertQualifiers:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualifiers(_:));

- (BOOL)TLSServerCertSelfSigned:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSelfSigned(_:));

- (NSData*)TLSServerCertSerialNumber:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSerialNumber(_:));
- (void)setTLSServerCertSerialNumber:(int)tLSServerCertIndex :(NSData*)newTLSServerCertSerialNumber NS_SWIFT_NAME(setTLSServerCertSerialNumber(_:_:));

- (NSString*)TLSServerCertSigAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSigAlgorithm(_:));

- (int)TLSServerCertSource:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSource(_:));

- (NSString*)TLSServerCertSubject:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubject(_:));

- (NSString*)TLSServerCertSubjectAlternativeName:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectAlternativeName(_:));
- (void)setTLSServerCertSubjectAlternativeName:(int)tLSServerCertIndex :(NSString*)newTLSServerCertSubjectAlternativeName NS_SWIFT_NAME(setTLSServerCertSubjectAlternativeName(_:_:));

- (NSData*)TLSServerCertSubjectKeyID:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectKeyID(_:));
- (void)setTLSServerCertSubjectKeyID:(int)tLSServerCertIndex :(NSData*)newTLSServerCertSubjectKeyID NS_SWIFT_NAME(setTLSServerCertSubjectKeyID(_:_:));

- (NSString*)TLSServerCertSubjectRDN:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectRDN(_:));
- (void)setTLSServerCertSubjectRDN:(int)tLSServerCertIndex :(NSString*)newTLSServerCertSubjectRDN NS_SWIFT_NAME(setTLSServerCertSubjectRDN(_:_:));

- (BOOL)TLSServerCertValid:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValid(_:));

- (NSString*)TLSServerCertValidFrom:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValidFrom(_:));
- (void)setTLSServerCertValidFrom:(int)tLSServerCertIndex :(NSString*)newTLSServerCertValidFrom NS_SWIFT_NAME(setTLSServerCertValidFrom(_:_:));

- (NSString*)TLSServerCertValidTo:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValidTo(_:));
- (void)setTLSServerCertValidTo:(int)tLSServerCertIndex :(NSString*)newTLSServerCertValidTo NS_SWIFT_NAME(setTLSServerCertValidTo(_:_:));

@property (nonatomic,readwrite,assign,getter=TLSAutoValidateCertificates,setter=setTLSAutoValidateCertificates:) BOOL TLSAutoValidateCertificates NS_SWIFT_NAME(TLSAutoValidateCertificates);

- (BOOL)TLSAutoValidateCertificates NS_SWIFT_NAME(TLSAutoValidateCertificates());
- (void)setTLSAutoValidateCertificates :(BOOL)newTLSAutoValidateCertificates NS_SWIFT_NAME(setTLSAutoValidateCertificates(_:));

@property (nonatomic,readwrite,assign,getter=TLSBaseConfiguration,setter=setTLSBaseConfiguration:) int TLSBaseConfiguration NS_SWIFT_NAME(TLSBaseConfiguration);

- (int)TLSBaseConfiguration NS_SWIFT_NAME(TLSBaseConfiguration());
- (void)setTLSBaseConfiguration :(int)newTLSBaseConfiguration NS_SWIFT_NAME(setTLSBaseConfiguration(_:));

@property (nonatomic,readwrite,assign,getter=TLSCiphersuites,setter=setTLSCiphersuites:) NSString* TLSCiphersuites NS_SWIFT_NAME(TLSCiphersuites);

- (NSString*)TLSCiphersuites NS_SWIFT_NAME(TLSCiphersuites());
- (void)setTLSCiphersuites :(NSString*)newTLSCiphersuites NS_SWIFT_NAME(setTLSCiphersuites(_:));

@property (nonatomic,readwrite,assign,getter=TLSClientAuth,setter=setTLSClientAuth:) int TLSClientAuth NS_SWIFT_NAME(TLSClientAuth);

- (int)TLSClientAuth NS_SWIFT_NAME(TLSClientAuth());
- (void)setTLSClientAuth :(int)newTLSClientAuth NS_SWIFT_NAME(setTLSClientAuth(_:));

@property (nonatomic,readwrite,assign,getter=TLSECCurves,setter=setTLSECCurves:) NSString* TLSECCurves NS_SWIFT_NAME(TLSECCurves);

- (NSString*)TLSECCurves NS_SWIFT_NAME(TLSECCurves());
- (void)setTLSECCurves :(NSString*)newTLSECCurves NS_SWIFT_NAME(setTLSECCurves(_:));

@property (nonatomic,readwrite,assign,getter=TLSExtensions,setter=setTLSExtensions:) NSString* TLSExtensions NS_SWIFT_NAME(TLSExtensions);

- (NSString*)TLSExtensions NS_SWIFT_NAME(TLSExtensions());
- (void)setTLSExtensions :(NSString*)newTLSExtensions NS_SWIFT_NAME(setTLSExtensions(_:));

@property (nonatomic,readwrite,assign,getter=TLSForceResumeIfDestinationChanges,setter=setTLSForceResumeIfDestinationChanges:) BOOL TLSForceResumeIfDestinationChanges NS_SWIFT_NAME(TLSForceResumeIfDestinationChanges);

- (BOOL)TLSForceResumeIfDestinationChanges NS_SWIFT_NAME(TLSForceResumeIfDestinationChanges());
- (void)setTLSForceResumeIfDestinationChanges :(BOOL)newTLSForceResumeIfDestinationChanges NS_SWIFT_NAME(setTLSForceResumeIfDestinationChanges(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedIdentity,setter=setTLSPreSharedIdentity:) NSString* TLSPreSharedIdentity NS_SWIFT_NAME(TLSPreSharedIdentity);

- (NSString*)TLSPreSharedIdentity NS_SWIFT_NAME(TLSPreSharedIdentity());
- (void)setTLSPreSharedIdentity :(NSString*)newTLSPreSharedIdentity NS_SWIFT_NAME(setTLSPreSharedIdentity(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedKey,setter=setTLSPreSharedKey:) NSString* TLSPreSharedKey NS_SWIFT_NAME(TLSPreSharedKey);

- (NSString*)TLSPreSharedKey NS_SWIFT_NAME(TLSPreSharedKey());
- (void)setTLSPreSharedKey :(NSString*)newTLSPreSharedKey NS_SWIFT_NAME(setTLSPreSharedKey(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedKeyCiphersuite,setter=setTLSPreSharedKeyCiphersuite:) NSString* TLSPreSharedKeyCiphersuite NS_SWIFT_NAME(TLSPreSharedKeyCiphersuite);

- (NSString*)TLSPreSharedKeyCiphersuite NS_SWIFT_NAME(TLSPreSharedKeyCiphersuite());
- (void)setTLSPreSharedKeyCiphersuite :(NSString*)newTLSPreSharedKeyCiphersuite NS_SWIFT_NAME(setTLSPreSharedKeyCiphersuite(_:));

@property (nonatomic,readwrite,assign,getter=TLSRenegotiationAttackPreventionMode,setter=setTLSRenegotiationAttackPreventionMode:) int TLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(TLSRenegotiationAttackPreventionMode);

- (int)TLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(TLSRenegotiationAttackPreventionMode());
- (void)setTLSRenegotiationAttackPreventionMode :(int)newTLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(setTLSRenegotiationAttackPreventionMode(_:));

@property (nonatomic,readwrite,assign,getter=TLSRevocationCheck,setter=setTLSRevocationCheck:) int TLSRevocationCheck NS_SWIFT_NAME(TLSRevocationCheck);

- (int)TLSRevocationCheck NS_SWIFT_NAME(TLSRevocationCheck());
- (void)setTLSRevocationCheck :(int)newTLSRevocationCheck NS_SWIFT_NAME(setTLSRevocationCheck(_:));

@property (nonatomic,readwrite,assign,getter=TLSSSLOptions,setter=setTLSSSLOptions:) int TLSSSLOptions NS_SWIFT_NAME(TLSSSLOptions);

- (int)TLSSSLOptions NS_SWIFT_NAME(TLSSSLOptions());
- (void)setTLSSSLOptions :(int)newTLSSSLOptions NS_SWIFT_NAME(setTLSSSLOptions(_:));

@property (nonatomic,readwrite,assign,getter=TLSTLSMode,setter=setTLSTLSMode:) int TLSTLSMode NS_SWIFT_NAME(TLSTLSMode);

- (int)TLSTLSMode NS_SWIFT_NAME(TLSTLSMode());
- (void)setTLSTLSMode :(int)newTLSTLSMode NS_SWIFT_NAME(setTLSTLSMode(_:));

@property (nonatomic,readwrite,assign,getter=TLSUseExtendedMasterSecret,setter=setTLSUseExtendedMasterSecret:) BOOL TLSUseExtendedMasterSecret NS_SWIFT_NAME(TLSUseExtendedMasterSecret);

- (BOOL)TLSUseExtendedMasterSecret NS_SWIFT_NAME(TLSUseExtendedMasterSecret());
- (void)setTLSUseExtendedMasterSecret :(BOOL)newTLSUseExtendedMasterSecret NS_SWIFT_NAME(setTLSUseExtendedMasterSecret(_:));

@property (nonatomic,readwrite,assign,getter=TLSUseSessionResumption,setter=setTLSUseSessionResumption:) BOOL TLSUseSessionResumption NS_SWIFT_NAME(TLSUseSessionResumption);

- (BOOL)TLSUseSessionResumption NS_SWIFT_NAME(TLSUseSessionResumption());
- (void)setTLSUseSessionResumption :(BOOL)newTLSUseSessionResumption NS_SWIFT_NAME(setTLSUseSessionResumption(_:));

@property (nonatomic,readwrite,assign,getter=TLSVersions,setter=setTLSVersions:) int TLSVersions NS_SWIFT_NAME(TLSVersions);

- (int)TLSVersions NS_SWIFT_NAME(TLSVersions());
- (void)setTLSVersions :(int)newTLSVersions NS_SWIFT_NAME(setTLSVersions(_:));

@property (nonatomic,readwrite,assign,getter=userCount,setter=setUserCount:) int userCount NS_SWIFT_NAME(userCount);

- (int)userCount NS_SWIFT_NAME(userCount());
- (void)setUserCount :(int)newUserCount NS_SWIFT_NAME(setUserCount(_:));

- (NSData*)userAssociatedData:(int)userIndex NS_SWIFT_NAME(userAssociatedData(_:));
- (void)setUserAssociatedData:(int)userIndex :(NSData*)newUserAssociatedData NS_SWIFT_NAME(setUserAssociatedData(_:_:));

- (NSString*)userBasePath:(int)userIndex NS_SWIFT_NAME(userBasePath(_:));
- (void)setUserBasePath:(int)userIndex :(NSString*)newUserBasePath NS_SWIFT_NAME(setUserBasePath(_:_:));

- (NSData*)userCertificate:(int)userIndex NS_SWIFT_NAME(userCertificate(_:));
- (void)setUserCertificate:(int)userIndex :(NSData*)newUserCertificate NS_SWIFT_NAME(setUserCertificate(_:_:));

- (NSString*)userData:(int)userIndex NS_SWIFT_NAME(userData(_:));
- (void)setUserData:(int)userIndex :(NSString*)newUserData NS_SWIFT_NAME(setUserData(_:_:));

- (NSString*)userEmail:(int)userIndex NS_SWIFT_NAME(userEmail(_:));
- (void)setUserEmail:(int)userIndex :(NSString*)newUserEmail NS_SWIFT_NAME(setUserEmail(_:_:));

- (long long)userHandle:(int)userIndex NS_SWIFT_NAME(userHandle(_:));
- (void)setUserHandle:(int)userIndex :(long long)newUserHandle NS_SWIFT_NAME(setUserHandle(_:_:));

- (NSString*)userHashAlgorithm:(int)userIndex NS_SWIFT_NAME(userHashAlgorithm(_:));
- (void)setUserHashAlgorithm:(int)userIndex :(NSString*)newUserHashAlgorithm NS_SWIFT_NAME(setUserHashAlgorithm(_:_:));

- (int)userIncomingSpeedLimit:(int)userIndex NS_SWIFT_NAME(userIncomingSpeedLimit(_:));
- (void)setUserIncomingSpeedLimit:(int)userIndex :(int)newUserIncomingSpeedLimit NS_SWIFT_NAME(setUserIncomingSpeedLimit(_:_:));

- (int)userOtpAlgorithm:(int)userIndex NS_SWIFT_NAME(userOtpAlgorithm(_:));
- (void)setUserOtpAlgorithm:(int)userIndex :(int)newUserOtpAlgorithm NS_SWIFT_NAME(setUserOtpAlgorithm(_:_:));

- (int)userOTPLen:(int)userIndex NS_SWIFT_NAME(userOTPLen(_:));
- (void)setUserOTPLen:(int)userIndex :(int)newUserOTPLen NS_SWIFT_NAME(setUserOTPLen(_:_:));

- (int)userOtpValue:(int)userIndex NS_SWIFT_NAME(userOtpValue(_:));
- (void)setUserOtpValue:(int)userIndex :(int)newUserOtpValue NS_SWIFT_NAME(setUserOtpValue(_:_:));

- (int)userOutgoingSpeedLimit:(int)userIndex NS_SWIFT_NAME(userOutgoingSpeedLimit(_:));
- (void)setUserOutgoingSpeedLimit:(int)userIndex :(int)newUserOutgoingSpeedLimit NS_SWIFT_NAME(setUserOutgoingSpeedLimit(_:_:));

- (NSString*)userPassword:(int)userIndex NS_SWIFT_NAME(userPassword(_:));
- (void)setUserPassword:(int)userIndex :(NSString*)newUserPassword NS_SWIFT_NAME(setUserPassword(_:_:));

- (NSData*)userSharedSecret:(int)userIndex NS_SWIFT_NAME(userSharedSecret(_:));
- (void)setUserSharedSecret:(int)userIndex :(NSData*)newUserSharedSecret NS_SWIFT_NAME(setUserSharedSecret(_:_:));

- (NSData*)userSSHKey:(int)userIndex NS_SWIFT_NAME(userSSHKey(_:));
- (void)setUserSSHKey:(int)userIndex :(NSData*)newUserSSHKey NS_SWIFT_NAME(setUserSSHKey(_:_:));

- (NSString*)userUsername:(int)userIndex NS_SWIFT_NAME(userUsername(_:));
- (void)setUserUsername:(int)userIndex :(NSString*)newUserUsername NS_SWIFT_NAME(setUserUsername(_:_:));

@property (nonatomic,readwrite,assign,getter=websiteName,setter=setWebsiteName:) NSString* websiteName NS_SWIFT_NAME(websiteName);

- (NSString*)websiteName NS_SWIFT_NAME(websiteName());
- (void)setWebsiteName :(NSString*)newWebsiteName NS_SWIFT_NAME(setWebsiteName(_:));

  /* Methods */

- (void)cleanup NS_SWIFT_NAME(cleanup());

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (void)dropClient:(long long)connectionId :(BOOL)forced NS_SWIFT_NAME(dropClient(_:_:));

- (NSData*)getClientBuffer:(long long)connectionID NS_SWIFT_NAME(getClientBuffer(_:));

- (NSData*)getRequestBytes:(long long)connectionId :(NSString*)requestFilter NS_SWIFT_NAME(getRequestBytes(_:_:));

- (NSString*)getRequestHeader:(long long)connectionId :(NSString*)headerName NS_SWIFT_NAME(getRequestHeader(_:_:));

- (NSString*)getRequestString:(long long)connectionId :(NSString*)requestFilter NS_SWIFT_NAME(getRequestString(_:_:));

- (NSString*)getRequestUsername:(long long)connectionId NS_SWIFT_NAME(getRequestUsername(_:));

- (NSString*)getResponseHeader:(long long)connectionId :(NSString*)headerName NS_SWIFT_NAME(getResponseHeader(_:_:));

- (NSString*)listClients NS_SWIFT_NAME(listClients());

- (void)pinClient:(long long)connectionId NS_SWIFT_NAME(pinClient(_:));

- (NSData*)processGenericRequest:(long long)connectionId :(NSData*)requestBytes NS_SWIFT_NAME(processGenericRequest(_:_:));

- (void)reset NS_SWIFT_NAME(reset());

- (void)setClientBuffer:(long long)connectionID :(NSData*)value NS_SWIFT_NAME(setClientBuffer(_:_:));

- (void)setClientFileEntry:(long long)connectionID NS_SWIFT_NAME(setClientFileEntry(_:));

- (void)setResponseBytes:(long long)connectionId :(NSData*)bytes :(NSString*)contentType :(NSString*)responseFilter NS_SWIFT_NAME(setResponseBytes(_:_:_:_:));

- (void)setResponseFile:(long long)connectionId :(NSString*)fileName :(NSString*)contentType :(NSString*)responseFilter NS_SWIFT_NAME(setResponseFile(_:_:_:_:));

- (void)setResponseHeader:(long long)connectionId :(NSString*)headerName :(NSString*)value NS_SWIFT_NAME(setResponseHeader(_:_:_:));

- (void)setResponseStatus:(long long)connectionId :(int)statusCode NS_SWIFT_NAME(setResponseStatus(_:_:));

- (void)setResponseString:(long long)connectionId :(NSString*)dataStr :(NSString*)contentType :(NSString*)responseFilter NS_SWIFT_NAME(setResponseString(_:_:_:_:));

- (void)start NS_SWIFT_NAME(start());

- (void)stop NS_SWIFT_NAME(stop());

@end

