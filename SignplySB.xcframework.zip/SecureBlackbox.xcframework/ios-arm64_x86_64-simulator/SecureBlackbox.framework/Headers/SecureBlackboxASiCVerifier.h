/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

//ASICEXTRACTIONMODES
#define AEM_NONE                                           0

#define AEM_ALL                                            1

#define AEM_SIGNED                                         2

#define AEM_SIGNED_AND_VALID                               3

//ACTIONS
#define AT_ADD                                             0

#define AT_KEEP                                            1

#define AT_UPDATE                                          2

#define AT_DELETE                                          3

#define AT_EXTRACT                                         4

#define AT_SKIP                                            5

//FILEDATASOURCES
#define FDS_FILE                                           0

#define FDS_STREAM                                         1

#define FDS_BUFFER                                         2

//ENCRYPTIONTYPES
#define AET_DEFAULT                                        0

#define AET_NO_ENCRYPTION                                  1

#define AET_GENERIC                                        2

#define AET_WIN_ZIP                                        3

#define AET_STRONG                                         4

//PROXYAUTHTYPES
#define PAT_NO_AUTHENTICATION                              0

#define PAT_BASIC                                          1

#define PAT_DIGEST                                         2

#define PAT_NTLM                                           3

//PROXYTYPES
#define CPT_NONE                                           0

#define CPT_SOCKS_4                                        1

#define CPT_SOCKS_5                                        2

#define CPT_WEB_TUNNEL                                     3

#define CPT_HTTP                                           4

//REVOCATIONCHECKKINDS
#define CRC_NONE                                           0

#define CRC_AUTO                                           1

#define CRC_ALL_CRL                                        2

#define CRC_ALL_OCSP                                       3

#define CRC_ALL_CRLAND_OCSP                                4

#define CRC_ANY_CRL                                        5

#define CRC_ANY_OCSP                                       6

#define CRC_ANY_CRLOR_OCSP                                 7

#define CRC_ANY_OCSPOR_CRL                                 8

//CHAINVALIDITIES
#define CVT_VALID                                          0

#define CVT_VALID_BUT_UNTRUSTED                            1

#define CVT_INVALID                                        2

#define CVT_CANT_BE_ESTABLISHED                            3

//ADESSIGNATURELEVELS
#define ASL_UNKNOWN                                        0

#define ASL_GENERIC                                        1

#define ASL_BASELINE_B                                     2

#define ASL_BASELINE_T                                     3

#define ASL_BASELINE_LT                                    4

#define ASL_BASELINE_LTA                                   5

#define ASL_BES                                            6

#define ASL_EPES                                           7

#define ASL_T                                              8

#define ASL_C                                              9

#define ASL_X                                              10

#define ASL_XTYPE_1                                        11

#define ASL_XTYPE_2                                        12

#define ASL_XL                                             13

#define ASL_XLTYPE_1                                       14

#define ASL_XLTYPE_2                                       15

#define ASL_A                                              16

#define ASL_EXTENDED_BES                                   17

#define ASL_EXTENDED_EPES                                  18

#define ASL_EXTENDED_T                                     19

#define ASL_EXTENDED_C                                     20

#define ASL_EXTENDED_X                                     21

#define ASL_EXTENDED_XTYPE_1                               22

#define ASL_EXTENDED_XTYPE_2                               23

#define ASL_EXTENDED_XLONG                                 24

#define ASL_EXTENDED_XL                                    25

#define ASL_EXTENDED_XLTYPE_1                              26

#define ASL_EXTENDED_XLTYPE_2                              27

#define ASL_EXTENDED_A                                     28

//ASICSIGNATURETYPES
#define CAST_UNKNOWN                                       0

#define CAST_CAD_ES                                        1

#define CAST_XAD_ES                                        2

#define CAST_TIMESTAMP                                     3

//SIGNATUREVALIDITIES
#define SVT_VALID                                          0

#define SVT_UNKNOWN                                        1

#define SVT_CORRUPTED                                      2

#define SVT_SIGNER_NOT_FOUND                               3

#define SVT_FAILURE                                        4

#define SVT_REFERENCE_CORRUPTED                            5

//DNSRESOLVEMODES
#define DM_AUTO                                            0

#define DM_PLATFORM                                        1

#define DM_OWN                                             2

#define DM_OWN_SECURE                                      3

//SECURETRANSPORTPREDEFINEDCONFIGURATIONS
#define STPC_DEFAULT                                       0

#define STPC_COMPATIBLE                                    1

#define STPC_COMPREHENSIVE_INSECURE                        2

#define STPC_HIGHLY_SECURE                                 3

//CLIENTAUTHTYPES
#define CCAT_NO_AUTH                                       0

#define CCAT_REQUEST_CERT                                  1

#define CCAT_REQUIRE_CERT                                  2

//RENEGOTIATIONATTACKPREVENTIONMODES
#define CRAPM_COMPATIBLE                                   0

#define CRAPM_STRICT                                       1

#define CRAPM_AUTO                                         2

//SSLMODES
#define SM_DEFAULT                                         0

#define SM_NO_TLS                                          1

#define SM_EXPLICIT_TLS                                    2

#define SM_IMPLICIT_TLS                                    3

#define SM_MIXED_TLS                                       4

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxASiCVerifierDelegate <NSObject>
@optional
- (void)onChainElementDownload:(int)kind :(NSString*)certRDN :(NSString*)CACertRDN :(NSString*)location :(int*)action NS_SWIFT_NAME(onChainElementDownload(_:_:_:_:_:));

- (void)onChainElementNeeded:(int)kind :(NSString*)certRDN :(NSString*)CACertRDN NS_SWIFT_NAME(onChainElementNeeded(_:_:_:));

- (void)onChainElementStore:(int)kind :(NSData*)body :(NSString**)URI NS_SWIFT_NAME(onChainElementStore(_:_:_:));

- (void)onChainValidated:(int)index :(NSString*)entityLabel :(NSString*)subjectRDN :(int)validationResult :(int)validationDetails :(int*)cancel NS_SWIFT_NAME(onChainValidated(_:_:_:_:_:_:));

- (void)onChainValidationProgress:(NSString*)eventKind :(NSString*)certRDN :(NSString*)CACertRDN :(int*)action NS_SWIFT_NAME(onChainValidationProgress(_:_:_:_:));

- (void)onContainerLoaded:(int*)cancel NS_SWIFT_NAME(onContainerLoaded(_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onFileExtractionStart:(NSString*)fileName :(long long)fileSize :(NSString*)modDate :(int*)extract :(NSString**)destFile NS_SWIFT_NAME(onFileExtractionStart(_:_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onSignatureFound:(int)index :(NSString*)entityLabel :(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(BOOL)certFound :(int*)validateSignature :(int*)validateChain NS_SWIFT_NAME(onSignatureFound(_:_:_:_:_:_:_:_:));

- (void)onSignatureValidated:(int)index :(NSString*)entityLabel :(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(int)validationResult :(int*)cancel NS_SWIFT_NAME(onSignatureValidated(_:_:_:_:_:_:_:));

- (void)onTimestampFound:(int)index :(NSString*)entityLabel :(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(BOOL)certFound :(int*)validateTimestamp :(int*)validateChain NS_SWIFT_NAME(onTimestampFound(_:_:_:_:_:_:_:_:));

- (void)onTimestampValidated:(int)index :(NSString*)entityLabel :(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(NSString*)time :(int)validationResult :(int)chainValidationResult :(int)chainValidationDetails :(int*)cancel NS_SWIFT_NAME(onTimestampValidated(_:_:_:_:_:_:_:_:_:_:));

- (void)onTLSCertNeeded:(NSString*)host :(NSString*)CANames NS_SWIFT_NAME(onTLSCertNeeded(_:_:));

- (void)onTLSCertValidate:(NSString*)serverHost :(NSString*)serverIP :(int*)accept NS_SWIFT_NAME(onTLSCertValidate(_:_:_:));

- (void)onTLSEstablished:(NSString*)host :(NSString*)version :(NSString*)ciphersuite :(NSData*)connectionId :(int*)abort NS_SWIFT_NAME(onTLSEstablished(_:_:_:_:_:));

- (void)onTLSHandshake:(NSString*)host :(int*)abort NS_SWIFT_NAME(onTLSHandshake(_:_:));

- (void)onTLSShutdown:(NSString*)host NS_SWIFT_NAME(onTLSShutdown(_:));

@end

@interface SecureBlackboxASiCVerifier : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxASiCVerifierDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasChainElementDownload;

  BOOL m_delegateHasChainElementNeeded;

  BOOL m_delegateHasChainElementStore;

  BOOL m_delegateHasChainValidated;

  BOOL m_delegateHasChainValidationProgress;

  BOOL m_delegateHasContainerLoaded;

  BOOL m_delegateHasError;

  BOOL m_delegateHasFileExtractionStart;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasSignatureFound;

  BOOL m_delegateHasSignatureValidated;

  BOOL m_delegateHasTimestampFound;

  BOOL m_delegateHasTimestampValidated;

  BOOL m_delegateHasTLSCertNeeded;

  BOOL m_delegateHasTLSCertValidate;

  BOOL m_delegateHasTLSEstablished;

  BOOL m_delegateHasTLSHandshake;

  BOOL m_delegateHasTLSShutdown;

}

+ (SecureBlackboxASiCVerifier*)asicverifier;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxASiCVerifierDelegate> delegate;
- (id <SecureBlackboxASiCVerifierDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxASiCVerifierDelegate>)anObject;

  /* Events */

- (void)onChainElementDownload:(int)kind :(NSString*)certRDN :(NSString*)CACertRDN :(NSString*)location :(int*)action NS_SWIFT_NAME(onChainElementDownload(_:_:_:_:_:));

- (void)onChainElementNeeded:(int)kind :(NSString*)certRDN :(NSString*)CACertRDN NS_SWIFT_NAME(onChainElementNeeded(_:_:_:));

- (void)onChainElementStore:(int)kind :(NSData*)body :(NSString**)URI NS_SWIFT_NAME(onChainElementStore(_:_:_:));

- (void)onChainValidated:(int)index :(NSString*)entityLabel :(NSString*)subjectRDN :(int)validationResult :(int)validationDetails :(int*)cancel NS_SWIFT_NAME(onChainValidated(_:_:_:_:_:_:));

- (void)onChainValidationProgress:(NSString*)eventKind :(NSString*)certRDN :(NSString*)CACertRDN :(int*)action NS_SWIFT_NAME(onChainValidationProgress(_:_:_:_:));

- (void)onContainerLoaded:(int*)cancel NS_SWIFT_NAME(onContainerLoaded(_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onFileExtractionStart:(NSString*)fileName :(long long)fileSize :(NSString*)modDate :(int*)extract :(NSString**)destFile NS_SWIFT_NAME(onFileExtractionStart(_:_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onSignatureFound:(int)index :(NSString*)entityLabel :(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(BOOL)certFound :(int*)validateSignature :(int*)validateChain NS_SWIFT_NAME(onSignatureFound(_:_:_:_:_:_:_:_:));

- (void)onSignatureValidated:(int)index :(NSString*)entityLabel :(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(int)validationResult :(int*)cancel NS_SWIFT_NAME(onSignatureValidated(_:_:_:_:_:_:_:));

- (void)onTimestampFound:(int)index :(NSString*)entityLabel :(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(BOOL)certFound :(int*)validateTimestamp :(int*)validateChain NS_SWIFT_NAME(onTimestampFound(_:_:_:_:_:_:_:_:));

- (void)onTimestampValidated:(int)index :(NSString*)entityLabel :(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(NSString*)time :(int)validationResult :(int)chainValidationResult :(int)chainValidationDetails :(int*)cancel NS_SWIFT_NAME(onTimestampValidated(_:_:_:_:_:_:_:_:_:_:));

- (void)onTLSCertNeeded:(NSString*)host :(NSString*)CANames NS_SWIFT_NAME(onTLSCertNeeded(_:_:));

- (void)onTLSCertValidate:(NSString*)serverHost :(NSString*)serverIP :(int*)accept NS_SWIFT_NAME(onTLSCertValidate(_:_:_:));

- (void)onTLSEstablished:(NSString*)host :(NSString*)version :(NSString*)ciphersuite :(NSData*)connectionId :(int*)abort NS_SWIFT_NAME(onTLSEstablished(_:_:_:_:_:));

- (void)onTLSHandshake:(NSString*)host :(int*)abort NS_SWIFT_NAME(onTLSHandshake(_:_:));

- (void)onTLSShutdown:(NSString*)host NS_SWIFT_NAME(onTLSShutdown(_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readonly,assign,getter=allSignaturesValid) BOOL allSignaturesValid NS_SWIFT_NAME(allSignaturesValid);

- (BOOL)allSignaturesValid NS_SWIFT_NAME(allSignaturesValid());

@property (nonatomic,readwrite,assign,getter=autoValidateSignatures,setter=setAutoValidateSignatures:) BOOL autoValidateSignatures NS_SWIFT_NAME(autoValidateSignatures);

- (BOOL)autoValidateSignatures NS_SWIFT_NAME(autoValidateSignatures());
- (void)setAutoValidateSignatures :(BOOL)newAutoValidateSignatures NS_SWIFT_NAME(setAutoValidateSignatures(_:));

@property (nonatomic,readwrite,assign,getter=blockedCertCount,setter=setBlockedCertCount:) int blockedCertCount NS_SWIFT_NAME(blockedCertCount);

- (int)blockedCertCount NS_SWIFT_NAME(blockedCertCount());
- (void)setBlockedCertCount :(int)newBlockedCertCount NS_SWIFT_NAME(setBlockedCertCount(_:));

- (NSData*)blockedCertBytes:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertBytes(_:));

- (BOOL)blockedCertCA:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertCA(_:));
- (void)setBlockedCertCA:(int)blockedCertIndex :(BOOL)newBlockedCertCA NS_SWIFT_NAME(setBlockedCertCA(_:_:));

- (NSData*)blockedCertCAKeyID:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertCAKeyID(_:));

- (int)blockedCertCertType:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertCertType(_:));

- (NSString*)blockedCertCRLDistributionPoints:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertCRLDistributionPoints(_:));
- (void)setBlockedCertCRLDistributionPoints:(int)blockedCertIndex :(NSString*)newBlockedCertCRLDistributionPoints NS_SWIFT_NAME(setBlockedCertCRLDistributionPoints(_:_:));

- (NSString*)blockedCertCurve:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertCurve(_:));
- (void)setBlockedCertCurve:(int)blockedCertIndex :(NSString*)newBlockedCertCurve NS_SWIFT_NAME(setBlockedCertCurve(_:_:));

- (NSString*)blockedCertFingerprint:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertFingerprint(_:));

- (NSString*)blockedCertFriendlyName:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertFriendlyName(_:));

- (long long)blockedCertHandle:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertHandle(_:));
- (void)setBlockedCertHandle:(int)blockedCertIndex :(long long)newBlockedCertHandle NS_SWIFT_NAME(setBlockedCertHandle(_:_:));

- (NSString*)blockedCertHashAlgorithm:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertHashAlgorithm(_:));
- (void)setBlockedCertHashAlgorithm:(int)blockedCertIndex :(NSString*)newBlockedCertHashAlgorithm NS_SWIFT_NAME(setBlockedCertHashAlgorithm(_:_:));

- (NSString*)blockedCertIssuer:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertIssuer(_:));

- (NSString*)blockedCertIssuerRDN:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertIssuerRDN(_:));
- (void)setBlockedCertIssuerRDN:(int)blockedCertIndex :(NSString*)newBlockedCertIssuerRDN NS_SWIFT_NAME(setBlockedCertIssuerRDN(_:_:));

- (NSString*)blockedCertKeyAlgorithm:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertKeyAlgorithm(_:));
- (void)setBlockedCertKeyAlgorithm:(int)blockedCertIndex :(NSString*)newBlockedCertKeyAlgorithm NS_SWIFT_NAME(setBlockedCertKeyAlgorithm(_:_:));

- (int)blockedCertKeyBits:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertKeyBits(_:));

- (NSString*)blockedCertKeyFingerprint:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertKeyFingerprint(_:));

- (int)blockedCertKeyUsage:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertKeyUsage(_:));
- (void)setBlockedCertKeyUsage:(int)blockedCertIndex :(int)newBlockedCertKeyUsage NS_SWIFT_NAME(setBlockedCertKeyUsage(_:_:));

- (BOOL)blockedCertKeyValid:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertKeyValid(_:));

- (NSString*)blockedCertOCSPLocations:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertOCSPLocations(_:));
- (void)setBlockedCertOCSPLocations:(int)blockedCertIndex :(NSString*)newBlockedCertOCSPLocations NS_SWIFT_NAME(setBlockedCertOCSPLocations(_:_:));

- (BOOL)blockedCertOCSPNoCheck:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertOCSPNoCheck(_:));
- (void)setBlockedCertOCSPNoCheck:(int)blockedCertIndex :(BOOL)newBlockedCertOCSPNoCheck NS_SWIFT_NAME(setBlockedCertOCSPNoCheck(_:_:));

- (int)blockedCertOrigin:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertOrigin(_:));

- (NSString*)blockedCertPolicyIDs:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertPolicyIDs(_:));
- (void)setBlockedCertPolicyIDs:(int)blockedCertIndex :(NSString*)newBlockedCertPolicyIDs NS_SWIFT_NAME(setBlockedCertPolicyIDs(_:_:));

- (NSData*)blockedCertPrivateKeyBytes:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertPrivateKeyBytes(_:));

- (BOOL)blockedCertPrivateKeyExists:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertPrivateKeyExists(_:));

- (BOOL)blockedCertPrivateKeyExtractable:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertPrivateKeyExtractable(_:));

- (NSData*)blockedCertPublicKeyBytes:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertPublicKeyBytes(_:));

- (BOOL)blockedCertQualified:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertQualified(_:));

- (int)blockedCertQualifiedStatements:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertQualifiedStatements(_:));
- (void)setBlockedCertQualifiedStatements:(int)blockedCertIndex :(int)newBlockedCertQualifiedStatements NS_SWIFT_NAME(setBlockedCertQualifiedStatements(_:_:));

- (NSString*)blockedCertQualifiers:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertQualifiers(_:));

- (BOOL)blockedCertSelfSigned:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSelfSigned(_:));

- (NSData*)blockedCertSerialNumber:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSerialNumber(_:));
- (void)setBlockedCertSerialNumber:(int)blockedCertIndex :(NSData*)newBlockedCertSerialNumber NS_SWIFT_NAME(setBlockedCertSerialNumber(_:_:));

- (NSString*)blockedCertSigAlgorithm:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSigAlgorithm(_:));

- (int)blockedCertSource:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSource(_:));

- (NSString*)blockedCertSubject:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSubject(_:));

- (NSString*)blockedCertSubjectAlternativeName:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSubjectAlternativeName(_:));
- (void)setBlockedCertSubjectAlternativeName:(int)blockedCertIndex :(NSString*)newBlockedCertSubjectAlternativeName NS_SWIFT_NAME(setBlockedCertSubjectAlternativeName(_:_:));

- (NSData*)blockedCertSubjectKeyID:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSubjectKeyID(_:));
- (void)setBlockedCertSubjectKeyID:(int)blockedCertIndex :(NSData*)newBlockedCertSubjectKeyID NS_SWIFT_NAME(setBlockedCertSubjectKeyID(_:_:));

- (NSString*)blockedCertSubjectRDN:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertSubjectRDN(_:));
- (void)setBlockedCertSubjectRDN:(int)blockedCertIndex :(NSString*)newBlockedCertSubjectRDN NS_SWIFT_NAME(setBlockedCertSubjectRDN(_:_:));

- (BOOL)blockedCertValid:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertValid(_:));

- (NSString*)blockedCertValidFrom:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertValidFrom(_:));
- (void)setBlockedCertValidFrom:(int)blockedCertIndex :(NSString*)newBlockedCertValidFrom NS_SWIFT_NAME(setBlockedCertValidFrom(_:_:));

- (NSString*)blockedCertValidTo:(int)blockedCertIndex NS_SWIFT_NAME(blockedCertValidTo(_:));
- (void)setBlockedCertValidTo:(int)blockedCertIndex :(NSString*)newBlockedCertValidTo NS_SWIFT_NAME(setBlockedCertValidTo(_:_:));

@property (nonatomic,readonly,assign,getter=certCount) int certCount NS_SWIFT_NAME(certCount);

- (int)certCount NS_SWIFT_NAME(certCount());

- (NSData*)certBytes:(int)certIndex NS_SWIFT_NAME(certBytes(_:));

- (BOOL)certCA:(int)certIndex NS_SWIFT_NAME(certCA(_:));

- (NSData*)certCAKeyID:(int)certIndex NS_SWIFT_NAME(certCAKeyID(_:));

- (int)certCertType:(int)certIndex NS_SWIFT_NAME(certCertType(_:));

- (NSString*)certCRLDistributionPoints:(int)certIndex NS_SWIFT_NAME(certCRLDistributionPoints(_:));

- (NSString*)certCurve:(int)certIndex NS_SWIFT_NAME(certCurve(_:));

- (NSString*)certFingerprint:(int)certIndex NS_SWIFT_NAME(certFingerprint(_:));

- (NSString*)certFriendlyName:(int)certIndex NS_SWIFT_NAME(certFriendlyName(_:));

- (long long)certHandle:(int)certIndex NS_SWIFT_NAME(certHandle(_:));

- (NSString*)certHashAlgorithm:(int)certIndex NS_SWIFT_NAME(certHashAlgorithm(_:));

- (NSString*)certIssuer:(int)certIndex NS_SWIFT_NAME(certIssuer(_:));

- (NSString*)certIssuerRDN:(int)certIndex NS_SWIFT_NAME(certIssuerRDN(_:));

- (NSString*)certKeyAlgorithm:(int)certIndex NS_SWIFT_NAME(certKeyAlgorithm(_:));

- (int)certKeyBits:(int)certIndex NS_SWIFT_NAME(certKeyBits(_:));

- (NSString*)certKeyFingerprint:(int)certIndex NS_SWIFT_NAME(certKeyFingerprint(_:));

- (int)certKeyUsage:(int)certIndex NS_SWIFT_NAME(certKeyUsage(_:));

- (BOOL)certKeyValid:(int)certIndex NS_SWIFT_NAME(certKeyValid(_:));

- (NSString*)certOCSPLocations:(int)certIndex NS_SWIFT_NAME(certOCSPLocations(_:));

- (BOOL)certOCSPNoCheck:(int)certIndex NS_SWIFT_NAME(certOCSPNoCheck(_:));

- (int)certOrigin:(int)certIndex NS_SWIFT_NAME(certOrigin(_:));

- (NSString*)certPolicyIDs:(int)certIndex NS_SWIFT_NAME(certPolicyIDs(_:));

- (NSData*)certPrivateKeyBytes:(int)certIndex NS_SWIFT_NAME(certPrivateKeyBytes(_:));

- (BOOL)certPrivateKeyExists:(int)certIndex NS_SWIFT_NAME(certPrivateKeyExists(_:));

- (BOOL)certPrivateKeyExtractable:(int)certIndex NS_SWIFT_NAME(certPrivateKeyExtractable(_:));

- (NSData*)certPublicKeyBytes:(int)certIndex NS_SWIFT_NAME(certPublicKeyBytes(_:));

- (BOOL)certQualified:(int)certIndex NS_SWIFT_NAME(certQualified(_:));

- (int)certQualifiedStatements:(int)certIndex NS_SWIFT_NAME(certQualifiedStatements(_:));

- (NSString*)certQualifiers:(int)certIndex NS_SWIFT_NAME(certQualifiers(_:));

- (BOOL)certSelfSigned:(int)certIndex NS_SWIFT_NAME(certSelfSigned(_:));

- (NSData*)certSerialNumber:(int)certIndex NS_SWIFT_NAME(certSerialNumber(_:));

- (NSString*)certSigAlgorithm:(int)certIndex NS_SWIFT_NAME(certSigAlgorithm(_:));

- (int)certSource:(int)certIndex NS_SWIFT_NAME(certSource(_:));

- (NSString*)certSubject:(int)certIndex NS_SWIFT_NAME(certSubject(_:));

- (NSString*)certSubjectAlternativeName:(int)certIndex NS_SWIFT_NAME(certSubjectAlternativeName(_:));

- (NSData*)certSubjectKeyID:(int)certIndex NS_SWIFT_NAME(certSubjectKeyID(_:));

- (NSString*)certSubjectRDN:(int)certIndex NS_SWIFT_NAME(certSubjectRDN(_:));

- (BOOL)certValid:(int)certIndex NS_SWIFT_NAME(certValid(_:));

- (NSString*)certValidFrom:(int)certIndex NS_SWIFT_NAME(certValidFrom(_:));

- (NSString*)certValidTo:(int)certIndex NS_SWIFT_NAME(certValidTo(_:));

@property (nonatomic,readwrite,assign,getter=checkTrustedLists,setter=setCheckTrustedLists:) BOOL checkTrustedLists NS_SWIFT_NAME(checkTrustedLists);

- (BOOL)checkTrustedLists NS_SWIFT_NAME(checkTrustedLists());
- (void)setCheckTrustedLists :(BOOL)newCheckTrustedLists NS_SWIFT_NAME(setCheckTrustedLists(_:));

@property (nonatomic,readonly,assign,getter=CRLCount) int CRLCount NS_SWIFT_NAME(CRLCount);

- (int)CRLCount NS_SWIFT_NAME(CRLCount());

- (NSData*)CRLBytes:(int)cRLIndex NS_SWIFT_NAME(CRLBytes(_:));

- (NSData*)CRLCAKeyID:(int)cRLIndex NS_SWIFT_NAME(CRLCAKeyID(_:));

- (int)CRLEntryCount:(int)cRLIndex NS_SWIFT_NAME(CRLEntryCount(_:));

- (long long)CRLHandle:(int)cRLIndex NS_SWIFT_NAME(CRLHandle(_:));

- (NSString*)CRLIssuer:(int)cRLIndex NS_SWIFT_NAME(CRLIssuer(_:));

- (NSString*)CRLIssuerRDN:(int)cRLIndex NS_SWIFT_NAME(CRLIssuerRDN(_:));

- (NSString*)CRLLocation:(int)cRLIndex NS_SWIFT_NAME(CRLLocation(_:));

- (NSString*)CRLNextUpdate:(int)cRLIndex NS_SWIFT_NAME(CRLNextUpdate(_:));

- (NSString*)CRLSigAlgorithm:(int)cRLIndex NS_SWIFT_NAME(CRLSigAlgorithm(_:));

- (int)CRLSource:(int)cRLIndex NS_SWIFT_NAME(CRLSource(_:));

- (NSData*)CRLTBS:(int)cRLIndex NS_SWIFT_NAME(CRLTBS(_:));

- (NSString*)CRLThisUpdate:(int)cRLIndex NS_SWIFT_NAME(CRLThisUpdate(_:));

@property (nonatomic,readwrite,assign,getter=extractionMode,setter=setExtractionMode:) int extractionMode NS_SWIFT_NAME(extractionMode);

- (int)extractionMode NS_SWIFT_NAME(extractionMode());
- (void)setExtractionMode :(int)newExtractionMode NS_SWIFT_NAME(setExtractionMode(_:));

@property (nonatomic,readonly,assign,getter=fileCount) int fileCount NS_SWIFT_NAME(fileCount);

- (int)fileCount NS_SWIFT_NAME(fileCount());

- (int)fileAction:(int)fileIndex NS_SWIFT_NAME(fileAction(_:));

- (NSString*)fileAttributes:(int)fileIndex NS_SWIFT_NAME(fileAttributes(_:));

- (long long)fileCompressedSize:(int)fileIndex NS_SWIFT_NAME(fileCompressedSize(_:));

- (int)fileDataSource:(int)fileIndex NS_SWIFT_NAME(fileDataSource(_:));

- (BOOL)fileDirectory:(int)fileIndex NS_SWIFT_NAME(fileDirectory(_:));

- (NSString*)fileEncryptionAlgorithm:(int)fileIndex NS_SWIFT_NAME(fileEncryptionAlgorithm(_:));

- (int)fileEncryptionKeyLength:(int)fileIndex NS_SWIFT_NAME(fileEncryptionKeyLength(_:));

- (int)fileEncryptionType:(int)fileIndex NS_SWIFT_NAME(fileEncryptionType(_:));

- (NSString*)fileFileName:(int)fileIndex NS_SWIFT_NAME(fileFileName(_:));

- (NSString*)fileFolder:(int)fileIndex NS_SWIFT_NAME(fileFolder(_:));

- (NSString*)fileLocalPath:(int)fileIndex NS_SWIFT_NAME(fileLocalPath(_:));

- (NSString*)fileMTime:(int)fileIndex NS_SWIFT_NAME(fileMTime(_:));

- (BOOL)fileNewFile:(int)fileIndex NS_SWIFT_NAME(fileNewFile(_:));

- (NSString*)filePath:(int)fileIndex NS_SWIFT_NAME(filePath(_:));

- (int)fileSignatureCount:(int)fileIndex NS_SWIFT_NAME(fileSignatureCount(_:));

- (BOOL)fileSigned:(int)fileIndex NS_SWIFT_NAME(fileSigned(_:));

- (long long)fileSize:(int)fileIndex NS_SWIFT_NAME(fileSize(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=ignoreChainValidationErrors,setter=setIgnoreChainValidationErrors:) BOOL ignoreChainValidationErrors NS_SWIFT_NAME(ignoreChainValidationErrors);

- (BOOL)ignoreChainValidationErrors NS_SWIFT_NAME(ignoreChainValidationErrors());
- (void)setIgnoreChainValidationErrors :(BOOL)newIgnoreChainValidationErrors NS_SWIFT_NAME(setIgnoreChainValidationErrors(_:));

@property (nonatomic,readwrite,assign,getter=inputBytes,setter=setInputBytes:) NSData* inputBytes NS_SWIFT_NAME(inputBytes);

- (NSData*)inputBytes NS_SWIFT_NAME(inputBytes());
- (void)setInputBytes :(NSData*)newInputBytes NS_SWIFT_NAME(setInputBytes(_:));

@property (nonatomic,readwrite,assign,getter=inputFile,setter=setInputFile:) NSString* inputFile NS_SWIFT_NAME(inputFile);

- (NSString*)inputFile NS_SWIFT_NAME(inputFile());
- (void)setInputFile :(NSString*)newInputFile NS_SWIFT_NAME(setInputFile(_:));

@property (nonatomic,readwrite,assign,getter=knownCertCount,setter=setKnownCertCount:) int knownCertCount NS_SWIFT_NAME(knownCertCount);

- (int)knownCertCount NS_SWIFT_NAME(knownCertCount());
- (void)setKnownCertCount :(int)newKnownCertCount NS_SWIFT_NAME(setKnownCertCount(_:));

- (NSData*)knownCertBytes:(int)knownCertIndex NS_SWIFT_NAME(knownCertBytes(_:));

- (BOOL)knownCertCA:(int)knownCertIndex NS_SWIFT_NAME(knownCertCA(_:));
- (void)setKnownCertCA:(int)knownCertIndex :(BOOL)newKnownCertCA NS_SWIFT_NAME(setKnownCertCA(_:_:));

- (NSData*)knownCertCAKeyID:(int)knownCertIndex NS_SWIFT_NAME(knownCertCAKeyID(_:));

- (int)knownCertCertType:(int)knownCertIndex NS_SWIFT_NAME(knownCertCertType(_:));

- (NSString*)knownCertCRLDistributionPoints:(int)knownCertIndex NS_SWIFT_NAME(knownCertCRLDistributionPoints(_:));
- (void)setKnownCertCRLDistributionPoints:(int)knownCertIndex :(NSString*)newKnownCertCRLDistributionPoints NS_SWIFT_NAME(setKnownCertCRLDistributionPoints(_:_:));

- (NSString*)knownCertCurve:(int)knownCertIndex NS_SWIFT_NAME(knownCertCurve(_:));
- (void)setKnownCertCurve:(int)knownCertIndex :(NSString*)newKnownCertCurve NS_SWIFT_NAME(setKnownCertCurve(_:_:));

- (NSString*)knownCertFingerprint:(int)knownCertIndex NS_SWIFT_NAME(knownCertFingerprint(_:));

- (NSString*)knownCertFriendlyName:(int)knownCertIndex NS_SWIFT_NAME(knownCertFriendlyName(_:));

- (long long)knownCertHandle:(int)knownCertIndex NS_SWIFT_NAME(knownCertHandle(_:));
- (void)setKnownCertHandle:(int)knownCertIndex :(long long)newKnownCertHandle NS_SWIFT_NAME(setKnownCertHandle(_:_:));

- (NSString*)knownCertHashAlgorithm:(int)knownCertIndex NS_SWIFT_NAME(knownCertHashAlgorithm(_:));
- (void)setKnownCertHashAlgorithm:(int)knownCertIndex :(NSString*)newKnownCertHashAlgorithm NS_SWIFT_NAME(setKnownCertHashAlgorithm(_:_:));

- (NSString*)knownCertIssuer:(int)knownCertIndex NS_SWIFT_NAME(knownCertIssuer(_:));

- (NSString*)knownCertIssuerRDN:(int)knownCertIndex NS_SWIFT_NAME(knownCertIssuerRDN(_:));
- (void)setKnownCertIssuerRDN:(int)knownCertIndex :(NSString*)newKnownCertIssuerRDN NS_SWIFT_NAME(setKnownCertIssuerRDN(_:_:));

- (NSString*)knownCertKeyAlgorithm:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyAlgorithm(_:));
- (void)setKnownCertKeyAlgorithm:(int)knownCertIndex :(NSString*)newKnownCertKeyAlgorithm NS_SWIFT_NAME(setKnownCertKeyAlgorithm(_:_:));

- (int)knownCertKeyBits:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyBits(_:));

- (NSString*)knownCertKeyFingerprint:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyFingerprint(_:));

- (int)knownCertKeyUsage:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyUsage(_:));
- (void)setKnownCertKeyUsage:(int)knownCertIndex :(int)newKnownCertKeyUsage NS_SWIFT_NAME(setKnownCertKeyUsage(_:_:));

- (BOOL)knownCertKeyValid:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyValid(_:));

- (NSString*)knownCertOCSPLocations:(int)knownCertIndex NS_SWIFT_NAME(knownCertOCSPLocations(_:));
- (void)setKnownCertOCSPLocations:(int)knownCertIndex :(NSString*)newKnownCertOCSPLocations NS_SWIFT_NAME(setKnownCertOCSPLocations(_:_:));

- (BOOL)knownCertOCSPNoCheck:(int)knownCertIndex NS_SWIFT_NAME(knownCertOCSPNoCheck(_:));
- (void)setKnownCertOCSPNoCheck:(int)knownCertIndex :(BOOL)newKnownCertOCSPNoCheck NS_SWIFT_NAME(setKnownCertOCSPNoCheck(_:_:));

- (int)knownCertOrigin:(int)knownCertIndex NS_SWIFT_NAME(knownCertOrigin(_:));

- (NSString*)knownCertPolicyIDs:(int)knownCertIndex NS_SWIFT_NAME(knownCertPolicyIDs(_:));
- (void)setKnownCertPolicyIDs:(int)knownCertIndex :(NSString*)newKnownCertPolicyIDs NS_SWIFT_NAME(setKnownCertPolicyIDs(_:_:));

- (NSData*)knownCertPrivateKeyBytes:(int)knownCertIndex NS_SWIFT_NAME(knownCertPrivateKeyBytes(_:));

- (BOOL)knownCertPrivateKeyExists:(int)knownCertIndex NS_SWIFT_NAME(knownCertPrivateKeyExists(_:));

- (BOOL)knownCertPrivateKeyExtractable:(int)knownCertIndex NS_SWIFT_NAME(knownCertPrivateKeyExtractable(_:));

- (NSData*)knownCertPublicKeyBytes:(int)knownCertIndex NS_SWIFT_NAME(knownCertPublicKeyBytes(_:));

- (BOOL)knownCertQualified:(int)knownCertIndex NS_SWIFT_NAME(knownCertQualified(_:));

- (int)knownCertQualifiedStatements:(int)knownCertIndex NS_SWIFT_NAME(knownCertQualifiedStatements(_:));
- (void)setKnownCertQualifiedStatements:(int)knownCertIndex :(int)newKnownCertQualifiedStatements NS_SWIFT_NAME(setKnownCertQualifiedStatements(_:_:));

- (NSString*)knownCertQualifiers:(int)knownCertIndex NS_SWIFT_NAME(knownCertQualifiers(_:));

- (BOOL)knownCertSelfSigned:(int)knownCertIndex NS_SWIFT_NAME(knownCertSelfSigned(_:));

- (NSData*)knownCertSerialNumber:(int)knownCertIndex NS_SWIFT_NAME(knownCertSerialNumber(_:));
- (void)setKnownCertSerialNumber:(int)knownCertIndex :(NSData*)newKnownCertSerialNumber NS_SWIFT_NAME(setKnownCertSerialNumber(_:_:));

- (NSString*)knownCertSigAlgorithm:(int)knownCertIndex NS_SWIFT_NAME(knownCertSigAlgorithm(_:));

- (int)knownCertSource:(int)knownCertIndex NS_SWIFT_NAME(knownCertSource(_:));

- (NSString*)knownCertSubject:(int)knownCertIndex NS_SWIFT_NAME(knownCertSubject(_:));

- (NSString*)knownCertSubjectAlternativeName:(int)knownCertIndex NS_SWIFT_NAME(knownCertSubjectAlternativeName(_:));
- (void)setKnownCertSubjectAlternativeName:(int)knownCertIndex :(NSString*)newKnownCertSubjectAlternativeName NS_SWIFT_NAME(setKnownCertSubjectAlternativeName(_:_:));

- (NSData*)knownCertSubjectKeyID:(int)knownCertIndex NS_SWIFT_NAME(knownCertSubjectKeyID(_:));
- (void)setKnownCertSubjectKeyID:(int)knownCertIndex :(NSData*)newKnownCertSubjectKeyID NS_SWIFT_NAME(setKnownCertSubjectKeyID(_:_:));

- (NSString*)knownCertSubjectRDN:(int)knownCertIndex NS_SWIFT_NAME(knownCertSubjectRDN(_:));
- (void)setKnownCertSubjectRDN:(int)knownCertIndex :(NSString*)newKnownCertSubjectRDN NS_SWIFT_NAME(setKnownCertSubjectRDN(_:_:));

- (BOOL)knownCertValid:(int)knownCertIndex NS_SWIFT_NAME(knownCertValid(_:));

- (NSString*)knownCertValidFrom:(int)knownCertIndex NS_SWIFT_NAME(knownCertValidFrom(_:));
- (void)setKnownCertValidFrom:(int)knownCertIndex :(NSString*)newKnownCertValidFrom NS_SWIFT_NAME(setKnownCertValidFrom(_:_:));

- (NSString*)knownCertValidTo:(int)knownCertIndex NS_SWIFT_NAME(knownCertValidTo(_:));
- (void)setKnownCertValidTo:(int)knownCertIndex :(NSString*)newKnownCertValidTo NS_SWIFT_NAME(setKnownCertValidTo(_:_:));

@property (nonatomic,readwrite,assign,getter=knownCRLCount,setter=setKnownCRLCount:) int knownCRLCount NS_SWIFT_NAME(knownCRLCount);

- (int)knownCRLCount NS_SWIFT_NAME(knownCRLCount());
- (void)setKnownCRLCount :(int)newKnownCRLCount NS_SWIFT_NAME(setKnownCRLCount(_:));

- (NSData*)knownCRLBytes:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLBytes(_:));

- (NSData*)knownCRLCAKeyID:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLCAKeyID(_:));
- (void)setKnownCRLCAKeyID:(int)knownCRLIndex :(NSData*)newKnownCRLCAKeyID NS_SWIFT_NAME(setKnownCRLCAKeyID(_:_:));

- (int)knownCRLEntryCount:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLEntryCount(_:));

- (long long)knownCRLHandle:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLHandle(_:));
- (void)setKnownCRLHandle:(int)knownCRLIndex :(long long)newKnownCRLHandle NS_SWIFT_NAME(setKnownCRLHandle(_:_:));

- (NSString*)knownCRLIssuer:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLIssuer(_:));

- (NSString*)knownCRLIssuerRDN:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLIssuerRDN(_:));

- (NSString*)knownCRLLocation:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLLocation(_:));

- (NSString*)knownCRLNextUpdate:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLNextUpdate(_:));
- (void)setKnownCRLNextUpdate:(int)knownCRLIndex :(NSString*)newKnownCRLNextUpdate NS_SWIFT_NAME(setKnownCRLNextUpdate(_:_:));

- (NSString*)knownCRLSigAlgorithm:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLSigAlgorithm(_:));
- (void)setKnownCRLSigAlgorithm:(int)knownCRLIndex :(NSString*)newKnownCRLSigAlgorithm NS_SWIFT_NAME(setKnownCRLSigAlgorithm(_:_:));

- (int)knownCRLSource:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLSource(_:));

- (NSData*)knownCRLTBS:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLTBS(_:));

- (NSString*)knownCRLThisUpdate:(int)knownCRLIndex NS_SWIFT_NAME(knownCRLThisUpdate(_:));
- (void)setKnownCRLThisUpdate:(int)knownCRLIndex :(NSString*)newKnownCRLThisUpdate NS_SWIFT_NAME(setKnownCRLThisUpdate(_:_:));

@property (nonatomic,readwrite,assign,getter=knownOCSPCount,setter=setKnownOCSPCount:) int knownOCSPCount NS_SWIFT_NAME(knownOCSPCount);

- (int)knownOCSPCount NS_SWIFT_NAME(knownOCSPCount());
- (void)setKnownOCSPCount :(int)newKnownOCSPCount NS_SWIFT_NAME(setKnownOCSPCount(_:));

- (NSData*)knownOCSPBytes:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPBytes(_:));

- (int)knownOCSPEntryCount:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPEntryCount(_:));

- (long long)knownOCSPHandle:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPHandle(_:));
- (void)setKnownOCSPHandle:(int)knownOCSPIndex :(long long)newKnownOCSPHandle NS_SWIFT_NAME(setKnownOCSPHandle(_:_:));

- (NSString*)knownOCSPIssuer:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPIssuer(_:));

- (NSString*)knownOCSPIssuerRDN:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPIssuerRDN(_:));

- (NSString*)knownOCSPLocation:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPLocation(_:));

- (NSString*)knownOCSPProducedAt:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPProducedAt(_:));
- (void)setKnownOCSPProducedAt:(int)knownOCSPIndex :(NSString*)newKnownOCSPProducedAt NS_SWIFT_NAME(setKnownOCSPProducedAt(_:_:));

- (NSString*)knownOCSPSigAlgorithm:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPSigAlgorithm(_:));
- (void)setKnownOCSPSigAlgorithm:(int)knownOCSPIndex :(NSString*)newKnownOCSPSigAlgorithm NS_SWIFT_NAME(setKnownOCSPSigAlgorithm(_:_:));

- (int)knownOCSPSource:(int)knownOCSPIndex NS_SWIFT_NAME(knownOCSPSource(_:));

@property (nonatomic,readonly,assign,getter=OCSPCount) int OCSPCount NS_SWIFT_NAME(OCSPCount);

- (int)OCSPCount NS_SWIFT_NAME(OCSPCount());

- (NSData*)OCSPBytes:(int)oCSPIndex NS_SWIFT_NAME(OCSPBytes(_:));

- (int)OCSPEntryCount:(int)oCSPIndex NS_SWIFT_NAME(OCSPEntryCount(_:));

- (long long)OCSPHandle:(int)oCSPIndex NS_SWIFT_NAME(OCSPHandle(_:));

- (NSString*)OCSPIssuer:(int)oCSPIndex NS_SWIFT_NAME(OCSPIssuer(_:));

- (NSString*)OCSPIssuerRDN:(int)oCSPIndex NS_SWIFT_NAME(OCSPIssuerRDN(_:));

- (NSString*)OCSPLocation:(int)oCSPIndex NS_SWIFT_NAME(OCSPLocation(_:));

- (NSString*)OCSPProducedAt:(int)oCSPIndex NS_SWIFT_NAME(OCSPProducedAt(_:));

- (NSString*)OCSPSigAlgorithm:(int)oCSPIndex NS_SWIFT_NAME(OCSPSigAlgorithm(_:));

- (int)OCSPSource:(int)oCSPIndex NS_SWIFT_NAME(OCSPSource(_:));

@property (nonatomic,readwrite,assign,getter=offlineMode,setter=setOfflineMode:) BOOL offlineMode NS_SWIFT_NAME(offlineMode);

- (BOOL)offlineMode NS_SWIFT_NAME(offlineMode());
- (void)setOfflineMode :(BOOL)newOfflineMode NS_SWIFT_NAME(setOfflineMode(_:));

@property (nonatomic,readonly,assign,getter=outputBytes) NSData* outputBytes NS_SWIFT_NAME(outputBytes);

- (NSData*)outputBytes NS_SWIFT_NAME(outputBytes());

@property (nonatomic,readwrite,assign,getter=outputFile,setter=setOutputFile:) NSString* outputFile NS_SWIFT_NAME(outputFile);

- (NSString*)outputFile NS_SWIFT_NAME(outputFile());
- (void)setOutputFile :(NSString*)newOutputFile NS_SWIFT_NAME(setOutputFile(_:));

@property (nonatomic,readwrite,assign,getter=outputPath,setter=setOutputPath:) NSString* outputPath NS_SWIFT_NAME(outputPath);

- (NSString*)outputPath NS_SWIFT_NAME(outputPath());
- (void)setOutputPath :(NSString*)newOutputPath NS_SWIFT_NAME(setOutputPath(_:));

@property (nonatomic,readwrite,assign,getter=profile,setter=setProfile:) NSString* profile NS_SWIFT_NAME(profile);

- (NSString*)profile NS_SWIFT_NAME(profile());
- (void)setProfile :(NSString*)newProfile NS_SWIFT_NAME(setProfile(_:));

@property (nonatomic,readwrite,assign,getter=proxyAddress,setter=setProxyAddress:) NSString* proxyAddress NS_SWIFT_NAME(proxyAddress);

- (NSString*)proxyAddress NS_SWIFT_NAME(proxyAddress());
- (void)setProxyAddress :(NSString*)newProxyAddress NS_SWIFT_NAME(setProxyAddress(_:));

@property (nonatomic,readwrite,assign,getter=proxyAuthentication,setter=setProxyAuthentication:) int proxyAuthentication NS_SWIFT_NAME(proxyAuthentication);

- (int)proxyAuthentication NS_SWIFT_NAME(proxyAuthentication());
- (void)setProxyAuthentication :(int)newProxyAuthentication NS_SWIFT_NAME(setProxyAuthentication(_:));

@property (nonatomic,readwrite,assign,getter=proxyPassword,setter=setProxyPassword:) NSString* proxyPassword NS_SWIFT_NAME(proxyPassword);

- (NSString*)proxyPassword NS_SWIFT_NAME(proxyPassword());
- (void)setProxyPassword :(NSString*)newProxyPassword NS_SWIFT_NAME(setProxyPassword(_:));

@property (nonatomic,readwrite,assign,getter=proxyPort,setter=setProxyPort:) int proxyPort NS_SWIFT_NAME(proxyPort);

- (int)proxyPort NS_SWIFT_NAME(proxyPort());
- (void)setProxyPort :(int)newProxyPort NS_SWIFT_NAME(setProxyPort(_:));

@property (nonatomic,readwrite,assign,getter=proxyProxyType,setter=setProxyProxyType:) int proxyProxyType NS_SWIFT_NAME(proxyProxyType);

- (int)proxyProxyType NS_SWIFT_NAME(proxyProxyType());
- (void)setProxyProxyType :(int)newProxyProxyType NS_SWIFT_NAME(setProxyProxyType(_:));

@property (nonatomic,readwrite,assign,getter=proxyRequestHeaders,setter=setProxyRequestHeaders:) NSString* proxyRequestHeaders NS_SWIFT_NAME(proxyRequestHeaders);

- (NSString*)proxyRequestHeaders NS_SWIFT_NAME(proxyRequestHeaders());
- (void)setProxyRequestHeaders :(NSString*)newProxyRequestHeaders NS_SWIFT_NAME(setProxyRequestHeaders(_:));

@property (nonatomic,readwrite,assign,getter=proxyResponseBody,setter=setProxyResponseBody:) NSString* proxyResponseBody NS_SWIFT_NAME(proxyResponseBody);

- (NSString*)proxyResponseBody NS_SWIFT_NAME(proxyResponseBody());
- (void)setProxyResponseBody :(NSString*)newProxyResponseBody NS_SWIFT_NAME(setProxyResponseBody(_:));

@property (nonatomic,readwrite,assign,getter=proxyResponseHeaders,setter=setProxyResponseHeaders:) NSString* proxyResponseHeaders NS_SWIFT_NAME(proxyResponseHeaders);

- (NSString*)proxyResponseHeaders NS_SWIFT_NAME(proxyResponseHeaders());
- (void)setProxyResponseHeaders :(NSString*)newProxyResponseHeaders NS_SWIFT_NAME(setProxyResponseHeaders(_:));

@property (nonatomic,readwrite,assign,getter=proxyUseIPv6,setter=setProxyUseIPv6:) BOOL proxyUseIPv6 NS_SWIFT_NAME(proxyUseIPv6);

- (BOOL)proxyUseIPv6 NS_SWIFT_NAME(proxyUseIPv6());
- (void)setProxyUseIPv6 :(BOOL)newProxyUseIPv6 NS_SWIFT_NAME(setProxyUseIPv6(_:));

@property (nonatomic,readwrite,assign,getter=proxyUsername,setter=setProxyUsername:) NSString* proxyUsername NS_SWIFT_NAME(proxyUsername);

- (NSString*)proxyUsername NS_SWIFT_NAME(proxyUsername());
- (void)setProxyUsername :(NSString*)newProxyUsername NS_SWIFT_NAME(setProxyUsername(_:));

@property (nonatomic,readwrite,assign,getter=revocationCheck,setter=setRevocationCheck:) int revocationCheck NS_SWIFT_NAME(revocationCheck);

- (int)revocationCheck NS_SWIFT_NAME(revocationCheck());
- (void)setRevocationCheck :(int)newRevocationCheck NS_SWIFT_NAME(setRevocationCheck(_:));

@property (nonatomic,readonly,assign,getter=signatureCount) int signatureCount NS_SWIFT_NAME(signatureCount);

- (int)signatureCount NS_SWIFT_NAME(signatureCount());

- (int)signatureChainValidationDetails:(int)signatureIndex NS_SWIFT_NAME(signatureChainValidationDetails(_:));

- (int)signatureChainValidationResult:(int)signatureIndex NS_SWIFT_NAME(signatureChainValidationResult(_:));

- (NSString*)signatureClaimedSigningTime:(int)signatureIndex NS_SWIFT_NAME(signatureClaimedSigningTime(_:));

- (int)signatureCompatibilityErrors:(int)signatureIndex NS_SWIFT_NAME(signatureCompatibilityErrors(_:));

- (BOOL)signatureContainsLongTermInfo:(int)signatureIndex NS_SWIFT_NAME(signatureContainsLongTermInfo(_:));

- (NSString*)signatureContentType:(int)signatureIndex NS_SWIFT_NAME(signatureContentType(_:));

- (NSString*)signatureEntityLabel:(int)signatureIndex NS_SWIFT_NAME(signatureEntityLabel(_:));

- (NSString*)signatureFileName:(int)signatureIndex NS_SWIFT_NAME(signatureFileName(_:));

- (long long)signatureHandle:(int)signatureIndex NS_SWIFT_NAME(signatureHandle(_:));

- (NSString*)signatureHashAlgorithm:(int)signatureIndex NS_SWIFT_NAME(signatureHashAlgorithm(_:));

- (NSString*)signatureIssuerRDN:(int)signatureIndex NS_SWIFT_NAME(signatureIssuerRDN(_:));

- (int)signatureLevel:(int)signatureIndex NS_SWIFT_NAME(signatureLevel(_:));

- (NSString*)signaturePolicyHash:(int)signatureIndex NS_SWIFT_NAME(signaturePolicyHash(_:));

- (NSString*)signaturePolicyHashAlgorithm:(int)signatureIndex NS_SWIFT_NAME(signaturePolicyHashAlgorithm(_:));

- (NSString*)signaturePolicyID:(int)signatureIndex NS_SWIFT_NAME(signaturePolicyID(_:));

- (NSString*)signaturePolicyURI:(int)signatureIndex NS_SWIFT_NAME(signaturePolicyURI(_:));

- (NSData*)signatureSerialNumber:(int)signatureIndex NS_SWIFT_NAME(signatureSerialNumber(_:));

- (NSData*)signatureSignatureBytes:(int)signatureIndex NS_SWIFT_NAME(signatureSignatureBytes(_:));

- (int)signatureSignatureType:(int)signatureIndex NS_SWIFT_NAME(signatureSignatureType(_:));

- (int)signatureSignatureValidationResult:(int)signatureIndex NS_SWIFT_NAME(signatureSignatureValidationResult(_:));

- (NSString*)signatureSignedFiles:(int)signatureIndex NS_SWIFT_NAME(signatureSignedFiles(_:));

- (NSData*)signatureSubjectKeyID:(int)signatureIndex NS_SWIFT_NAME(signatureSubjectKeyID(_:));

- (NSString*)signatureSubjectRDN:(int)signatureIndex NS_SWIFT_NAME(signatureSubjectRDN(_:));

- (BOOL)signatureTimestamped:(int)signatureIndex NS_SWIFT_NAME(signatureTimestamped(_:));

- (NSString*)signatureValidatedSigningTime:(int)signatureIndex NS_SWIFT_NAME(signatureValidatedSigningTime(_:));

- (NSString*)signatureValidationLog:(int)signatureIndex NS_SWIFT_NAME(signatureValidationLog(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSMode,setter=setSocketDNSMode:) int socketDNSMode NS_SWIFT_NAME(socketDNSMode);

- (int)socketDNSMode NS_SWIFT_NAME(socketDNSMode());
- (void)setSocketDNSMode :(int)newSocketDNSMode NS_SWIFT_NAME(setSocketDNSMode(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSPort,setter=setSocketDNSPort:) int socketDNSPort NS_SWIFT_NAME(socketDNSPort);

- (int)socketDNSPort NS_SWIFT_NAME(socketDNSPort());
- (void)setSocketDNSPort :(int)newSocketDNSPort NS_SWIFT_NAME(setSocketDNSPort(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSQueryTimeout,setter=setSocketDNSQueryTimeout:) int socketDNSQueryTimeout NS_SWIFT_NAME(socketDNSQueryTimeout);

- (int)socketDNSQueryTimeout NS_SWIFT_NAME(socketDNSQueryTimeout());
- (void)setSocketDNSQueryTimeout :(int)newSocketDNSQueryTimeout NS_SWIFT_NAME(setSocketDNSQueryTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSServers,setter=setSocketDNSServers:) NSString* socketDNSServers NS_SWIFT_NAME(socketDNSServers);

- (NSString*)socketDNSServers NS_SWIFT_NAME(socketDNSServers());
- (void)setSocketDNSServers :(NSString*)newSocketDNSServers NS_SWIFT_NAME(setSocketDNSServers(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSTotalTimeout,setter=setSocketDNSTotalTimeout:) int socketDNSTotalTimeout NS_SWIFT_NAME(socketDNSTotalTimeout);

- (int)socketDNSTotalTimeout NS_SWIFT_NAME(socketDNSTotalTimeout());
- (void)setSocketDNSTotalTimeout :(int)newSocketDNSTotalTimeout NS_SWIFT_NAME(setSocketDNSTotalTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketIncomingSpeedLimit,setter=setSocketIncomingSpeedLimit:) int socketIncomingSpeedLimit NS_SWIFT_NAME(socketIncomingSpeedLimit);

- (int)socketIncomingSpeedLimit NS_SWIFT_NAME(socketIncomingSpeedLimit());
- (void)setSocketIncomingSpeedLimit :(int)newSocketIncomingSpeedLimit NS_SWIFT_NAME(setSocketIncomingSpeedLimit(_:));

@property (nonatomic,readwrite,assign,getter=socketLocalAddress,setter=setSocketLocalAddress:) NSString* socketLocalAddress NS_SWIFT_NAME(socketLocalAddress);

- (NSString*)socketLocalAddress NS_SWIFT_NAME(socketLocalAddress());
- (void)setSocketLocalAddress :(NSString*)newSocketLocalAddress NS_SWIFT_NAME(setSocketLocalAddress(_:));

@property (nonatomic,readwrite,assign,getter=socketLocalPort,setter=setSocketLocalPort:) int socketLocalPort NS_SWIFT_NAME(socketLocalPort);

- (int)socketLocalPort NS_SWIFT_NAME(socketLocalPort());
- (void)setSocketLocalPort :(int)newSocketLocalPort NS_SWIFT_NAME(setSocketLocalPort(_:));

@property (nonatomic,readwrite,assign,getter=socketOutgoingSpeedLimit,setter=setSocketOutgoingSpeedLimit:) int socketOutgoingSpeedLimit NS_SWIFT_NAME(socketOutgoingSpeedLimit);

- (int)socketOutgoingSpeedLimit NS_SWIFT_NAME(socketOutgoingSpeedLimit());
- (void)setSocketOutgoingSpeedLimit :(int)newSocketOutgoingSpeedLimit NS_SWIFT_NAME(setSocketOutgoingSpeedLimit(_:));

@property (nonatomic,readwrite,assign,getter=socketTimeout,setter=setSocketTimeout:) int socketTimeout NS_SWIFT_NAME(socketTimeout);

- (int)socketTimeout NS_SWIFT_NAME(socketTimeout());
- (void)setSocketTimeout :(int)newSocketTimeout NS_SWIFT_NAME(setSocketTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketUseIPv6,setter=setSocketUseIPv6:) BOOL socketUseIPv6 NS_SWIFT_NAME(socketUseIPv6);

- (BOOL)socketUseIPv6 NS_SWIFT_NAME(socketUseIPv6());
- (void)setSocketUseIPv6 :(BOOL)newSocketUseIPv6 NS_SWIFT_NAME(setSocketUseIPv6(_:));

@property (nonatomic,readonly,assign,getter=timestampCount) int timestampCount NS_SWIFT_NAME(timestampCount);

- (int)timestampCount NS_SWIFT_NAME(timestampCount());

- (long long)timestampAccuracy:(int)timestampIndex NS_SWIFT_NAME(timestampAccuracy(_:));

- (NSData*)timestampBytes:(int)timestampIndex NS_SWIFT_NAME(timestampBytes(_:));

- (int)timestampCertificateIndex:(int)timestampIndex NS_SWIFT_NAME(timestampCertificateIndex(_:));

- (int)timestampChainValidationDetails:(int)timestampIndex NS_SWIFT_NAME(timestampChainValidationDetails(_:));

- (int)timestampChainValidationResult:(int)timestampIndex NS_SWIFT_NAME(timestampChainValidationResult(_:));

- (BOOL)timestampContainsLongTermInfo:(int)timestampIndex NS_SWIFT_NAME(timestampContainsLongTermInfo(_:));

- (NSString*)timestampEntityLabel:(int)timestampIndex NS_SWIFT_NAME(timestampEntityLabel(_:));

- (NSString*)timestampHashAlgorithm:(int)timestampIndex NS_SWIFT_NAME(timestampHashAlgorithm(_:));

- (NSString*)timestampParentEntity:(int)timestampIndex NS_SWIFT_NAME(timestampParentEntity(_:));

- (NSData*)timestampSerialNumber:(int)timestampIndex NS_SWIFT_NAME(timestampSerialNumber(_:));

- (NSString*)timestampTime:(int)timestampIndex NS_SWIFT_NAME(timestampTime(_:));

- (int)timestampTimestampType:(int)timestampIndex NS_SWIFT_NAME(timestampTimestampType(_:));

- (NSString*)timestampTSAName:(int)timestampIndex NS_SWIFT_NAME(timestampTSAName(_:));

- (NSString*)timestampValidationLog:(int)timestampIndex NS_SWIFT_NAME(timestampValidationLog(_:));

- (int)timestampValidationResult:(int)timestampIndex NS_SWIFT_NAME(timestampValidationResult(_:));

@property (nonatomic,readwrite,assign,getter=TLSClientCertCount,setter=setTLSClientCertCount:) int TLSClientCertCount NS_SWIFT_NAME(TLSClientCertCount);

- (int)TLSClientCertCount NS_SWIFT_NAME(TLSClientCertCount());
- (void)setTLSClientCertCount :(int)newTLSClientCertCount NS_SWIFT_NAME(setTLSClientCertCount(_:));

- (NSData*)TLSClientCertBytes:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertBytes(_:));

- (BOOL)TLSClientCertCA:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCA(_:));
- (void)setTLSClientCertCA:(int)tLSClientCertIndex :(BOOL)newTLSClientCertCA NS_SWIFT_NAME(setTLSClientCertCA(_:_:));

- (NSData*)TLSClientCertCAKeyID:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCAKeyID(_:));

- (int)TLSClientCertCertType:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCertType(_:));

- (NSString*)TLSClientCertCRLDistributionPoints:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCRLDistributionPoints(_:));
- (void)setTLSClientCertCRLDistributionPoints:(int)tLSClientCertIndex :(NSString*)newTLSClientCertCRLDistributionPoints NS_SWIFT_NAME(setTLSClientCertCRLDistributionPoints(_:_:));

- (NSString*)TLSClientCertCurve:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertCurve(_:));
- (void)setTLSClientCertCurve:(int)tLSClientCertIndex :(NSString*)newTLSClientCertCurve NS_SWIFT_NAME(setTLSClientCertCurve(_:_:));

- (NSString*)TLSClientCertFingerprint:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertFingerprint(_:));

- (NSString*)TLSClientCertFriendlyName:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertFriendlyName(_:));

- (long long)TLSClientCertHandle:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertHandle(_:));
- (void)setTLSClientCertHandle:(int)tLSClientCertIndex :(long long)newTLSClientCertHandle NS_SWIFT_NAME(setTLSClientCertHandle(_:_:));

- (NSString*)TLSClientCertHashAlgorithm:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertHashAlgorithm(_:));
- (void)setTLSClientCertHashAlgorithm:(int)tLSClientCertIndex :(NSString*)newTLSClientCertHashAlgorithm NS_SWIFT_NAME(setTLSClientCertHashAlgorithm(_:_:));

- (NSString*)TLSClientCertIssuer:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertIssuer(_:));

- (NSString*)TLSClientCertIssuerRDN:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertIssuerRDN(_:));
- (void)setTLSClientCertIssuerRDN:(int)tLSClientCertIndex :(NSString*)newTLSClientCertIssuerRDN NS_SWIFT_NAME(setTLSClientCertIssuerRDN(_:_:));

- (NSString*)TLSClientCertKeyAlgorithm:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyAlgorithm(_:));
- (void)setTLSClientCertKeyAlgorithm:(int)tLSClientCertIndex :(NSString*)newTLSClientCertKeyAlgorithm NS_SWIFT_NAME(setTLSClientCertKeyAlgorithm(_:_:));

- (int)TLSClientCertKeyBits:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyBits(_:));

- (NSString*)TLSClientCertKeyFingerprint:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyFingerprint(_:));

- (int)TLSClientCertKeyUsage:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyUsage(_:));
- (void)setTLSClientCertKeyUsage:(int)tLSClientCertIndex :(int)newTLSClientCertKeyUsage NS_SWIFT_NAME(setTLSClientCertKeyUsage(_:_:));

- (BOOL)TLSClientCertKeyValid:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertKeyValid(_:));

- (NSString*)TLSClientCertOCSPLocations:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertOCSPLocations(_:));
- (void)setTLSClientCertOCSPLocations:(int)tLSClientCertIndex :(NSString*)newTLSClientCertOCSPLocations NS_SWIFT_NAME(setTLSClientCertOCSPLocations(_:_:));

- (BOOL)TLSClientCertOCSPNoCheck:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertOCSPNoCheck(_:));
- (void)setTLSClientCertOCSPNoCheck:(int)tLSClientCertIndex :(BOOL)newTLSClientCertOCSPNoCheck NS_SWIFT_NAME(setTLSClientCertOCSPNoCheck(_:_:));

- (int)TLSClientCertOrigin:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertOrigin(_:));

- (NSString*)TLSClientCertPolicyIDs:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPolicyIDs(_:));
- (void)setTLSClientCertPolicyIDs:(int)tLSClientCertIndex :(NSString*)newTLSClientCertPolicyIDs NS_SWIFT_NAME(setTLSClientCertPolicyIDs(_:_:));

- (NSData*)TLSClientCertPrivateKeyBytes:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPrivateKeyBytes(_:));

- (BOOL)TLSClientCertPrivateKeyExists:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPrivateKeyExists(_:));

- (BOOL)TLSClientCertPrivateKeyExtractable:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPrivateKeyExtractable(_:));

- (NSData*)TLSClientCertPublicKeyBytes:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertPublicKeyBytes(_:));

- (BOOL)TLSClientCertQualified:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertQualified(_:));

- (int)TLSClientCertQualifiedStatements:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertQualifiedStatements(_:));
- (void)setTLSClientCertQualifiedStatements:(int)tLSClientCertIndex :(int)newTLSClientCertQualifiedStatements NS_SWIFT_NAME(setTLSClientCertQualifiedStatements(_:_:));

- (NSString*)TLSClientCertQualifiers:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertQualifiers(_:));

- (BOOL)TLSClientCertSelfSigned:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSelfSigned(_:));

- (NSData*)TLSClientCertSerialNumber:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSerialNumber(_:));
- (void)setTLSClientCertSerialNumber:(int)tLSClientCertIndex :(NSData*)newTLSClientCertSerialNumber NS_SWIFT_NAME(setTLSClientCertSerialNumber(_:_:));

- (NSString*)TLSClientCertSigAlgorithm:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSigAlgorithm(_:));

- (int)TLSClientCertSource:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSource(_:));

- (NSString*)TLSClientCertSubject:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSubject(_:));

- (NSString*)TLSClientCertSubjectAlternativeName:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSubjectAlternativeName(_:));
- (void)setTLSClientCertSubjectAlternativeName:(int)tLSClientCertIndex :(NSString*)newTLSClientCertSubjectAlternativeName NS_SWIFT_NAME(setTLSClientCertSubjectAlternativeName(_:_:));

- (NSData*)TLSClientCertSubjectKeyID:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSubjectKeyID(_:));
- (void)setTLSClientCertSubjectKeyID:(int)tLSClientCertIndex :(NSData*)newTLSClientCertSubjectKeyID NS_SWIFT_NAME(setTLSClientCertSubjectKeyID(_:_:));

- (NSString*)TLSClientCertSubjectRDN:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertSubjectRDN(_:));
- (void)setTLSClientCertSubjectRDN:(int)tLSClientCertIndex :(NSString*)newTLSClientCertSubjectRDN NS_SWIFT_NAME(setTLSClientCertSubjectRDN(_:_:));

- (BOOL)TLSClientCertValid:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertValid(_:));

- (NSString*)TLSClientCertValidFrom:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertValidFrom(_:));
- (void)setTLSClientCertValidFrom:(int)tLSClientCertIndex :(NSString*)newTLSClientCertValidFrom NS_SWIFT_NAME(setTLSClientCertValidFrom(_:_:));

- (NSString*)TLSClientCertValidTo:(int)tLSClientCertIndex NS_SWIFT_NAME(TLSClientCertValidTo(_:));
- (void)setTLSClientCertValidTo:(int)tLSClientCertIndex :(NSString*)newTLSClientCertValidTo NS_SWIFT_NAME(setTLSClientCertValidTo(_:_:));

@property (nonatomic,readonly,assign,getter=TLSServerCertCount) int TLSServerCertCount NS_SWIFT_NAME(TLSServerCertCount);

- (int)TLSServerCertCount NS_SWIFT_NAME(TLSServerCertCount());

- (NSData*)TLSServerCertBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertBytes(_:));

- (BOOL)TLSServerCertCA:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCA(_:));

- (NSData*)TLSServerCertCAKeyID:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCAKeyID(_:));

- (int)TLSServerCertCertType:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCertType(_:));

- (NSString*)TLSServerCertCRLDistributionPoints:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCRLDistributionPoints(_:));

- (NSString*)TLSServerCertCurve:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCurve(_:));

- (NSString*)TLSServerCertFingerprint:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertFingerprint(_:));

- (NSString*)TLSServerCertFriendlyName:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertFriendlyName(_:));

- (long long)TLSServerCertHandle:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertHandle(_:));

- (NSString*)TLSServerCertHashAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertHashAlgorithm(_:));

- (NSString*)TLSServerCertIssuer:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertIssuer(_:));

- (NSString*)TLSServerCertIssuerRDN:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertIssuerRDN(_:));

- (NSString*)TLSServerCertKeyAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyAlgorithm(_:));

- (int)TLSServerCertKeyBits:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyBits(_:));

- (NSString*)TLSServerCertKeyFingerprint:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyFingerprint(_:));

- (int)TLSServerCertKeyUsage:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyUsage(_:));

- (BOOL)TLSServerCertKeyValid:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyValid(_:));

- (NSString*)TLSServerCertOCSPLocations:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOCSPLocations(_:));

- (BOOL)TLSServerCertOCSPNoCheck:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOCSPNoCheck(_:));

- (int)TLSServerCertOrigin:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOrigin(_:));

- (NSString*)TLSServerCertPolicyIDs:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPolicyIDs(_:));

- (NSData*)TLSServerCertPrivateKeyBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyBytes(_:));

- (BOOL)TLSServerCertPrivateKeyExists:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyExists(_:));

- (BOOL)TLSServerCertPrivateKeyExtractable:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyExtractable(_:));

- (NSData*)TLSServerCertPublicKeyBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPublicKeyBytes(_:));

- (BOOL)TLSServerCertQualified:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualified(_:));

- (int)TLSServerCertQualifiedStatements:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualifiedStatements(_:));

- (NSString*)TLSServerCertQualifiers:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualifiers(_:));

- (BOOL)TLSServerCertSelfSigned:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSelfSigned(_:));

- (NSData*)TLSServerCertSerialNumber:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSerialNumber(_:));

- (NSString*)TLSServerCertSigAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSigAlgorithm(_:));

- (int)TLSServerCertSource:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSource(_:));

- (NSString*)TLSServerCertSubject:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubject(_:));

- (NSString*)TLSServerCertSubjectAlternativeName:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectAlternativeName(_:));

- (NSData*)TLSServerCertSubjectKeyID:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectKeyID(_:));

- (NSString*)TLSServerCertSubjectRDN:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectRDN(_:));

- (BOOL)TLSServerCertValid:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValid(_:));

- (NSString*)TLSServerCertValidFrom:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValidFrom(_:));

- (NSString*)TLSServerCertValidTo:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValidTo(_:));

@property (nonatomic,readwrite,assign,getter=TLSAutoValidateCertificates,setter=setTLSAutoValidateCertificates:) BOOL TLSAutoValidateCertificates NS_SWIFT_NAME(TLSAutoValidateCertificates);

- (BOOL)TLSAutoValidateCertificates NS_SWIFT_NAME(TLSAutoValidateCertificates());
- (void)setTLSAutoValidateCertificates :(BOOL)newTLSAutoValidateCertificates NS_SWIFT_NAME(setTLSAutoValidateCertificates(_:));

@property (nonatomic,readwrite,assign,getter=TLSBaseConfiguration,setter=setTLSBaseConfiguration:) int TLSBaseConfiguration NS_SWIFT_NAME(TLSBaseConfiguration);

- (int)TLSBaseConfiguration NS_SWIFT_NAME(TLSBaseConfiguration());
- (void)setTLSBaseConfiguration :(int)newTLSBaseConfiguration NS_SWIFT_NAME(setTLSBaseConfiguration(_:));

@property (nonatomic,readwrite,assign,getter=TLSCiphersuites,setter=setTLSCiphersuites:) NSString* TLSCiphersuites NS_SWIFT_NAME(TLSCiphersuites);

- (NSString*)TLSCiphersuites NS_SWIFT_NAME(TLSCiphersuites());
- (void)setTLSCiphersuites :(NSString*)newTLSCiphersuites NS_SWIFT_NAME(setTLSCiphersuites(_:));

@property (nonatomic,readwrite,assign,getter=TLSClientAuth,setter=setTLSClientAuth:) int TLSClientAuth NS_SWIFT_NAME(TLSClientAuth);

- (int)TLSClientAuth NS_SWIFT_NAME(TLSClientAuth());
- (void)setTLSClientAuth :(int)newTLSClientAuth NS_SWIFT_NAME(setTLSClientAuth(_:));

@property (nonatomic,readwrite,assign,getter=TLSECCurves,setter=setTLSECCurves:) NSString* TLSECCurves NS_SWIFT_NAME(TLSECCurves);

- (NSString*)TLSECCurves NS_SWIFT_NAME(TLSECCurves());
- (void)setTLSECCurves :(NSString*)newTLSECCurves NS_SWIFT_NAME(setTLSECCurves(_:));

@property (nonatomic,readwrite,assign,getter=TLSExtensions,setter=setTLSExtensions:) NSString* TLSExtensions NS_SWIFT_NAME(TLSExtensions);

- (NSString*)TLSExtensions NS_SWIFT_NAME(TLSExtensions());
- (void)setTLSExtensions :(NSString*)newTLSExtensions NS_SWIFT_NAME(setTLSExtensions(_:));

@property (nonatomic,readwrite,assign,getter=TLSForceResumeIfDestinationChanges,setter=setTLSForceResumeIfDestinationChanges:) BOOL TLSForceResumeIfDestinationChanges NS_SWIFT_NAME(TLSForceResumeIfDestinationChanges);

- (BOOL)TLSForceResumeIfDestinationChanges NS_SWIFT_NAME(TLSForceResumeIfDestinationChanges());
- (void)setTLSForceResumeIfDestinationChanges :(BOOL)newTLSForceResumeIfDestinationChanges NS_SWIFT_NAME(setTLSForceResumeIfDestinationChanges(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedIdentity,setter=setTLSPreSharedIdentity:) NSString* TLSPreSharedIdentity NS_SWIFT_NAME(TLSPreSharedIdentity);

- (NSString*)TLSPreSharedIdentity NS_SWIFT_NAME(TLSPreSharedIdentity());
- (void)setTLSPreSharedIdentity :(NSString*)newTLSPreSharedIdentity NS_SWIFT_NAME(setTLSPreSharedIdentity(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedKey,setter=setTLSPreSharedKey:) NSString* TLSPreSharedKey NS_SWIFT_NAME(TLSPreSharedKey);

- (NSString*)TLSPreSharedKey NS_SWIFT_NAME(TLSPreSharedKey());
- (void)setTLSPreSharedKey :(NSString*)newTLSPreSharedKey NS_SWIFT_NAME(setTLSPreSharedKey(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedKeyCiphersuite,setter=setTLSPreSharedKeyCiphersuite:) NSString* TLSPreSharedKeyCiphersuite NS_SWIFT_NAME(TLSPreSharedKeyCiphersuite);

- (NSString*)TLSPreSharedKeyCiphersuite NS_SWIFT_NAME(TLSPreSharedKeyCiphersuite());
- (void)setTLSPreSharedKeyCiphersuite :(NSString*)newTLSPreSharedKeyCiphersuite NS_SWIFT_NAME(setTLSPreSharedKeyCiphersuite(_:));

@property (nonatomic,readwrite,assign,getter=TLSRenegotiationAttackPreventionMode,setter=setTLSRenegotiationAttackPreventionMode:) int TLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(TLSRenegotiationAttackPreventionMode);

- (int)TLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(TLSRenegotiationAttackPreventionMode());
- (void)setTLSRenegotiationAttackPreventionMode :(int)newTLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(setTLSRenegotiationAttackPreventionMode(_:));

@property (nonatomic,readwrite,assign,getter=TLSRevocationCheck,setter=setTLSRevocationCheck:) int TLSRevocationCheck NS_SWIFT_NAME(TLSRevocationCheck);

- (int)TLSRevocationCheck NS_SWIFT_NAME(TLSRevocationCheck());
- (void)setTLSRevocationCheck :(int)newTLSRevocationCheck NS_SWIFT_NAME(setTLSRevocationCheck(_:));

@property (nonatomic,readwrite,assign,getter=TLSSSLOptions,setter=setTLSSSLOptions:) int TLSSSLOptions NS_SWIFT_NAME(TLSSSLOptions);

- (int)TLSSSLOptions NS_SWIFT_NAME(TLSSSLOptions());
- (void)setTLSSSLOptions :(int)newTLSSSLOptions NS_SWIFT_NAME(setTLSSSLOptions(_:));

@property (nonatomic,readwrite,assign,getter=TLSTLSMode,setter=setTLSTLSMode:) int TLSTLSMode NS_SWIFT_NAME(TLSTLSMode);

- (int)TLSTLSMode NS_SWIFT_NAME(TLSTLSMode());
- (void)setTLSTLSMode :(int)newTLSTLSMode NS_SWIFT_NAME(setTLSTLSMode(_:));

@property (nonatomic,readwrite,assign,getter=TLSUseExtendedMasterSecret,setter=setTLSUseExtendedMasterSecret:) BOOL TLSUseExtendedMasterSecret NS_SWIFT_NAME(TLSUseExtendedMasterSecret);

- (BOOL)TLSUseExtendedMasterSecret NS_SWIFT_NAME(TLSUseExtendedMasterSecret());
- (void)setTLSUseExtendedMasterSecret :(BOOL)newTLSUseExtendedMasterSecret NS_SWIFT_NAME(setTLSUseExtendedMasterSecret(_:));

@property (nonatomic,readwrite,assign,getter=TLSUseSessionResumption,setter=setTLSUseSessionResumption:) BOOL TLSUseSessionResumption NS_SWIFT_NAME(TLSUseSessionResumption);

- (BOOL)TLSUseSessionResumption NS_SWIFT_NAME(TLSUseSessionResumption());
- (void)setTLSUseSessionResumption :(BOOL)newTLSUseSessionResumption NS_SWIFT_NAME(setTLSUseSessionResumption(_:));

@property (nonatomic,readwrite,assign,getter=TLSVersions,setter=setTLSVersions:) int TLSVersions NS_SWIFT_NAME(TLSVersions);

- (int)TLSVersions NS_SWIFT_NAME(TLSVersions());
- (void)setTLSVersions :(int)newTLSVersions NS_SWIFT_NAME(setTLSVersions(_:));

@property (nonatomic,readwrite,assign,getter=trustedCertCount,setter=setTrustedCertCount:) int trustedCertCount NS_SWIFT_NAME(trustedCertCount);

- (int)trustedCertCount NS_SWIFT_NAME(trustedCertCount());
- (void)setTrustedCertCount :(int)newTrustedCertCount NS_SWIFT_NAME(setTrustedCertCount(_:));

- (NSData*)trustedCertBytes:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertBytes(_:));

- (BOOL)trustedCertCA:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertCA(_:));
- (void)setTrustedCertCA:(int)trustedCertIndex :(BOOL)newTrustedCertCA NS_SWIFT_NAME(setTrustedCertCA(_:_:));

- (NSData*)trustedCertCAKeyID:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertCAKeyID(_:));

- (int)trustedCertCertType:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertCertType(_:));

- (NSString*)trustedCertCRLDistributionPoints:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertCRLDistributionPoints(_:));
- (void)setTrustedCertCRLDistributionPoints:(int)trustedCertIndex :(NSString*)newTrustedCertCRLDistributionPoints NS_SWIFT_NAME(setTrustedCertCRLDistributionPoints(_:_:));

- (NSString*)trustedCertCurve:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertCurve(_:));
- (void)setTrustedCertCurve:(int)trustedCertIndex :(NSString*)newTrustedCertCurve NS_SWIFT_NAME(setTrustedCertCurve(_:_:));

- (NSString*)trustedCertFingerprint:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertFingerprint(_:));

- (NSString*)trustedCertFriendlyName:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertFriendlyName(_:));

- (long long)trustedCertHandle:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertHandle(_:));
- (void)setTrustedCertHandle:(int)trustedCertIndex :(long long)newTrustedCertHandle NS_SWIFT_NAME(setTrustedCertHandle(_:_:));

- (NSString*)trustedCertHashAlgorithm:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertHashAlgorithm(_:));
- (void)setTrustedCertHashAlgorithm:(int)trustedCertIndex :(NSString*)newTrustedCertHashAlgorithm NS_SWIFT_NAME(setTrustedCertHashAlgorithm(_:_:));

- (NSString*)trustedCertIssuer:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertIssuer(_:));

- (NSString*)trustedCertIssuerRDN:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertIssuerRDN(_:));
- (void)setTrustedCertIssuerRDN:(int)trustedCertIndex :(NSString*)newTrustedCertIssuerRDN NS_SWIFT_NAME(setTrustedCertIssuerRDN(_:_:));

- (NSString*)trustedCertKeyAlgorithm:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertKeyAlgorithm(_:));
- (void)setTrustedCertKeyAlgorithm:(int)trustedCertIndex :(NSString*)newTrustedCertKeyAlgorithm NS_SWIFT_NAME(setTrustedCertKeyAlgorithm(_:_:));

- (int)trustedCertKeyBits:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertKeyBits(_:));

- (NSString*)trustedCertKeyFingerprint:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertKeyFingerprint(_:));

- (int)trustedCertKeyUsage:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertKeyUsage(_:));
- (void)setTrustedCertKeyUsage:(int)trustedCertIndex :(int)newTrustedCertKeyUsage NS_SWIFT_NAME(setTrustedCertKeyUsage(_:_:));

- (BOOL)trustedCertKeyValid:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertKeyValid(_:));

- (NSString*)trustedCertOCSPLocations:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertOCSPLocations(_:));
- (void)setTrustedCertOCSPLocations:(int)trustedCertIndex :(NSString*)newTrustedCertOCSPLocations NS_SWIFT_NAME(setTrustedCertOCSPLocations(_:_:));

- (BOOL)trustedCertOCSPNoCheck:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertOCSPNoCheck(_:));
- (void)setTrustedCertOCSPNoCheck:(int)trustedCertIndex :(BOOL)newTrustedCertOCSPNoCheck NS_SWIFT_NAME(setTrustedCertOCSPNoCheck(_:_:));

- (int)trustedCertOrigin:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertOrigin(_:));

- (NSString*)trustedCertPolicyIDs:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertPolicyIDs(_:));
- (void)setTrustedCertPolicyIDs:(int)trustedCertIndex :(NSString*)newTrustedCertPolicyIDs NS_SWIFT_NAME(setTrustedCertPolicyIDs(_:_:));

- (NSData*)trustedCertPrivateKeyBytes:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertPrivateKeyBytes(_:));

- (BOOL)trustedCertPrivateKeyExists:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertPrivateKeyExists(_:));

- (BOOL)trustedCertPrivateKeyExtractable:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertPrivateKeyExtractable(_:));

- (NSData*)trustedCertPublicKeyBytes:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertPublicKeyBytes(_:));

- (BOOL)trustedCertQualified:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertQualified(_:));

- (int)trustedCertQualifiedStatements:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertQualifiedStatements(_:));
- (void)setTrustedCertQualifiedStatements:(int)trustedCertIndex :(int)newTrustedCertQualifiedStatements NS_SWIFT_NAME(setTrustedCertQualifiedStatements(_:_:));

- (NSString*)trustedCertQualifiers:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertQualifiers(_:));

- (BOOL)trustedCertSelfSigned:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSelfSigned(_:));

- (NSData*)trustedCertSerialNumber:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSerialNumber(_:));
- (void)setTrustedCertSerialNumber:(int)trustedCertIndex :(NSData*)newTrustedCertSerialNumber NS_SWIFT_NAME(setTrustedCertSerialNumber(_:_:));

- (NSString*)trustedCertSigAlgorithm:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSigAlgorithm(_:));

- (int)trustedCertSource:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSource(_:));

- (NSString*)trustedCertSubject:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSubject(_:));

- (NSString*)trustedCertSubjectAlternativeName:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSubjectAlternativeName(_:));
- (void)setTrustedCertSubjectAlternativeName:(int)trustedCertIndex :(NSString*)newTrustedCertSubjectAlternativeName NS_SWIFT_NAME(setTrustedCertSubjectAlternativeName(_:_:));

- (NSData*)trustedCertSubjectKeyID:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSubjectKeyID(_:));
- (void)setTrustedCertSubjectKeyID:(int)trustedCertIndex :(NSData*)newTrustedCertSubjectKeyID NS_SWIFT_NAME(setTrustedCertSubjectKeyID(_:_:));

- (NSString*)trustedCertSubjectRDN:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertSubjectRDN(_:));
- (void)setTrustedCertSubjectRDN:(int)trustedCertIndex :(NSString*)newTrustedCertSubjectRDN NS_SWIFT_NAME(setTrustedCertSubjectRDN(_:_:));

- (BOOL)trustedCertValid:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertValid(_:));

- (NSString*)trustedCertValidFrom:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertValidFrom(_:));
- (void)setTrustedCertValidFrom:(int)trustedCertIndex :(NSString*)newTrustedCertValidFrom NS_SWIFT_NAME(setTrustedCertValidFrom(_:_:));

- (NSString*)trustedCertValidTo:(int)trustedCertIndex NS_SWIFT_NAME(trustedCertValidTo(_:));
- (void)setTrustedCertValidTo:(int)trustedCertIndex :(NSString*)newTrustedCertValidTo NS_SWIFT_NAME(setTrustedCertValidTo(_:_:));

@property (nonatomic,readwrite,assign,getter=validationMoment,setter=setValidationMoment:) NSString* validationMoment NS_SWIFT_NAME(validationMoment);

- (NSString*)validationMoment NS_SWIFT_NAME(validationMoment());
- (void)setValidationMoment :(NSString*)newValidationMoment NS_SWIFT_NAME(setValidationMoment(_:));

  /* Methods */

- (void)close:(BOOL)saveChanges NS_SWIFT_NAME(close(_:));

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (void)extractFile:(NSString*)fileName NS_SWIFT_NAME(extractFile(_:));

- (void)extractFiles:(NSString*)sigLabel NS_SWIFT_NAME(extractFiles(_:));

- (void)open NS_SWIFT_NAME(open());

- (void)reset NS_SWIFT_NAME(reset());

- (void)revalidate:(NSString*)sigLabel NS_SWIFT_NAME(revalidate(_:));

- (void)selectInfo:(NSString*)entityLabel :(int)infoType :(BOOL)clearSelection NS_SWIFT_NAME(selectInfo(_:_:_:));

- (void)unsign:(NSString*)sigLabel NS_SWIFT_NAME(unsign(_:));

- (void)verify NS_SWIFT_NAME(verify());

@end

