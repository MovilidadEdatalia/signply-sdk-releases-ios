/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

//XMLDATATYPES
#define CXDT_XML                                           0

#define CXDT_BINARY                                        1

#define CXDT_BASE_64                                       2

//XMLCANONICALIZATIONMETHODS
#define CXCM_NONE                                          0

#define CXCM_CANON                                         1

#define CXCM_CANON_COMMENT                                 2

#define CXCM_EXCL_CANON                                    3

#define CXCM_EXCL_CANON_COMMENT                            4

#define CXCM_MIN_CANON                                     5

#define CXCM_CANON_V_1_1                                   6

#define CXCM_CANON_COMMENT_V_1_1                           7

//XMLREFERENCETARGETTYPES
#define RTT_AUTO                                           0

#define RTT_XMLELEMENT                                     1

#define RTT_DATA                                           2

#define RTT_URI                                            3

//XMLSIGNATURETYPES
#define CXST_DETACHED                                      1

#define CXST_ENVELOPING                                    2

#define CXST_ENVELOPED                                     4

//SIGNATUREVALIDITIES
#define SVT_VALID                                          0

#define SVT_UNKNOWN                                        1

#define SVT_CORRUPTED                                      2

#define SVT_SIGNER_NOT_FOUND                               3

#define SVT_FAILURE                                        4

#define SVT_REFERENCE_CORRUPTED                            5

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxXMLVerifierDelegate <NSObject>
@optional
- (void)onDocumentLoaded:(int*)cancel NS_SWIFT_NAME(onDocumentLoaded(_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onReferenceValidated:(int)referenceIndex :(NSString*)ID :(NSString*)URI :(NSString*)refType :(BOOL)digestValid NS_SWIFT_NAME(onReferenceValidated(_:_:_:_:_:));

- (void)onResolveReference:(int)referenceIndex :(NSString*)URI NS_SWIFT_NAME(onResolveReference(_:_:));

- (void)onSignatureFound:(int)index :(NSString*)entityLabel :(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(BOOL)certFound :(int*)validateSignature :(int*)validateChain NS_SWIFT_NAME(onSignatureFound(_:_:_:_:_:_:_:_:));

- (void)onSignatureValidated:(int)index :(NSString*)entityLabel :(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(int)validationResult :(int*)cancel NS_SWIFT_NAME(onSignatureValidated(_:_:_:_:_:_:_:));

@end

@interface SecureBlackboxXMLVerifier : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxXMLVerifierDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasDocumentLoaded;

  BOOL m_delegateHasError;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasReferenceValidated;

  BOOL m_delegateHasResolveReference;

  BOOL m_delegateHasSignatureFound;

  BOOL m_delegateHasSignatureValidated;

}

+ (SecureBlackboxXMLVerifier*)xmlverifier;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxXMLVerifierDelegate> delegate;
- (id <SecureBlackboxXMLVerifierDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxXMLVerifierDelegate>)anObject;

  /* Events */

- (void)onDocumentLoaded:(int*)cancel NS_SWIFT_NAME(onDocumentLoaded(_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onReferenceValidated:(int)referenceIndex :(NSString*)ID :(NSString*)URI :(NSString*)refType :(BOOL)digestValid NS_SWIFT_NAME(onReferenceValidated(_:_:_:_:_:));

- (void)onResolveReference:(int)referenceIndex :(NSString*)URI NS_SWIFT_NAME(onResolveReference(_:_:));

- (void)onSignatureFound:(int)index :(NSString*)entityLabel :(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(BOOL)certFound :(int*)validateSignature :(int*)validateChain NS_SWIFT_NAME(onSignatureFound(_:_:_:_:_:_:_:_:));

- (void)onSignatureValidated:(int)index :(NSString*)entityLabel :(NSString*)issuerRDN :(NSData*)serialNumber :(NSData*)subjectKeyID :(int)validationResult :(int*)cancel NS_SWIFT_NAME(onSignatureValidated(_:_:_:_:_:_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readonly,assign,getter=allSignaturesValid) BOOL allSignaturesValid NS_SWIFT_NAME(allSignaturesValid);

- (BOOL)allSignaturesValid NS_SWIFT_NAME(allSignaturesValid());

@property (nonatomic,readwrite,assign,getter=autoValidateSignatures,setter=setAutoValidateSignatures:) BOOL autoValidateSignatures NS_SWIFT_NAME(autoValidateSignatures);

- (BOOL)autoValidateSignatures NS_SWIFT_NAME(autoValidateSignatures());
- (void)setAutoValidateSignatures :(BOOL)newAutoValidateSignatures NS_SWIFT_NAME(setAutoValidateSignatures(_:));

@property (nonatomic,readonly,assign,getter=certCount) int certCount NS_SWIFT_NAME(certCount);

- (int)certCount NS_SWIFT_NAME(certCount());

- (NSData*)certBytes:(int)certIndex NS_SWIFT_NAME(certBytes(_:));

- (BOOL)certCA:(int)certIndex NS_SWIFT_NAME(certCA(_:));

- (NSData*)certCAKeyID:(int)certIndex NS_SWIFT_NAME(certCAKeyID(_:));

- (int)certCertType:(int)certIndex NS_SWIFT_NAME(certCertType(_:));

- (NSString*)certCRLDistributionPoints:(int)certIndex NS_SWIFT_NAME(certCRLDistributionPoints(_:));

- (NSString*)certCurve:(int)certIndex NS_SWIFT_NAME(certCurve(_:));

- (NSString*)certFingerprint:(int)certIndex NS_SWIFT_NAME(certFingerprint(_:));

- (NSString*)certFriendlyName:(int)certIndex NS_SWIFT_NAME(certFriendlyName(_:));

- (long long)certHandle:(int)certIndex NS_SWIFT_NAME(certHandle(_:));

- (NSString*)certHashAlgorithm:(int)certIndex NS_SWIFT_NAME(certHashAlgorithm(_:));

- (NSString*)certIssuer:(int)certIndex NS_SWIFT_NAME(certIssuer(_:));

- (NSString*)certIssuerRDN:(int)certIndex NS_SWIFT_NAME(certIssuerRDN(_:));

- (NSString*)certKeyAlgorithm:(int)certIndex NS_SWIFT_NAME(certKeyAlgorithm(_:));

- (int)certKeyBits:(int)certIndex NS_SWIFT_NAME(certKeyBits(_:));

- (NSString*)certKeyFingerprint:(int)certIndex NS_SWIFT_NAME(certKeyFingerprint(_:));

- (int)certKeyUsage:(int)certIndex NS_SWIFT_NAME(certKeyUsage(_:));

- (BOOL)certKeyValid:(int)certIndex NS_SWIFT_NAME(certKeyValid(_:));

- (NSString*)certOCSPLocations:(int)certIndex NS_SWIFT_NAME(certOCSPLocations(_:));

- (BOOL)certOCSPNoCheck:(int)certIndex NS_SWIFT_NAME(certOCSPNoCheck(_:));

- (int)certOrigin:(int)certIndex NS_SWIFT_NAME(certOrigin(_:));

- (NSString*)certPolicyIDs:(int)certIndex NS_SWIFT_NAME(certPolicyIDs(_:));

- (NSData*)certPrivateKeyBytes:(int)certIndex NS_SWIFT_NAME(certPrivateKeyBytes(_:));

- (BOOL)certPrivateKeyExists:(int)certIndex NS_SWIFT_NAME(certPrivateKeyExists(_:));

- (BOOL)certPrivateKeyExtractable:(int)certIndex NS_SWIFT_NAME(certPrivateKeyExtractable(_:));

- (NSData*)certPublicKeyBytes:(int)certIndex NS_SWIFT_NAME(certPublicKeyBytes(_:));

- (BOOL)certQualified:(int)certIndex NS_SWIFT_NAME(certQualified(_:));

- (int)certQualifiedStatements:(int)certIndex NS_SWIFT_NAME(certQualifiedStatements(_:));

- (NSString*)certQualifiers:(int)certIndex NS_SWIFT_NAME(certQualifiers(_:));

- (BOOL)certSelfSigned:(int)certIndex NS_SWIFT_NAME(certSelfSigned(_:));

- (NSData*)certSerialNumber:(int)certIndex NS_SWIFT_NAME(certSerialNumber(_:));

- (NSString*)certSigAlgorithm:(int)certIndex NS_SWIFT_NAME(certSigAlgorithm(_:));

- (int)certSource:(int)certIndex NS_SWIFT_NAME(certSource(_:));

- (NSString*)certSubject:(int)certIndex NS_SWIFT_NAME(certSubject(_:));

- (NSString*)certSubjectAlternativeName:(int)certIndex NS_SWIFT_NAME(certSubjectAlternativeName(_:));

- (NSData*)certSubjectKeyID:(int)certIndex NS_SWIFT_NAME(certSubjectKeyID(_:));

- (NSString*)certSubjectRDN:(int)certIndex NS_SWIFT_NAME(certSubjectRDN(_:));

- (BOOL)certValid:(int)certIndex NS_SWIFT_NAME(certValid(_:));

- (NSString*)certValidFrom:(int)certIndex NS_SWIFT_NAME(certValidFrom(_:));

- (NSString*)certValidTo:(int)certIndex NS_SWIFT_NAME(certValidTo(_:));

@property (nonatomic,readwrite,assign,getter=dataBytes,setter=setDataBytes:) NSData* dataBytes NS_SWIFT_NAME(dataBytes);

- (NSData*)dataBytes NS_SWIFT_NAME(dataBytes());
- (void)setDataBytes :(NSData*)newDataBytes NS_SWIFT_NAME(setDataBytes(_:));

@property (nonatomic,readwrite,assign,getter=dataFile,setter=setDataFile:) NSString* dataFile NS_SWIFT_NAME(dataFile);

- (NSString*)dataFile NS_SWIFT_NAME(dataFile());
- (void)setDataFile :(NSString*)newDataFile NS_SWIFT_NAME(setDataFile(_:));

@property (nonatomic,readwrite,assign,getter=dataType,setter=setDataType:) int dataType NS_SWIFT_NAME(dataType);

- (int)dataType NS_SWIFT_NAME(dataType());
- (void)setDataType :(int)newDataType NS_SWIFT_NAME(setDataType(_:));

@property (nonatomic,readwrite,assign,getter=dataURI,setter=setDataURI:) NSString* dataURI NS_SWIFT_NAME(dataURI);

- (NSString*)dataURI NS_SWIFT_NAME(dataURI());
- (void)setDataURI :(NSString*)newDataURI NS_SWIFT_NAME(setDataURI(_:));

@property (nonatomic,readwrite,assign,getter=encoding,setter=setEncoding:) NSString* encoding NS_SWIFT_NAME(encoding);

- (NSString*)encoding NS_SWIFT_NAME(encoding());
- (void)setEncoding :(NSString*)newEncoding NS_SWIFT_NAME(setEncoding(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=inputBytes,setter=setInputBytes:) NSData* inputBytes NS_SWIFT_NAME(inputBytes);

- (NSData*)inputBytes NS_SWIFT_NAME(inputBytes());
- (void)setInputBytes :(NSData*)newInputBytes NS_SWIFT_NAME(setInputBytes(_:));

@property (nonatomic,readwrite,assign,getter=inputFile,setter=setInputFile:) NSString* inputFile NS_SWIFT_NAME(inputFile);

- (NSString*)inputFile NS_SWIFT_NAME(inputFile());
- (void)setInputFile :(NSString*)newInputFile NS_SWIFT_NAME(setInputFile(_:));

@property (nonatomic,readwrite,assign,getter=knownCertCount,setter=setKnownCertCount:) int knownCertCount NS_SWIFT_NAME(knownCertCount);

- (int)knownCertCount NS_SWIFT_NAME(knownCertCount());
- (void)setKnownCertCount :(int)newKnownCertCount NS_SWIFT_NAME(setKnownCertCount(_:));

- (NSData*)knownCertBytes:(int)knownCertIndex NS_SWIFT_NAME(knownCertBytes(_:));

- (BOOL)knownCertCA:(int)knownCertIndex NS_SWIFT_NAME(knownCertCA(_:));
- (void)setKnownCertCA:(int)knownCertIndex :(BOOL)newKnownCertCA NS_SWIFT_NAME(setKnownCertCA(_:_:));

- (NSData*)knownCertCAKeyID:(int)knownCertIndex NS_SWIFT_NAME(knownCertCAKeyID(_:));

- (int)knownCertCertType:(int)knownCertIndex NS_SWIFT_NAME(knownCertCertType(_:));

- (NSString*)knownCertCRLDistributionPoints:(int)knownCertIndex NS_SWIFT_NAME(knownCertCRLDistributionPoints(_:));
- (void)setKnownCertCRLDistributionPoints:(int)knownCertIndex :(NSString*)newKnownCertCRLDistributionPoints NS_SWIFT_NAME(setKnownCertCRLDistributionPoints(_:_:));

- (NSString*)knownCertCurve:(int)knownCertIndex NS_SWIFT_NAME(knownCertCurve(_:));
- (void)setKnownCertCurve:(int)knownCertIndex :(NSString*)newKnownCertCurve NS_SWIFT_NAME(setKnownCertCurve(_:_:));

- (NSString*)knownCertFingerprint:(int)knownCertIndex NS_SWIFT_NAME(knownCertFingerprint(_:));

- (NSString*)knownCertFriendlyName:(int)knownCertIndex NS_SWIFT_NAME(knownCertFriendlyName(_:));

- (long long)knownCertHandle:(int)knownCertIndex NS_SWIFT_NAME(knownCertHandle(_:));
- (void)setKnownCertHandle:(int)knownCertIndex :(long long)newKnownCertHandle NS_SWIFT_NAME(setKnownCertHandle(_:_:));

- (NSString*)knownCertHashAlgorithm:(int)knownCertIndex NS_SWIFT_NAME(knownCertHashAlgorithm(_:));
- (void)setKnownCertHashAlgorithm:(int)knownCertIndex :(NSString*)newKnownCertHashAlgorithm NS_SWIFT_NAME(setKnownCertHashAlgorithm(_:_:));

- (NSString*)knownCertIssuer:(int)knownCertIndex NS_SWIFT_NAME(knownCertIssuer(_:));

- (NSString*)knownCertIssuerRDN:(int)knownCertIndex NS_SWIFT_NAME(knownCertIssuerRDN(_:));
- (void)setKnownCertIssuerRDN:(int)knownCertIndex :(NSString*)newKnownCertIssuerRDN NS_SWIFT_NAME(setKnownCertIssuerRDN(_:_:));

- (NSString*)knownCertKeyAlgorithm:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyAlgorithm(_:));
- (void)setKnownCertKeyAlgorithm:(int)knownCertIndex :(NSString*)newKnownCertKeyAlgorithm NS_SWIFT_NAME(setKnownCertKeyAlgorithm(_:_:));

- (int)knownCertKeyBits:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyBits(_:));

- (NSString*)knownCertKeyFingerprint:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyFingerprint(_:));

- (int)knownCertKeyUsage:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyUsage(_:));
- (void)setKnownCertKeyUsage:(int)knownCertIndex :(int)newKnownCertKeyUsage NS_SWIFT_NAME(setKnownCertKeyUsage(_:_:));

- (BOOL)knownCertKeyValid:(int)knownCertIndex NS_SWIFT_NAME(knownCertKeyValid(_:));

- (NSString*)knownCertOCSPLocations:(int)knownCertIndex NS_SWIFT_NAME(knownCertOCSPLocations(_:));
- (void)setKnownCertOCSPLocations:(int)knownCertIndex :(NSString*)newKnownCertOCSPLocations NS_SWIFT_NAME(setKnownCertOCSPLocations(_:_:));

- (BOOL)knownCertOCSPNoCheck:(int)knownCertIndex NS_SWIFT_NAME(knownCertOCSPNoCheck(_:));
- (void)setKnownCertOCSPNoCheck:(int)knownCertIndex :(BOOL)newKnownCertOCSPNoCheck NS_SWIFT_NAME(setKnownCertOCSPNoCheck(_:_:));

- (int)knownCertOrigin:(int)knownCertIndex NS_SWIFT_NAME(knownCertOrigin(_:));

- (NSString*)knownCertPolicyIDs:(int)knownCertIndex NS_SWIFT_NAME(knownCertPolicyIDs(_:));
- (void)setKnownCertPolicyIDs:(int)knownCertIndex :(NSString*)newKnownCertPolicyIDs NS_SWIFT_NAME(setKnownCertPolicyIDs(_:_:));

- (NSData*)knownCertPrivateKeyBytes:(int)knownCertIndex NS_SWIFT_NAME(knownCertPrivateKeyBytes(_:));

- (BOOL)knownCertPrivateKeyExists:(int)knownCertIndex NS_SWIFT_NAME(knownCertPrivateKeyExists(_:));

- (BOOL)knownCertPrivateKeyExtractable:(int)knownCertIndex NS_SWIFT_NAME(knownCertPrivateKeyExtractable(_:));

- (NSData*)knownCertPublicKeyBytes:(int)knownCertIndex NS_SWIFT_NAME(knownCertPublicKeyBytes(_:));

- (BOOL)knownCertQualified:(int)knownCertIndex NS_SWIFT_NAME(knownCertQualified(_:));

- (int)knownCertQualifiedStatements:(int)knownCertIndex NS_SWIFT_NAME(knownCertQualifiedStatements(_:));
- (void)setKnownCertQualifiedStatements:(int)knownCertIndex :(int)newKnownCertQualifiedStatements NS_SWIFT_NAME(setKnownCertQualifiedStatements(_:_:));

- (NSString*)knownCertQualifiers:(int)knownCertIndex NS_SWIFT_NAME(knownCertQualifiers(_:));

- (BOOL)knownCertSelfSigned:(int)knownCertIndex NS_SWIFT_NAME(knownCertSelfSigned(_:));

- (NSData*)knownCertSerialNumber:(int)knownCertIndex NS_SWIFT_NAME(knownCertSerialNumber(_:));
- (void)setKnownCertSerialNumber:(int)knownCertIndex :(NSData*)newKnownCertSerialNumber NS_SWIFT_NAME(setKnownCertSerialNumber(_:_:));

- (NSString*)knownCertSigAlgorithm:(int)knownCertIndex NS_SWIFT_NAME(knownCertSigAlgorithm(_:));

- (int)knownCertSource:(int)knownCertIndex NS_SWIFT_NAME(knownCertSource(_:));

- (NSString*)knownCertSubject:(int)knownCertIndex NS_SWIFT_NAME(knownCertSubject(_:));

- (NSString*)knownCertSubjectAlternativeName:(int)knownCertIndex NS_SWIFT_NAME(knownCertSubjectAlternativeName(_:));
- (void)setKnownCertSubjectAlternativeName:(int)knownCertIndex :(NSString*)newKnownCertSubjectAlternativeName NS_SWIFT_NAME(setKnownCertSubjectAlternativeName(_:_:));

- (NSData*)knownCertSubjectKeyID:(int)knownCertIndex NS_SWIFT_NAME(knownCertSubjectKeyID(_:));
- (void)setKnownCertSubjectKeyID:(int)knownCertIndex :(NSData*)newKnownCertSubjectKeyID NS_SWIFT_NAME(setKnownCertSubjectKeyID(_:_:));

- (NSString*)knownCertSubjectRDN:(int)knownCertIndex NS_SWIFT_NAME(knownCertSubjectRDN(_:));
- (void)setKnownCertSubjectRDN:(int)knownCertIndex :(NSString*)newKnownCertSubjectRDN NS_SWIFT_NAME(setKnownCertSubjectRDN(_:_:));

- (BOOL)knownCertValid:(int)knownCertIndex NS_SWIFT_NAME(knownCertValid(_:));

- (NSString*)knownCertValidFrom:(int)knownCertIndex NS_SWIFT_NAME(knownCertValidFrom(_:));
- (void)setKnownCertValidFrom:(int)knownCertIndex :(NSString*)newKnownCertValidFrom NS_SWIFT_NAME(setKnownCertValidFrom(_:_:));

- (NSString*)knownCertValidTo:(int)knownCertIndex NS_SWIFT_NAME(knownCertValidTo(_:));
- (void)setKnownCertValidTo:(int)knownCertIndex :(NSString*)newKnownCertValidTo NS_SWIFT_NAME(setKnownCertValidTo(_:_:));

@property (nonatomic,readonly,assign,getter=outputBytes) NSData* outputBytes NS_SWIFT_NAME(outputBytes);

- (NSData*)outputBytes NS_SWIFT_NAME(outputBytes());

@property (nonatomic,readwrite,assign,getter=outputFile,setter=setOutputFile:) NSString* outputFile NS_SWIFT_NAME(outputFile);

- (NSString*)outputFile NS_SWIFT_NAME(outputFile());
- (void)setOutputFile :(NSString*)newOutputFile NS_SWIFT_NAME(setOutputFile(_:));

@property (nonatomic,readonly,assign,getter=referenceCount) int referenceCount NS_SWIFT_NAME(referenceCount);

- (int)referenceCount NS_SWIFT_NAME(referenceCount());

- (BOOL)referenceAutoGenerateElementId:(int)referenceIndex NS_SWIFT_NAME(referenceAutoGenerateElementId(_:));

- (int)referenceCanonicalizationMethod:(int)referenceIndex NS_SWIFT_NAME(referenceCanonicalizationMethod(_:));

- (NSString*)referenceCustomElementId:(int)referenceIndex NS_SWIFT_NAME(referenceCustomElementId(_:));

- (NSString*)referenceDataObjectDescription:(int)referenceIndex NS_SWIFT_NAME(referenceDataObjectDescription(_:));

- (NSString*)referenceDataObjectEncoding:(int)referenceIndex NS_SWIFT_NAME(referenceDataObjectEncoding(_:));

- (NSString*)referenceDataObjectIdentifier:(int)referenceIndex NS_SWIFT_NAME(referenceDataObjectIdentifier(_:));

- (NSString*)referenceDataObjectMimeType:(int)referenceIndex NS_SWIFT_NAME(referenceDataObjectMimeType(_:));

- (NSData*)referenceDigestValue:(int)referenceIndex NS_SWIFT_NAME(referenceDigestValue(_:));

- (long long)referenceHandle:(int)referenceIndex NS_SWIFT_NAME(referenceHandle(_:));

- (BOOL)referenceHasDataObjectFormat:(int)referenceIndex NS_SWIFT_NAME(referenceHasDataObjectFormat(_:));

- (NSString*)referenceHashAlgorithm:(int)referenceIndex NS_SWIFT_NAME(referenceHashAlgorithm(_:));

- (BOOL)referenceHasURI:(int)referenceIndex NS_SWIFT_NAME(referenceHasURI(_:));

- (NSString*)referenceID:(int)referenceIndex NS_SWIFT_NAME(referenceID(_:));

- (NSString*)referenceInclusiveNamespacesPrefixList:(int)referenceIndex NS_SWIFT_NAME(referenceInclusiveNamespacesPrefixList(_:));

- (NSString*)referenceReferenceType:(int)referenceIndex NS_SWIFT_NAME(referenceReferenceType(_:));

- (NSData*)referenceTargetData:(int)referenceIndex NS_SWIFT_NAME(referenceTargetData(_:));

- (int)referenceTargetType:(int)referenceIndex NS_SWIFT_NAME(referenceTargetType(_:));

- (NSString*)referenceTargetXMLElement:(int)referenceIndex NS_SWIFT_NAME(referenceTargetXMLElement(_:));

- (NSString*)referenceURI:(int)referenceIndex NS_SWIFT_NAME(referenceURI(_:));

- (BOOL)referenceUseBase64Transform:(int)referenceIndex NS_SWIFT_NAME(referenceUseBase64Transform(_:));

- (BOOL)referenceUseEnvelopedSignatureTransform:(int)referenceIndex NS_SWIFT_NAME(referenceUseEnvelopedSignatureTransform(_:));

- (BOOL)referenceUseXPathFilter2Transform:(int)referenceIndex NS_SWIFT_NAME(referenceUseXPathFilter2Transform(_:));

- (BOOL)referenceUseXPathTransform:(int)referenceIndex NS_SWIFT_NAME(referenceUseXPathTransform(_:));

- (BOOL)referenceValidationResult:(int)referenceIndex NS_SWIFT_NAME(referenceValidationResult(_:));

- (NSString*)referenceXPathExpression:(int)referenceIndex NS_SWIFT_NAME(referenceXPathExpression(_:));

- (NSString*)referenceXPathFilter2Expressions:(int)referenceIndex NS_SWIFT_NAME(referenceXPathFilter2Expressions(_:));

- (NSString*)referenceXPathFilter2Filters:(int)referenceIndex NS_SWIFT_NAME(referenceXPathFilter2Filters(_:));

- (NSString*)referenceXPathFilter2PrefixList:(int)referenceIndex NS_SWIFT_NAME(referenceXPathFilter2PrefixList(_:));

- (NSString*)referenceXPathPrefixList:(int)referenceIndex NS_SWIFT_NAME(referenceXPathPrefixList(_:));

@property (nonatomic,readonly,assign,getter=signatureCount) int signatureCount NS_SWIFT_NAME(signatureCount);

- (int)signatureCount NS_SWIFT_NAME(signatureCount());

- (int)signatureCanonicalizationMethod:(int)signatureIndex NS_SWIFT_NAME(signatureCanonicalizationMethod(_:));

- (int)signatureCompatibilityErrors:(int)signatureIndex NS_SWIFT_NAME(signatureCompatibilityErrors(_:));

- (NSString*)signatureEntityLabel:(int)signatureIndex NS_SWIFT_NAME(signatureEntityLabel(_:));

- (long long)signatureHandle:(int)signatureIndex NS_SWIFT_NAME(signatureHandle(_:));

- (NSString*)signatureHashAlgorithm:(int)signatureIndex NS_SWIFT_NAME(signatureHashAlgorithm(_:));

- (NSString*)signatureIssuerRDN:(int)signatureIndex NS_SWIFT_NAME(signatureIssuerRDN(_:));

- (NSString*)signatureParentEntity:(int)signatureIndex NS_SWIFT_NAME(signatureParentEntity(_:));

- (NSData*)signatureSerialNumber:(int)signatureIndex NS_SWIFT_NAME(signatureSerialNumber(_:));

- (NSData*)signatureSignatureBytes:(int)signatureIndex NS_SWIFT_NAME(signatureSignatureBytes(_:));

- (int)signatureSignatureType:(int)signatureIndex NS_SWIFT_NAME(signatureSignatureType(_:));

- (int)signatureSignatureValidationResult:(int)signatureIndex NS_SWIFT_NAME(signatureSignatureValidationResult(_:));

- (NSData*)signatureSubjectKeyID:(int)signatureIndex NS_SWIFT_NAME(signatureSubjectKeyID(_:));

- (NSString*)signatureSubjectRDN:(int)signatureIndex NS_SWIFT_NAME(signatureSubjectRDN(_:));

- (NSString*)signatureXMLElement:(int)signatureIndex NS_SWIFT_NAME(signatureXMLElement(_:));

  /* Methods */

- (void)addKnownNamespace:(NSString*)prefix :(NSString*)URI NS_SWIFT_NAME(addKnownNamespace(_:_:));

- (void)close:(BOOL)saveChanges NS_SWIFT_NAME(close(_:));

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (NSString*)getInnerXML:(NSString*)XPath NS_SWIFT_NAME(getInnerXML(_:));

- (NSString*)getOuterXML:(NSString*)XPath NS_SWIFT_NAME(getOuterXML(_:));

- (void)getSignedData:(NSString*)sigLabel :(int)refIndex NS_SWIFT_NAME(getSignedData(_:_:));

- (NSString*)getTextContent:(NSString*)XPath NS_SWIFT_NAME(getTextContent(_:));

- (void)open NS_SWIFT_NAME(open());

- (void)reset NS_SWIFT_NAME(reset());

- (void)revalidate:(NSString*)sigLabel :(BOOL)detached NS_SWIFT_NAME(revalidate(_:_:));

- (void)selectInfo:(NSString*)entityLabel :(int)infoType :(BOOL)clearSelection NS_SWIFT_NAME(selectInfo(_:_:_:));

- (void)setInnerXML:(NSString*)XPath :(NSString*)value NS_SWIFT_NAME(setInnerXML(_:_:));

- (void)setTextContent:(NSString*)XPath :(NSString*)value NS_SWIFT_NAME(setTextContent(_:_:));

- (void)unsign:(NSString*)sigLabel NS_SWIFT_NAME(unsign(_:));

- (void)verify NS_SWIFT_NAME(verify());

- (void)verifyDetached NS_SWIFT_NAME(verifyDetached());

@end

