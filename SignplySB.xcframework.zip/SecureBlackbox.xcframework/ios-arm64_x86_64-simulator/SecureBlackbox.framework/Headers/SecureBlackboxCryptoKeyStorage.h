/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxCryptoKeyStorageDelegate <NSObject>
@optional
- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onPasswordNeeded:(NSString*)neededFor :(NSString**)password :(int*)cancel NS_SWIFT_NAME(onPasswordNeeded(_:_:_:));

@end

@interface SecureBlackboxCryptoKeyStorage : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxCryptoKeyStorageDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasError;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasPasswordNeeded;

}

+ (SecureBlackboxCryptoKeyStorage*)cryptokeystorage;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxCryptoKeyStorageDelegate> delegate;
- (id <SecureBlackboxCryptoKeyStorageDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxCryptoKeyStorageDelegate>)anObject;

  /* Events */

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onPasswordNeeded:(NSString*)neededFor :(NSString**)password :(int*)cancel NS_SWIFT_NAME(onPasswordNeeded(_:_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readonly,assign,getter=keyCount) int keyCount NS_SWIFT_NAME(keyCount);

- (int)keyCount NS_SWIFT_NAME(keyCount());

- (NSString*)keyAlgorithm:(int)keyIndex NS_SWIFT_NAME(keyAlgorithm(_:));

- (int)keyBits:(int)keyIndex NS_SWIFT_NAME(keyBits(_:));

- (NSString*)keyCurve:(int)keyIndex NS_SWIFT_NAME(keyCurve(_:));

- (BOOL)keyExportable:(int)keyIndex NS_SWIFT_NAME(keyExportable(_:));

- (NSString*)keyFingerprint:(int)keyIndex NS_SWIFT_NAME(keyFingerprint(_:));

- (long long)keyHandle:(int)keyIndex NS_SWIFT_NAME(keyHandle(_:));

- (NSData*)keyID:(int)keyIndex NS_SWIFT_NAME(keyID(_:));

- (NSData*)keyIV:(int)keyIndex NS_SWIFT_NAME(keyIV(_:));

- (NSData*)keyKey:(int)keyIndex NS_SWIFT_NAME(keyKey(_:));

- (NSData*)keyNonce:(int)keyIndex NS_SWIFT_NAME(keyNonce(_:));

- (BOOL)keyPrivate:(int)keyIndex NS_SWIFT_NAME(keyPrivate(_:));

- (BOOL)keyPublic:(int)keyIndex NS_SWIFT_NAME(keyPublic(_:));

- (NSData*)keySubject:(int)keyIndex NS_SWIFT_NAME(keySubject(_:));

- (BOOL)keySymmetric:(int)keyIndex NS_SWIFT_NAME(keySymmetric(_:));

- (BOOL)keyValid:(int)keyIndex NS_SWIFT_NAME(keyValid(_:));

@property (nonatomic,readonly,assign,getter=opened) BOOL opened NS_SWIFT_NAME(opened);

- (BOOL)opened NS_SWIFT_NAME(opened());

@property (nonatomic,readwrite,assign,getter=pinnedKeyAlgorithm,setter=setPinnedKeyAlgorithm:) NSString* pinnedKeyAlgorithm NS_SWIFT_NAME(pinnedKeyAlgorithm);

- (NSString*)pinnedKeyAlgorithm NS_SWIFT_NAME(pinnedKeyAlgorithm());
- (void)setPinnedKeyAlgorithm :(NSString*)newPinnedKeyAlgorithm NS_SWIFT_NAME(setPinnedKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=pinnedKeyBits) int pinnedKeyBits NS_SWIFT_NAME(pinnedKeyBits);

- (int)pinnedKeyBits NS_SWIFT_NAME(pinnedKeyBits());

@property (nonatomic,readwrite,assign,getter=pinnedKeyCurve,setter=setPinnedKeyCurve:) NSString* pinnedKeyCurve NS_SWIFT_NAME(pinnedKeyCurve);

- (NSString*)pinnedKeyCurve NS_SWIFT_NAME(pinnedKeyCurve());
- (void)setPinnedKeyCurve :(NSString*)newPinnedKeyCurve NS_SWIFT_NAME(setPinnedKeyCurve(_:));

@property (nonatomic,readonly,assign,getter=pinnedKeyExportable) BOOL pinnedKeyExportable NS_SWIFT_NAME(pinnedKeyExportable);

- (BOOL)pinnedKeyExportable NS_SWIFT_NAME(pinnedKeyExportable());

@property (nonatomic,readonly,assign,getter=pinnedKeyFingerprint) NSString* pinnedKeyFingerprint NS_SWIFT_NAME(pinnedKeyFingerprint);

- (NSString*)pinnedKeyFingerprint NS_SWIFT_NAME(pinnedKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=pinnedKeyHandle,setter=setPinnedKeyHandle:) long long pinnedKeyHandle NS_SWIFT_NAME(pinnedKeyHandle);

- (long long)pinnedKeyHandle NS_SWIFT_NAME(pinnedKeyHandle());
- (void)setPinnedKeyHandle :(long long)newPinnedKeyHandle NS_SWIFT_NAME(setPinnedKeyHandle(_:));

@property (nonatomic,readwrite,assign,getter=pinnedKeyID,setter=setPinnedKeyID:) NSData* pinnedKeyID NS_SWIFT_NAME(pinnedKeyID);

- (NSData*)pinnedKeyID NS_SWIFT_NAME(pinnedKeyID());
- (void)setPinnedKeyID :(NSData*)newPinnedKeyID NS_SWIFT_NAME(setPinnedKeyID(_:));

@property (nonatomic,readwrite,assign,getter=pinnedKeyIV,setter=setPinnedKeyIV:) NSData* pinnedKeyIV NS_SWIFT_NAME(pinnedKeyIV);

- (NSData*)pinnedKeyIV NS_SWIFT_NAME(pinnedKeyIV());
- (void)setPinnedKeyIV :(NSData*)newPinnedKeyIV NS_SWIFT_NAME(setPinnedKeyIV(_:));

@property (nonatomic,readonly,assign,getter=pinnedKeyKey) NSData* pinnedKeyKey NS_SWIFT_NAME(pinnedKeyKey);

- (NSData*)pinnedKeyKey NS_SWIFT_NAME(pinnedKeyKey());

@property (nonatomic,readwrite,assign,getter=pinnedKeyNonce,setter=setPinnedKeyNonce:) NSData* pinnedKeyNonce NS_SWIFT_NAME(pinnedKeyNonce);

- (NSData*)pinnedKeyNonce NS_SWIFT_NAME(pinnedKeyNonce());
- (void)setPinnedKeyNonce :(NSData*)newPinnedKeyNonce NS_SWIFT_NAME(setPinnedKeyNonce(_:));

@property (nonatomic,readonly,assign,getter=pinnedKeyPrivate) BOOL pinnedKeyPrivate NS_SWIFT_NAME(pinnedKeyPrivate);

- (BOOL)pinnedKeyPrivate NS_SWIFT_NAME(pinnedKeyPrivate());

@property (nonatomic,readonly,assign,getter=pinnedKeyPublic) BOOL pinnedKeyPublic NS_SWIFT_NAME(pinnedKeyPublic);

- (BOOL)pinnedKeyPublic NS_SWIFT_NAME(pinnedKeyPublic());

@property (nonatomic,readwrite,assign,getter=pinnedKeySubject,setter=setPinnedKeySubject:) NSData* pinnedKeySubject NS_SWIFT_NAME(pinnedKeySubject);

- (NSData*)pinnedKeySubject NS_SWIFT_NAME(pinnedKeySubject());
- (void)setPinnedKeySubject :(NSData*)newPinnedKeySubject NS_SWIFT_NAME(setPinnedKeySubject(_:));

@property (nonatomic,readonly,assign,getter=pinnedKeySymmetric) BOOL pinnedKeySymmetric NS_SWIFT_NAME(pinnedKeySymmetric);

- (BOOL)pinnedKeySymmetric NS_SWIFT_NAME(pinnedKeySymmetric());

@property (nonatomic,readonly,assign,getter=pinnedKeyValid) BOOL pinnedKeyValid NS_SWIFT_NAME(pinnedKeyValid);

- (BOOL)pinnedKeyValid NS_SWIFT_NAME(pinnedKeyValid());

@property (nonatomic,readonly,assign,getter=selectedKeyCount) int selectedKeyCount NS_SWIFT_NAME(selectedKeyCount);

- (int)selectedKeyCount NS_SWIFT_NAME(selectedKeyCount());

- (NSString*)selectedKeyAlgorithm:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyAlgorithm(_:));

- (int)selectedKeyBits:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyBits(_:));

- (NSString*)selectedKeyCurve:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyCurve(_:));

- (BOOL)selectedKeyExportable:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyExportable(_:));

- (NSString*)selectedKeyFingerprint:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyFingerprint(_:));

- (long long)selectedKeyHandle:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyHandle(_:));

- (NSData*)selectedKeyID:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyID(_:));

- (NSData*)selectedKeyIV:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyIV(_:));

- (NSData*)selectedKeyKey:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyKey(_:));

- (NSData*)selectedKeyNonce:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyNonce(_:));

- (BOOL)selectedKeyPrivate:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyPrivate(_:));

- (BOOL)selectedKeyPublic:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyPublic(_:));

- (NSData*)selectedKeySubject:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeySubject(_:));

- (BOOL)selectedKeySymmetric:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeySymmetric(_:));

- (BOOL)selectedKeyValid:(int)selectedKeyIndex NS_SWIFT_NAME(selectedKeyValid(_:));

@property (nonatomic,readonly,assign,getter=storageID) NSString* storageID NS_SWIFT_NAME(storageID);

- (NSString*)storageID NS_SWIFT_NAME(storageID());

@property (nonatomic,readonly,assign,getter=storageLocation) NSString* storageLocation NS_SWIFT_NAME(storageLocation);

- (NSString*)storageLocation NS_SWIFT_NAME(storageLocation());

  /* Methods */

- (void)addPinned NS_SWIFT_NAME(addPinned());

- (void)clear NS_SWIFT_NAME(clear());

- (void)close:(BOOL)save NS_SWIFT_NAME(close(_:));

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (void)createNew:(NSString*)storageLocation :(NSString*)storageID NS_SWIFT_NAME(createNew(_:_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (NSString*)getStorageProperty:(NSString*)propName NS_SWIFT_NAME(getStorageProperty(_:));

- (void)importBytes:(NSData*)value :(int)format :(NSString*)keyAlgorithm :(NSString*)scheme :(NSString*)schemeParams :(int)keyType :(NSString*)password NS_SWIFT_NAME(importBytes(_:_:_:_:_:_:_:));

- (void)importFromFile:(NSString*)fileName :(int)format :(NSString*)keyAlgorithm :(NSString*)scheme :(NSString*)schemeParams :(int)keyType :(NSString*)password NS_SWIFT_NAME(importFromFile(_:_:_:_:_:_:_:));

- (NSString*)listStores NS_SWIFT_NAME(listStores());

- (void)login:(int)sessionType :(NSString*)pin :(BOOL)readOnly NS_SWIFT_NAME(login(_:_:_:));

- (void)logout:(BOOL)closeSesion NS_SWIFT_NAME(logout(_:));

- (void)open:(NSString*)storageID NS_SWIFT_NAME(open(_:));

- (void)refresh NS_SWIFT_NAME(refresh());

- (void)remove:(int)index NS_SWIFT_NAME(remove(_:));

- (void)reset NS_SWIFT_NAME(reset());

- (void)select:(NSString*)filter :(BOOL)privateKeyNeeded :(int)maxCount NS_SWIFT_NAME(select(_:_:_:));

- (void)setStorageProperty:(NSString*)propName :(NSString*)propValue NS_SWIFT_NAME(setStorageProperty(_:_:));

@end

