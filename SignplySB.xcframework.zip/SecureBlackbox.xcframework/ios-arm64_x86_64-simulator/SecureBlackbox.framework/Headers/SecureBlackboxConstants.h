/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>

// The archive file does not exist
extern const int SB_ERROR_ARCHIVE_FILE_NOT_EXISTS;

// Unsupported archive type
extern const int SB_ERROR_ARCHIVE_UNSUPPORTED_TYPE;

// Unsupported source
extern const int SB_ERROR_ARCHIVE_UNSUPPORTED_SOURCE;

// Unsupported action
extern const int SB_ERROR_ARCHIVE_UNSUPPORTED_ACTION;

// Cannot delete file in archive
extern const int SB_ERROR_ARCHIVE_NOT_DELETE_FILE_IN_ARCHIVE;

// The archive already contains file with this name
extern const int SB_ERROR_ARCHIVE_FILE_ALREADY_IN_ARCHIVE;

// Not set files for archive
extern const int SB_ERROR_ARCHIVE_FILES_NOT_SET;

// This type of archive is not modifying
extern const int SB_ERROR_ARCHIVE_TYPE_NOT_MODIFYING;

// This type of archive can contain only one file
extern const int SB_ERROR_ARCHIVE_CAN_CONTAINE_ONE_FILE;

// The specified file was not found in archive
extern const int SB_ERROR_ARCHIVE_FILE_NOT_FOUND;

// Cannot update new file in archive
extern const int SB_ERROR_ARCHIVE_NOT_UPDATE_NEW_FILE;

// Invalid archive
extern const int SB_ERROR_ARCHIVE_INVALID;

// The output file with this name already exists
extern const int SB_ERROR_ARCHIVE_OUTPUTFILE_ALREADY_EXISTS;

// Unsupported encryption type
extern const int SB_ERROR_ARCHIVE_UNSUPPORTED_ENCRYPTION_TYPE;

// This type of archive cannot contain folders
extern const int SB_ERROR_ARCHIVE_CANNOT_CONTAINE_FOLDER;

// Unsupported level
extern const int SB_ERROR_ASIC_UNSUPPORTED_LEVEL;

// Unsupported signature type
extern const int SB_ERROR_ASIC_UNSUPPORTED_SIGNATURE_TYPE;

// Unsupported extraction mode
extern const int SB_ERROR_ASIC_UNSUPPORTED_EXTRACTION_MODE;

// The input file does not exist
extern const int SB_ERROR_ASIC_INPUTFILE_NOT_EXISTS;

// The output file with this name already exists
extern const int SB_ERROR_ASIC_OUTPUTFILE_ALREADY_EXISTS;

// The document has already been signed once during this session
extern const int SB_ERROR_ASIC_CONTAINER_SIGNED;

// The document is not signed
extern const int SB_ERROR_ASIC_CONTAINER_NOT_SIGNED;

// Invalid parameter
extern const int SB_ERROR_INVALID_PARAMETER;

// Invalid configuration
extern const int SB_ERROR_INVALID_SETUP;

// Invalid state
extern const int SB_ERROR_INVALID_STATE;

// Invalid value
extern const int SB_ERROR_INVALID_VALUE;

// Private key not found
extern const int SB_ERROR_NO_PRIVATE_KEY;

// Cancelled by the user
extern const int SB_ERROR_CANCELLED_BY_USER;

// The file was not found
extern const int SB_ERROR_NO_SUCH_FILE;

// Unsupported feature or operation
extern const int SB_ERROR_UNSUPPORTED_FEATURE;

// General error
extern const int SB_ERROR_GENERAL_ERROR;

// Cannot change algorithm for existing key
extern const int SB_ERROR_CRYPTO_CANNOT_CHANGE_ALGORITHM;

// The file was not found
extern const int SB_ERROR_CRYPTO_FILE_NOT_EXISTS;

// Failed to decrypt data
extern const int SB_ERROR_CRYPTO_DECRYPTION_FAILED;

// Unsupported file operation
extern const int SB_ERROR_FTP_UNSUPPORTED_FILE_OPERATION;

// Unsupported keep-alive policy
extern const int SB_ERROR_HTTP_UNSUPPORTED_KEEPALIVEPOLICY;

// Wrong request filter string format
extern const int SB_ERROR_HTTP_WRONG_REQUEST_FILTER_FORMAT;

// The input file does not exist
extern const int SB_ERROR_JADES_INPUTFILE_NOT_EXISTS;

// KMIP request failed
extern const int SB_ERROR_KMIP_REQUEST_FAILED;

// The input file does not exist
extern const int SB_ERROR_KMIP_INPUTFILE_NOT_EXISTS;

// Unsupported key algorithm
extern const int SB_ERROR_KMIP_UNSUPPORTED_KEY_ALGORITHM;

// Invalid key
extern const int SB_ERROR_KMIP_INVALID_KEY;

// Failed to assemble the mail message
extern const int SB_ERROR_MAIL_ASSEMBLY_FAILED;

// Failed to assemble the mail message
extern const int SB_ERROR_MAIL_PARSING_FAILED;

// No decryption certificate found
extern const int SB_ERROR_MAIL_NO_DECRYPTION_CERTIFICATE;

// The input file does not exist
extern const int SB_ERROR_OFFICE_INPUTFILE_NOT_EXISTS;

// Unsupported document format
extern const int SB_ERROR_OFFICE_UNSUPPORTED_DOCUMENT_FORMAT;

// The document cannot be signed
extern const int SB_ERROR_OFFICE_DOCUMENT_NOT_SIGNABLE;

// The document is already encrypted
extern const int SB_ERROR_OFFICE_DOCUMENT_ENCRYPTED;

// The document cannot be encrypted
extern const int SB_ERROR_OFFICE_DOCUMENT_NOT_ENCRYPTABLE;

// The document is not encrypted
extern const int SB_ERROR_OFFICE_DOCUMENT_NOT_ENCRYPTED;

// Unsupported encryption type
extern const int SB_ERROR_OFFICE_DOCUMENT_UNKNOWN_ENCRYPTION;

// Invalid password
extern const int SB_ERROR_OFFICE_INVALID_PASSWORD;

// No signature found to complete the asynchronous signing
extern const int SB_ERROR_OFFICE_SIGNATURE_NOT_FOUND;

// User not found
extern const int SB_ERROR_OTP_USER_NOT_FOUND;

// The input file does not exist
extern const int SB_ERROR_PDF_INPUTFILE_NOT_EXISTS;

// Cannot encrypt already encrypted file
extern const int SB_ERROR_PDF_ENCRYPTED;

// The file is not encrypted
extern const int SB_ERROR_PDF_NOT_ENCRYPTED;

// Invalid password
extern const int SB_ERROR_PDF_INVALID_PASSWORD;

// Failed to decrypt the file
extern const int SB_ERROR_PDF_DECRYPTION_FAILED;

// The document is signed
extern const int SB_ERROR_PDF_SIGNED;

// The document is not signed
extern const int SB_ERROR_PDF_NOT_SIGNED;

// Cannot update this type of signature
extern const int SB_ERROR_PDF_INAPPROPRIATE_SIGNATURE;

// Unsupported feature or operation
extern const int SB_ERROR_PDF_NOT_SUPPORTED;

// No timestamp server specified
extern const int SB_ERROR_PDF_NO_TIMESTAMP_SERVER;

// The component is not in edit mode
extern const int SB_ERROR_PDF_READONLY;

// The file was not found
extern const int SB_ERROR_PGP_FILE_NOT_EXISTS;

// Invalid signing key
extern const int SB_ERROR_PGP_INVALID_KEY;

// No secret key is available
extern const int SB_ERROR_PGP_NO_SECRET_KEY;

// The operation is not supported on a subkey
extern const int SB_ERROR_PGP_OPERATION_ON_SUBKEY;

// The input file does not exist
extern const int SB_ERROR_PKI_INPUTFILE_NOT_EXISTS;

// Data file does not exist
extern const int SB_ERROR_PKI_DATAFILE_NOT_EXISTS;

// Timestamping failed
extern const int SB_ERROR_PKI_TIMESTAMPING_FAILED;

// CRL error
extern const int SB_ERROR_PKI_CRL_ERROR;

// OCSP error
extern const int SB_ERROR_PKI_OCSP_ERROR;

// Invalid password
extern const int SB_ERROR_PKI_INVALID_PASSWORD;

// The slot has not been found or is empty
extern const int SB_ERROR_PKI_PKCS11_SLOT_NOT_FOUND;

// Bad credentials
extern const int SB_ERROR_PKI_BAD_CREDENTIALS;

// Unsupported storage location
extern const int SB_ERROR_PKI_UNSUPPORTED_STORAGE;

// Unsupported certificate format
extern const int SB_ERROR_PKI_UNSUPPORTED_CERTIFICATE_FORMAT;

// Unsupported signature type
extern const int SB_ERROR_PKI_UNSUPPORTED_SIGNATURE_TYPE;

// Unsupported CRL format
extern const int SB_ERROR_PKI_UNSUPPORTED_CRL_FORMAT;

// Private key not found
extern const int SB_ERROR_PKI_PRIVATE_KEY_NOT_FOUND;

// Signature index is out of bounds
extern const int SB_ERROR_PKI_INVALID_SIGNATURE_INDEX;

// Unsupported signature level
extern const int SB_ERROR_PKI_UNSUPPORTED_SIGNATURE_LEVEL;

// Operation not supported
extern const int SB_ERROR_PKI_ACTION_NOT_SUPPORTED;

// Asynchronous pre-signing can only produce BES and EPES signatures
extern const int SB_ERROR_PKI_BAD_ASYNCSIGN_LEVEL;

// Asynchronous signing cannot apply timestamping on this stage
extern const int SB_ERROR_PKI_TIMESTAMP_SERVER_SET;

// Storage of this type can only contain one certificate
extern const int SB_ERROR_PKI_MULTIPLE_CERTIFICATES;

// No usable OCSP responders identified
extern const int SB_ERROR_PKI_OCSP_REQUEST_FAILED;

// Unsupported certificate or certificate request format
extern const int SB_ERROR_PKI_UNSUPPORTED_CERTREQUEST_FORMAT;

// Unrecognized object format
extern const int SB_ERROR_PKI_UNRECOGNIZED_FORMAT;

// Wrong OCSP list structure
extern const int SB_ERROR_PKI_UNSUPPORTED_OCSP_FORMAT;

// The module has not been found
extern const int SB_ERROR_PKI_PKCS11_MODULE_NOT_FOUND;

// The storage type does not support this feature
extern const int SB_ERROR_PKI_STORAGE_DOES_NOT_SUPPORT_FEATURE;

// Async document ID is empty
extern const int SB_ERROR_PKI_EMPTY_ASYNC_ID;

// Invalid async document ID
extern const int SB_ERROR_PKI_INVALID_ASYNC_ID;

// The file is not signed
extern const int SB_ERROR_PKI_FILE_NOT_SIGNED;

// No presigned data found
extern const int SB_ERROR_PKI_NO_PRESIGNED_DATA;

// Invalid binding name
extern const int SB_ERROR_SAML_INVALID_BINDING_NAME;

// Invalid SAML binding type
extern const int SB_ERROR_SAML_INVALID_BINDING_TYPE;

// Base directory not set
extern const int SB_ERROR_SAML_SP_BASE_DIRECTORY_NOT_SET;

// Invalid parameter
extern const int SB_ERROR_SAML_INVALID_PARAM;

// Invalid input data
extern const int SB_ERROR_SAML_INVALID_DATA;

// Data is not loaded
extern const int SB_ERROR_SAML_NOT_LOADED;

// New document is not created
extern const int SB_ERROR_SAML_NOT_CREATED;

// Endpoint of unsupported type encountered or cannot find appropriate IdP service
extern const int SB_ERROR_SAML_INVALID_SERVICE;

// Multiple endpoints of the same kind are not supported
extern const int SB_ERROR_SAML_MULTIPLE_ENDPOINTS_NOT_SUPPORTED;

// Failed to process the request
extern const int SB_ERROR_SAML_PROCESSING_FAILED;

// Session not found
extern const int SB_ERROR_SAML_SESSION_NOT_FOUND;

// Unsupported file operation
extern const int SB_ERROR_SFTP_UNSUPPORTED_FILE_OPERATION;

// Invalid authentication type
extern const int SB_ERROR_SFTP_INVALID_AUTH_TYPE;

// The input file does not exist
extern const int SB_ERROR_SOAP_INPUTFILE_NOT_EXISTS;

// Invalid key type
extern const int SB_ERROR_SOAP_INVALID_KEY_TYPE;

// No signature found to complete the asynchronous signing
extern const int SB_ERROR_SOAP_SIGNATURE_NOT_FOUND;

// Unsupported signature type
extern const int SB_ERROR_SOAP_UNSUPPORTED_SIGNATURE_TYPE;

// Unexpected HTTP status code
extern const int SB_ERROR_SOAP_UNEXPECTED_HTTP_STATUS_CODE;

// SOAP service failed
extern const int SB_ERROR_SOAP_SERVICE_FAILED;

// Failed to loaded the trusted keys
extern const int SB_ERROR_SSH_INVALID_KEY;

// Other operation is in progress
extern const int SB_ERROR_SSH_BUSY;

// Command execution failed
extern const int SB_ERROR_SSH_EXEC_FAILED;

// Failed to read data from the connection
extern const int SB_ERROR_SSH_READ_FAILED;

// Failed to write data to the connection
extern const int SB_ERROR_SSH_WRITE_FAILED;

// The input file does not exist
extern const int SB_ERROR_XML_INPUTFILE_NOT_EXISTS;

// Data file does not exist
extern const int SB_ERROR_XML_DATAFILE_NOT_EXISTS;

// Unsupported hash algorithm
extern const int SB_ERROR_XML_UNSUPPORTED_HASH_ALGORITHM;

// Unsupported key type
extern const int SB_ERROR_XML_UNSUPPORTED_KEY_TYPE;

// Unsupported encryption algorithm
extern const int SB_ERROR_XML_INVALID_ENCRYPTION_METHOD;

// XML element not found
extern const int SB_ERROR_XML_NOT_FOUND;

// XML element has no ID
extern const int SB_ERROR_XML_NO_ELEMENT_ID;

// Authorization not started; call StartAuthorization() method first
extern const int SB_OAUTH2_ERROR_AUTH_NOT_STARTED;

// Redirected data could not be empty
extern const int SB_OAUTH2_ERROR_INVALID_AUTH_CODE;

// Authorization failed
extern const int SB_OAUTH2_ERROR_AUTH_FAILED;

// No TElSimpleOAuth2Client.OnLaunchBrowser event handler available
extern const int SB_OAUTH2_ERROR_NO_LAUNCH_BROWSER_HANDLER;

// Timeout exceeded while waiting for an authorization code
extern const int SB_OAUTH2_ERROR_TIMEOUT;

// The user has cancelled the autothorization process
extern const int SB_OAUTH2_ERROR_CANCELLED;

// Current access token has expired
extern const int SB_OAUTH2_ERROR_EXPIRED;

// Invalid or inappropriate grant type
extern const int SB_OAUTH2_ERROR_INVALID_GRANT_TYPE;

// A server certificate is required to handle HTTPS redirects
extern const int SB_OAUTH2_ERROR_NO_SERVER_CERTIFICATE;

// Server socket error
extern const int SB_OAUTH2_ERROR_SERVER_SOCKET_ERROR;

// Redirect received is not active
extern const int SB_OAUTH2_ERROR_SERVER_NOT_ACTIVE;

// Secure session failed
extern const int SB_OAUTH2_ERROR_SSL_FAILED;

// Public key is invalid
extern const int SB_SSHKEY_ERROR_INVALID_PUBLIC_KEY;

// Private key is invalid
extern const int SB_SSHKEY_ERROR_INVALID_PRIVATE_KEY;

// Failed to read from file
extern const int SB_SSHKEY_ERROR_FILE_READ_ERROR;

// Failed to write to file
extern const int SB_SSHKEY_ERROR_FILE_WRITE_ERROR;

// Algorithm is unsupported
extern const int SB_SSHKEY_ERROR_UNSUPPORTED_ALGORITHM;

// Internal error
extern const int SB_SSHKEY_ERROR_INTERNAL_ERROR;

// Buffer is too small
extern const int SB_SSHKEY_ERROR_BUFFER_TOO_SMALL;

// There is no private key
extern const int SB_SSHKEY_ERROR_NO_PRIVATE_KEY;

// Wrong password for private key
extern const int SB_SSHKEY_ERROR_INVALID_PASSPHRASE;

// PEM algorithm is unsupported
extern const int SB_SSHKEY_ERROR_UNSUPPORTED_PEM_ALGORITHM;

// Unsupported curve
extern const int SB_SSHKEY_ERROR_UNSUPPORTED_CURVE;

// Message doesn not contain encrypted data
extern const int SB_MESSAGE_ERROR_NO_ENCRYPTED_DATA;

// No certificate found for the requested operation
extern const int SB_MESSAGE_ERROR_NO_CERTIFICATE;

// Unable to decrypt the content encryption key
extern const int SB_MESSAGE_ERROR_KEY_DECRYPTION_FAILED;

// Buffer for output data is too small
extern const int SB_MESSAGE_ERROR_BUFFER_TOO_SMALL;

// Unable to decrypt the content
extern const int SB_MESSAGE_ERROR_CONTENT_DECRYPTION_FAILED;

// Not valid PKCS7 message
extern const int SB_MESSAGE_ERROR_INVALID_FORMAT;

// No recipient certificates provided
extern const int SB_MESSAGE_ERROR_NO_RECIPIENTS;

// Unsupported algorithm
extern const int SB_MESSAGE_ERROR_UNSUPPORTED_ALGORITHM;

// Unable to encrypt message due to internal error
extern const int SB_MESSAGE_ERROR_ENCRYPTION_FAILED;

// Invalid key length
extern const int SB_MESSAGE_ERROR_INVALID_KEY_LENGTH;

// No signed data was found
extern const int SB_MESSAGE_ERROR_NO_SIGNED_DATA;

// Signed message contains invalid digital signature
extern const int SB_MESSAGE_ERROR_INVALID_SIGNATURE;

// Signed message contains invalid message digest
extern const int SB_MESSAGE_ERROR_INVALID_DIGEST;

// Unable to sign message due to internal error
extern const int SB_MESSAGE_ERROR_SIGNING_FAILED;

// Internal error occured
extern const int SB_MESSAGE_ERROR_INTERNAL_ERROR;

// Signed message contains invalid MAC signature
extern const int SB_MESSAGE_ERROR_INVALID_MAC;

// Message signature is of an unsupported type
extern const int SB_MESSAGE_ERROR_UNSUPPORTED_SIGNATURE_TYPE;

// The countersignature is not valid
extern const int SB_MESSAGE_ERROR_INVALID_COUNTERSIGNATURE;

// Cannot obtain message digest
extern const int SB_MESSAGE_ERROR_DIGEST_NOT_FOUND;

// Digest value is computed via an unsupported digest algorithm
extern const int SB_MESSAGE_ERROR_UNSUPPORTED_DIGEST_ALGORITHM;

// The action is cancelled by user
extern const int SB_MESSAGE_ERROR_CANCELLED_BY_USER;

// Message verification failed
extern const int SB_MESSAGE_ERROR_VERIFICATION_FAILED;

// Digest calculation failed
extern const int SB_MESSAGE_ERROR_DIGEST_CALCULATION_FAILED;

// MAC calculation is failed
extern const int SB_MESSAGE_ERROR_MAC_CALCULATION_FAILED;

// No TSP client found
extern const int SB_MESSAGE_ERROR_TSPCLIENT_NOT_FOUND;

// Message time stamp does not succeed verification
extern const int SB_MESSAGE_ERROR_BAD_TIMESTAMP;

// Operation with RSA key has failed
extern const int SB_MESSAGE_ERROR_KEYOP_FAILED_RSA;

// Operation with DSA key has failed
extern const int SB_MESSAGE_ERROR_KEYOP_FAILED_DSA;

// Operation with RSA PSS key has failed
extern const int SB_MESSAGE_ERROR_KEYOP_FAILED_RSA_PSS;

// Compressed data was not found
extern const int SB_MESSAGE_ERROR_NO_COMPRESSED_DATA;

// EC key operation failed
extern const int SB_MESSAGE_ERROR_KEYOP_FAILED_EC;

// Wrong Distributed Cryptography asynchronous operation state
extern const int SB_MESSAGE_ERROR_DC_BAD_ASYNC_STATE;

// A remote server reported error during Distributed Cryptography asynchronous operation
extern const int SB_MESSAGE_ERROR_DC_SERVER_ERROR;

// Distributed Cryptography module is unavailable
extern const int SB_MESSAGE_ERROR_DC_MODULE_UNAVAILABLE;

// GOST key operation failed
extern const int SB_MESSAGE_ERROR_KEYOP_FAILED_GOST;

// Message timestamping has failed
extern const int SB_MESSAGE_ERROR_TIMESTAMPING_FAILED;

// Timestamped data was not found
extern const int SB_MESSAGE_ERROR_NO_TIMESTAMPED_DATA;

// An ASN.1 counter-DoS limitation was exceeded due to the size/depth of the provided ASN.1 structure
extern const int SB_MESSAGE_ERROR_ASN_LIMIT_EXCEEDED;

// Data not available
extern const int SB_MESSAGE_ERROR_DATA_NOT_AVAILABLE;

// Unverified Distributed Cryptography asynchronous state
extern const int SB_MESSAGE_ERROR_DC_ASYNC_STATE_UNVERIFIED;

// No Distributed Cryptography state storage
extern const int SB_MESSAGE_ERROR_DC_NO_STATE_STORAGE;

// Failed to create stream
extern const int SB_MESSAGE_ERROR_DC_FAILED_TO_CREATE_STREAM;

// No presigned data was found
extern const int SB_MESSAGE_ERROR_DC_NO_PRESIGNED_DATA;

// Invalid encryption cipher mode
extern const int SB_MESSAGE_ERROR_INVALID_ENCRYPTION_CIPHER_MODE;

// No OnRemoteDecrypt event handler
extern const int SB_MESSAGE_ERROR_NO_ONREMOTEDECRYPT_HANDLER;

// Cannot process data in non-detached mode
extern const int SB_MESSAGE_ERROR_DETACHED_EXPECTED;

// Setup inconsistent
extern const int SB_MESSAGE_ERROR_SETUP_INCONSISTENT;

// The format of the data buffer is not valid
extern const int SB_CRL_ERROR_INVALID_FORMAT;

// The CRL is signed with unknown or unsupported algorithm
extern const int SB_CRL_ERROR_BAD_SIGNATURE_ALGORITHM;

// The CRL was not signed with the specified certificate
extern const int SB_CRL_ERROR_INVALID_ISSUER;

// The signature is invalid. The CRL has been altered or broken.
extern const int SB_CRL_ERROR_INVALID_SIGNATURE;

// The CRL version is not supported
extern const int SB_CRL_ERROR_UNSUPPORTED_VERSION;

// The algorithm, used to sign the CRL, was not recognized.
extern const int SB_CRL_ERROR_UNSUPPORTED_ALGORITHM;

// Certificate not specified or certificate algorithm does not correspond to CRL signature algorithm.
extern const int SB_CRL_ERROR_INVALID_CERTIFICATE;

// Specified certificate does not have a private key, necessary to sign the CRL.
extern const int SB_CRL_ERROR_PRIVATE_KEY_NOT_FOUND;

// The certificate utilizes unsupported public key algorithm.
extern const int SB_CRL_ERROR_UNSUPPORTED_CERTIFICATE;

// Internal CRL error
extern const int SB_CRL_ERROR_INTERNAL_ERROR;

// Specified buffer is too small to save the CRL to.
extern const int SB_CRL_ERROR_BUFFER_TOO_SMALL;

// Nothing to verify
extern const int SB_CRL_ERROR_NOTHING_TO_VERIFY;

// An unsigned CRL has been received.
extern const int SB_CRL_ERROR_NO_SIGNED_CRL_FOUND;

// Cannot clone abstract CRL object
extern const int SB_CRL_ERROR_ABSTRACT_ERROR;

// Invalid argument value
extern const int SB_AUTHENTICODE_ERROR_INVALID_ARGUMENT;

// Operation cancelled
extern const int SB_AUTHENTICODE_ERROR_CANCELLED;

// File is too small to contain a correct EXE
extern const int SB_AUTHENTICODE_ERROR_FILE_TOO_SMALL;

// The file is missing a correct MZ stamp and therefore is not a valid EXE file
extern const int SB_AUTHENTICODE_ERROR_INVALID_EXECUTABLE;

// The file is missing a correct PE stamp and therefore is not a valid PE file
extern const int SB_AUTHENTICODE_ERROR_INVALID_PE_FORMAT;

// No authenticode signature
extern const int SB_AUTHENTICODE_ERROR_NO_SIGNATURES;

// The inluded Authenticode block cannot be parsed correctly
extern const int SB_AUTHENTICODE_ERROR_SIGNATURE_CORRUPTED;

// No PE file is currently open
extern const int SB_AUTHENTICODE_ERROR_FILE_NOT_OPEN;

// The authenticode block is not the last block in the executable, removing it is not safe
extern const int SB_AUTHENTICODE_ERROR_SIGNATURE_NOT_LAST;

// Cannot change a timestamped signature: remove the timestamp first
extern const int SB_AUTHENTICODE_ERROR_SIGNATURE_TIMESTAMPED;

// Failed to generate a timestamp request
extern const int SB_AUTHENTICODE_ERROR_CANNOT_TIMESTAMP;

// Invalid response from the timestamping server
extern const int SB_AUTHENTICODE_ERROR_INVALID_TIMESTAMP;

// No pending timestamp; call StartTimestamp method first
extern const int SB_AUTHENTICODE_ERROR_NO_PENDING_TIMESTAMP;

// PE image data flags are not supported
extern const int SB_AUTHENTICODE_ERROR_SIGNATURE_NOT_SUPPORTED;

// Signing certificate not found
extern const int SB_CADES_ERROR_NO_SIGNING_CERT;

// No signature object found
extern const int SB_CADES_ERROR_NO_SIGNATURE;

// Signature is invalid
extern const int SB_CADES_ERROR_SIGNATURE_INVALID;

// No timestamping service details were provided, cannot add a timestamp
extern const int SB_CADES_ERROR_NO_TSA_DETAILS;

// Cannot modify a signature that contains validation timestamps
extern const int SB_CADES_ERROR_CANT_MODIFIED_TIMESTAMPED_CONTENT;

// Timestamp does not match the timestamped source
extern const int SB_CADES_ERROR_TIMESTAMP_DOESNT_MATCH_SOURCE;

// Collected validation information is not complete
extern const int SB_CADES_ERROR_VALIDATION_INFO_INCOMPLETE;

// CAdES-C signature MUST contain a signature timestamp attribute
extern const int SB_CADES_ERROR_C_MUST_CONTAIN_SIG_TIMESTAMP;

// Bad signature state
extern const int SB_CADES_ERROR_BAD_SIGNATURE_STATE;

// Signature cannot be upgraded to the specified level
extern const int SB_CADES_ERROR_CANT_UPGRADE_SIGNATURE_LEVEL;

// Cannot upgrade CAdES-T signature to CAdES-T subtype
extern const int SB_CADES_ERROR_CANT_UPGRADE_TO_SAME_LEVEL;

// Only archival timestamps (version 1-3) are accepted by this method
extern const int SB_CADES_ERROR_ONLY_ARCHIVAL_TIMESTAMP_ALLOWED;

// Empty CRAM-MD5 challenge
extern const int SB_SASL_CRAM_ERROR_EMPTY_CHALLENGE;

// Invalid CRAM-MD5 challenge
extern const int SB_SASL_CRAM_ERROR_INVALID_CHALLENGE;

// Invalid Digest-MD5 challenge
extern const int SB_SASL_DIGEST_ERROR_INVALID_CHALLENGE;

// Required Digest-MD5 parameter not specified
extern const int SB_SASL_DIGEST_ERROR_PARAMETER_NOT_SPECIFIED;

// Unknown OAuth 2.0 response
extern const int SB_SASL_XOAUTH2_ERROR_UNKNOWN_RESPONSE;

// Authentication with OAuth 2.0 failed
extern const int SB_SASL_XOAUTH2_ERROR_AUTHENTICATION_FAILED;

// Invalid SCRAM parameter received from server
extern const int SB_SASL_SCARM_ERROR_INVALID_SERVER_PARAMETER;

// Received server signature does not match the calculated one
extern const int SB_SASL_SCRAM_ERROR_INVALID_SERVER_SIGNATURE;

// Unsupported SASL mechanism
extern const int SB_SASL_ERROR_INVALID_MECHANISM;

// Mechanism priority must be greater than 0
extern const int SB_SASL_ERROR_INVALID_PRIORITY;

// Custom request command cannot be empty
extern const int SB_SASL_ERROR_INVALID_CUSTOM_REQUEST;

// Connection cancelled by the user
extern const int SB_SSL_ERROR_CONNECTION_CANCELLED_BY_USER;

// Timeout
extern const int SB_SSL_ERROR_TIMEOUT;

// Unsupported MAC algorithm
extern const int SB_SSL_ERROR_UNSUPPORTED_MAC_ALGORITHM;

// Client KEX computation error
extern const int SB_SSL_ERROR_CLIENT_KEX_COMPUTATION_ERROR;

// Compression error
extern const int SB_SSL_ERROR_COMPRESSION_ERROR;

// Crypto subsystem not initialized
extern const int SB_SSL_ERROR_CRYPTO_NOT_INITIALIZED;

// Private key operation failed
extern const int SB_SSL_ERROR_PRIVATE_KEY_OPERATION_FAILED;

// Unsupported version combo
extern const int SB_SSL_ERROR_UNSUPPORTED_VERSION_COMBO;

// KEX exchange sign version failed
extern const int SB_SSL_ERROR_KEX_EXCHANGE_SIGNVER_FAILED;

// KEX exchange parse error
extern const int SB_SSL_ERROR_KEX_EXCHANGE_PARSE_ERROR;

// Security not active
extern const int SB_SSL_ERROR_NOT_ACTIVE;

// No certificate validation handler
extern const int SB_SSL_ERROR_NO_CERT_VALIDATION_HANDLER;

// Unsupported RSP certificate index
extern const int SB_SSL_ERROR_UNSUPPORTED_RSP_CERTINDEX;

// Remote signing failed
extern const int SB_SSL_ERROR_REMOTE_SIGNING_FAILED;

// Group unsupported
extern const int SB_SSL_ERROR_GROUP_UNSUPPORTED;

// Group disabled
extern const int SB_SSL_ERROR_GROUP_DISABLED;

// Remote decryption failed
extern const int SB_SSL_ERROR_REMOTE_DECRYPTION_FAILED;

// Unexpected SSL/TLS message
extern const int SB_SSL_ERROR_UNEXPECTED_MESSAGE;

// Negotiation failed: bad record MAC
extern const int SB_SSL_ERROR_BAD_RECORD_MAC;

// Negotiation failed: decryption failed
extern const int SB_SSL_ERROR_DECRYPTION_FAILED;

// Packet size too large
extern const int SB_SSL_ERROR_RECORD_OVERFLOW;

// Compression or decompression failure
extern const int SB_SSL_ERROR_DECOMPRESSION_FAILURE;

// Incompatible versions or cipher suite lists
extern const int SB_SSL_ERROR_HANDSHAKE_FAILURE;

// No certificate provided by the peer
extern const int SB_SSL_ERROR_NO_CERTIFICATE;

// Bad ceritificate provided by the peer
extern const int SB_SSL_ERROR_BAD_CERTIFICATE;

// Unsupported certificate provided by the peer
extern const int SB_SSL_ERROR_UNSUPPORTED_CERTIFICATE;

// Peer certificate is revoked
extern const int SB_SSL_ERROR_CERTIFICATE_REVOKED;

// Peer certificate is expired
extern const int SB_SSL_ERROR_CERTIFICATE_EXPIRED;

// Unknown certificate provided by the peer
extern const int SB_SSL_ERROR_CERTIFICATE_UNKNOWN;

// Illegal parameter during handshake
extern const int SB_SSL_ERROR_ILLEGAL_PARAMETER;

// Unknown CA specified in peer certificate
extern const int SB_SSL_ERROR_UNKNOWN_CA;

// The requested application-layer resource cannot be accessed by the requestor
extern const int SB_SSL_ERROR_ACCESS_DENIED;

// Negotiation failed: decode error
extern const int SB_SSL_ERROR_DECODE_ERROR;

// Negotiation failed: decrypt error
extern const int SB_SSL_ERROR_DECRYPT_ERROR;

// The peer is only configured to use exportable cipher suites
extern const int SB_SSL_ERROR_EXPORT_RESTRICTION;

// The peers have not been able to negotiate a version to use
extern const int SB_SSL_ERROR_PROTOCOL_VERSION;

// The cipher suites mutually supported by the peers are too weak and do not provide an adequate level of security
extern const int SB_SSL_ERROR_INSUFFICIENT_SECURITY;

// Internal error
extern const int SB_SSL_ERROR_INTERNAL_ERROR;

// Connection canceled by the user
extern const int SB_SSL_ERROR_USER_CANCELED;

// One of the peers requested a renegotiation, which was refused by the other
extern const int SB_SSL_ERROR_NO_RENEGOTIATION;

// Secure session was closed gracefully and can be restored or cloned in future
extern const int SB_SSL_ERROR_CLOSE_NOTIFY;

// Unknown protocol error
extern const int SB_SSL_ERROR_UNKNOWN_PROTOCOL_ERROR;

// Unsupported extension
extern const int SB_SSL_ERROR_UNSUPPORTED_EXTENSION;

// No shared cipher
extern const int SB_SSL_ERROR_NO_SHARED_CIPHER;

// Inappropriate fallback
extern const int SB_SSL_ERROR_INAPPROPRIATE_FALLBACK;

// Unknown PSK identity
extern const int SB_SSL_ERROR_UNKNOWN_PSK_IDENTITY;

// Failed to obtain a certificate
extern const int SB_SSL_ERROR_CERTIFICATE_UNOBTAINABLE;

// Unrecognized name
extern const int SB_SSL_ERROR_UNRECOGNIZED_NAME;

// Bad certificate status response
extern const int SB_SSL_ERROR_BAD_CERTIFICATE_STATUS_RESPONSE;

// Bad certificate hash value
extern const int SB_SSL_ERROR_BAD_CERTIFICATE_HASH_VALUE;

// Missing extension
extern const int SB_SSL_ERROR_MISSING_EXTENSION;

// Required certificate not provided
extern const int SB_SSL_ERROR_CERTIFICATE_REQUIRED;

// No application protocol
extern const int SB_SSL_ERROR_NO_APPLICATION_PROTOCOL;

// No certificates
extern const int SB_OCSP_ERROR_NO_CERTIFICATES;

// No issuer certificates
extern const int SB_OCSP_ERROR_NO_ISSUER_CERTIFICATES;

// Invalid data
extern const int SB_OCSP_ERROR_WRONG_DATA;

// No event handler
extern const int SB_OCSP_ERROR_NO_EVENT_HANDLER;

// No parameters
extern const int SB_OCSP_ERROR_NO_PARAMETERS;

// No reply
extern const int SB_OCSP_ERROR_NO_REPLY;

// Invalid signature
extern const int SB_OCSP_ERROR_WRONG_SIGNATURE;

// Unsupported algorithm
extern const int SB_OCSP_ERROR_UNSUPPORTED_ALGORITHM;

// Invalid response
extern const int SB_OCSP_ERROR_INVALID_RESPONSE;

// Invalid HTTP reply
extern const int SB_OCSP_ERROR_WRONG_HTTP_REPLY;

// Unrecognized format
extern const int SB_TSP_ERROR_UNRECOGNIZED_FORMAT;

// Invalid too long data
extern const int SB_TSP_ERROR_DATA_TOO_LONG;

// Unsupported reply
extern const int SB_TSP_ERROR_UNSUPPORTED_REPLY;

// General error
extern const int SB_TSP_ERROR_GENERAL_ERROR;

// Rejected request
extern const int SB_TSP_ERROR_REQUEST_REJECTED;

// Operation aborted
extern const int SB_TSP_ERROR_ABORTED;

// No reply from server
extern const int SB_TSP_ERROR_NO_REPLY;

// No parameters
extern const int SB_TSP_ERROR_NO_PARAMETERS;

// No certificates
extern const int SB_TSP_ERROR_NO_CERTIFICATES;

// Invalid response data
extern const int SB_TSP_ERROR_WRONG_DATA;

// Wrong message imprint
extern const int SB_TSP_ERROR_WRONG_IMPRINT;

// Wrong nonce from server
extern const int SB_TSP_ERROR_WRONG_NONCE;

// Unexpected certificates
extern const int SB_TSP_ERROR_UNEXPECTED_CERTIFICATES;

// Cannot perform this operation on closed connection
extern const int SB_IMAP_ERROR_NOT_CONNECTED;

// Cannot perform this operation on open connection
extern const int SB_IMAP_ERROR_ALREADY_CONNECTED;

// No IMAP server address specified
extern const int SB_IMAP_ERROR_NO_ADDRESS;

// No complete reply received
extern const int SB_IMAP_ERROR_NO_REPLY;

// Invalid format of server reply
extern const int SB_IMAP_ERROR_BAD_REPLY;

// Line length cannot be lesst then 1000 octets
extern const int SB_IMAP_ERROR_INVALID_LENGTH;

// Buffer of the specified size cannot hold the already received data
extern const int SB_IMAP_ERROR_SMALL_LENGTH;

// Server response contains too long line
extern const int SB_IMAP_ERROR_TOO_LONG_LINE;

// Operation is not allowed in the current state
extern const int SB_IMAP_ERROR_INVALID_STATE;

// No SASL mechanisms supported by both the client and the server
extern const int SB_IMAP_ERROR_NO_SALS_MECHANISM;

// Authorization failed
extern const int SB_IMAP_ERROR_AUTHORIZATION_FAILED;

// Winsock initialization failed
extern const int SB_SOCKET_ERROR_WINSOCK_INIT_FAILED;

// Wrong socket state
extern const int SB_SOCKET_ERROR_WRONG_SOCKET_STATE;

// Not a socket
extern const int SB_SOCKET_ERROR_NOT_A_SOCKET;

// Invalid address
extern const int SB_SOCKET_ERROR_INVALID_ADDRESS;

// Accept failed
extern const int SB_SOCKET_ERROR_ACCEPT_FAILED;

// Socket handle is IPv6 and could not be used with IPv4 address
extern const int SB_SOCKET_ERROR_ADDRESS_FAMILY_MISMATCH;

// Invalid socket type
extern const int SB_SOCKET_ERROR_INVALID_SOCKET_TYPE;

// SOCKS protocol negotiation failed
extern const int SB_SOCKET_ERROR_SOCKS_NEGOTIATION_FAILED;

// SOCKS authentication failed
extern const int SB_SOCKET_ERROR_SOCKS_AUTH_FAILED;

// SOCKS failed to resolve destination address
extern const int SB_SOCKET_ERROR_SOCKS_FAILED_TO_RESOLVE_DESTINATION_ADDRESS;

// DNS security failure
extern const int SB_SOCKET_ERROR_DNS_SECURITY_FAILURE;

// DNS timeout exceeded
extern const int SB_SOCKET_ERROR_DNS_TIMEOUT;

// Web Tunnel negotiation failed
extern const int SB_SOCKET_ERROR_WEBTUNNEL_NEGOTIATION_FAILED;

// Timeout
extern const int SB_SOCKET_ERROR_TIMEOUT;

// Could not receive expected proxy header
extern const int SB_SOCKET_ERROR_NO_PROXY_HEADER;

// Expected proxy header not valid
extern const int SB_SOCKET_ERROR_WRONG_PROXY_HEADER;

// Failed to bind a socket
extern const int SB_SOCKET_ERROR_BIND_FAILED;

// Failed to decode static DNS rules
extern const int SB_SOCKET_ERROR_INVALID_STATIC_DNS_RULES;

// Failed to switch a socket to listening mode
extern const int SB_SOCKET_ERROR_LISTEN_FAILED;

// Socket closed gracefully
extern const int SB_SOCKET_ERROR_CLOSED_GRACEFULLY;

// Failed to connect to remote host
extern const int SB_HTTP_ERROR_CONNECT_FAILED;

// Communication failed for unidentified reason during sending request or retrieving response
extern const int SB_HTTP_ERROR_REQUEST_NOT_COMPLETED;

// The provided URL has invalid protocol identifier (i.e. not HTTP and not HTTPS)
extern const int SB_HTTP_ERROR_INVALID_PROTOCOL_IN_URI;

// The response header contains unparseable date/time values
extern const int SB_HTTP_ERROR_DATETIME_PARSING_ERROR;

// Error happened when trying to decompress incoming data or when trying to compress outgoing data
extern const int SB_HTTP_ERROR_COMPRESSION_ERROR;

// Error happened during authentication process
extern const int SB_HTTP_ERROR_AUTH_FAILURE;

// Response headers could not be parsed by the client
extern const int SB_HTTP_ERROR_CANT_PARSE_RESPONSE;

// Client request headers could not be parsed by the server
extern const int SB_HTTP_ERROR_CANT_PARSE_REQUEST;

// Unknown transfer encoding
extern const int SB_HTTP_ERROR_UNKNOWN_TRANSFER_ENCODING;

// Error while decoding response Transfer-Encoding
extern const int SB_HTTP_ERROR_TRANSFER_DECODING;

// Connection lost unexpectedly
extern const int SB_HTTP_ERROR_CONNECT_LOST_UNEXPECTEDLY;

// Cannot perform this operation on closed connection
extern const int SB_POP3_ERROR_NOT_CONNECTED;

// Cannot perform this operation on open connection
extern const int SB_POP3_ERROR_ALREADY_CONNECTED;

// Operation is not allowed in the current state
extern const int SB_POP3_ERROR_INVALID_STATE;

// Line length cannot be lesst then 1000 octets
extern const int SB_POP3_ERROR_INVALID_LENGTH;

// Buffer of the specified size cannot hold the already received data
extern const int SB_POP3_ERROR_SMALL_LENGTH;

// No POP3 server address specified
extern const int SB_POP3_ERROR_NO_ADDRESS;

// Server reply cannot be empty
extern const int SB_POP3_ERROR_EMPTY_REPLY;

// Invalid format of server reply
extern const int SB_POP3_ERROR_INVALID_REPLY;

// Insufficient buffer space
extern const int SB_POP3_ERROR_INSUFFICIENT_BUFFER;

// Server response contains too long line
extern const int SB_POP3_ERROR_TOO_LONG_LINE;

// Authorization failed
extern const int SB_POP3_ERROR_AUTHORIZATION_FAILED;

// Failed to retrive a message
extern const int SB_POP3_ERROR_MESSAGE_FAILED;

// Failed to delete a message
extern const int SB_POP3_ERROR_DELETE_FAILED;

// Failed to get mailbox information
extern const int SB_POP3_ERROR_MAILBOX_INFO_FAILED;

// Failed to get server capabilities
extern const int SB_POP3_ERROR_CAPABILITIES_FAILED;

// Failed to establish SSL session
extern const int SB_POP3_ERROR_SSL_SESSION_FAILURE;

// Failed to get a message ID
extern const int SB_POP3_ERROR_ID_INFO_FAILED;

// Failed to get all message IDs
extern const int SB_POP3_ERROR_ALLID_INFO_FAILED;

// Failed to get a header of a message
extern const int SB_POP3_ERROR_TOP_INFO_FAILED;

// Failed to get a list of message sizes
extern const int SB_POP3_ERROR_LIST_INFO_FAILED;

// Server stopped responding on control channel (transfer succeeded)
extern const int SB_FTPS_ERROR_CONTROL_CHANNEL_HANGUP;

// No data is being transferred via control channel.
extern const int SB_FTPS_ERROR_CONTROL_CHANNEL_NO_DATA;

// Unaccepted reply code. Such codes may be sent by servers when data connection closure was initiated on the client side.
extern const int SB_FTPS_ERROR_UNACCEPTED_REPLY_CODE;

// Invalid server reply
extern const int SB_FTPS_ERROR_INVALID_REPLY;

// Source entry exists and is not a file - can not read
extern const int SB_FTPS_ERROR_LOCAL_SOURCE_NOT_FILE;

// Destination entry exists and it is not a file - can not override
extern const int SB_FTPS_ERROR_LOCAL_TARGET_NOT_FILE;

// Impossible to resume data transfer (because resume offset is too large)
extern const int SB_FTPS_ERROR_RESUME_OFFSET_TOO_LARGE;

// The criteria for the requested operation is not met.
extern const int SB_FTPS_ERROR_OPERATION_CRITERIA_NOT_MET;

// The criteria for the requested operation is not met.
extern const int SB_FTPS_ERROR_TIMES_NOT_SET;

// Impossible to resume data transfer (because resume offset is too large)
extern const int SB_SFTP_ERROR_OFFSET_TOO_LARGE;

// Failed to write file attributes
extern const int SB_SFTP_ERROR_TIMES_NOT_SET;

// Source entry exists and is not a file - can not read
extern const int SB_SFTP_ERROR_LOCAL_SOURCE_NOT_FILE;

// Destination entry exists and is not a file - can not override
extern const int SB_SFTP_ERROR_LOCAL_TARGET_NOT_FILE;

// The criteria for the requested operation is not met
extern const int SB_SFTP_ERROR_OPERATION_CRITERIA_NOT_MET;

// Operation interrupted by user
extern const int SB_SFTP_ERROR_INTERRUPTED_BY_USER;

// Command tunnel error
extern const int SB_SFTP_ERROR_SECONDARY_CHANNEL_ERROR;

// Unsupported digest algorithm
extern const int SB_SFTP_ERROR_UNSUPPORTED_ALGORITHM;

// Unsupported protocol version
extern const int SB_SFTP_ERROR_UNSUPPORTED_VERSION;

// Invalid Packet
extern const int SB_SFTP_ERROR_INVALID_PACKET;

// Tunnel error
extern const int SB_SFTP_ERROR_TUNNEL_ERROR;

// Connection closed by lower level protocol
extern const int SB_SFTP_ERROR_CONNECTION_CLOSED;

// Unsupported action
extern const int SB_SFTP_ERROR_UNSUPPORTED_ACTION;

// The supplied handle is not a text file handle
extern const int SB_SFTP_ERROR_NOT_A_TEXT_HANDLE;

// Cancelled by the user
extern const int SB_SFTP_ERROR_CANCELLED_BY_USER;

// Not in synchronous mode
extern const int SB_SFTP_ERROR_WRONG_MODE;

// Client not connected
extern const int SB_SFTP_ERROR_NOT_CONNECTED;

// Bad or unsupported async state
extern const int SB_DC_ERROR_BAD_ASYNC_STATE;

// Remote error
extern const int SB_DC_ERROR_REMOTE_ERROR;

// Request unauthenticated
extern const int SB_DC_ERROR_REQUEST_UNAUTHENTICATED;

// No signing certificate
extern const int SB_DC_ERROR_NO_SIGNING_CERT;

// Invalid signing certificate
extern const int SB_DC_ERROR_INVALID_SIGNING_CERT;

// Remote signign failed
extern const int SB_DC_ERROR_REMOTE_SIGN_FAILED;

// Feature is not implemented
extern const int SB_DC_ERROR_STORAGE_FEATURE_NOT_IMPLEMENTED;

// Could not pick a random name for temporary file
extern const int SB_DC_ERROR_STORAGE_COULD_NOT_PICK_RANDOM_NAME;

// Could not create a temporary stream
extern const int SB_DC_ERROR_STORAGE_COULD_NOT_CREATE_TEMP_STREAM;

// Bad temporary stream object
extern const int SB_DC_ERROR_STORAGE_BAD_TEMP_STREAM;

// Failed to rename file
extern const int SB_DC_ERROR_STORAGE_FAILED_TO_RENAME_FILE;

// File already exists
extern const int SB_DC_ERROR_STORAGE_FILE_ALREADY_EXISTS;

// Failed to delete file
extern const int SB_DC_ERROR_STORAGE_FAILED_TO_DELETE_FILE;

// File not found
extern const int SB_DC_ERROR_STORAGE_FILE_NOT_FOUND;

// Could not open state file
extern const int SB_DC_ERROR_STORAGE_COULD_NOT_OPEN_STATE_FILE;

// Unexpected server reply code
extern const int SB_SMTP_ERROR_INVALID_REPLY;

// Unaccepted domain name
extern const int SB_SMTP_ERROR_NO_DOMAIN_FOR_LOGIN;

// Invalid parameter
extern const int SB_SMTP_ERROR_INVALID_PARAMETER;

// No SASL mechanisms supported by both the client and the server
extern const int SB_SMTP_ERROR_NO_APPLICABLE_SASL_MECH;

// User authentication failed
extern const int SB_SMTP_ERROR_AUTH_FAILED;

// No authentication method enabled from those supported by the server
extern const int SB_SMTP_ERROR_NO_AUTHENTICATION;

// Invalid HTTP response code received
extern const int SB_OAUTH2_ERROR_INVALID_HTTP_CODE;

// Invalid OAuth 2.0 response format
extern const int SB_OAUTH2_ERROR_INVALID_RESPONSE_FORMAT;

// Invalid state parameter value
extern const int SB_OAUTH2_ERROR_INVALID_STATE_PARAMETER;

// No refresh token returned by authorization server
extern const int SB_OAUTH2_ERROR_NO_REFRESH_TOKEN;

// Name of custom parameter must not be empty
extern const int SB_OAUTH2_ERROR_INVALID_PARAMETER;

// Invalid HTTP header
extern const int SB_OAUTH2_ERROR_INVALID_HTTP_HEADER;

// Socket error in Redirect Receiver
extern const int SB_OAUTH2_ERROR_SOCKET_ERROR;

// Invalid XML structure
extern const int SB_WEBDAV_ERROR_INVALID_XML;

// Invalid serialized XML structure
extern const int SB_WEBDAV_ERROR_INVALID_LOCKS_XML;

// Internal error
extern const int SB_WEBDAV_ERROR_INTERNAL;

// Collection object or URL is expected as a parameter
extern const int SB_WEBDAV_CLIENT_ERROR_COLLECTION_EXPECTED;

// Document object or URL is expected as a parameter
extern const int SB_WEBDAV_CLIENT_ERROR_DOCUMENT_EXPECTED;

// Status code error
extern const int SB_WEBDAV_CLIENT_ERROR_STATUSCODE;

// Can not read file size
extern const int SB_WEBDAV_CLIENT_ERROR_NO_FILESIZE;

// Resume offset is too large
extern const int SB_WEBDAV_CLIENT_ERROR_OFFSET_TOO_LARGE;

// Precondition error
extern const int SB_WEBDAV_CLIENT_ERROR_PRECONDITION_FAILED;

// Protected and inherited ACEs cannot be used in ACL change request
extern const int SB_WEBDAV_CLIENT_ERROR_PROTECTED_OR_INHERITED_ACE;

// HTTP protocol error
extern const int SB_WEBDAV_CLIENT_ERROR_HTTP_ERROR;

// Invalid depth parameter
extern const int SB_WEBDAV_SERVER_ERROR_INVALID_DEPTH;

// Invalid scope parameter
extern const int SB_WEBDAV_SERVER_ERROR_INVALID_SCOPE;

// Invalid timeout
extern const int SB_WEBDAV_SERVER_ERROR_INVALID_TIMEOUT;

// Precondition error
extern const int SB_WEBDAV_SERVER_ERROR_PRECONDITION_FAILED;

// Resource already exists or is protected
extern const int SB_WEBDAV_SERVER_ERROR_RESOUCE_EXISTS_OR_PROTECTED;

// File system error
extern const int SB_WEBDAV_SERVER_ERROR_FILESYSTEM;

// Failed to clone object
extern const int SB_PDF_ERROR_CLONE_OBJECT_FAILED;

// Invalid stream data
extern const int SB_PDF_ERROR_INVALID_STREAM_DATA;

// Invalid stream dictionary
extern const int SB_PDF_ERROR_INVALID_STREAM_DICTIONARY;

// Invalid reference
extern const int SB_PDF_ERROR_INVALID_REFERENCE;

// Invalid reference table
extern const int SB_PDF_ERROR_INVALID_REFERENCE_TABLE;

// Invalid indirect object
extern const int SB_PDF_ERROR_INVALID_INDIRECT_OBJECT;

// Invalid object stream
extern const int SB_PDF_ERROR_INVALID_OBJECT_STREAM;

// Invalid object or generation number
extern const int SB_PDF_ERROR_INVALID_OBJECT_OR_GENERATION_NUMBER;

// Invalid type in Root object list
extern const int SB_PDF_ERROR_INVALID_ROOT_OBJECT_LIST_ITEM_TYPE;

// Invalid cross-reference stream
extern const int SB_PDF_ERROR_INVALID_CROSS_REFERENCE_STREAM;

// Invalid cross-reference stream data
extern const int SB_PDF_ERROR_INVALID_CROSS_REFERENCE_STREAM_DATA;

// Only indirect objects allowed
extern const int SB_PDF_ERROR_INDIRECT_OBJECT_EXPECTED;

// Bad object
extern const int SB_PDF_ERROR_BAD_OBJECT;

// Bad document trailer
extern const int SB_PDF_ERROR_BAD_TRAILER;

// Unexpected EOF
extern const int SB_PDF_ERROR_UNEXPECTED_EOF;

// Unexpected character
extern const int SB_PDF_ERROR_UNEXPECTED_CHARACTER;

// Illegal string
extern const int SB_PDF_ERROR_ILLEGAL_STRING;

// Illegal stream dictionary
extern const int SB_PDF_ERROR_ILLEGAL_STREAM_DICTIONARY;

// Unsupported document version
extern const int SB_PDF_ERROR_UNSUPPORTED_VERSION;

// Bad cross-reference entry
extern const int SB_PDF_ERROR_BAD_CROSS_REFERENCE_ENTRY;

// Cycle previous cross-reference
extern const int SB_PDF_ERROR_CYCLE_CROSS_REFERENCE;

// Possible error in Xref table: indirect expected
extern const int SB_PDF_ERROR_XREF_TABLE_ERROR_INDIRECT_EXPECTED;

// Unsupported field size
extern const int SB_PDF_ERROR_UNSUPPORTED_CROSS_REFERENCE_FIELD_SIZE;

// Unsupported encoding filter
extern const int SB_PDF_ERROR_UNSUPPORTED_ENCODING_FILTER;

// Invalid index
extern const int SB_PDF_ERROR_CROSS_REFERENCE_STREAM_INVALID_INDEX;

// Invalid W entry in a cross-reference stream
extern const int SB_PDF_ERROR_CROSS_REFERENCE_STREAM_INVALID_W_ENTRY;

// Object already exists
extern const int SB_PDF_ERROR_OBJECT_ALREADY_EXISTS;

// Decompression error
extern const int SB_PDF_ERROR_DECOMPRESSION_FAILED;

// Invalid PNG data
extern const int SB_PDF_ERROR_INVALID_PNG_DATA;

// Unsupported PNG predictor
extern const int SB_PDF_ERROR_UNSUPPORTED_PNG_PREDICTOR;

// Unsupported predictor algorithm
extern const int SB_PDF_ERROR_UNSUPPORTED_PREDICTOR_ALGORITHM;

// Document not available
extern const int SB_PDF_ERROR_NO_DOCUMENT;

// Document is not opened
extern const int SB_PDF_ERROR_DOCUMENT_NOT_OPENED;

// Unsupported document format
extern const int SB_PDF_ERROR_UNSUPPORTED_DOCUMENT_FORMAT;

// Invalid AcroForm entry
extern const int SB_PDF_ERROR_INVALID_ACRO_FORM_ENTRY;

// Invalid ROOT entry
extern const int SB_PDF_ERROR_INVALID_ROOT_ENTRY;

// Invalid linearization dictionary
extern const int SB_PDF_ERROR_INVALID_LINEARIZATION_DICTIONARY;

// Invalid document ID
extern const int SB_PDF_ERROR_INVALID_DOCUMENT_ID;

// Bad document catalog
extern const int SB_PDF_ERROR_INVALID_DOCUMENT_CATALOG;

// Bad information dictionary
extern const int SB_PDF_ERROR_INVALID_DOCUMENT_INFO_DICTIONARY;

// Invalid pages dictionary
extern const int SB_PDF_ERROR_INVALID_DOCUMENT_PAGES_DICTIONARY;

// Invalid requirements dictionary
extern const int SB_PDF_ERROR_INVALID_DOCUMENT_REQUIREMENTS_DICTIONARY;

// Invalid names dictionary
extern const int SB_PDF_ERROR_INVALID_DOCUMENT_NAMES_DICTIONARY;

// Invalid annotation
extern const int SB_PDF_ERROR_INVALID_DOCUMENT_ANNOTATION;

// Cannot modify version in signed document
extern const int SB_PDF_ERROR_DOCUMENT_SIGNED_CANT_CHANGE_VERSION;

// Cannot change DecryptionMode property for opened document
extern const int SB_PDF_ERROR_DOCUMENT_OPENED_CANT_CHANGE_PROPERTY;

// Unsupported image type
extern const int SB_PDF_ERROR_UNSUPPORTED_IMAGE_TYPE;

// Unsupported mask image type
extern const int SB_PDF_ERROR_UNSUPPORTED_MASK_IMAGE_TYPE;

// Unsupported color space type
extern const int SB_PDF_ERROR_UNSUPPORTED_COLOR_SPACE_TYPE;

// Security handler already registered
extern const int SB_PDF_ERROR_SECURITY_HANDLER_ALREADY_REGISTERED;

// Security handler not found
extern const int SB_PDF_ERROR_SECURITY_HANDLER_NOT_FOUND;

// Security handler is not bound to PDF document
extern const int SB_PDF_ERROR_SECURITY_HANDLER_NOT_ATTACHED;

// No security handler available
extern const int SB_PDF_ERROR_NO_SECURITY_HANDLER;

// Security handler is not assigned
extern const int SB_PDF_ERROR_NO_SIGNATURE_HANDLER;

// Unsupported digest algorithm
extern const int SB_PDF_ERROR_UNSUPPORTED_DIGEST_ALGORITHM;

// Unsupported encryption algorithm
extern const int SB_PDF_ERROR_UNSUPPORTED_ENCRYPTION_ALGORITHM;

// Invalid digest
extern const int SB_PDF_ERROR_INVALID_DIGEST;

// Invalid signature reference
extern const int SB_PDF_ERROR_INVALID_SIGNATURE_REFERENCE;

// Security handler not intended for signing
extern const int SB_PDF_ERROR_INVALID_SECURTIY_HANDLER;

// Invalid signature contents
extern const int SB_PDF_ERROR_INVALID_SIGNATURE_CONTENTS;

// Invalid signature byte range
extern const int SB_PDF_ERROR_INVALID_SIGNATURE_BYTE_RANGE;

// Byte range does not cover the entire document
extern const int SB_PDF_ERROR_BYTE_RANGE_NOT_COVER_DOCUMENT;

// Document is not encrypted
extern const int SB_PDF_ERROR_DOCUMENT_NOT_ENCRYPTED;

// Cannot encrypt signed document
extern const int SB_PDF_ERROR_DOCUMENT_SIGNED_CANT_ENCRYPT;

// Cannot encrypt encrypted document
extern const int SB_PDF_ERROR_DOCUMENT_ENCRYPTED_CANT_ENCRYPT;

// Cannot sign encrypted document
extern const int SB_PDF_ERROR_DOCUMENT_ENCRYPTED_CANT_SIGN;

// Cannot timestamp encrypted document
extern const int SB_PDF_ERROR_DOCUMENT_ENCRYPTED_CANT_TIMESTAMP;

// Cannot update signature in encrypted document
extern const int SB_PDF_ERROR_DOCUMENT_ENCRYPTED_CANT_UPDATE_SIGNATURE;

// Cannot sign and encrypt document with more than one signature.
extern const int SB_PDF_ERROR_CANT_SIGN_AND_ENCRYPT_TOO_MANY_SIGNATURES;

// Invalid decryption mode
extern const int SB_PDF_ERROR_INVALID_DECRYPTION_MODE;

// Cannot sign encrypted document. Invalid decryption mode.
extern const int SB_PDF_ERROR_INVALID_DECRYPTION_MODE_CANT_SIGN;

// Cannot modify document after signature update
extern const int SB_PDF_ERROR_SIGNATURE_UPDATED_CANT_MODIFY;

// No enough space for signature
extern const int SB_PDF_ERROR_NO_ENOUGH_SPACE_FOR_SIGNATURE;

// No enough space to place the timestamp
extern const int SB_PDF_ERROR_NO_ENOUGH_SPACE_FOR_SIGNATURE_UPDATE;

// No enough space to place the timestamp
extern const int SB_PDF_ERROR_NO_ENOUGH_SPACE_FOR_TIMESTAMP;

// Failed to reload a signature
extern const int SB_PDF_ERROR_RELOAD_SIGNATURE_FAILED;

// Signature is too large to fit in the allocated window. Please consider extending the window by assigning the number of bytes to add to the TElPDFSignature.ExtraSpace property before closing the document.
extern const int SB_PDF_ERROR_SIGNATURE_SIZE_TOO_LARGE;

// There is only one MDP signature allowed (it should be a first signature over a document)
extern const int SB_PDF_ERROR_MDP_SIGNATURE_NOT_FIRST;

// Current signature settings will make existent MDP signature invalid in Adobe Acrobat 8 and lower. Please either disable compatibility mode (Adobe8Compatibility property) or make signature invisible.
extern const int SB_PDF_ERROR_ADOBE8_COMPATIBILITY_WARNING;

// Cannot decrypt object
extern const int SB_PDF_ERROR_CANT_DECRYPT_OBJECT;

// Cannot add more than one signature
extern const int SB_PDF_ERROR_CANT_ADD_SECOND_SIGNATURE;

// Invalid signature information
extern const int SB_PDF_ERROR_INVALID_SIGNATURE_INFORMATION;

// Invalid security handler information
extern const int SB_PDF_ERROR_INVALID_SECURITY_HANDLER_INFORMATION;

// Invalid encrypted data
extern const int SB_PDF_ERROR_INVALID_ENCRYPTED_DATA;

// Invalid block cipher padding
extern const int SB_PDF_ERROR_INVALID_BLOCK_CIPHER_PADDING;

// Invalid key size
extern const int SB_PDF_ERROR_INVALID_KEY_SIZE;

// Invalid password
extern const int SB_PDF_ERROR_INVALID_PASSWORD;

// Invalid password info
extern const int SB_PDF_ERROR_INVALID_PASSWORD_INFO;

// Object is not encrypted
extern const int SB_PDF_ERROR_OBJECT_NOT_ENCRYPTED;

// Unexpected cipher info
extern const int SB_PDF_ERROR_UNEXPECTED_CIPHER_INFO;

// Failed to verify permissions
extern const int SB_PDF_ERROR_PERMISSIONS_VERIFICATION_FAILED;

// Unsupported revision
extern const int SB_PDF_ERROR_UNSUPPORTED_PASSWORD_HANDLER_REVISION;

// Unsupported security handler subfilter
extern const int SB_PDF_ERROR_UNSUPPORTED_SECURITY_HANDLER_SUBFILTER;

// Invalid signing certificate chain
extern const int SB_PDF_ERROR_INVALID_SIGNING_CERTIFICATE_CHAIN;

// Invalid PKCS#7 data
extern const int SB_PDF_ERROR_INVALID_PKCS7_DATA;

// No signing certificate found
extern const int SB_PDF_ERROR_NO_SIGNING_CERTIFICATE;

// Signer certificate not found
extern const int SB_PDF_ERROR_NO_SIGNER_CERTIFICATE;

// Unsupported feature
extern const int SB_PDF_ERROR_UNSUPPORTED_FEATURE;

// Unsupported signature type
extern const int SB_PDF_ERROR_UNSUPPORTED_SIGNATURE_TYPE;

// TSP client component not found
extern const int SB_PDF_ERROR_NO_TSP_CLIENT;

// No proper certificate for encryption found
extern const int SB_PDF_ERROR_NO_ENCRYPTION_CERTIFICATE;

// Unsupported key encryption algorithm
extern const int SB_PDF_ERROR_UNSUPPORTED_KEY_ENCRYPTION_ALGORITHM;

// Encryption failed
extern const int SB_PDF_ERROR_ENCRYPTION_FAILED;

// Failed to generate encryption key
extern const int SB_PDF_ERROR_ENCRYPTION_KEY_GENERATION_FAILED;

// No decryption key found
extern const int SB_PDF_ERROR_NO_DECRYPTION_KEY;

// Bad asynchronous operation state
extern const int SB_PDF_ERROR_BAD_ASYNC_STATE;

// Distributed Cryptography module is not available
extern const int SB_PDF_ERROR_DC_MODULE_UNAVAILABLE;

// Internal error
extern const int SB_XML_ERROR_INTERNAL_ERROR;

// Not implemented
extern const int SB_XML_ERROR_NOT_IMPLEMENTED;

// Index out of bounds
extern const int SB_XML_ERROR_INDEX_OUT_OF_BOUNDS;

// Invalid parameter
extern const int SB_XML_ERROR_INVALID_PARAMATER;

// No XML document available.
extern const int SB_XML_ERROR_NO_DOCUMENT_PARAMETER;

// No XML element available.
extern const int SB_XML_ERROR_NO_ELEMENT_PARAMETER;

// No XML node available.
extern const int SB_XML_ERROR_NO_NODE_PARAMETER;

// No XML node list available.
extern const int SB_XML_ERROR_NO_NODE_LIST_PARAMETER;

// No XML element available.
extern const int SB_XML_ERROR_NO_ELEMENT;

// No XML node available.
extern const int SB_XML_ERROR_NO_NODE;

// Invalid XML node.
extern const int SB_XML_ERROR_INVALID_NODE;

// Invalid XML element.
extern const int SB_XML_ERROR_INVALID_ELEMENT;

// XML element not found
extern const int SB_XML_ERROR_ELEMENT_NOT_FOUND;

// XML node not found
extern const int SB_XML_ERROR_NODE_NOT_FOUND;

// Unexpected XML element
extern const int SB_XML_ERROR_UNEXPECTED_ELEMENT;

// Invalid character
extern const int SB_XML_ERROR_INVALID_CHARACTER_AT_POSITION;

// Unexpected end of file or invalid stream position
extern const int SB_XML_ERROR_UNEXPECTED_END_OF_FILE;

// Encoding is not set
extern const int SB_XML_ERROR_NO_ENCODING;

// Marlformed sequence
extern const int SB_XML_ERROR_MALFORMED_SEQUENCE;

// Invalid sequence
extern const int SB_XML_ERROR_INVALID_SEQUENCE;

// Invalid char
extern const int SB_XML_ERROR_INVALID_CHAR;

// XML parse error
extern const int SB_XML_ERROR_PARSE_FAILED_AT_POSITION;

// Cannot create a document with empty root tag name
extern const int SB_XML_ERROR_DOCUMENT_ELEMENT_EMPTY_NAME;

// Cannot create an element with empty tag name
extern const int SB_XML_ERROR_ELEMENT_EMPTY_NAME;

// Cannot create an entity with empty name
extern const int SB_XML_ERROR_NODE_EMPTY_NAME;

// Failed to reload node data
extern const int SB_XML_ERROR_NODE_DATA_RELOAD_FAILED;

// Failed to load raw data
extern const int SB_XML_ERROR_RAW_DATA_LOAD_FAILED;

// Node cannot have child elements
extern const int SB_XML_ERROR_NODE_NO_CHILD_NODES;

// Wrong document node
extern const int SB_XML_ERROR_NODE_WRONG_DOCUMENT;

// Invalid node type
extern const int SB_XML_ERROR_NODE_INVALID_NODE_TYPE;

// Node has a parent
extern const int SB_XML_ERROR_NODE_HAS_PARENT;

// Node parent refers to itself
extern const int SB_XML_ERROR_NODE_PARENT_EQUAL_SELF;

// Invalid attribute quote
extern const int SB_XML_ERROR_NODE_INVALID_QUOTE;

// Invalid offset parameter
extern const int SB_XML_ERROR_INVALID_PARAMETER_OFFSET;

// Canonical form must be encoded using UTF-8
extern const int SB_XML_ERROR_INVALID_ENCODING;

// Cannot override the default prefix
extern const int SB_XML_ERROR_DEFAULT_PREFIX_OVERRIDE;

// Invalid canonicalization method
extern const int SB_XML_ERROR_INVALID_C14N_METHOD;

// No canonicalization method used
extern const int SB_XML_ERROR_NO_C14N_METHOD;

// Invalid XPath node type
extern const int SB_XML_ERROR_INVALID_XPATH_NODE_TYPE;

// Invalid XPath variable value
extern const int SB_XML_ERROR_INVALID_XPATH_VARIABLE_VALUE;

// Failed to encode to Base64
extern const int SB_XML_ERROR_BASE64_ENCODING_FAILED;

// Failed to decode from Base64
extern const int SB_XML_ERROR_BASE64_DECODING_FAILED;

// Failed to extract Id (invalid local URI)
extern const int SB_XML_ERROR_ID_EXTRACT_FAILED;

// Failed to parse XML date and time
extern const int SB_XML_ERROR_DATETIME_PARSE_FAILED;

// Unsupported data and time format
extern const int SB_XML_ERROR_UNSUPPORTED_DATETIME_FORMAT;

// Invalid public key
extern const int SB_XML_ERROR_INVALID_PUBLIC_KEY;

// No signing certificate
extern const int SB_XML_ERROR_NO_SIGNING_CERTIFICATE;

// Unsupported hash algorithm
extern const int SB_XML_ERROR_UNSUPPORTED_DIGEST_ALGORITHM;

// Unsupported EC field type
extern const int SB_XML_ERROR_UNSUPPORTED_EC_FIELD_TYPE;

// Mask generation function is unknown or unsupported
extern const int SB_XML_ERROR_UNSUPPORTED_MASK_GENERATION_FUNCTION;

// Unsupported prime number type
extern const int SB_XML_ERROR_UNSUPPORTED_EC_PRIME_NUMBER_TYPE;

// No key data available.
extern const int SB_XML_ERROR_NO_KEY_DATA;

// HMAC key data expected
extern const int SB_XML_ERROR_NO_HMAC_KEY_DATA;

// DSA key data expected
extern const int SB_XML_ERROR_NO_DSA_KEY_DATA;

// RSA key data expected
extern const int SB_XML_ERROR_NO_RSA_KEY_DATA;

// ECDSA key data expected
extern const int SB_XML_ERROR_NO_ECDSA_KEY_DATA;

// GOST R 34.10-94 key data expected
extern const int SB_XML_ERROR_NO_GOST94_KEY_DATA;

// GOST R 34.10-2001 key data expected
extern const int SB_XML_ERROR_NO_GOST2001_KEY_DATA;

// Invalid key data
extern const int SB_XML_ERROR_INVALID_KEY_DATA;

// HMAC method not supported
extern const int SB_XML_ERROR_UNSUPPORTED_HMAC_METHOD;

// Signature method not supported for this certificate type
extern const int SB_XML_ERROR_UNSUPPORTED_SIGNATURE_METHOD;

// Unsupported signature algorithm
extern const int SB_XML_ERROR_UNSUPPORTED_SIGNATURE_ALGORITHM;

// Bad asynchronous operation state
extern const int SB_XML_ERROR_BAD_ASYNC_STATE;

// Pre-signed signature element not found
extern const int SB_XML_ERROR_NO_ASYNC_SIGNATURE;

// Async mode is not supported for this signature method type
extern const int SB_XML_ERROR_ASYNC_MODE_NOT_SUPPORTED;

// Timestamping failed
extern const int SB_XML_ERROR_TIMESTAMP_FAILED;

// Signature not loaded or already removed
extern const int SB_XML_ERROR_SIGNATURE_NOT_LOADED;

// RSA-PSS parameters expected
extern const int SB_XML_ERROR_NO_RSA_PSS_PARAMETERS;

// Too many QualifyingProperties elements
extern const int SB_XML_ERROR_TOO_MANY_QUALIFYING_PROPERTIES;

// SignatureProperties element exist in more than one QualifyingProperties
extern const int SB_XML_ERROR_TOO_MANY_SIGNATURE_PROPERTIES;

// SignatureProperties element does not exist in QualifyingProperties
extern const int SB_XML_ERROR_NO_SIGNATURE_PROPERTIES;

// Failed to load certificate from async state
extern const int SB_XML_ERROR_ASYNC_STATE_CERTIFICATE_LOAD_FAILED;

// Unsupported certificate public key algorithm
extern const int SB_XML_ERROR_UNSUPPORTED_CERTIFICATE_PUBLIC_KEY_ALGORITHM;

// The length of AES key is either 128, 192 or 256 bits
extern const int SB_XML_ERROR_INVALID_AES_KEY_LENGTH;

// The length of Camellia key is either 128, 192 or 256 bits
extern const int SB_XML_ERROR_INVALID_CAMELLIA_KEY_LENGTH;

// The length of the data in Key Wrap must be 8, 16, 24 and etc. bytes
extern const int SB_XML_ERROR_INVALID_AES_WRAPPED_KEY_LENGTH;

// xedtExternal mode not allowed for Node encryption
extern const int SB_XML_ERROR_INVALID_EXTERNAL_MODE_FOR_NODE_ENCRYPTION;

// xedtExternal mode not allowed for Node list encryption
extern const int SB_XML_ERROR_INVALID_EXTERNAL_MODE_FOR_NODE_LIST_ENCRYPTION;

// xedtElement mode not allowed for Node list encryption
extern const int SB_XML_ERROR_INVALID_ELEMENT_MODE_FOR_NODE_LIST_ENCRYPTION;

// xedtElement mode not allowed for Binary encryption
extern const int SB_XML_ERROR_INVALID_ELEMENT_MODE_FOR_BINARY_ENCRYPTION;

// xedtContent mode not allowed for Binary encryption
extern const int SB_XML_ERROR_INVALID_CONTENT_MODE_FOR_BINARY_ENCRYPTION;

// EncryptedData not loaded
extern const int SB_XML_ERROR_ENCRYPTED_DATA_NOT_LOADED;

// No Key Encryption Key (KEK) data available
extern const int SB_XML_ERROR_NO_KEY_ENCRYPTION_KEY_DATA;

// Invalid Key Encryption Key (KEK) data
extern const int SB_XML_ERROR_INVALID_KEY_ENCRYPTION_KEY_DATA;

// The Key Wrap method is incorrect for the current Key Encryption Key (KEK)
extern const int SB_XML_ERROR_INVALID_KEY_WRAP_METHOD;

// The encryption method is incorrect
extern const int SB_XML_ERROR_UNSUPPORTED_ENCRYPTION_METHOD;

// Unsupported Key Encryption Key (KEK) type
extern const int SB_XML_ERROR_UNSUPPORTED_KEY_ENCRYPTION_KEY_METHOD;

// Unsupported Key Encryption Key (KEK) algorithm
extern const int SB_XML_ERROR_UNSUPPORTED_KEY_ENCRYPTION_TYPE;

// Unsupported Key Encryption Key (KEK) wrap method
extern const int SB_XML_ERROR_UNSUPPORTED_KEY_WRAP_METHOD;

// Unsupported Key Encryption Key (KEK) transport method
extern const int SB_XML_ERROR_UNSUPPORTED_KEY_TRANSPORT_METHOD;

// The length of the data in Wrapped Key is either 16, 24 or 32 bytes
extern const int SB_XML_ERROR_INVALID_TRIPLE_DES_WRAPPED_KEY_LENGTH;

// The length of the encrypted data in Key Wrap must be 16, 24, 32 and etc. bytes
extern const int SB_XML_ERROR_INVALID_AES_ENCRYPTED_WRAPPED_KEY_LENGTH;

// The encrypted data in Key Wrap is corrupted or Key Encryption Key (KEK) is incorrect
extern const int SB_XML_ERROR_INVALID_ENCRYPTED_WRAPPED_KEY;

// The encrypted data is corrupted or Key is incorrect
extern const int SB_XML_ERROR_INVALID_ENCRYPTED_DATA;

// The length of the data in Encrypted Wrapped Key is either 32, 40 or 48 bytes
extern const int SB_XML_ERROR_INVALID_TRIPLE_DES_ENCRYPTED_WRAPPED_KEY_LENGTH;

// Cannot encrypt attribute
extern const int SB_XML_ERROR_CANT_ENCRYPT_ATTRIBUTE_NODE;

// CipherValue is missing
extern const int SB_XML_ERROR_NO_CIPHER_VALUE;

// Specified key derivation method is not supported
extern const int SB_XML_ERROR_KEY_DERIVATION_METHOD_NOT_SUPPORTED;

// Invalid XAdES version
extern const int SB_XML_ERROR_INVALID_XADES_VERSION;

// XAdES version not supported
extern const int SB_XML_ERROR_UNSUPPORTED_XADES_VERSION;

// Invalid type cast
extern const int SB_XML_ERROR_INVALID_OBJECT_TYPE_PARAMETER;

// Qualifier type not supported
extern const int SB_XML_ERROR_UNSUPPORTED_QUALIFIER_TYPE;

// ASN.1 data encoding method not supported
extern const int SB_XML_ERROR_UNSUPPORTED_PKI_DATA_ENCODING_METHOD;

// Property not supported in specified XAdES version
extern const int SB_XML_ERROR_UNSUPPORTED_XADES_V111_PROPERTY;

// Property not supported in specified XAdES version
extern const int SB_XML_ERROR_UNSUPPORTED_XADES_V111_V122_PROPERTY;

// XAdES form not supported by this XAdES version
extern const int SB_XML_ERROR_UNSUPPORTED_XADES_FORM;

// Include require context
extern const int SB_XML_ERROR_INCLUDE_NO_CONTEXT;

// Include has a wrong context
extern const int SB_XML_ERROR_INCLUDE_INVALID_CONTEXT;

// No TSP client available
extern const int SB_XML_ERROR_NO_TSP_CLIENT;

// Signing certificate not found
extern const int SB_XML_ERROR_SIGNING_CERTIFICATE_NOT_FOUND;

// QualifyingProperties object not found (or signature is not calculated)
extern const int SB_XML_ERROR_QUALIFYING_PROPERTIES_NOT_FOUND;

// Collected validation information is incomplete
extern const int SB_XML_ERROR_VALIDATION_INFORMATION_INCOMPLETE;

// Signer processor expected
extern const int SB_XML_ERROR_SIGNER_PROCESSOR_EXPECTED;

// Retrieved certificate does not match specified CertID
extern const int SB_XML_ERROR_RETRIEVED_CERTIFICATE_NOT_MATCH;

// Retrieved CRL does not match specified CRLRef
extern const int SB_XML_ERROR_RETRIEVED_CRL_NOT_MATCH;

// Retrieved OCSP response does not match specified OCSPRef
extern const int SB_XML_ERROR_RETRIEVED_OCSP_RESPONSE_NOT_MATCH;

// Failed to add unsigned signature property from a lower XAdES form to existent signature with a higher XAdES form
extern const int SB_XML_ERROR_UNSIGNED_SIGNATURE_PROPERTY_ADD_FAILED;

// Cannot add AllDataObjectsTimeStamp to the signed XML document
extern const int SB_XML_ERROR_DOCUMENT_SIGNED_CANT_ADD_ALL_DATA_OBJECTS_TIMESTAMP;

// Verifier processor expected
extern const int SB_XML_ERROR_VERIFIER_PROCESSOR_EXPECTED;

// Internal error
extern const int SB_SOAP_ERROR_INTERNAL_ERROR;

// Not implemented
extern const int SB_SOAP_ERROR_NOT_IMPLEMENTED;

// Unsupported operation
extern const int SB_SOAP_ERROR_UNSUPPORTED_OPERATION;

// The XML document already contains a Document element
extern const int SB_SOAP_ERROR_DOCUMENT_ELEMENT_EXISTS;

// SOAP envelope already contain a Body element
extern const int SB_SOAP_ERROR_ENVELOPE_BODY_ELEMENT_EXISTS;

// SOAP envelope already contain a Header element
extern const int SB_SOAP_ERROR_ENVELOPE_HEADER_ELEMENT_EXISTS;

// Body element is not loaded
extern const int SB_SOAP_ERROR_BODY_ELEMENT_NOT_LOADED;

// Header element is not loaded
extern const int SB_SOAP_ERROR_HEADER_ELEMENT_NOT_LOADED;

// Header block is not loaded
extern const int SB_SOAP_ERROR_HEADER_BLOCK_NOT_LOADED;

// SOAP message is not loaded
extern const int SB_SOAP_ERROR_MESSAGE_NOT_LOADED;

// No header block available
extern const int SB_SOAP_ERROR_WSSE_NO_HEADER_BLOCK;

// Token is not loaded
extern const int SB_SOAP_ERROR_WSSE_TOKEN_NOT_LOADED;

// Element is not loaded
extern const int SB_SOAP_ERROR_WSSE_ELEMENT_NOT_LOADED;

// BinarySecurityToken is not loaded
extern const int SB_SOAP_ERROR_WSSE_BINARY_SECURITY_TOKEN_NOT_LOADED;

// Password is not loaded
extern const int SB_SOAP_ERROR_WSSE_PASSWORD_NOT_LOADED;

// Nonce is not loaded
extern const int SB_SOAP_ERROR_WSSE_NONCE_NOT_LOADED;

// Cannot add/move token element
extern const int SB_SOAP_ERROR_WSSE_ADD_TOKEN_FAILED;

// Invalid value type
extern const int SB_SOAP_ERROR_WSSE_INVALID_BINARY_SECURITY_TOKEN_VALUE_TYPE;

// UsernameToken element already contains a Nonce element
extern const int SB_SOAP_ERROR_WSSE_USERNAME_TOKEN_NONCE_ELEMENT_EXISTS;

// UsernameToken element already contains a Password element
extern const int SB_SOAP_ERROR_WSSE_USERNAME_TOKEN_PASSWORD_ELEMENT_EXISTS;

// UsernameToken element already contains a Username element
extern const int SB_SOAP_ERROR_WSSE_USERNAME_TOKEN_USERNAME_ELEMENT_EXISTS;

// DateTime is not loaded
extern const int SB_SOAP_ERROR_WSU_DATETIME_NOT_LOADED;

// Timestamp element already contains a Created element
extern const int SB_SOAP_ERROR_WSU_TIMESTAMP_CREATED_ELEMENT_EXISTS;

// Timestamp element already contains a Expires element
extern const int SB_SOAP_ERROR_WSU_TIMESTAMP_EXPIRES_ELEMENT_EXISTS;

// UsernameToken element already contains a Created element
extern const int SB_SOAP_ERROR_WSSE_USERNAME_TOKEN_CREATED_ELEMENT_EXISTS;

// Security handler already registered
extern const int SB_SOAP_ERROR_SECURITY_HANDLER_ALREADY_REGISTERED;

// The signature handler is not attached to the envelope
extern const int SB_SOAP_ERROR_SIGNATURE_HANDLER_NOT_ATTACHED;

// Cannot sign (signature already calculated)
extern const int SB_SOAP_ERROR_SIGNATURE_CALCULATED_CANT_SIGN;

// Cannot validate (signature is not calculated)
extern const int SB_SOAP_ERROR_SIGNATURE_NOT_CALCULATED_CANT_VALIDATE;

// Cannot complete async sign (no signature)
extern const int SB_SOAP_ERROR_NO_SIGNATURE_CANT_COMPLETE_ASYNC_SIGN;

// The target element does not have an Id
extern const int SB_SOAP_ERROR_TARGET_ELEMENT_HAS_NO_ID;

// Nothing to sign
extern const int SB_SOAP_ERROR_NOTHING_TO_SIGN;

// No certificate
extern const int SB_SOAP_ERROR_NO_CERTIFICATE;

// No key data
extern const int SB_SOAP_ERROR_NO_KEY_DATA;

// Failed to modify signature element
extern const int SB_SOAP_ERROR_SIGNATURE_ELEMENT_MODIFICATION_FAILED;

// This combination of parameters could not be used for this signature handler
extern const int SB_SOAP_ERROR_INVALID_PARAMETERS_COMBINATION;

// Failed to change security header block for calculated signature
extern const int SB_SOAP_ERROR_SIGNATURE_CALCULATED_CANT_CHANGE_SECURITY_HEADER_BLOCK;

// Unexpected HTTP status code
extern const int SB_SOAP_ERROR_UNEXPECTED_HTTP_STATUS_CODE;

// HTTP client is missing
extern const int SB_SOAP_ERROR_NO_HTTP_CLIENT;

// Invalid PartsList parameter
extern const int SB_SOAP_ERROR_INVALID_PARTS_LIST_PARAMETER;

// Invalid boolean value
extern const int SB_SOAP_ERROR_INVALID_BOOLEAN_VALUE;

// Parameter value is not a number
extern const int SB_SOAP_ERROR_INVALID_NUMBER_VALUE;

// Parameter value is not properly formatted date and time
extern const int SB_SOAP_ERROR_INVALID_DATETIME_VALUE;

// Parameter value is not Base64 encoded binary
extern const int SB_SOAP_ERROR_INVALID_BASE64_VALUE;

// Invalid parameter name
extern const int SB_SOAP_ERROR_INVALID_PARAMETER_NAME;

// Internal error
extern const int SB_OFFICE_ERROR_INTERNAL_ERROR;

// Not implemented
extern const int SB_OFFICE_ERROR_NOT_IMPLEMENTED;

// Index out of bounds
extern const int SB_OFFICE_ERROR_INDEX_OUT_OF_BOUNDS;

// Document is not opened
extern const int SB_OFFICE_ERROR_DOCUMENT_NOT_OPENED;

// Document is not encrypted
extern const int SB_OFFICE_ERROR_DOCUMENT_NOT_ENCRYPTED;

// Operation is not supported for this document format
extern const int SB_OFFICE_ERROR_DOCUMENT_FORMAT_UNSUPPORTED_OPERATION;

// Security handler already registered
extern const int SB_OFFICE_ERROR_SECURITY_HANDLER_ALREADY_REGISTERED;

// Invalid document format
extern const int SB_OFFICE_ERROR_INVALID_DOCUMENT_FORMAT;

// Invalid document type
extern const int SB_OFFICE_ERROR_INVALID_DOCUMENT_TYPE;

// Invalid signature handler
extern const int SB_OFFICE_ERROR_INVALID_SIGNATURE_HANDLER;

// Invalid encryption handler
extern const int SB_OFFICE_ERROR_INVALID_ENCRYPTION_HANDLER;

// Cannot change encryption handler
extern const int SB_OFFICE_ERROR_ENCRYPTION_HANDLER_CHANGE_FAILED;

// Cannot attach (signature already calculated)
extern const int SB_OFFICE_ERROR_SIGNATURE_CALCULATED_CANT_ATTACH;

// The signature handler is not attached to a document
extern const int SB_OFFICE_ERROR_SIGNATURE_HANDLER_NOT_ATTACHED;

// Cannot attach (signature already attached)
extern const int SB_OFFICE_ERROR_CANT_ATTACH_SIGNATURE;

// Cannot detach (signature already calculated)
extern const int SB_OFFICE_ERROR_SIGNATURE_CALCULATED_CANT_DETACH;

// Cannot sign shared workbook
extern const int SB_OFFICE_ERROR_SHARED_WORKBOOK_CANT_SIGN;

// Invalid encryption stream
extern const int SB_OFFICE_ERROR_INVALID_ENCRYPTION_STREAM;

// Invalid UserEditAtom
extern const int SB_OFFICE_ERROR_INVALID_USER_EDIT_ATOM;

// Invalid PersistDirectoryAtom
extern const int SB_OFFICE_ERROR_INVALID_PERSIST_DIRECTORY_ATOM;

// EncryptedPackage stream entry not found
extern const int SB_OFFICE_ERROR_ENCRYPTED_PACKAGE_ENTRY_NOT_FOUND;

// Cannot encrypt document using this encryption handler
extern const int SB_OFFICE_ERROR_ENCRYPTION_HANDLER_CANT_ENCRYPT_DOCUMENT;

// Workbook BOF record not found
extern const int SB_OFFICE_ERROR_WORKBOOK_BOF_RECORD_NOT_FOUND;

// Cannot encrypt encrypted document
extern const int SB_OFFICE_ERROR_ENCRYPTION_FAILED_DOCUMENT_ENCRYPTED;

// Cannot encrypt signed document
extern const int SB_OFFICE_ERROR_ENCRYPTION_FAILED_DOCUMENT_SIGNED;

// Invalid OfficeArtBStoreContainerFileBlock
extern const int SB_OFFICE_ERROR_INVALID_ART_BSTORE_CONTAINER_FILE_BLOCK;

// Unsupported OfficeArtBStoreContainerFileBlock
extern const int SB_OFFICE_ERROR_UNSUPPORTED_ART_BSTORE_CONTAINER_FILE_BLOCK;

// DataSpaces\\Version stream entry not found
extern const int SB_OFFICE_ERROR_DATA_SPACES_VERSION_ENTRY_NOT_FOUND;

// DataSpaceMap stream entry not found
extern const int SB_OFFICE_ERROR_DATA_SPACE_MAP_ENTRY_NOT_FOUND;

// DataSpaceInfo storage entry not found
extern const int SB_OFFICE_ERROR_DATA_SPACE_INFO_ENTRY_NOT_FOUND;

// DataSpaces\\TransformInfo storage entry not found
extern const int SB_OFFICE_ERROR_DATA_SPACES_TRANSFORM_INFO_ENTRY_NOT_FOUND;

// StrongEncryptionDataSpace stream entry not found
extern const int SB_OFFICE_ERROR_STRONG_ENCRYPTION_DATA_SPACE_ENTRY_NOT_FOUND;

// DataSpaces\\TransformInfo\\StrongEncryptionTransform storage entry not found
extern const int SB_OFFICE_ERROR_DATA_SPACES_STRONG_ENCRYPTION_TRANSFORM_NOT_FOUND;

// DataSpaces\\TransformInfo\\StrongEncryptionTransform\\Primary stream entry not found
extern const int SB_OFFICE_ERROR_DATA_SPACES_STRONG_ENCRYPTION_TRANSFORM_PRIMARY_NOT_FOUND;

// Invalid DataSpaceDefinition TransformReference entry
extern const int SB_OFFICE_ERROR_INVALID_DATA_SPACE_DEFINITION_TRANSFORM_REFERENCE_ENTRY;

// Invalid TransformInfoHeader
extern const int SB_OFFICE_ERROR_INVALID_TRANSFORM_INFO_HEADER;

// EncryptionInfo stream entry not found
extern const int SB_OFFICE_ERROR_ENCRYPTION_INFO_ENTRY_NOT_FOUND;

// Invalid Current User stream size
extern const int SB_OFFICE_ERROR_INVALID_CURRENT_USER_STREAM_SIZE;

// Package signature corrupted
extern const int SB_OFFICE_ERROR_CORRUPTED_PACKAGE_SIGNATURE;

// Digital Signature Origin part not found
extern const int SB_OFFICE_ERROR_ORIGIN_PART_NOT_FOUND;

// Failed to read data
extern const int SB_OFFICE_ERROR_DATA_READ_FAILED;

// Fixed Document part not found
extern const int SB_OFFICE_ERROR_FIXED_DOCUMENT_PART_NOT_FOUND;

// Fixed Document Sequence part not found
extern const int SB_OFFICE_ERROR_FIXED_DOCUMENT_SEQUENCE_PART_NOT_FOUND;

// Invalid Signature Definitions part
extern const int SB_OFFICE_ERROR_INVALID_SIGNATURE_DEFINITION_PART;

// No signature definition available
extern const int SB_OFFICE_ERROR_NO_SIGNATURE_DEFINITION;

// Invalid parameter value
extern const int SB_OFFICE_ERROR_INVALID_PARAM_VALUE;

// No office document part
extern const int SB_OFFICE_ERROR_NO_OFFICE_DOCUMENT_PART;

// Cannot modify calculation properties for signed spreadsheet
extern const int SB_OFFICE_ERROR_CALC_PROPS_FAILED_SIGNED_SPREADSHEET;

// Unsupported algorithm
extern const int SB_OFFICE_ERROR_UNSUPPORTED_ALGORITHM;

// Unsupported hash algorithm
extern const int SB_OFFICE_ERROR_UNSUPPORTED_DIGEST_ALGORITHM;

// Invalid cipher mode
extern const int SB_OFFICE_ERROR_INVALID_CIPHER_MODE;

// Invalid password
extern const int SB_OFFICE_ERROR_INVALID_PASSWORD;

// Invalid EncryptedPackage stream size value
extern const int SB_OFFICE_ERROR_INVALID_ENCRYPTED_PACKAGE_STREAM_SIZE_VALUE;

// Invalid EncryptionHeader flags
extern const int SB_OFFICE_ERROR_INVALID_ENCRYPTION_HEADER_FLAGS;

// Invalid encryption algorithm
extern const int SB_OFFICE_ERROR_INVALID_ENCRYPTION_ALGORITHM;

// Invalid hash algorithm
extern const int SB_OFFICE_ERROR_INVALID_DIGEST_ALGORITHM;

// Invalid encryption algorithm key size
extern const int SB_OFFICE_ERROR_INVALID_ENCRYPTION_ALGORITHM_KEY_SIZE;

// Invalid EncryptionVerifier salt size
extern const int SB_OFFICE_ERROR_INVALID_ENCRYPTION_VERIFIER_SALT_SIZE;

// Invalid salt size
extern const int SB_OFFICE_ERROR_INVALID_SALT_SIZE;

// Invalid block size
extern const int SB_OFFICE_ERROR_INVALID_BLOCK_SIZE;

// Invalid hash size
extern const int SB_OFFICE_ERROR_INVALID_HASH_SIZE;

// Invalid spin count
extern const int SB_OFFICE_ERROR_INVALID_SPIN_COUNT;

// Invalid HMAC key size
extern const int SB_OFFICE_ERROR_INVALID_HMAC_KEY_SIZE;

// Invalid checksum
extern const int SB_OFFICE_ERROR_INVALID_CHECKSUM;

// Invalid file entry size value
extern const int SB_OFFICE_ERROR_INVALID_FILE_ENTRY_SIZE_VALUE;

// Invalid verifier hash size
extern const int SB_OFFICE_ERROR_INVALID_VERIFIER_HASH_SIZE;

// Invalid key length
extern const int SB_OFFICE_ERROR_INVALID_KEY_LENGTH;

// Insufficient data
extern const int SB_OFFICE_ERROR_INSUFFICIENT_DATA;

// Failed to read data size from EncryptedPackage
extern const int SB_OFFICE_ERROR_ENCRYPTED_PACKAGE_DATA_SIZE_READ_FAILED;

// Failed to write data size to EncryptedPackage
extern const int SB_OFFICE_ERROR_ENCRYPTED_PACKAGE_DATA_SIZE_WRITE_FAILED;

// Cannot modify encryption handler properties (document already encrypted)
extern const int SB_OFFICE_ERROR_CANT_MODIFY_ENCRYPTION_HANDLER_PROPERTIES;

// Cannot modify signature properties (signature already calculated)
extern const int SB_OFFICE_ERROR_CANT_MODIFY_SIGNATURE_PROPERTIES;

// Cannot modify key encryptors (document already encrypted)
extern const int SB_OFFICE_ERROR_CANT_MODIFY_KEY_ENCRYPTORS;

// Password is too short
extern const int SB_OFFICE_ERROR_PASSWORD_TOO_SHORT;

// Password is too long
extern const int SB_OFFICE_ERROR_PASSWORD_TOO_LONG;

// Data integrity error
extern const int SB_OFFICE_ERROR_DATA_INTEGRITY_ERROR;

// File entry is not encrypted
extern const int SB_OFFICE_ERROR_FILE_ENTRY_NOT_ENCRYPTED;

// Unsupported auto increment parameter value
extern const int SB_OFFICE_ERROR_UNSUPPORTED_AUTO_INCREMENT_PARAMETER_VALUE;

// No certificate
extern const int SB_OFFICE_ERROR_NO_CERTIFICATE;

// No key data
extern const int SB_OFFICE_ERROR_NO_KEY_DATA;

// Cannot sign (signature already calculated)
extern const int SB_OFFICE_ERROR_SIGNATURE_CALCULATED_CANT_SIGN;

// Cannot sign protected document
extern const int SB_OFFICE_ERROR_PROTECTED_DOCUMENT_SIGN_UNSUPPORTED;

// Cannot validate (signature is not calculated)
extern const int SB_OFFICE_ERROR_SIGNATURE_NOT_CALCULATED_CANT_VALIDATE;

// Nothing to sign
extern const int SB_OFFICE_ERROR_NOTHING_TO_SIGN;

// The package-specific Object element not found
extern const int SB_OFFICE_ERROR_PACKAGE_OBJECT_ELEMENT_NOT_FOUND;

// Invalid package-specific Object element
extern const int SB_OFFICE_ERROR_INVALID_PACKAGE_OBJECT_ELEMENT;

// Invalid package part content type
extern const int SB_OFFICE_ERROR_INVALID_PACKAGE_PART_CONTENT_TYPE;

// Invalid transform in package-specific Manifest element
extern const int SB_OFFICE_ERROR_INVALID_TRANSFORM_IN_PACKAGE_MANIFEST_ELEMENT;

// Unsupported canonicalization method
extern const int SB_OFFICE_ERROR_UNSUPPORTED_CANONICALIZATION_METHOD;

// No package part available
extern const int SB_OFFICE_ERROR_NO_PACKAGE_PART;

// No relationsips
extern const int SB_OFFICE_ERROR_NO_RELATIONSHIPS;

// No signed part available
extern const int SB_OFFICE_ERROR_NO_SIGNED_PART;

// No signed entry available
extern const int SB_OFFICE_ERROR_NO_SIGNED_ENTRY;

// The signed part is not attached to a signature handler
extern const int SB_OFFICE_ERROR_SIGNED_PART_NOT_ATTACHED;

// Package part not found
extern const int SB_OFFICE_ERROR_PACKAGE_PART_NOT_FOUND;

// Package entry not found
extern const int SB_OFFICE_ERROR_PACKAGE_ENTRY_NOT_FOUND;

// Cannot modify signed parts (signature already calculated)
extern const int SB_OFFICE_ERROR_CANT_MODIFY_SIGNED_PARTS;

// Cannot modify signed entries (signature already calculated)
extern const int SB_OFFICE_ERROR_CANT_MODIFY_SIGNED_ENTRIES;

// Signed relationship part already exists
extern const int SB_OFFICE_ERROR_SIGNED_RELATIONSHIP_PART_EXISTS;

// Signed part already exists
extern const int SB_OFFICE_ERROR_SIGNED_PART_EXISTS;

// Signed entry already exists
extern const int SB_OFFICE_ERROR_SIGNED_ENTRY_EXISTS;

// Cannot embed certificate into a signed part after signing
extern const int SB_OFFICE_ERROR_SIGNATURE_CALCULATED_CANT_EMBED_CERTIFICATE;

// Cannot complete async sign (no signature)
extern const int SB_OFFICE_ERROR_CANT_COMPLETE_ASYNC_SIGN_NO_SIGNATURE;

// Failed to load certificate from async state
extern const int SB_OFFICE_ERROR_ASYNC_STATE_CERTIFICATE_LOAD_FAILED;

// Bad asynchronous operation state
extern const int SB_OFFICE_ERROR_BAD_ASYNC_STATE;

// Cannot create part which already exists
extern const int SB_OFFICE_ERROR_PART_CREATE_FAILED_EXISTS;

// Failed to create part (package is read-only)
extern const int SB_OFFICE_ERROR_PART_CREATE_FAILED_READONLY;

// Failed to delete part (package is read-only)
extern const int SB_OFFICE_ERROR_PART_DELETE_FAILED_READONLY;

// Failed to create part stream (package is read-only)
extern const int SB_OFFICE_ERROR_PART_STREAM_CREATE_FAILED_READONLY;

// Failed to delete part stream (package is read-only)
extern const int SB_OFFICE_ERROR_PART_STREAM_DELETE_FAILED_READONLY;

// The package directory does not exists
extern const int SB_OFFICE_ERROR_PACKAGE_DIRECTORY_NOT_EXISTS;

// Content Types stream not found
extern const int SB_OFFICE_ERROR_CONTENT_TYPES_STREAM_NOT_FOUND;

// Manifest stream not found
extern const int SB_OFFICE_ERROR_MANIFEST_STREAM_NOT_FOUND;

// MIME Media Type stream not found
extern const int SB_OFFICE_ERROR_MIMETYPE_STREAM_NOT_FOUND;

// Failed to open part stream for writing
extern const int SB_OFFICE_ERROR_STREAM_OPEN_FOR_WRITING_FAILED;

// The stream already exists
extern const int SB_OFFICE_ERROR_STREAM_EXISTS;

// Duplicate part
extern const int SB_OFFICE_ERROR_DUPLICATE_PART;

// Failed to get interleaved part stream
extern const int SB_OFFICE_ERROR_INTERLEAVED_PART_STREAM_GET_FAILED;

// Output buffer too small
extern const int SB_OFFICE_ERROR_OUTPUT_BUFFER_TOO_SMALL;

// Failed to read value
extern const int SB_OFFICE_ERROR_VALUE_READ_FAILED;

// Failed to write value
extern const int SB_OFFICE_ERROR_VALUE_WRITE_FAILED;

// No Stream Available
extern const int SB_OFFICE_ERROR_NO_STREAM_PARAMETER;

// Invalid reserved value
extern const int SB_OFFICE_ERROR_INVALID_RESERVED_VALUE;

// Invalid DataSpaces feature identifier
extern const int SB_OFFICE_ERROR_INVALID_DATA_SPACES_FEATURE_IDENTIFIER;

// Invalid DataSpaces reader version
extern const int SB_OFFICE_ERROR_INVALID_DATA_SPACES_READER_VERSION;

// Invalid DataSpacesMap header length
extern const int SB_OFFICE_ERROR_INVALID_DATA_SPACE_MAP_HEADER_LENGTH;

// Invalid DataSpacesMapEntry length
extern const int SB_OFFICE_ERROR_INVALID_DATA_SPACE_MAP_ENTRY_LENGTH;

// Invalid DataSpacesDefinition header length
extern const int SB_OFFICE_ERROR_INVALID_DATA_SPACE_DEFINITION_HEADER_LENGTH;

// Invalid EncryptionHeader size extra value
extern const int SB_OFFICE_ERROR_INVALID_ENCRYPTION_HEADER_SIZE_EXTRA;

// Invalid EncryptionHeader length
extern const int SB_OFFICE_ERROR_INVALID_ENCRYPTION_HEADER_LENGTH;

// Invalid EncryptionVerifier salt size
extern const int SB_OFFICE_ERROR_INVALID_BIN_ENCRYPTION_VERIFIER_SALT_SIZE;

// Invalid encrypted stream name length
extern const int SB_OFFICE_ERROR_INVALID_ENCRYPTED_STREAM_NAME_LENGTH;

// Invalid CertificateInfo size
extern const int SB_OFFICE_ERROR_INVALID_CERTIFICATE_INFO_SIZE;

// Invalid CertificateInfo version
extern const int SB_OFFICE_ERROR_INVALID_CERTIFICATE_INFO_VERSION;

// Invalid CertificateInfo signer name length
extern const int SB_OFFICE_ERROR_INVALID_CERTIFICATE_INFO_SIGNER_NAME_LENGTH;

// Invalid CertificateInfo issuer name length
extern const int SB_OFFICE_ERROR_INVALID_CERTIFICATE_INFO_ISSUER_NAME_LENGTH;

// Invalid DocSigSerializedCertStore version
extern const int SB_OFFICE_ERROR_INVALID_DOC_SIG_SERIALIZED_CERT_STORE_VERSION;

// Invalid DocSigSerializedCertStore file type
extern const int SB_OFFICE_ERROR_INVALID_DOC_SIG_SERIALIZED_CERT_STORE_FILE_TYPE;

// Invalid IntermediateCertificatesStore size
extern const int SB_OFFICE_ERROR_INVALID_INTERMEDIATE_CERTIFICATES_STORE_SIZE;

// Invalid EndElementMarkerEntry
extern const int SB_OFFICE_ERROR_INVALID_END_ELEMENT_MARKER_ENTRY;

// Invalid PersistDirectoryEntry
extern const int SB_OFFICE_ERROR_INVALID_PERSIST_DIRECTORY_ENTRY;

// Invalid record size
extern const int SB_OFFICE_ERROR_INVALID_RECORD_SIZE;

// Invalid suffix name for a logical item
extern const int SB_OFFICE_ERROR_INVALID_LOGICAL_ITEM_SUFFIX_NAME;

// Invalid XML element
extern const int SB_OFFICE_ERROR_INVALID_XML_ELEMENT;

// No XML element available
extern const int SB_OFFICE_ERROR_NO_XML_ELEMENT_PARAMETER;

// No XML document available
extern const int SB_OFFICE_ERROR_NO_XML_DOCUMENT_PARAMETER;

// Invalid key encryptor XML element
extern const int SB_OFFICE_ERROR_INVALID_KEY_ENCRYPTOR_XML_ELEMENT;

// Required element is missing (in SignatureInfoV1 element)
extern const int SB_OFFICE_ERROR_SIGNATURE_INFO_V1_NO_REQUIRED_ELEMENT;

// A positive integer is expected
extern const int SB_OFFICE_ERROR_NEGATIVE_INTEGER;

// Version string is too long
extern const int SB_OFFICE_ERROR_VERSION_STRING_TOO_LONG;

// Signature comments string is too long
extern const int SB_OFFICE_ERROR_SIGNATURE_COMMENTS_STRING_TOO_LONG;

// Signature provider url string is too long
extern const int SB_OFFICE_ERROR_SIGNATURE_PROVIDER_URL_STRING_TOO_LONG;

// Signature text string is too long
extern const int SB_OFFICE_ERROR_SIGNATURE_TEXT_STRING_TOO_LONG;

// Invalid data
extern const int SB_SAML_ERROR_INVALID_DATA;

// Failed to save metadata
extern const int SB_SAML_ERROR_FAILED_TO_SAVE_METADATA;

// Bad metadata
extern const int SB_SAML_ERROR_BAD_METADATA;

// Decryption failed
extern const int SB_SAML_ERROR_DECRYPTION_FAILED;

// Cannot find an appropriate session
extern const int SB_SAML_ERROR_NO_SESSION;

// Unexpected request
extern const int SB_SAML_ERROR_UNEXPECTED_REQUEST;

// Service provider record not found
extern const int SB_SAML_ERROR_SP_RECORD_NOT_FOUND;

// Artifact not found
extern const int SB_SAML_ERROR_ARTIFACT_NOT_FOUND;

// Unsupported binding type
extern const int SB_SAML_ERROR_BINDING_UNSUPPORTED;

// Request originates from an unknown SP
extern const int SB_SAML_ERROR_SP_UNKNOWN;

// Signature required
extern const int SB_SAML_ERROR_SIGNATURE_REQUIRED;

// Signature is not valid
extern const int SB_SAML_ERROR_SIGNATURE_NOT_VALID;

// Request error
extern const int SB_SAML_ERROR_REQUEST_ERROR;

// Cancelled by the user
extern const int SB_SAML_ERROR_USER_CANCELLED;

// The request is addressed to an unknown destination
extern const int SB_SAML_ERROR_DESTINATION_UNKNOWN;

// Configuration incomplete
extern const int SB_SAML_ERROR_CONFIGURATION_INCOMPLETE;

// Unsupported policy
extern const int SB_SAML_ERROR_UNSUPPORTED_POLICY;

// Authentication error
extern const int SB_SAML_ERROR_AUTH_ERROR;

// Internal error
extern const int SB_SAML_ERROR_INTERNAL_ERROR;

// General error
extern const int SB_SAML_ERROR_GENERAL_ERROR;

// Unknown principal
extern const int SB_SAML_ERROR_PRINCIPAL_UNKNOWN;

// Unknown issuer
extern const int SB_SAML_ERROR_SOURCE_UNKNOWN;

// Unknown attribute
extern const int SB_SAML_ERROR_ATTRIBUTE_UNKNOWN;

// Could not find a suitable ARS endpoint
extern const int SB_SAML_ERROR_IDP_UNKNOWN;

// HTTP request failed
extern const int SB_SAML_ERROR_HTTP_REQUEST_FAILED;

// Response error
extern const int SB_SAML_ERROR_RESPONSE_ERROR;

// Bad parameter
extern const int SB_SAML_ERROR_BAD_PARAMETER;

// Unexpected response
extern const int SB_SAML_ERROR_UNEXPECTED_RESPONSE;

// It was not possible to establish the type of the archive file.
extern const int aftUnknown;

// The archive contains data in ZIP format.
extern const int aftZip;

// The archive file contains data in GZIP format.
extern const int aftGzip;

// The archive contains BZIP2 data.
extern const int aftBzip2;

// The archive contains a .tar file.
extern const int aftTar;

// The archive contains a .tar.gz file.
extern const int aftTarGzip;

// The archive contains data in .tar.bz2 format.
extern const int aftTarBzip2;

// Unknown signature level
extern const int aslUnknown;

// Generic (this value applicable to XAdES signature only and corresponds to XML-DSIG signature)
extern const int aslGeneric;

// Baseline B (B-B, basic)
extern const int aslBaselineB;

// Baseline T (B-T, timestamped)
extern const int aslBaselineT;

// Baseline LT (B-LT, long-term)
extern const int aslBaselineLT;

// Baseline LTA (B-LTA, long-term with archived timestamp)
extern const int aslBaselineLTA;

// BES (Basic Electronic Signature)
extern const int aslBES;

// EPES (Electronic Signature with an Explicit Policy)
extern const int aslEPES;

// T (Timestamped)
extern const int aslT;

// C (T with revocation references)
extern const int aslC;

// X (C with SigAndRefs timestamp or RefsOnly timestamp) (this value applicable to XAdES signature only)
extern const int aslX;

// X Type 1 (C with an ES-C timestamp) (this value applicable to CAdES signature only)
extern const int aslXType1;

// X Type 2 (C with a CertsAndCRLs timestamp) (this value applicable to CAdES signature only)
extern const int aslXType2;

// X-L (X with revocation values) (this value applicable to XAdES signature only)
extern const int aslXL;

// X-L Type 1 (C with revocation values and an ES-C timestamp) (this value applicable to CAdES signature only)
extern const int aslXLType1;

// X-L Type 2 (C with revocation values and a CertsAndCRLs timestamp) (this value applicable to CAdES signature only)
extern const int aslXLType2;

// A (archived)
extern const int aslA;

// Extended BES
extern const int aslExtendedBES;

// Extended EPES
extern const int aslExtendedEPES;

// Extended T
extern const int aslExtendedT;

// Extended C
extern const int aslExtendedC;

// Extended X (this value applicable to XAdES signature only)
extern const int aslExtendedX;

// Extended X (type 1) (this value applicable to CAdES signature only)
extern const int aslExtendedXType1;

// Extended X (type 2) (this value applicable to CAdES signature only)
extern const int aslExtendedXType2;

// Extended X-Long (this value applicable to XAdES signature only)
extern const int aslExtendedXLong;

// Extended X-L (this value applicable to XAdES signature only)
extern const int aslExtendedXL;

// Extended XL (type 1) (this value applicable to CAdES signature only)
extern const int aslExtendedXLType1;

// Extended XL (type 2) (this value applicable to CAdES signature only)
extern const int aslExtendedXLType2;

// Extended A
extern const int aslExtendedA;

// Add one more unsigned attribute with the same OID
extern const int acrInsert;

// Do nothing
extern const int acrIgnore;

// Replace the existing unsigned attribute with the provided one
extern const int acrReplace;

// Throw an error
extern const int acrError;

// Do nothing
extern const int tcrIgnore;

// Replace the existing timestamp with a new one
extern const int tcrReplace;

// Throw an error
extern const int tcrError;

// Unknown validation error
extern const int cerrUnknown;

// No message digest attribute included in the signature
extern const int cerrNoMessageDigest;

// No mandatory content-type attribute is included in the signature
extern const int cerrNoContentType;

// No mandatory signing-certificate (-v2) attribute is included in the signature
extern const int cerrNoSigningCertificate;

// No signature policy information is included in the signature
extern const int cerrNoSignaturePolicy;

// The signature is not timestamped
extern const int cerrNoSignatureTimestamp;

// No certificate-references attribute was found in the signature
extern const int cerrNoCertificateReferences;

// No revocation-references attribute was found in the signature
extern const int cerrNoRevocationReferences;

// No certificate-values attribute was found in the signature
extern const int cerrNoCertificateValues;

// No revocation-values attribute was found in the signature
extern const int cerrNoRevocationValues;

// No timestamped validation data was found in the signature
extern const int cerrNoTimestampedValidationData;

// No archival timestamp was found in the signature
extern const int cerrNoArchivalTimestamp;

// Unexpected validation elements were found in the signature
extern const int cerrUnexpectedValidationElements;

// Some mandatory validation elements are missing from the signature
extern const int cerrMissingValidationElements;

// ATS Hash Index attribute is invalid
extern const int cerrInvalidATSHashIndex;

// No mandatory signing-time attribute was found in the signature
extern const int cerrNoSigningTime;

// Signature policy store attribute is misplaced
extern const int cerrMisplacedSigPolicyStore;

// Add attributes
extern const int cukAddAttributes;

// Update attributes
extern const int cukUpdateAttributes;

// Unknown certificate format
extern const int cfmUnknown;

// DER file format. Applicable to certificates, certificate requests, private keys. Encryption not supported
extern const int cfmDER;

// PEM file format. Applicable to certificates, certificate requests, private keys. Encryption supported for private keys.
extern const int cfmPEM;

// PFX/PKCS#12 file format. Applicable to certificates. Encryption supported.
extern const int cfmPFX;

// SPC file format. Applicable to certificates. Encryption not supported.
extern const int cfmSPC;

// PVK file format. Applicable to private keys. Encryption not supported.
extern const int cfmPVK;

// PKCS#8 file format. Applicable to private keys. Encryption supported.
extern const int cfmPKCS8;

// NET file format. Applicable to private keys. Encryption not supported.
extern const int cfmNET;

// Unknown or uninitialized certificate type
extern const int ctUnknown;

// An X.509 digital certificate
extern const int ctX509Certificate;

// An X.509 certificate request (CSR)
extern const int ctX509CertificateRequest;

// Unknown key usage
extern const int ckuUnknown;

// Digital signature
extern const int ckuDigitalSignature;

// Non-repudiation
extern const int ckuNonRepudiation;

// Key encipherment
extern const int ckuKeyEncipherment;

// Data encipherment
extern const int ckuDataEncipherment;

// Key agreement
extern const int ckuKeyAgreement;

// Certificate signing
extern const int ckuKeyCertSign;

// Revocation signing
extern const int ckuCRLSign;

// Encipher only
extern const int ckuEncipherOnly;

// Decipher only
extern const int ckuDecipherOnly;

// Server authentication
extern const int ckuServerAuthentication;

// Client authentication
extern const int ckuClientAuthentication;

// Code signing
extern const int ckuCodeSigning;

// Email protection
extern const int ckuEmailProtection;

// Timestamping
extern const int ckuTimeStamping;

// OCSP signing
extern const int ckuOCSPSigning;

// Smartcard logon
extern const int ckuSmartCardLogon;

// Kerberos - client authentication
extern const int ckuKeyPurposeClientAuth;

// Kerberos - KDC
extern const int ckuKeyPurposeKDC;

// 
extern NSString* const SB_CERT_ALGORITHM_ID_RSA_ENCRYPTION;

// 
extern NSString* const SB_CERT_ALGORITHM_MD2_RSA_ENCRYPTION;

// 
extern NSString* const SB_CERT_ALGORITHM_MD5_RSA_ENCRYPTION;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA1_RSA_ENCRYPTION;

// 
extern NSString* const SB_CERT_ALGORITHM_ID_DSA;

// 
extern NSString* const SB_CERT_ALGORITHM_ID_DSA_SHA1;

// 
extern NSString* const SB_CERT_ALGORITHM_DH_PUBLIC;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA224_RSA_ENCRYPTION;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA256_RSA_ENCRYPTION;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA384_RSA_ENCRYPTION;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA512_RSA_ENCRYPTION;

// 
extern NSString* const SB_CERT_ALGORITHM_ID_RSAPSS;

// 
extern NSString* const SB_CERT_ALGORITHM_ID_RSAOAEP;

// 
extern NSString* const SB_CERT_ALGORITHM_RSASIGNATURE_RIPEMD160;

// 
extern NSString* const SB_CERT_ALGORITHM_ID_ELGAMAL;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA1_ECDSA;

// 
extern NSString* const SB_CERT_ALGORITHM_RECOMMENDED_ECDSA;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA224_ECDSA;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA256_ECDSA;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA384_ECDSA;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA512_ECDSA;

// 
extern NSString* const SB_CERT_ALGORITHM_EC;

// 
extern NSString* const SB_CERT_ALGORITHM_SPECIFIED_ECDSA;

// 
extern NSString* const SB_CERT_ALGORITHM_GOST_R3410_1994;

// 
extern NSString* const SB_CERT_ALGORITHM_GOST_R3410_2001;

// 
extern NSString* const SB_CERT_ALGORITHM_GOST_R3411_WITH_R3410_1994;

// 
extern NSString* const SB_CERT_ALGORITHM_GOST_R3411_WITH_R3410_2001;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA1_ECDSA_PLAIN;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA224_ECDSA_PLAIN;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA256_ECDSA_PLAIN;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA384_ECDSA_PLAIN;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA512_ECDSA_PLAIN;

// 
extern NSString* const SB_CERT_ALGORITHM_RIPEMD160_ECDSA_PLAIN;

// 
extern NSString* const SB_CERT_ALGORITHM_WHIRLPOOL_RSA_ENCRYPTION;

// 
extern NSString* const SB_CERT_ALGORITHM_ID_DSA_SHA224;

// 
extern NSString* const SB_CERT_ALGORITHM_ID_DSA_SHA256;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA3_224_RSA_ENCRYPTION;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA3_256_RSA_ENCRYPTION;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA3_384_RSA_ENCRYPTION;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA3_512_RSA_ENCRYPTION;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA3_224_ECDSA;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA3_256_ECDSA;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA3_384_ECDSA;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA3_512_ECDSA;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA3_224_ECDSA_PLAIN;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA3_256_ECDSA_PLAIN;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA3_384_ECDSA_PLAIN;

// 
extern NSString* const SB_CERT_ALGORITHM_SHA3_512_ECDSA_PLAIN;

// 
extern NSString* const SB_CERT_ALGORITHM_ID_DSA_SHA3_224;

// 
extern NSString* const SB_CERT_ALGORITHM_ID_DSA_SHA3_256;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2S_128_RSA_ENCRYPTION;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2S_160_RSA_ENCRYPTION;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2S_224_RSA_ENCRYPTION;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2S_256_RSA_ENCRYPTION;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2B_160_RSA_ENCRYPTION;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2B_256_RSA_ENCRYPTION;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2B_384_RSA_ENCRYPTION;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2B_512_RSA_ENCRYPTION;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2S_128_ECDSA;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2S_160_ECDSA;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2S_224_ECDSA;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2S_256_ECDSA;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2B_160_ECDSA;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2B_256_ECDSA;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2B_384_ECDSA;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2B_512_ECDSA;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2S_128_ECDSA_PLAIN;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2S_160_ECDSA_PLAIN;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2S_224_ECDSA_PLAIN;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2S_256_ECDSA_PLAIN;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2B_160_ECDSA_PLAIN;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2B_256_ECDSA_PLAIN;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2B_384_ECDSA_PLAIN;

// 
extern NSString* const SB_CERT_ALGORITHM_BLAKE2B_512_ECDSA_PLAIN;

// 
extern NSString* const SB_CERT_ALGORITHM_ID_DSA_BLAKE2S_224;

// 
extern NSString* const SB_CERT_ALGORITHM_ID_DSA_BLAKE2S_256;

// 
extern NSString* const SB_CERT_ALGORITHM_EDDSA_ED25519;

// 
extern NSString* const SB_CERT_ALGORITHM_EDDSA_ED448;

// 
extern NSString* const SB_CERT_ALGORITHM_EDDSA_ED25519_PH;

// 
extern NSString* const SB_CERT_ALGORITHM_EDDSA_ED448_PH;

// 
extern NSString* const SB_CERT_ALGORITHM_EDDSA;

// 
extern NSString* const SB_CERT_ALGORITHM_EDDSA_SIGNATURE;

// 
extern NSString* const cslUnspecified;

// in-memory storage
extern NSString* const cslMemory;

// file storage
extern NSString* const cslFile;

// OS-specific certificate storage (e.g. CryptoAPI)
extern NSString* const cslSystem;

// PKCS#11 compatible device
extern NSString* const cslPKCS11;

// 
extern NSString* const cslKMIP;

// Apple certificates storage (macOS and iOS only)
extern NSString* const cslApple;

// java key storage
extern NSString* const cslJava;

// The key format was not recognized as one of the known formats.
extern const int kffUnknown;

// The default format in current circumstances. This depends on the key being loaded or saved.
extern const int kffAuto;

// DER (binary) format
extern const int kffDER;

// PEM format (base64-encoded with headers)
extern const int kffPEM;

// JSON key format
extern const int kffJSON;

// The default key type in current circumstances. This depends on the operation, the file content, and the storage type.
extern const int ktAuto;

// The operation should be performed on a public key.
extern const int ktPublic;

// The operation should be performed on a private or secret key
extern const int ktSecret;

// The default encoding type in current circumstances. This depends on the operation and the type of the key being used.
extern const int cetDefault;

// Raw binary encoding (no encoding)
extern const int cetBinary;

// Base64 encoding (armouring)
extern const int cetBase64;

// JSON compact encoding
extern const int cetCompact;

// JSON standard encoding
extern const int cetJSON;

// The chain is valid
extern const int cvtValid;

// The chain is valid, but the root certificate is not trusted
extern const int cvtValidButUntrusted;

// The chain is not valid (some of certificates are revoked, expired, or contain an invalid signature)
extern const int cvtInvalid;

// The validity of the chain cannot be established because of missing or unavailable validation information (certificates, CRLs, or OCSP responses)
extern const int cvtCantBeEstablished;

// One or more certificates in the validation path are malformed
extern const int cvrBadData;

// One or more certificates are revoked
extern const int cvrRevoked;

// One or more certificates are not yet valid
extern const int cvrNotYetValid;

// One or more certificates are expired
extern const int cvrExpired;

// A certificate contains a non-valid digital signature
extern const int cvrInvalidSignature;

// A CA certificate for one or more certificates has not been found (chain incomplete)
extern const int cvrUnknownCA;

// One of the CA certificates are not authorized to act as CA
extern const int cvrCAUnauthorized;

// One or more CRLs could not be verified
extern const int cvrCRLNotVerified;

// One or more OCSP responses could not be verified
extern const int cvrOCSPNotVerified;

// The identity protected by the certificate (a TLS endpoint or an e-mail addressee) does not match what is recorded in the certificate
extern const int cvrIdentityMismatch;

// A mandatory key usage is not enabled in one of the chain certificates
extern const int cvrNoKeyUsage;

// One or more certificates are blocked
extern const int cvrBlocked;

// General validation failure
extern const int cvrFailure;

// Chain loop: one of the CA certificates recursively signs itself
extern const int cvrChainLoop;

// A weak algorithm is used in one of certificates or revocation elements
extern const int cvrWeakAlgorithm;

// The chain was considered invalid following intervention from a user code
extern const int cvrUserEnforced;

// 
extern NSString* const SB_EC_SECP112R1;

// 
extern NSString* const SB_EC_SECP112R2;

// 
extern NSString* const SB_EC_SECP128R1;

// 
extern NSString* const SB_EC_SECP128R2;

// 
extern NSString* const SB_EC_SECP160K1;

// 
extern NSString* const SB_EC_SECP160R1;

// 
extern NSString* const SB_EC_SECP160R2;

// 
extern NSString* const SB_EC_SECP192K1;

// 
extern NSString* const SB_EC_SECP192R1;

// 
extern NSString* const SB_EC_SECP224K1;

// 
extern NSString* const SB_EC_SECP224R1;

// 
extern NSString* const SB_EC_SECP256K1;

// 
extern NSString* const SB_EC_SECP256R1;

// 
extern NSString* const SB_EC_SECP384R1;

// 
extern NSString* const SB_EC_SECP521R1;

// 
extern NSString* const SB_EC_SECT113R1;

// 
extern NSString* const SB_EC_SECT113R2;

// 
extern NSString* const SB_EC_SECT131R1;

// 
extern NSString* const SB_EC_SECT131R2;

// 
extern NSString* const SB_EC_SECT163K1;

// 
extern NSString* const SB_EC_SECT163R1;

// 
extern NSString* const SB_EC_SECT163R2;

// 
extern NSString* const SB_EC_SECT193R1;

// 
extern NSString* const SB_EC_SECT193R2;

// 
extern NSString* const SB_EC_SECT233K1;

// 
extern NSString* const SB_EC_SECT233R1;

// 
extern NSString* const SB_EC_SECT239K1;

// 
extern NSString* const SB_EC_SECT283K1;

// 
extern NSString* const SB_EC_SECT283R1;

// 
extern NSString* const SB_EC_SECT409K1;

// 
extern NSString* const SB_EC_SECT409R1;

// 
extern NSString* const SB_EC_SECT571K1;

// 
extern NSString* const SB_EC_SECT571R1;

// 
extern NSString* const SB_EC_PRIME192V1;

// 
extern NSString* const SB_EC_PRIME192V2;

// 
extern NSString* const SB_EC_PRIME192V3;

// 
extern NSString* const SB_EC_PRIME239V1;

// 
extern NSString* const SB_EC_PRIME239V2;

// 
extern NSString* const SB_EC_PRIME239V3;

// 
extern NSString* const SB_EC_PRIME256V1;

// 
extern NSString* const SB_EC_C2PNB163V1;

// 
extern NSString* const SB_EC_C2PNB163V2;

// 
extern NSString* const SB_EC_C2PNB163V3;

// 
extern NSString* const SB_EC_C2PNB176W1;

// 
extern NSString* const SB_EC_C2TNB191V1;

// 
extern NSString* const SB_EC_C2TNB191V2;

// 
extern NSString* const SB_EC_C2TNB191V3;

// 
extern NSString* const SB_EC_C2ONB191V4;

// 
extern NSString* const SB_EC_C2ONB191V5;

// 
extern NSString* const SB_EC_C2PNB208W1;

// 
extern NSString* const SB_EC_C2TNB239V1;

// 
extern NSString* const SB_EC_C2TNB239V2;

// 
extern NSString* const SB_EC_C2TNB239V3;

// 
extern NSString* const SB_EC_C2ONB239V4;

// 
extern NSString* const SB_EC_C2ONB239V5;

// 
extern NSString* const SB_EC_C2PNB272W1;

// 
extern NSString* const SB_EC_C2PNB304W1;

// 
extern NSString* const SB_EC_C2TNB359V1;

// 
extern NSString* const SB_EC_C2PNB368W1;

// 
extern NSString* const SB_EC_C2TNB431R1;

// 
extern NSString* const SB_EC_NISTP192;

// 
extern NSString* const SB_EC_NISTP224;

// 
extern NSString* const SB_EC_NISTP256;

// 
extern NSString* const SB_EC_NISTP384;

// 
extern NSString* const SB_EC_NISTP521;

// 
extern NSString* const SB_EC_NISTB163;

// 
extern NSString* const SB_EC_NISTB233;

// 
extern NSString* const SB_EC_NISTB283;

// 
extern NSString* const SB_EC_NISTB409;

// 
extern NSString* const SB_EC_NISTB571;

// 
extern NSString* const SB_EC_NISTK163;

// 
extern NSString* const SB_EC_NISTK233;

// 
extern NSString* const SB_EC_NISTK283;

// 
extern NSString* const SB_EC_NISTK409;

// 
extern NSString* const SB_EC_NISTK571;

// 
extern NSString* const SB_EC_GOSTCPTEST;

// 
extern NSString* const SB_EC_GOSTCPA;

// 
extern NSString* const SB_EC_GOSTCPB;

// 
extern NSString* const SB_EC_GOSTCPC;

// 
extern NSString* const SB_EC_GOSTCPXCHA;

// 
extern NSString* const SB_EC_GOSTCPXCHB;

// 
extern NSString* const SB_EC_BRAINPOOLP160R1;

// 
extern NSString* const SB_EC_BRAINPOOLP160T1;

// 
extern NSString* const SB_EC_BRAINPOOLP192R1;

// 
extern NSString* const SB_EC_BRAINPOOLP192T1;

// 
extern NSString* const SB_EC_BRAINPOOLP224R1;

// 
extern NSString* const SB_EC_BRAINPOOLP224T1;

// 
extern NSString* const SB_EC_BRAINPOOLP256R1;

// 
extern NSString* const SB_EC_BRAINPOOLP256T1;

// 
extern NSString* const SB_EC_BRAINPOOLP320R1;

// 
extern NSString* const SB_EC_BRAINPOOLP320T1;

// 
extern NSString* const SB_EC_BRAINPOOLP384R1;

// 
extern NSString* const SB_EC_BRAINPOOLP384T1;

// 
extern NSString* const SB_EC_BRAINPOOLP512R1;

// 
extern NSString* const SB_EC_BRAINPOOLP512T1;

// 
extern NSString* const SB_EC_CURVE25519;

// 
extern NSString* const SB_EC_CURVE448;

// 
extern const int ostOk;

// 
extern const int ostNoSuchFile;

// 
extern const int ostAccessDenied;

// 
extern const int ostWriteProtect;

// 
extern const int ostUnsupported;

// 
extern const int ostInvalidParameter;

// 
extern const int ostEOF;

// Handle the requested action automatically by the server
extern const int fraAuto;

// Override the action using the user code logic
extern const int fraCustom;

// Abort the requested action
extern const int fraAbort;

// Download file
extern const int cffoDownloadFile;

// Upload file
extern const int cffoUploadFile;

// Delete file
extern const int cffoDeleteFile;

// Make directory
extern const int cffoMakeDir;

// Unknown signature level
extern const int jaslUnknown;

// Generic signature: JSON Web Signature (JWS)
extern const int jaslGeneric;

// Baseline B (B-B, basic)
extern const int jaslBaselineB;

// Baseline T (B-T, timestamped)
extern const int jaslBaselineT;

// Baseline LT (B-LT, long-term)
extern const int jaslBaselineLT;

// Baseline LTA (B-LTA, long-term with archived timestamp)
extern const int jaslBaselineLTA;

// Add signature validation references
extern const int jukAddValidationDataRefs;

// Add signature validation values
extern const int jukAddValidationDataValues;

// Add timestamp validation data
extern const int jukAddTimestampValidationData;

// Unknown
extern const int javUnknown;

// JAdES v1.1.1
extern const int jav111;

// 
extern NSString* const SB_HASH_ALGORITHM_SHA1;

// 
extern NSString* const SB_HASH_ALGORITHM_SHA224;

// 
extern NSString* const SB_HASH_ALGORITHM_SHA256;

// 
extern NSString* const SB_HASH_ALGORITHM_SHA384;

// 
extern NSString* const SB_HASH_ALGORITHM_SHA512;

// 
extern NSString* const SB_HASH_ALGORITHM_MD2;

// 
extern NSString* const SB_HASH_ALGORITHM_MD4;

// 
extern NSString* const SB_HASH_ALGORITHM_MD5;

// 
extern NSString* const SB_HASH_ALGORITHM_RIPEMD160;

// 
extern NSString* const SB_HASH_ALGORITHM_CRC32;

// 
extern NSString* const SB_HASH_ALGORITHM_SSL3;

// 
extern NSString* const SB_HASH_ALGORITHM_GOST_R3411_1994;

// 
extern NSString* const SB_HASH_ALGORITHM_WHIRLPOOL;

// 
extern NSString* const SB_HASH_ALGORITHM_POLY1305;

// 
extern NSString* const SB_HASH_ALGORITHM_SHA3_224;

// 
extern NSString* const SB_HASH_ALGORITHM_SHA3_256;

// 
extern NSString* const SB_HASH_ALGORITHM_SHA3_384;

// 
extern NSString* const SB_HASH_ALGORITHM_SHA3_512;

// 
extern NSString* const SB_HASH_ALGORITHM_BLAKE2S_128;

// 
extern NSString* const SB_HASH_ALGORITHM_BLAKE2S_160;

// 
extern NSString* const SB_HASH_ALGORITHM_BLAKE2S_224;

// 
extern NSString* const SB_HASH_ALGORITHM_BLAKE2S_256;

// 
extern NSString* const SB_HASH_ALGORITHM_BLAKE2B_160;

// 
extern NSString* const SB_HASH_ALGORITHM_BLAKE2B_256;

// 
extern NSString* const SB_HASH_ALGORITHM_BLAKE2B_384;

// 
extern NSString* const SB_HASH_ALGORITHM_BLAKE2B_512;

// 
extern NSString* const SB_HASH_ALGORITHM_SHAKE_128;

// 
extern NSString* const SB_HASH_ALGORITHM_SHAKE_256;

// 
extern NSString* const SB_HASH_ALGORITHM_SHAKE_128_LEN;

// 
extern NSString* const SB_HASH_ALGORITHM_SHAKE_256_LEN;

// The multipart message contains form data.
extern const int hmmFormData;

// The multipart message contains related parts.
extern const int hmmRelated;

// Message has been answered.
extern const int imapMessageAnswered;

// Message is 'deleted' for removal later.
extern const int imapMessageDeleted;

// Message has not completed composition (marked as a draft).
extern const int imapMessageDraft;

// Message is 'flagged' for urgent/special attention.
extern const int imapMessageFlagged;

// Message is 'recently' arrived in this mailbox. This session is the first session to have been notified about this message.
extern const int imapMessageRecent;

// Message has been read.
extern const int imapMessageSeen;

// 
extern const int otUnknown;

// 
extern const int otCertificate;

// 
extern const int otSymmetricKey;

// 
extern const int otPublicKey;

// 
extern const int otPrivateKey;

// 
extern NSString* const SB_MAC_ALGORITHM_HMAC_SHA1;

// 
extern NSString* const SB_MAC_ALGORITHM_HMAC_SHA256;

// 
extern NSString* const SB_MAC_ALGORITHM_HMAC_SHA512;

// Unknown signature level
extern const int paslUnknown;

// Generic signature: Legacy Adobe signature (adbe.pkcs7.detached), corresponds to pstLegacy signature type
extern const int paslGeneric;

// Baseline B (B-B, basic)
extern const int paslBaselineB;

// Baseline T (B-T, timestamped)
extern const int paslBaselineT;

// Baseline LT (B-LT, long-term)
extern const int paslBaselineLT;

// Baseline LTA (B-LTA, long-term with archived timestamp)
extern const int paslBaselineLTA;

// BES (Basic Electronic Signature)
extern const int paslBES;

// EPES (Electronic Signature with an Explicit Policy)
extern const int paslEPES;

// LTV (Electronic Signature with with revocation info)
extern const int paslLTV;

// Annotating is allowed
extern const int pepAnnotations;

// Assembling a new document on the basis of the processed one is allowed
extern const int pepAssemble;

// Extraction/copying of the pictures and text from the document is allowed
extern const int pepExtract;

// Content extraction is allowed for accessibility purposes only
extern const int pepExtractAcc;

// Filling forms in is allowed
extern const int pepFillInForms;

// High quality printing is allowed
extern const int pepHighQualityPrint;

// Low quality printing is allowed
extern const int pepLowQualityPrint;

// Modifications are allowed
extern const int pepModify;

// Unknown signature type
extern const int pstUnknown;

// Legacy Adobe signature (adbe.pkcs7.detached or adbe.pkcs7.sha1)
extern const int pstLegacy;

// PAdES signature (ETSI.CAdES.detached), use Level field for detailed info
extern const int pstPAdES;

// Document timestamp (ETSI.RFC3161)
extern const int pstDocumentTimestamp;

// The default unsign kind (currently maps to uskFull)
extern const int uskDefault;

// Full removal of the signature, its widget, and field
extern const int uskFull;

// Remove the signature, but keep its field
extern const int uskKeepField;

// Remove the signature, but keeps the widget
extern const int uskKeepAppearance;

// Unknown, unsupported, or uninitialized set of options
extern const int wroUnknown;

// Enabling this option prevents the signature widget from being rotated when the containing document is rotated in a viewing app.
extern const int wroNoRotate;

// Enabling this option prevents the widget from being displayed when the document is viewed in an app (the widget will still be printed, if configured).
extern const int wroNoView;

// Keeps the widget at the same size when the document is zoomed in or out.
extern const int wroNoZoom;

// Makes the widget printable.
extern const int wroPrint;

// Controls the ReadOnly flag of the widget object.
extern const int wroReadOnly;

// If set, the signature widget will only be displayed when the viewer hovers a mouse pointer over it.
extern const int wroToggleNoView;

// 
extern NSString* const SB_PGP_COMPRESSION_ALGORITHM_NONE;

// 
extern NSString* const SB_PGP_COMPRESSION_ALGORITHM_ZIP;

// 
extern NSString* const SB_PGP_COMPRESSION_ALGORITHM_ZLIB;

// 
extern NSString* const SB_PGP_COMPRESSION_ALGORITHM_BZIP2;

// 
extern NSString* const SB_PGP_CURVE_P256;

// 
extern NSString* const SB_PGP_CURVE_P384;

// 
extern NSString* const SB_PGP_CURVE_P521;

// 
extern NSString* const SB_PGP_CURVE_ED25519;

// 
extern NSString* const SB_PGP_CURVE_CURVE25519;

// 
extern NSString* const SB_PGP_CURVE_BRAINPOOLP256R1;

// 
extern NSString* const SB_PGP_CURVE_BRAINPOOLP512R1;

// 
extern NSString* const SB_PGP_PUBLIC_KEY_ALGORITHM_RSA;

// 
extern NSString* const SB_PGP_PUBLIC_KEY_ALGORITHM_RSA_ENCRYPT;

// 
extern NSString* const SB_PGP_PUBLIC_KEY_ALGORITHM_RSA_SIGN;

// 
extern NSString* const SB_PGP_PUBLIC_KEY_ALGORITHM_DSA;

// 
extern NSString* const SB_PGP_PUBLIC_KEY_ALGORITHM_ECDSA;

// 
extern NSString* const SB_PGP_PUBLIC_KEY_ALGORITHM_ECDH;

// 
extern NSString* const SB_PGP_PUBLIC_KEY_ALGORITHM_ELGAMAL_ENCRYPT;

// 
extern NSString* const SB_PGP_PUBLIC_KEY_ALGORITHM_ELGAMAL;

// 
extern NSString* const SB_PGP_PUBLIC_KEY_ALGORITHM_EDDSA;

// A traditional signature, compatible (algorithm permitting) with PGP 2.6.x
extern const int pstNormal;

// A newer one-pass signature
extern const int pstOnePass;

// A detached signature, i.e., a signature contained in a separate file from the data it covers
extern const int pstDetached;

// A signature made over textual data and appended to it
extern const int pstCleartext;

// 
extern NSString* const SB_PGP_SYMMETRIC_ALGORITHM_PLAINTEXT;

// 
extern NSString* const SB_PGP_SYMMETRIC_ALGORITHM_IDEA;

// 
extern NSString* const SB_PGP_SYMMETRIC_ALGORITHM_3DES;

// 
extern NSString* const SB_PGP_SYMMETRIC_ALGORITHM_CAST5;

// 
extern NSString* const SB_PGP_SYMMETRIC_ALGORITHM_BLOWFISH;

// 
extern NSString* const SB_PGP_SYMMETRIC_ALGORITHM_AES128;

// 
extern NSString* const SB_PGP_SYMMETRIC_ALGORITHM_AES192;

// 
extern NSString* const SB_PGP_SYMMETRIC_ALGORITHM_AES256;

// 
extern NSString* const SB_PGP_SYMMETRIC_ALGORITHM_TWOFISH256;

// Unsupported or weak security algorithm
extern const int pfiBadAlg;

// Message check failed
extern const int pfiBadMessageCheck;

// Bad request
extern const int pfiBadRequest;

// Bad timing
extern const int pfiBadTime;

// Bad certificate ID
extern const int pfiBadCertId;

// Bad data format
extern const int pfiBadDataFormat;

// Wrong authority
extern const int pfiWrongAuthority;

// Incorrect data
extern const int pfiIncorrectData;

// Missing timestamp
extern const int pfiMissingTimestamp;

// Bad POP
extern const int pfiBadPOP;

// Request granted
extern const int psGranted;

// Request granted with modifications
extern const int psGrantedWithMods;

// Request rejected
extern const int psRejection;

// Waiting (service busy)
extern const int psWaiting;

// Revocation warning
extern const int psRevocationWarning;

// Revocation notification
extern const int psRevocationNotification;

// Key update warning
extern const int psKeyUpdateWarning;

// Qualified status unknown. Use config's QualifiedInfo setting to obtain service status URI.
extern const int sqsUnknown;

// None
extern const int sqsNone;

// Granted
extern const int sqsGranted;

// Withdrawn
extern const int sqsWithdrawn;

// Set by national law
extern const int sqsSetByNationalLaw;

// Deprecated by national law
extern const int sqsDeprecatedByNationalLaw;

// Recognized at national level
extern const int sqsRecognizedAtNationalLevel;

// Deprecated at national level
extern const int sqsDeprecatedAtNationalLevel;

// Under supervision
extern const int sqsUnderSupervision;

// Supervision in cessation
extern const int sqsSupervisionInCessation;

// Supervision ceased
extern const int sqsSupervisionCeased;

// Supervision revoked
extern const int sqsSupervisionRevoked;

// Accredited
extern const int sqsAccredited;

// Accreditation ceased
extern const int sqsAccreditationCeased;

// Accreditation revoked
extern const int sqsAccreditationRevoked;

// Deprecated. The subject service is in accordance with the scheme's specific status determination criteria (only for use in positive approval schemes).
extern const int sqsInAccordance;

// Deprecated. The subject service is no longer overseen by the scheme, e.g. due to nonrenewal or withdrawal by the TSP, or cessation of the service or the scheme's operations.
extern const int sqsExpired;

// Deprecated. The subject service's status is temporarily uncertain whilst checks are made by the scheme operator (typically e.g. while a revocation request is being investigated or if action is required to resolve a deficiency in the service fulfilling the scheme's criteria.
extern const int sqsSuspended;

// Deprecated. The subject service's approved status has been revoked because it is no longer in accordance with the scheme's specific status determination criteria (only for use in positive approval schemes).
extern const int sqsRevoked;

// Deprecated. The subject service is not in accordance with the scheme's specific status determination criteria (only for use in negative approval schemes).
extern const int sqsNotInAccordance;

// 
extern const int rrUnknown;

// 
extern const int rrUnspecified;

// 
extern const int rrKeyCompromise;

// 
extern const int rrCACompromise;

// 
extern const int rrAffiliationChanged;

// 
extern const int rrSuperseded;

// 
extern const int rrCessationOfOperation;

// 
extern const int rrCertificateHold;

// 
extern const int rrRemoveFromCRL;

// 
extern const int rrPrivilegeWithdrawn;

// 
extern const int rrAACompromise;

// Select the current entity
extern const int sitEntity;

// Select the parent entity of the current entity
extern const int sitParentEntity;

// Select all timestamps covering the current entity
extern const int sitTimestamps;

// Select all signatures covering the current entity
extern const int sitSignatures;

// Select the signing chain of the current entity
extern const int sitSigningChain;

// Select all certificates embedded in the current entity
extern const int sitEmbeddedCertificates;

// Select all CRLs embedded in the current entity
extern const int sitEmbeddedCRLs;

// Select all OCSP responses embedded in the current entity
extern const int sitEmbeddedOCSPs;

// Select the whole pack of embedded revocation information (certificates, CRLs and OCSPs)
extern const int sitEmbeddedRevInfo;

// Select all the certificates used to validate this entity's chain
extern const int sitUsedCertificates;

// Select all the CRLs used to validate this entity's chain
extern const int sitUsedCRLs;

// Select all the OCSP responses used to validate this entity's chain
extern const int sitUsedOCSPs;

// Select the whole pack of revocation information used to validate this entity's chain (certificates, CRLs, OCSP responses)
extern const int sitUsedRevInfo;

// Select this entity's CMS attributes
extern const int sitAttributes;

// Select this entity's XML references
extern const int sitReferences;

// Select this entity's signed parts
extern const int sitSignedParts;

// The signature is valid
extern const int svtValid;

// Signature validity is unknown
extern const int svtUnknown;

// The signature is corrupted
extern const int svtCorrupted;

// Failed to acquire the signing certificate. The signature cannot be validated.
extern const int svtSignerNotFound;

// General failure
extern const int svtFailure;

// Reference corrupted (XML-based signatures only)
extern const int svtReferenceCorrupted;

// RHOSTS file authentication. Rarely used today.
extern const int atRhosts;

// Public key (sometimes called private key) authentication
extern const int atPublicKey;

// Password-based authentication
extern const int atPassword;

// Hostbased authentication
extern const int atHostbased;

// Keyboard-interactive authentication. This is often used in place of generic password authentication.
extern const int atKeyboard;

// GSS authentication
extern const int atGssWithMic;

// GSS authentication with key exchange
extern const int atGssKeyex;

// Public key agent authentication
extern const int atPublicKeyAgent;

// Accept the key for the current session only.
extern const int catAcceptOnce;

// Accept the key for the current session and store the key to the trusted keys list.
extern const int catAcceptPermanently;

// Reject the key and close the connection.
extern const int catReject;

// A private key
extern const int cktPrivate;

// A public key
extern const int cktPublic;

// Wait for the close-notify message when shutting down the connection
extern const int cssloExpectShutdownMessage;

// (DEPRECATED) Use a DTLS version workaround when talking to very old OpenSSL versions
extern const int cssloOpenSSLDTLSWorkaround;

// Do not align the client-side PMS by the RSA modulus size. It is unlikely that you will ever need to adjust it.
extern const int cssloDisableKexLengthAlignment;

// Enforce the use of the client certificate hash algorithm. It is unlikely that you will ever need to adjust it.
extern const int cssloForceUseOfClientCertHashAlg;

// Automatically add the server name extension when known
extern const int cssloAutoAddServerNameExtension;

// Accept trusted SRP primes only
extern const int cssloAcceptTrustedSRPPrimesOnly;

// Disable (do not send) the signature algorithms extension. It is unlikely that you will ever need to adjust it.
extern const int cssloDisableSignatureAlgorithmsExtension;

// (server option) Do not allow fallback from TLS versions higher than currently enabled
extern const int cssloIntolerateHigherProtocolVersions;

// Stick to preferred certificate hash algorithms
extern const int cssloStickToPrefCertHashAlg;

// Disable implicit TLS 1.3 to 1.2 fallbacks
extern const int cssloNoImplicitTLS12Fallback;

// Send the handshake message as large batches rather than individually
extern const int cssloUseHandshakeBatches;

// SSL 2
extern const int csbSSL2;

// SSL 3
extern const int csbSSL3;

// TLS 1.0
extern const int csbTLS1;

// TLS 1.1
extern const int csbTLS11;

// TLS 1.2
extern const int csbTLS12;

// TLS 1.3
extern const int csbTLS13;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_RC4;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_DES;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_3DES;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_RC2;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_AES128;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_AES192;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_AES256;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_IDENTITY;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_BLOWFISH;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_CAST128;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_IDEA;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_TWOFISH;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_TWOFISH128;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_TWOFISH192;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_TWOFISH256;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_CAMELLIA;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_CAMELLIA128;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_CAMELLIA192;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_CAMELLIA256;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_SERPENT;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_SERPENT128;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_SERPENT192;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_SERPENT256;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_SEED;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_RABBIT;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_SYMMETRIC;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_GOST_28147_1989;

// 
extern NSString* const SB_SYMMETRIC_ALGORITHM_CHACHA20;

// The default mode in current circumstances.
extern const int scmDefault;

// ECB (electronic code book) mode. This is insecure, unless you know how to use it right.
extern const int scmECB;

// CBC (cipher block chaining mode)
extern const int scmCBC;

// Counter mode
extern const int scmCTR;

// Cipher feedback mode
extern const int scmCFB8;

// Galois counter mode
extern const int scmGCM;

// CCM mode
extern const int scmCCM;

// Poly1305 mode (only to be used with ChaCha20 algorithm)
extern const int scmPoly1305;

// OCB mode
extern const int scmOCB;

// No padding. You might need to adjust the length of the input data to align it by the encryption block boundary.
extern const int scpNone;

// Standard PKCS5 (sometimes also referred to as PKCS7) padding
extern const int scpPKCS5;

// ANSI X.923 padding
extern const int scpANSIX923;

// 
extern const int tstUnknown;

// Supported by: Authenticode components
extern const int tstLegacy;

// Supported by: Authenticode components
extern const int tstTrusted;

// Supported by: CAdES components
extern const int tstGeneric;

// Supported by: CAdES components
extern const int tstESC;

// Supported by: CAdES components
extern const int tstContent;

// Supported by: CAdES components
extern const int tstCertsAndCRLs;

// Archive timestamp. Supported by: ASiC, CAdES, JAdES, Office, SOAP, XAdES components
extern const int tstArchive;

// Archive v2 timestamp. Supported by: ASiC, CAdES components
extern const int tstArchive2;

// Archive v3 timestamp. Supported by: ASiC, CAdES components
extern const int tstArchive3;

// Individual data objects timetamp. Supported by: ASiC, Office, SOAP, XAdES components
extern const int tstIndividualDataObjects;

// All data objects timestamp. Supported by: ASiC, Office, SOAP, XAdES components
extern const int tstAllDataObjects;

// Signature timestamp. Supported by: ASiC, JAdES, Office, SOAP, XAdES components
extern const int tstSignature;

// RefsOnly timestamp. Supported by: ASiC, JAdES, Office, SOAP, XAdES components
extern const int tstRefsOnly;

// SigAndRefs timestamp. Supported by: ASiC, JAdES, Office, SOAP, XAdES components
extern const int tstSigAndRefs;

// SignedData timestamp. Supported by: JAdES components
extern const int tstSignedData;

// Archive timestamp v1.4.1. Supported by: ASiC, Office, SOAP, XAdES components
extern const int tstArchive141;

// Unknown validation error
extern const int xceUnknown;

// Inconsistent signing certificate
extern const int xceInconsistentSigningCertificate;

// Add signature validation references
extern const int xukAddValidationDataRefs;

// Add signature validation values
extern const int xukAddValidationDataValues;

// Add timestamp validation data
extern const int xukAddTimestampValidationData;

// Unknown
extern const int xavUnknown;

// XAdES v1.1.1
extern const int xav111;

// XAdES v1.2.2
extern const int xav122;

// XAdES v1.3.2
extern const int xav132;

// XAdES v1.4.1 (aka v1.4.2)
extern const int xav141;

// 
extern NSString* const SB_XML_ENCRYPTION_ALGORITHM_RC4;

// 
extern NSString* const SB_XML_ENCRYPTION_ALGORITHM_DES;

// 
extern NSString* const SB_XML_ENCRYPTION_ALGORITHM_3DES;

// 
extern NSString* const SB_XML_ENCRYPTION_ALGORITHM_AES128;

// 
extern NSString* const SB_XML_ENCRYPTION_ALGORITHM_AES192;

// 
extern NSString* const SB_XML_ENCRYPTION_ALGORITHM_AES256;

// 
extern NSString* const SB_XML_ENCRYPTION_ALGORITHM_CAMELLIA128;

// 
extern NSString* const SB_XML_ENCRYPTION_ALGORITHM_CAMELLIA192;

// 
extern NSString* const SB_XML_ENCRYPTION_ALGORITHM_CAMELLIA256;

// 
extern NSString* const SB_XML_ENCRYPTION_ALGORITHM_SEED;

// 
extern const int stUnauthenticated;

// 
extern const int stUser;

// 
extern const int stAdministrator;

// Handle the action automatically (the default behaviour)
extern const int veaAuto;

// Accept the request implied by the event (accept the certificate, allow the object retrieval)
extern const int veaContinue;

// Reject the request implied by the event (reject the certificate, disallow the object retrieval)
extern const int veaReject;

// Accept the validated certificate immediately
extern const int veaAcceptNow;

// Abort the validation, reject the certificate
extern const int veaAbortNow;

// Unknown or unsupported element type
extern const int cekUnknown;

// An X.509 certificate
extern const int cekCertificate;

// A CRL
extern const int cekCRL;

// An OCSP response
extern const int cekOCSP;

// The source is unknown
extern const int qisUnknown;

// The information was taken from the certificate
extern const int qisCertificate;

// The information was taken from an online TSL
extern const int qisTSL;

// The information was taken from both the certificate and an online TSL
extern const int qisBoth;

// Unknown origin
extern const int saoUnknown;

// The assertion is part of a SAML request
extern const int saoRequest;

// The assertion is part of a SAML response
extern const int saoResponse;

// The extension is not included in the certificate
extern const int cesNotIncluded;

// The extension is included and is marked critical
extern const int cesCritical;

// The extension is included and is not marked critical
extern const int cesNonCritical;

// Unknown or unspecified format
extern const int mtfUnknown;

// RFC5544-compliant format, based on PKCS#7 TimeStampedData object
extern const int mtfRFC5544;

// A generic RFC3161 timestamp response object (TimeStampToken)
extern const int mtfCMS;

// Same as mtfCMS, but including the auxiliary TSA response wrapper (TimeStampResp)
extern const int mtfTSPReply;

// The scope of signature is unknown
extern const int cssUnknown;

// The signature is a top-level signature over the data
extern const int cssData;

// The signature is a countersignature, and is made over another signature
extern const int cssSignature;

// The signature is made over a timestamp
extern const int cssTimestamp;

// The scope of signature is unknown
extern const int sssUnknown;

// The signature covers the entire SAML message
extern const int sssMessage;

// The signature covers an assertion
extern const int sssAssertion;

// The signature covers the binding
extern const int sssBinding;

// The service is of unknown or unsupported type
extern const int spsUnknown;

// The assertion consumer service (SP side only)
extern const int spsAssertionConsumerService;

// The single logout service (SP or IdP sides)
extern const int spsSingleLogoutService;

// The artifact resolution service (SP or IdP sides)
extern const int spsArtifactResolutionService;

// The attribute query service (IdP side only)
extern const int spsAttributeQueryService;

// The single sign-on service (IdP side only)
extern const int spsSingleSignOnService;

// Unknown or undefined processing result
extern const int sprUnknown;

// The processing completed successfully. No tangible output has been generated (e.g. an artifact was resolved and acknowledged, but nothing needs to be sent to the browser).
extern const int sprSuccess;

// The processing was fully or partially successful. The output contains a new SAML message that needs to be conveyed to the other SAML party.
extern const int sprSAMLMessage;

// The processing was fully or partially successful. The output contains or redirects to a SAML login page.
extern const int sprSignOnPage;

// The processing was fully or partially successful. The output contains, or redirects to, a generic web resource.
extern const int sprResource;

// The processing failed due to SAML-related issue (bad sign-on parameters, unknown principal etc.). The output contains a SAML error message. This still needs to be relayed to the other SAML party.
extern const int sprSAMLError;

// The operation could not be completed due to an issue with configuration (e.g. non-existent SAML endpoint), permissions, or network. The SAML protocol could not commence. The output contains a transport-layer (HTTP) error message which can/should be displayed to the user in the browser.
extern const int sprTransportError;

// Unknown or unsupported encryption type
extern const int metUnknown;

// Certificate-based encryption
extern const int metCertEncrypted;

// Symmetric key-based encryption
extern const int metKeyEncrypted;

// Certificate-based encryption with authentication (AEAD)
extern const int metCertEncryptedAndAuthenticated;

// Unknown or unsupported signature types
extern const int stUnknown;

// Detached PKCS#1 signature
extern const int stPKCS1Detached;

// Detached PKCS#7 signature
extern const int stPKCS7Detached;

// Enveloping PKCS#7 signature
extern const int stPKCS7Enveloping;

// Detached PKCS#7 MAC signature
extern const int stPKCS7MACDetached;

// Enveloping PKCS#7 MAC signature
extern const int stPKCS7MACEnveloping;

// STORED
extern const int acaStored;

// SHRUNK
extern const int acaShrunk;

// REDUCE_1
extern const int acaReduce1;

// REDUCE_2
extern const int acaReduce2;

// REDUCE_3
extern const int acaReduce3;

// REDUCE_4
extern const int acaReduce4;

// IMPLODE
extern const int acaImplode;

// Tokenizing
extern const int acaTokenizing;

// Deflate
extern const int acaDeflate;

// Deflate64
extern const int acaDeflate64;

// TERSE (old)
extern const int acaTerseOld;

// Bzip2
extern const int acaBzip2;

// LZMA
extern const int acaLzma;

// TERSE (new)
extern const int acaTerseNew;

// LZ77
extern const int acaLz77;

// WAVPACK
extern const int acaWavPack;

// PPMD v1
extern const int acaPPMDv1;

// WinZIP AES
extern const int acaWinzipAES;

// Unknown or unsupported algorithm
extern const int acaUnknown;

// The property contains text
extern const int svfText;

// The property contains binary data. The Value property contains a hex encoding of it.
extern const int svfBinary;

// Allow logins over insecure connections
extern const int cfsoPlainLogin;

// Enable encryption
extern const int cfsoEncryption;

// Enable AUTH command (explicit TLS)
extern const int cfsoAuth;

// Allow clear control channel mode
extern const int cfsoClearControlChannel;

// Allow clear data channel TLS connections
extern const int cfsoClearDataChannel;

// Allow encrypted data channel TLS connections
extern const int cfsoEncryptedDataChannel;

// Allows the component to accept unauthenticated messages (those not signed with KeyID/KeySecret). Use with extreme care.
extern const int aspAcceptUnsignedRequests;

// Ignore requests of PKCS1 type.
extern const int aspIgnorePKCS1Requests;

// Ignore requests of PKCS7 type.
extern const int aspIgnorePKCS7Requests;

// Ignore the TSA URL provided in the request, and either stick with the service provided via TimestampServer property, or not timestamp the message altogether.
extern const int aspIgnoreRequestTSA;

// Ignore the signing time included in the request.
extern const int aspIgnoreRequestSigningTime;

// Ignore auxiliary PKCS7 settings (content type, attributes) included in the request.
extern const int aspIgnoreRequestPKCS7Settings;

// Timestamp created signatures (PKCS7 only), even if the client did not request it.
extern const int aspAlwaysTimestampSigs;

// Stop on the first failure and throw an exception
extern const int ehStopOnFailure;

// Ignore individual processing errors, just proceed to the next item on the list
extern const int ehIgnoreErrors;

// Try to process all the items by ignoring any mid-way errors, but throw an exception at the end of the processing if any of the items failed to process
extern const int ehTryAllItems;

// Basic authentication
extern const int haBasic;

// Digest authentication (RFC 2617)
extern const int haDigest;

// Windows NTLM authentication
extern const int haNTLM;

// Kerberos (Negotiate) authentication
extern const int haKerberos;

// OAuth2 authentication
extern const int haOAuth2;

// SFTP (secure file transfer)
extern const int scSFTP;

// Remote shell access
extern const int scShell;

// Remote command execution
extern const int scCommand;

// Local (client-side) forwarding
extern const int scClientForwarding;

// Remote (server-side) forwarding
extern const int scServerForwarding;

// 
extern const int cftmOverwrite;

// 
extern const int cftmSkip;

// The signature is corrupted
extern const int cftmAppendToEnd;

// 
extern const int cftmResume;

// 
extern const int cftmOverwriteIfDiffSize;

// 
extern const int cftmSaveWithNewName;

// 
extern const int cftmRenameExistingTarget;

// Indicates whether the POP3 server supports the APOP command.
extern const int popApopSupported;

// Indicates whether the POP3 server supports the EXPIRE extension. See the ExpirationPeriod field.
extern const int popExpireSupported;

// Indicates whether the POP3 server supports the IMPLEMENTATION extension. See the ServerDetails field.
extern const int popImplementationSupported;

// Indicates whether the POP3 server supports the LOGIN-DELAY extension. See the LoginDelay field.
extern const int popLoginDelaySupported;

// Indicates whether the POP3 server supports the RESP-CODES extension. The RESP-CODES capability indicates that any response text issued by this server which begins with an open square bracket is an extended response code.
extern const int popRespCodesSupported;

// Indicates whether the POP3 server supports SASL authentication.
extern const int popSaslSupported;

// Indicates whether the POP3 server supports the TOP command.
extern const int popTopSupported;

// Indicates whether the POP3 server supports the UIDL command.
extern const int popUidlSupported;

// Indicates whether the POP3 server supports the USER command.
extern const int popUserSupported;

// Indicates whether the SMTP server supports LOGIN authentication method.
extern const int smtpAuthLoginSupported;

// Indicates whether the SMTP server supports PLAIN authentication method.
extern const int smtpAuthPlainSupported;

// Indicates whether the SMTP server supports the binary sending mode.
extern const int smtpBinarySupported;

// Indicates whether the SMTP server supports message chunking.
extern const int smtpChunkingSupported;

// Indicates whether the SMTP server supports Delivery Status Notifications.
extern const int smtpDsnSupported;

// Indicates whether the SMTP server supports SASL authentication.
extern const int smtpSaslSupported;

// Indicates whether the SMTP server supports the SIZE service extension. See MaxMessageSize property for the message size limit.
extern const int smtpSizeSupported;

// Indicates whether the SMTP server supports status codes.
extern const int smtpStatusCodesSupported;

// Indicates whether the SMTP server supports 8-bit messages (RFC 6152).
extern const int smtp8BitMimeSupported;

// Indicates whether the mailbox has \\HasChildren attribute specified.
extern const int imapMailboxHasChildren;

// Indicates whether the mailbox has \\HasNoChildren attribute specified.
extern const int imapMailboxHasNoChildren;

// Indicates whether the mailbox has \\Marked attribute specified.
extern const int imapMailboxMarked;

// Indicates whether the mailbox has \\NoInferiors attribute specified.
extern const int imapMailboxNoInferiors;

// Indicates whether the mailbox has \\NoSelect attribute specified.
extern const int imapMailboxNoSelect;

// Indicates whether the mailbox has \\Unmarked attribute specified.
extern const int imapMailboxUnmarked;

// Specifies whether the server forbids login.
extern const int imapLoginDisabled;

// Indicates whether the IMAP server supports the IDLE command.
extern const int imapIdleSupported;

// The object can be used for signing
extern const int kuSign;

// The object can be used for verifying signatures
extern const int kuVerify;

// The object has an encryption capability
extern const int kuEncrypt;

// The object has a decryption capability
extern const int kuDecrypt;

// The object supports key wrapping
extern const int kuWrapKey;

// The object supports key unwrapping
extern const int kuUnwrapKey;

// The object supports exports
extern const int kuExport;

// The object can be used for generating MAC imprints
extern const int kuMacGenerate;

// The object can be used for verifying MAC imprints
extern const int kuMacVerify;

// The object supports key derivation
extern const int kuDeriveKey;

// The object has content commitment capability
extern const int kuContentCommitment;

// The object can be used for key agreement
extern const int kuKeyAgreement;

// The object can be used for signing certificates
extern const int kuCertificateSign;

// The object can be used for signing CRLs
extern const int kuCrlSign;

// The object can be used for generating cryptograms
extern const int kuGenerateCryptogram;

// The object can be used for validation of cryptograms
extern const int kuValidateCryptogram;

// The object supports encryption key translation
extern const int kuTranslateEncrypt;

// The object supports decryption key translation
extern const int kuTranslateDecrypt;

// The object supports wrapping key translation
extern const int kuTranslateWrap;

// The object supports unwrapping key translation
extern const int kuTranslateUnwrap;

// 
extern const int kccCancelled;

// 
extern const int kccUnableToCancel;

// 
extern const int kccCompleted;

// 
extern const int kccFailed;

// 
extern const int kccUnavailable;

// TBD
extern const int csbtNone;

// TBD
extern const int csbtSOAP;

// TBD
extern const int csbtPAOS;

// TBD
extern const int csbtRedirect;

// TBD
extern const int csbtPOST;

// TBD
extern const int csbtArtifact;

// Place the Signature tag after the issuer tag in the XML document
extern const int ssfSignatureAfterIssuer;

// Place the Signature tag before the entity descriptor tag in the XML metadata
extern const int ssfSignatureBeforeDescriptor;

// Include the IssuerSerial key data element
extern const int ssfKeyDataIssuerSerial;

// Include the SubjectKeyIdentifier key data element
extern const int ssfKeyDataSKI;

// Include the SubjectName key data element
extern const int ssfKeyDataSubjectName;

// Include the Certificate key data element
extern const int ssfKeyDataCertificate;

// Include the CRL key data element
extern const int ssfKeyDataCRL;

// Sign authentication requests (SP only)
extern const int ssfSignAuthnRequests;

// Sign artifact resolve requests
extern const int ssfSignArtifactResolveRequests;

// Sign logout requests
extern const int ssfSignLogoutRequests;

// Sign outgoing assertions (IdP only)
extern const int ssfSignAssertions;

// Sign all responses (IdP only)
extern const int ssfSignResponses;

// Encrypt generated assertions (IdP only)
extern const int ssfEncryptAssertions;

// Enforces inclusion of NameIDPolicyAllowCreate element in the NameIDPolicy record
extern const int arfAllowCreate;

// Enforces inclusion of the ForceAuthn element
extern const int arfForceAuthn;

// Enforces saving of IsPassive element
extern const int arfIsPassive;

// The default version (situation-specific)
extern const int pvDefault;

// Version 3
extern const int pv3;

// Version 4
extern const int pv4;

// Version 5
extern const int pv5;

// Version 6
extern const int pv6;

// Normal strength
extern const int psNormal;

// Increased strength
extern const int psStrong;

// The key can certify other keys
extern const int KeyFlagCertifyOtherKeys;

// The key can be used to sign data
extern const int KeyFlagSignData;

// The key can be used to encrypt data (in transit)
extern const int KeyFlagEncryptData;

// The key can be used to encrypt data (at rest)
extern const int KeyFlagEncryptStorage;

// The key is part of a split key scheme
extern const int KeyFlagSplitKey;

// The key is part of a group key scheme
extern const int KeyFlagGroupKey;

// File extraction failed
extern const int aceExtractionFailed;

// The file already exists
extern const int aceFileAlreadyExists;

// Cannot create a file
extern const int aceCannotCreateFile;

// The directory already exists
extern const int aceDirAlreadyExists;

// The file has already been added to the archive
extern const int aceFileAlreadyAdded;

// The calculated file or archive CRC does not match the stored CRC
extern const int aceCRCMismatch;

// The provided password is wrong
extern const int aceInvalidPassword;

// Ignore the conflict - go ahead (overwrite etc.)
extern const int auaIgnore;

// Abort the operation
extern const int auaAbort;

// Make another attempt
extern const int auaRetry;

// Skip this item and proceed with the operation
extern const int auaSkip;

