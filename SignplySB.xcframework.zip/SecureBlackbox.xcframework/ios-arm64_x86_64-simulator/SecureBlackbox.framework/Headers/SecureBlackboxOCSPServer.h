/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//CERTSTATUSES
#define CS_UNKNOWN                                         0

#define CS_GOOD                                            1

#define CS_REVOKED                                         2

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

//ASYNCSIGNMETHODS
#define ASMD_PKCS1                                         0

#define ASMD_PKCS7                                         1

//EXTERNALCRYPTOMODES
#define ECM_DEFAULT                                        0

#define ECM_DISABLED                                       1

#define ECM_GENERIC                                        2

#define ECM_DCAUTH                                         3

#define ECM_DCAUTH_JSON                                    4

//CHAINVALIDITIES
#define CVT_VALID                                          0

#define CVT_VALID_BUT_UNTRUSTED                            1

#define CVT_INVALID                                        2

#define CVT_CANT_BE_ESTABLISHED                            3

//DNSRESOLVEMODES
#define DM_AUTO                                            0

#define DM_PLATFORM                                        1

#define DM_OWN                                             2

#define DM_OWN_SECURE                                      3

//SECURETRANSPORTPREDEFINEDCONFIGURATIONS
#define STPC_DEFAULT                                       0

#define STPC_COMPATIBLE                                    1

#define STPC_COMPREHENSIVE_INSECURE                        2

#define STPC_HIGHLY_SECURE                                 3

//CLIENTAUTHTYPES
#define CCAT_NO_AUTH                                       0

#define CCAT_REQUEST_CERT                                  1

#define CCAT_REQUIRE_CERT                                  2

//RENEGOTIATIONATTACKPREVENTIONMODES
#define CRAPM_COMPATIBLE                                   0

#define CRAPM_STRICT                                       1

#define CRAPM_AUTO                                         2

//REVOCATIONCHECKKINDS
#define CRC_NONE                                           0

#define CRC_AUTO                                           1

#define CRC_ALL_CRL                                        2

#define CRC_ALL_OCSP                                       3

#define CRC_ALL_CRLAND_OCSP                                4

#define CRC_ANY_CRL                                        5

#define CRC_ANY_OCSP                                       6

#define CRC_ANY_CRLOR_OCSP                                 7

#define CRC_ANY_OCSPOR_CRL                                 8

//SSLMODES
#define SM_DEFAULT                                         0

#define SM_NO_TLS                                          1

#define SM_EXPLICIT_TLS                                    2

#define SM_IMPLICIT_TLS                                    3

#define SM_MIXED_TLS                                       4

//OTPALGORITHMS
#define OA_NONE                                            0

#define OA_HMAC                                            1

#define OA_TIME                                            2

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxOCSPServerDelegate <NSObject>
@optional
- (void)onAccept:(NSString*)remoteAddress :(int)remotePort :(int*)accept NS_SWIFT_NAME(onAccept(_:_:_:));

- (void)onAuthAttempt:(long long)connectionID :(NSString*)HTTPMethod :(NSString*)URI :(NSString*)authMethod :(NSString*)username :(NSString*)password :(int*)allow NS_SWIFT_NAME(onAuthAttempt(_:_:_:_:_:_:_:));

- (void)onConnect:(long long)connectionID :(NSString*)remoteAddress :(int)remotePort NS_SWIFT_NAME(onConnect(_:_:_:));

- (void)onDisconnect:(long long)connectionID NS_SWIFT_NAME(onDisconnect(_:));

- (void)onError:(long long)connectionId :(int)errorCode :(BOOL)fatal :(BOOL)remote :(NSString*)description NS_SWIFT_NAME(onError(_:_:_:_:_:));

- (void)onExternalSign:(long long)connectionID :(NSString*)operationId :(NSString*)hashAlgorithm :(NSString*)pars :(NSString*)data :(NSString**)signedData NS_SWIFT_NAME(onExternalSign(_:_:_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onStatusRequest:(long long)connectionId :(NSString*)hashAlgorithm :(NSData*)issuerNameHash :(NSData*)issuerKeyHash :(NSData*)certificateSerial :(int*)certStatus :(int*)reason :(NSString**)revocationTime :(NSString**)thisUpdate :(NSString**)nextUpdate NS_SWIFT_NAME(onStatusRequest(_:_:_:_:_:_:_:_:_:_:));

- (void)onTLSCertValidate:(long long)connectionID :(int*)accept NS_SWIFT_NAME(onTLSCertValidate(_:_:));

- (void)onTLSEstablished:(long long)connectionID NS_SWIFT_NAME(onTLSEstablished(_:));

- (void)onTLSPSK:(long long)connectionID :(NSString*)identity :(NSString**)PSK :(NSString**)ciphersuite NS_SWIFT_NAME(onTLSPSK(_:_:_:_:));

- (void)onTLSShutdown:(long long)connectionID NS_SWIFT_NAME(onTLSShutdown(_:));

@end

@interface SecureBlackboxOCSPServer : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxOCSPServerDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasAccept;

  BOOL m_delegateHasAuthAttempt;

  BOOL m_delegateHasConnect;

  BOOL m_delegateHasDisconnect;

  BOOL m_delegateHasError;

  BOOL m_delegateHasExternalSign;

  BOOL m_delegateHasNotification;

  BOOL m_delegateHasStatusRequest;

  BOOL m_delegateHasTLSCertValidate;

  BOOL m_delegateHasTLSEstablished;

  BOOL m_delegateHasTLSPSK;

  BOOL m_delegateHasTLSShutdown;

}

+ (SecureBlackboxOCSPServer*)ocspserver;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxOCSPServerDelegate> delegate;
- (id <SecureBlackboxOCSPServerDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxOCSPServerDelegate>)anObject;

  /* Events */

- (void)onAccept:(NSString*)remoteAddress :(int)remotePort :(int*)accept NS_SWIFT_NAME(onAccept(_:_:_:));

- (void)onAuthAttempt:(long long)connectionID :(NSString*)HTTPMethod :(NSString*)URI :(NSString*)authMethod :(NSString*)username :(NSString*)password :(int*)allow NS_SWIFT_NAME(onAuthAttempt(_:_:_:_:_:_:_:));

- (void)onConnect:(long long)connectionID :(NSString*)remoteAddress :(int)remotePort NS_SWIFT_NAME(onConnect(_:_:_:));

- (void)onDisconnect:(long long)connectionID NS_SWIFT_NAME(onDisconnect(_:));

- (void)onError:(long long)connectionId :(int)errorCode :(BOOL)fatal :(BOOL)remote :(NSString*)description NS_SWIFT_NAME(onError(_:_:_:_:_:));

- (void)onExternalSign:(long long)connectionID :(NSString*)operationId :(NSString*)hashAlgorithm :(NSString*)pars :(NSString*)data :(NSString**)signedData NS_SWIFT_NAME(onExternalSign(_:_:_:_:_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

- (void)onStatusRequest:(long long)connectionId :(NSString*)hashAlgorithm :(NSData*)issuerNameHash :(NSData*)issuerKeyHash :(NSData*)certificateSerial :(int*)certStatus :(int*)reason :(NSString**)revocationTime :(NSString**)thisUpdate :(NSString**)nextUpdate NS_SWIFT_NAME(onStatusRequest(_:_:_:_:_:_:_:_:_:_:));

- (void)onTLSCertValidate:(long long)connectionID :(int*)accept NS_SWIFT_NAME(onTLSCertValidate(_:_:));

- (void)onTLSEstablished:(long long)connectionID NS_SWIFT_NAME(onTLSEstablished(_:));

- (void)onTLSPSK:(long long)connectionID :(NSString*)identity :(NSString**)PSK :(NSString**)ciphersuite NS_SWIFT_NAME(onTLSPSK(_:_:_:_:));

- (void)onTLSShutdown:(long long)connectionID NS_SWIFT_NAME(onTLSShutdown(_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readonly,assign,getter=active) BOOL active NS_SWIFT_NAME(active);

- (BOOL)active NS_SWIFT_NAME(active());

@property (nonatomic,readwrite,assign,getter=authRealm,setter=setAuthRealm:) NSString* authRealm NS_SWIFT_NAME(authRealm);

- (NSString*)authRealm NS_SWIFT_NAME(authRealm());
- (void)setAuthRealm :(NSString*)newAuthRealm NS_SWIFT_NAME(setAuthRealm(_:));

@property (nonatomic,readwrite,assign,getter=authTypes,setter=setAuthTypes:) int authTypes NS_SWIFT_NAME(authTypes);

- (int)authTypes NS_SWIFT_NAME(authTypes());
- (void)setAuthTypes :(int)newAuthTypes NS_SWIFT_NAME(setAuthTypes(_:));

@property (nonatomic,readwrite,assign,getter=badEntryCount,setter=setBadEntryCount:) int badEntryCount NS_SWIFT_NAME(badEntryCount);

- (int)badEntryCount NS_SWIFT_NAME(badEntryCount());
- (void)setBadEntryCount :(int)newBadEntryCount NS_SWIFT_NAME(setBadEntryCount(_:));

- (int)badEntryCertStatus:(int)badEntryIndex NS_SWIFT_NAME(badEntryCertStatus(_:));
- (void)setBadEntryCertStatus:(int)badEntryIndex :(int)newBadEntryCertStatus NS_SWIFT_NAME(setBadEntryCertStatus(_:_:));

- (long long)badEntryHandle:(int)badEntryIndex NS_SWIFT_NAME(badEntryHandle(_:));
- (void)setBadEntryHandle:(int)badEntryIndex :(long long)newBadEntryHandle NS_SWIFT_NAME(setBadEntryHandle(_:_:));

- (NSString*)badEntryNextUpdate:(int)badEntryIndex NS_SWIFT_NAME(badEntryNextUpdate(_:));
- (void)setBadEntryNextUpdate:(int)badEntryIndex :(NSString*)newBadEntryNextUpdate NS_SWIFT_NAME(setBadEntryNextUpdate(_:_:));

- (NSString*)badEntryRevocationDate:(int)badEntryIndex NS_SWIFT_NAME(badEntryRevocationDate(_:));
- (void)setBadEntryRevocationDate:(int)badEntryIndex :(NSString*)newBadEntryRevocationDate NS_SWIFT_NAME(setBadEntryRevocationDate(_:_:));

- (int)badEntryRevocationReason:(int)badEntryIndex NS_SWIFT_NAME(badEntryRevocationReason(_:));
- (void)setBadEntryRevocationReason:(int)badEntryIndex :(int)newBadEntryRevocationReason NS_SWIFT_NAME(setBadEntryRevocationReason(_:_:));

- (NSData*)badEntrySerialNumber:(int)badEntryIndex NS_SWIFT_NAME(badEntrySerialNumber(_:));
- (void)setBadEntrySerialNumber:(int)badEntryIndex :(NSData*)newBadEntrySerialNumber NS_SWIFT_NAME(setBadEntrySerialNumber(_:_:));

- (NSString*)badEntryThisUpdate:(int)badEntryIndex NS_SWIFT_NAME(badEntryThisUpdate(_:));
- (void)setBadEntryThisUpdate:(int)badEntryIndex :(NSString*)newBadEntryThisUpdate NS_SWIFT_NAME(setBadEntryThisUpdate(_:_:));

@property (nonatomic,readonly,assign,getter=boundPort) int boundPort NS_SWIFT_NAME(boundPort);

- (int)boundPort NS_SWIFT_NAME(boundPort());

@property (nonatomic,readonly,assign,getter=CACertBytes) NSData* CACertBytes NS_SWIFT_NAME(CACertBytes);

- (NSData*)CACertBytes NS_SWIFT_NAME(CACertBytes());

@property (nonatomic,readwrite,assign,getter=CACertCA,setter=setCACertCA:) BOOL CACertCA NS_SWIFT_NAME(CACertCA);

- (BOOL)CACertCA NS_SWIFT_NAME(CACertCA());
- (void)setCACertCA :(BOOL)newCACertCA NS_SWIFT_NAME(setCACertCA(_:));

@property (nonatomic,readonly,assign,getter=CACertCAKeyID) NSData* CACertCAKeyID NS_SWIFT_NAME(CACertCAKeyID);

- (NSData*)CACertCAKeyID NS_SWIFT_NAME(CACertCAKeyID());

@property (nonatomic,readonly,assign,getter=CACertCertType) int CACertCertType NS_SWIFT_NAME(CACertCertType);

- (int)CACertCertType NS_SWIFT_NAME(CACertCertType());

@property (nonatomic,readwrite,assign,getter=CACertCRLDistributionPoints,setter=setCACertCRLDistributionPoints:) NSString* CACertCRLDistributionPoints NS_SWIFT_NAME(CACertCRLDistributionPoints);

- (NSString*)CACertCRLDistributionPoints NS_SWIFT_NAME(CACertCRLDistributionPoints());
- (void)setCACertCRLDistributionPoints :(NSString*)newCACertCRLDistributionPoints NS_SWIFT_NAME(setCACertCRLDistributionPoints(_:));

@property (nonatomic,readwrite,assign,getter=CACertCurve,setter=setCACertCurve:) NSString* CACertCurve NS_SWIFT_NAME(CACertCurve);

- (NSString*)CACertCurve NS_SWIFT_NAME(CACertCurve());
- (void)setCACertCurve :(NSString*)newCACertCurve NS_SWIFT_NAME(setCACertCurve(_:));

@property (nonatomic,readonly,assign,getter=CACertFingerprint) NSString* CACertFingerprint NS_SWIFT_NAME(CACertFingerprint);

- (NSString*)CACertFingerprint NS_SWIFT_NAME(CACertFingerprint());

@property (nonatomic,readonly,assign,getter=CACertFriendlyName) NSString* CACertFriendlyName NS_SWIFT_NAME(CACertFriendlyName);

- (NSString*)CACertFriendlyName NS_SWIFT_NAME(CACertFriendlyName());

@property (nonatomic,readwrite,assign,getter=CACertHandle,setter=setCACertHandle:) long long CACertHandle NS_SWIFT_NAME(CACertHandle);

- (long long)CACertHandle NS_SWIFT_NAME(CACertHandle());
- (void)setCACertHandle :(long long)newCACertHandle NS_SWIFT_NAME(setCACertHandle(_:));

@property (nonatomic,readwrite,assign,getter=CACertHashAlgorithm,setter=setCACertHashAlgorithm:) NSString* CACertHashAlgorithm NS_SWIFT_NAME(CACertHashAlgorithm);

- (NSString*)CACertHashAlgorithm NS_SWIFT_NAME(CACertHashAlgorithm());
- (void)setCACertHashAlgorithm :(NSString*)newCACertHashAlgorithm NS_SWIFT_NAME(setCACertHashAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=CACertIssuer) NSString* CACertIssuer NS_SWIFT_NAME(CACertIssuer);

- (NSString*)CACertIssuer NS_SWIFT_NAME(CACertIssuer());

@property (nonatomic,readwrite,assign,getter=CACertIssuerRDN,setter=setCACertIssuerRDN:) NSString* CACertIssuerRDN NS_SWIFT_NAME(CACertIssuerRDN);

- (NSString*)CACertIssuerRDN NS_SWIFT_NAME(CACertIssuerRDN());
- (void)setCACertIssuerRDN :(NSString*)newCACertIssuerRDN NS_SWIFT_NAME(setCACertIssuerRDN(_:));

@property (nonatomic,readwrite,assign,getter=CACertKeyAlgorithm,setter=setCACertKeyAlgorithm:) NSString* CACertKeyAlgorithm NS_SWIFT_NAME(CACertKeyAlgorithm);

- (NSString*)CACertKeyAlgorithm NS_SWIFT_NAME(CACertKeyAlgorithm());
- (void)setCACertKeyAlgorithm :(NSString*)newCACertKeyAlgorithm NS_SWIFT_NAME(setCACertKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=CACertKeyBits) int CACertKeyBits NS_SWIFT_NAME(CACertKeyBits);

- (int)CACertKeyBits NS_SWIFT_NAME(CACertKeyBits());

@property (nonatomic,readonly,assign,getter=CACertKeyFingerprint) NSString* CACertKeyFingerprint NS_SWIFT_NAME(CACertKeyFingerprint);

- (NSString*)CACertKeyFingerprint NS_SWIFT_NAME(CACertKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=CACertKeyUsage,setter=setCACertKeyUsage:) int CACertKeyUsage NS_SWIFT_NAME(CACertKeyUsage);

- (int)CACertKeyUsage NS_SWIFT_NAME(CACertKeyUsage());
- (void)setCACertKeyUsage :(int)newCACertKeyUsage NS_SWIFT_NAME(setCACertKeyUsage(_:));

@property (nonatomic,readonly,assign,getter=CACertKeyValid) BOOL CACertKeyValid NS_SWIFT_NAME(CACertKeyValid);

- (BOOL)CACertKeyValid NS_SWIFT_NAME(CACertKeyValid());

@property (nonatomic,readwrite,assign,getter=CACertOCSPLocations,setter=setCACertOCSPLocations:) NSString* CACertOCSPLocations NS_SWIFT_NAME(CACertOCSPLocations);

- (NSString*)CACertOCSPLocations NS_SWIFT_NAME(CACertOCSPLocations());
- (void)setCACertOCSPLocations :(NSString*)newCACertOCSPLocations NS_SWIFT_NAME(setCACertOCSPLocations(_:));

@property (nonatomic,readwrite,assign,getter=CACertOCSPNoCheck,setter=setCACertOCSPNoCheck:) BOOL CACertOCSPNoCheck NS_SWIFT_NAME(CACertOCSPNoCheck);

- (BOOL)CACertOCSPNoCheck NS_SWIFT_NAME(CACertOCSPNoCheck());
- (void)setCACertOCSPNoCheck :(BOOL)newCACertOCSPNoCheck NS_SWIFT_NAME(setCACertOCSPNoCheck(_:));

@property (nonatomic,readonly,assign,getter=CACertOrigin) int CACertOrigin NS_SWIFT_NAME(CACertOrigin);

- (int)CACertOrigin NS_SWIFT_NAME(CACertOrigin());

@property (nonatomic,readwrite,assign,getter=CACertPolicyIDs,setter=setCACertPolicyIDs:) NSString* CACertPolicyIDs NS_SWIFT_NAME(CACertPolicyIDs);

- (NSString*)CACertPolicyIDs NS_SWIFT_NAME(CACertPolicyIDs());
- (void)setCACertPolicyIDs :(NSString*)newCACertPolicyIDs NS_SWIFT_NAME(setCACertPolicyIDs(_:));

@property (nonatomic,readonly,assign,getter=CACertPrivateKeyBytes) NSData* CACertPrivateKeyBytes NS_SWIFT_NAME(CACertPrivateKeyBytes);

- (NSData*)CACertPrivateKeyBytes NS_SWIFT_NAME(CACertPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=CACertPrivateKeyExists) BOOL CACertPrivateKeyExists NS_SWIFT_NAME(CACertPrivateKeyExists);

- (BOOL)CACertPrivateKeyExists NS_SWIFT_NAME(CACertPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=CACertPrivateKeyExtractable) BOOL CACertPrivateKeyExtractable NS_SWIFT_NAME(CACertPrivateKeyExtractable);

- (BOOL)CACertPrivateKeyExtractable NS_SWIFT_NAME(CACertPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=CACertPublicKeyBytes) NSData* CACertPublicKeyBytes NS_SWIFT_NAME(CACertPublicKeyBytes);

- (NSData*)CACertPublicKeyBytes NS_SWIFT_NAME(CACertPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=CACertQualified) BOOL CACertQualified NS_SWIFT_NAME(CACertQualified);

- (BOOL)CACertQualified NS_SWIFT_NAME(CACertQualified());

@property (nonatomic,readwrite,assign,getter=CACertQualifiedStatements,setter=setCACertQualifiedStatements:) int CACertQualifiedStatements NS_SWIFT_NAME(CACertQualifiedStatements);

- (int)CACertQualifiedStatements NS_SWIFT_NAME(CACertQualifiedStatements());
- (void)setCACertQualifiedStatements :(int)newCACertQualifiedStatements NS_SWIFT_NAME(setCACertQualifiedStatements(_:));

@property (nonatomic,readonly,assign,getter=CACertQualifiers) NSString* CACertQualifiers NS_SWIFT_NAME(CACertQualifiers);

- (NSString*)CACertQualifiers NS_SWIFT_NAME(CACertQualifiers());

@property (nonatomic,readonly,assign,getter=CACertSelfSigned) BOOL CACertSelfSigned NS_SWIFT_NAME(CACertSelfSigned);

- (BOOL)CACertSelfSigned NS_SWIFT_NAME(CACertSelfSigned());

@property (nonatomic,readwrite,assign,getter=CACertSerialNumber,setter=setCACertSerialNumber:) NSData* CACertSerialNumber NS_SWIFT_NAME(CACertSerialNumber);

- (NSData*)CACertSerialNumber NS_SWIFT_NAME(CACertSerialNumber());
- (void)setCACertSerialNumber :(NSData*)newCACertSerialNumber NS_SWIFT_NAME(setCACertSerialNumber(_:));

@property (nonatomic,readonly,assign,getter=CACertSigAlgorithm) NSString* CACertSigAlgorithm NS_SWIFT_NAME(CACertSigAlgorithm);

- (NSString*)CACertSigAlgorithm NS_SWIFT_NAME(CACertSigAlgorithm());

@property (nonatomic,readonly,assign,getter=CACertSource) int CACertSource NS_SWIFT_NAME(CACertSource);

- (int)CACertSource NS_SWIFT_NAME(CACertSource());

@property (nonatomic,readonly,assign,getter=CACertSubject) NSString* CACertSubject NS_SWIFT_NAME(CACertSubject);

- (NSString*)CACertSubject NS_SWIFT_NAME(CACertSubject());

@property (nonatomic,readwrite,assign,getter=CACertSubjectAlternativeName,setter=setCACertSubjectAlternativeName:) NSString* CACertSubjectAlternativeName NS_SWIFT_NAME(CACertSubjectAlternativeName);

- (NSString*)CACertSubjectAlternativeName NS_SWIFT_NAME(CACertSubjectAlternativeName());
- (void)setCACertSubjectAlternativeName :(NSString*)newCACertSubjectAlternativeName NS_SWIFT_NAME(setCACertSubjectAlternativeName(_:));

@property (nonatomic,readwrite,assign,getter=CACertSubjectKeyID,setter=setCACertSubjectKeyID:) NSData* CACertSubjectKeyID NS_SWIFT_NAME(CACertSubjectKeyID);

- (NSData*)CACertSubjectKeyID NS_SWIFT_NAME(CACertSubjectKeyID());
- (void)setCACertSubjectKeyID :(NSData*)newCACertSubjectKeyID NS_SWIFT_NAME(setCACertSubjectKeyID(_:));

@property (nonatomic,readwrite,assign,getter=CACertSubjectRDN,setter=setCACertSubjectRDN:) NSString* CACertSubjectRDN NS_SWIFT_NAME(CACertSubjectRDN);

- (NSString*)CACertSubjectRDN NS_SWIFT_NAME(CACertSubjectRDN());
- (void)setCACertSubjectRDN :(NSString*)newCACertSubjectRDN NS_SWIFT_NAME(setCACertSubjectRDN(_:));

@property (nonatomic,readonly,assign,getter=CACertValid) BOOL CACertValid NS_SWIFT_NAME(CACertValid);

- (BOOL)CACertValid NS_SWIFT_NAME(CACertValid());

@property (nonatomic,readwrite,assign,getter=CACertValidFrom,setter=setCACertValidFrom:) NSString* CACertValidFrom NS_SWIFT_NAME(CACertValidFrom);

- (NSString*)CACertValidFrom NS_SWIFT_NAME(CACertValidFrom());
- (void)setCACertValidFrom :(NSString*)newCACertValidFrom NS_SWIFT_NAME(setCACertValidFrom(_:));

@property (nonatomic,readwrite,assign,getter=CACertValidTo,setter=setCACertValidTo:) NSString* CACertValidTo NS_SWIFT_NAME(CACertValidTo);

- (NSString*)CACertValidTo NS_SWIFT_NAME(CACertValidTo());
- (void)setCACertValidTo :(NSString*)newCACertValidTo NS_SWIFT_NAME(setCACertValidTo(_:));

@property (nonatomic,readwrite,assign,getter=endpoint,setter=setEndpoint:) NSString* endpoint NS_SWIFT_NAME(endpoint);

- (NSString*)endpoint NS_SWIFT_NAME(endpoint());
- (void)setEndpoint :(NSString*)newEndpoint NS_SWIFT_NAME(setEndpoint(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoAsyncDocumentID,setter=setExternalCryptoAsyncDocumentID:) NSString* externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID);

- (NSString*)externalCryptoAsyncDocumentID NS_SWIFT_NAME(externalCryptoAsyncDocumentID());
- (void)setExternalCryptoAsyncDocumentID :(NSString*)newExternalCryptoAsyncDocumentID NS_SWIFT_NAME(setExternalCryptoAsyncDocumentID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoCustomParams,setter=setExternalCryptoCustomParams:) NSString* externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams);

- (NSString*)externalCryptoCustomParams NS_SWIFT_NAME(externalCryptoCustomParams());
- (void)setExternalCryptoCustomParams :(NSString*)newExternalCryptoCustomParams NS_SWIFT_NAME(setExternalCryptoCustomParams(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoData,setter=setExternalCryptoData:) NSString* externalCryptoData NS_SWIFT_NAME(externalCryptoData);

- (NSString*)externalCryptoData NS_SWIFT_NAME(externalCryptoData());
- (void)setExternalCryptoData :(NSString*)newExternalCryptoData NS_SWIFT_NAME(setExternalCryptoData(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoExternalHashCalculation,setter=setExternalCryptoExternalHashCalculation:) BOOL externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation);

- (BOOL)externalCryptoExternalHashCalculation NS_SWIFT_NAME(externalCryptoExternalHashCalculation());
- (void)setExternalCryptoExternalHashCalculation :(BOOL)newExternalCryptoExternalHashCalculation NS_SWIFT_NAME(setExternalCryptoExternalHashCalculation(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoHashAlgorithm,setter=setExternalCryptoHashAlgorithm:) NSString* externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm);

- (NSString*)externalCryptoHashAlgorithm NS_SWIFT_NAME(externalCryptoHashAlgorithm());
- (void)setExternalCryptoHashAlgorithm :(NSString*)newExternalCryptoHashAlgorithm NS_SWIFT_NAME(setExternalCryptoHashAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeyID,setter=setExternalCryptoKeyID:) NSString* externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID);

- (NSString*)externalCryptoKeyID NS_SWIFT_NAME(externalCryptoKeyID());
- (void)setExternalCryptoKeyID :(NSString*)newExternalCryptoKeyID NS_SWIFT_NAME(setExternalCryptoKeyID(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoKeySecret,setter=setExternalCryptoKeySecret:) NSString* externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret);

- (NSString*)externalCryptoKeySecret NS_SWIFT_NAME(externalCryptoKeySecret());
- (void)setExternalCryptoKeySecret :(NSString*)newExternalCryptoKeySecret NS_SWIFT_NAME(setExternalCryptoKeySecret(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMethod,setter=setExternalCryptoMethod:) int externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod);

- (int)externalCryptoMethod NS_SWIFT_NAME(externalCryptoMethod());
- (void)setExternalCryptoMethod :(int)newExternalCryptoMethod NS_SWIFT_NAME(setExternalCryptoMethod(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoMode,setter=setExternalCryptoMode:) int externalCryptoMode NS_SWIFT_NAME(externalCryptoMode);

- (int)externalCryptoMode NS_SWIFT_NAME(externalCryptoMode());
- (void)setExternalCryptoMode :(int)newExternalCryptoMode NS_SWIFT_NAME(setExternalCryptoMode(_:));

@property (nonatomic,readwrite,assign,getter=externalCryptoPublicKeyAlgorithm,setter=setExternalCryptoPublicKeyAlgorithm:) NSString* externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm);

- (NSString*)externalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(externalCryptoPublicKeyAlgorithm());
- (void)setExternalCryptoPublicKeyAlgorithm :(NSString*)newExternalCryptoPublicKeyAlgorithm NS_SWIFT_NAME(setExternalCryptoPublicKeyAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=goodEntryCount,setter=setGoodEntryCount:) int goodEntryCount NS_SWIFT_NAME(goodEntryCount);

- (int)goodEntryCount NS_SWIFT_NAME(goodEntryCount());
- (void)setGoodEntryCount :(int)newGoodEntryCount NS_SWIFT_NAME(setGoodEntryCount(_:));

- (int)goodEntryCertStatus:(int)goodEntryIndex NS_SWIFT_NAME(goodEntryCertStatus(_:));
- (void)setGoodEntryCertStatus:(int)goodEntryIndex :(int)newGoodEntryCertStatus NS_SWIFT_NAME(setGoodEntryCertStatus(_:_:));

- (long long)goodEntryHandle:(int)goodEntryIndex NS_SWIFT_NAME(goodEntryHandle(_:));
- (void)setGoodEntryHandle:(int)goodEntryIndex :(long long)newGoodEntryHandle NS_SWIFT_NAME(setGoodEntryHandle(_:_:));

- (NSString*)goodEntryNextUpdate:(int)goodEntryIndex NS_SWIFT_NAME(goodEntryNextUpdate(_:));
- (void)setGoodEntryNextUpdate:(int)goodEntryIndex :(NSString*)newGoodEntryNextUpdate NS_SWIFT_NAME(setGoodEntryNextUpdate(_:_:));

- (NSString*)goodEntryRevocationDate:(int)goodEntryIndex NS_SWIFT_NAME(goodEntryRevocationDate(_:));
- (void)setGoodEntryRevocationDate:(int)goodEntryIndex :(NSString*)newGoodEntryRevocationDate NS_SWIFT_NAME(setGoodEntryRevocationDate(_:_:));

- (int)goodEntryRevocationReason:(int)goodEntryIndex NS_SWIFT_NAME(goodEntryRevocationReason(_:));
- (void)setGoodEntryRevocationReason:(int)goodEntryIndex :(int)newGoodEntryRevocationReason NS_SWIFT_NAME(setGoodEntryRevocationReason(_:_:));

- (NSData*)goodEntrySerialNumber:(int)goodEntryIndex NS_SWIFT_NAME(goodEntrySerialNumber(_:));
- (void)setGoodEntrySerialNumber:(int)goodEntryIndex :(NSData*)newGoodEntrySerialNumber NS_SWIFT_NAME(setGoodEntrySerialNumber(_:_:));

- (NSString*)goodEntryThisUpdate:(int)goodEntryIndex NS_SWIFT_NAME(goodEntryThisUpdate(_:));
- (void)setGoodEntryThisUpdate:(int)goodEntryIndex :(NSString*)newGoodEntryThisUpdate NS_SWIFT_NAME(setGoodEntryThisUpdate(_:_:));

@property (nonatomic,readwrite,assign,getter=host,setter=setHost:) NSString* host NS_SWIFT_NAME(host);

- (NSString*)host NS_SWIFT_NAME(host());
- (void)setHost :(NSString*)newHost NS_SWIFT_NAME(setHost(_:));

@property (nonatomic,readwrite,assign,getter=pinnedCertCount,setter=setPinnedCertCount:) int pinnedCertCount NS_SWIFT_NAME(pinnedCertCount);

- (int)pinnedCertCount NS_SWIFT_NAME(pinnedCertCount());
- (void)setPinnedCertCount :(int)newPinnedCertCount NS_SWIFT_NAME(setPinnedCertCount(_:));

- (NSData*)pinnedCertBytes:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertBytes(_:));

- (BOOL)pinnedCertCA:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertCA(_:));
- (void)setPinnedCertCA:(int)pinnedCertIndex :(BOOL)newPinnedCertCA NS_SWIFT_NAME(setPinnedCertCA(_:_:));

- (NSData*)pinnedCertCAKeyID:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertCAKeyID(_:));

- (int)pinnedCertCertType:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertCertType(_:));

- (NSString*)pinnedCertCRLDistributionPoints:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertCRLDistributionPoints(_:));
- (void)setPinnedCertCRLDistributionPoints:(int)pinnedCertIndex :(NSString*)newPinnedCertCRLDistributionPoints NS_SWIFT_NAME(setPinnedCertCRLDistributionPoints(_:_:));

- (NSString*)pinnedCertCurve:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertCurve(_:));
- (void)setPinnedCertCurve:(int)pinnedCertIndex :(NSString*)newPinnedCertCurve NS_SWIFT_NAME(setPinnedCertCurve(_:_:));

- (NSString*)pinnedCertFingerprint:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertFingerprint(_:));

- (NSString*)pinnedCertFriendlyName:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertFriendlyName(_:));

- (long long)pinnedCertHandle:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertHandle(_:));
- (void)setPinnedCertHandle:(int)pinnedCertIndex :(long long)newPinnedCertHandle NS_SWIFT_NAME(setPinnedCertHandle(_:_:));

- (NSString*)pinnedCertHashAlgorithm:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertHashAlgorithm(_:));
- (void)setPinnedCertHashAlgorithm:(int)pinnedCertIndex :(NSString*)newPinnedCertHashAlgorithm NS_SWIFT_NAME(setPinnedCertHashAlgorithm(_:_:));

- (NSString*)pinnedCertIssuer:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertIssuer(_:));

- (NSString*)pinnedCertIssuerRDN:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertIssuerRDN(_:));
- (void)setPinnedCertIssuerRDN:(int)pinnedCertIndex :(NSString*)newPinnedCertIssuerRDN NS_SWIFT_NAME(setPinnedCertIssuerRDN(_:_:));

- (NSString*)pinnedCertKeyAlgorithm:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertKeyAlgorithm(_:));
- (void)setPinnedCertKeyAlgorithm:(int)pinnedCertIndex :(NSString*)newPinnedCertKeyAlgorithm NS_SWIFT_NAME(setPinnedCertKeyAlgorithm(_:_:));

- (int)pinnedCertKeyBits:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertKeyBits(_:));

- (NSString*)pinnedCertKeyFingerprint:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertKeyFingerprint(_:));

- (int)pinnedCertKeyUsage:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertKeyUsage(_:));
- (void)setPinnedCertKeyUsage:(int)pinnedCertIndex :(int)newPinnedCertKeyUsage NS_SWIFT_NAME(setPinnedCertKeyUsage(_:_:));

- (BOOL)pinnedCertKeyValid:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertKeyValid(_:));

- (NSString*)pinnedCertOCSPLocations:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertOCSPLocations(_:));
- (void)setPinnedCertOCSPLocations:(int)pinnedCertIndex :(NSString*)newPinnedCertOCSPLocations NS_SWIFT_NAME(setPinnedCertOCSPLocations(_:_:));

- (BOOL)pinnedCertOCSPNoCheck:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertOCSPNoCheck(_:));
- (void)setPinnedCertOCSPNoCheck:(int)pinnedCertIndex :(BOOL)newPinnedCertOCSPNoCheck NS_SWIFT_NAME(setPinnedCertOCSPNoCheck(_:_:));

- (int)pinnedCertOrigin:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertOrigin(_:));

- (NSString*)pinnedCertPolicyIDs:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertPolicyIDs(_:));
- (void)setPinnedCertPolicyIDs:(int)pinnedCertIndex :(NSString*)newPinnedCertPolicyIDs NS_SWIFT_NAME(setPinnedCertPolicyIDs(_:_:));

- (NSData*)pinnedCertPrivateKeyBytes:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertPrivateKeyBytes(_:));

- (BOOL)pinnedCertPrivateKeyExists:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertPrivateKeyExists(_:));

- (BOOL)pinnedCertPrivateKeyExtractable:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertPrivateKeyExtractable(_:));

- (NSData*)pinnedCertPublicKeyBytes:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertPublicKeyBytes(_:));

- (BOOL)pinnedCertQualified:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertQualified(_:));

- (int)pinnedCertQualifiedStatements:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertQualifiedStatements(_:));
- (void)setPinnedCertQualifiedStatements:(int)pinnedCertIndex :(int)newPinnedCertQualifiedStatements NS_SWIFT_NAME(setPinnedCertQualifiedStatements(_:_:));

- (NSString*)pinnedCertQualifiers:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertQualifiers(_:));

- (BOOL)pinnedCertSelfSigned:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertSelfSigned(_:));

- (NSData*)pinnedCertSerialNumber:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertSerialNumber(_:));
- (void)setPinnedCertSerialNumber:(int)pinnedCertIndex :(NSData*)newPinnedCertSerialNumber NS_SWIFT_NAME(setPinnedCertSerialNumber(_:_:));

- (NSString*)pinnedCertSigAlgorithm:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertSigAlgorithm(_:));

- (int)pinnedCertSource:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertSource(_:));

- (NSString*)pinnedCertSubject:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertSubject(_:));

- (NSString*)pinnedCertSubjectAlternativeName:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertSubjectAlternativeName(_:));
- (void)setPinnedCertSubjectAlternativeName:(int)pinnedCertIndex :(NSString*)newPinnedCertSubjectAlternativeName NS_SWIFT_NAME(setPinnedCertSubjectAlternativeName(_:_:));

- (NSData*)pinnedCertSubjectKeyID:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertSubjectKeyID(_:));
- (void)setPinnedCertSubjectKeyID:(int)pinnedCertIndex :(NSData*)newPinnedCertSubjectKeyID NS_SWIFT_NAME(setPinnedCertSubjectKeyID(_:_:));

- (NSString*)pinnedCertSubjectRDN:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertSubjectRDN(_:));
- (void)setPinnedCertSubjectRDN:(int)pinnedCertIndex :(NSString*)newPinnedCertSubjectRDN NS_SWIFT_NAME(setPinnedCertSubjectRDN(_:_:));

- (BOOL)pinnedCertValid:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertValid(_:));

- (NSString*)pinnedCertValidFrom:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertValidFrom(_:));
- (void)setPinnedCertValidFrom:(int)pinnedCertIndex :(NSString*)newPinnedCertValidFrom NS_SWIFT_NAME(setPinnedCertValidFrom(_:_:));

- (NSString*)pinnedCertValidTo:(int)pinnedCertIndex NS_SWIFT_NAME(pinnedCertValidTo(_:));
- (void)setPinnedCertValidTo:(int)pinnedCertIndex :(NSString*)newPinnedCertValidTo NS_SWIFT_NAME(setPinnedCertValidTo(_:_:));

@property (nonatomic,readonly,assign,getter=pinnedClientAEADCipher) BOOL pinnedClientAEADCipher NS_SWIFT_NAME(pinnedClientAEADCipher);

- (BOOL)pinnedClientAEADCipher NS_SWIFT_NAME(pinnedClientAEADCipher());

@property (nonatomic,readonly,assign,getter=pinnedClientChainValidationDetails) int pinnedClientChainValidationDetails NS_SWIFT_NAME(pinnedClientChainValidationDetails);

- (int)pinnedClientChainValidationDetails NS_SWIFT_NAME(pinnedClientChainValidationDetails());

@property (nonatomic,readonly,assign,getter=pinnedClientChainValidationResult) int pinnedClientChainValidationResult NS_SWIFT_NAME(pinnedClientChainValidationResult);

- (int)pinnedClientChainValidationResult NS_SWIFT_NAME(pinnedClientChainValidationResult());

@property (nonatomic,readonly,assign,getter=pinnedClientCiphersuite) NSString* pinnedClientCiphersuite NS_SWIFT_NAME(pinnedClientCiphersuite);

- (NSString*)pinnedClientCiphersuite NS_SWIFT_NAME(pinnedClientCiphersuite());

@property (nonatomic,readonly,assign,getter=pinnedClientClientAuthenticated) BOOL pinnedClientClientAuthenticated NS_SWIFT_NAME(pinnedClientClientAuthenticated);

- (BOOL)pinnedClientClientAuthenticated NS_SWIFT_NAME(pinnedClientClientAuthenticated());

@property (nonatomic,readonly,assign,getter=pinnedClientClientAuthRequested) BOOL pinnedClientClientAuthRequested NS_SWIFT_NAME(pinnedClientClientAuthRequested);

- (BOOL)pinnedClientClientAuthRequested NS_SWIFT_NAME(pinnedClientClientAuthRequested());

@property (nonatomic,readonly,assign,getter=pinnedClientConnectionEstablished) BOOL pinnedClientConnectionEstablished NS_SWIFT_NAME(pinnedClientConnectionEstablished);

- (BOOL)pinnedClientConnectionEstablished NS_SWIFT_NAME(pinnedClientConnectionEstablished());

@property (nonatomic,readonly,assign,getter=pinnedClientConnectionID) NSData* pinnedClientConnectionID NS_SWIFT_NAME(pinnedClientConnectionID);

- (NSData*)pinnedClientConnectionID NS_SWIFT_NAME(pinnedClientConnectionID());

@property (nonatomic,readonly,assign,getter=pinnedClientDigestAlgorithm) NSString* pinnedClientDigestAlgorithm NS_SWIFT_NAME(pinnedClientDigestAlgorithm);

- (NSString*)pinnedClientDigestAlgorithm NS_SWIFT_NAME(pinnedClientDigestAlgorithm());

@property (nonatomic,readonly,assign,getter=pinnedClientEncryptionAlgorithm) NSString* pinnedClientEncryptionAlgorithm NS_SWIFT_NAME(pinnedClientEncryptionAlgorithm);

- (NSString*)pinnedClientEncryptionAlgorithm NS_SWIFT_NAME(pinnedClientEncryptionAlgorithm());

@property (nonatomic,readonly,assign,getter=pinnedClientExportable) BOOL pinnedClientExportable NS_SWIFT_NAME(pinnedClientExportable);

- (BOOL)pinnedClientExportable NS_SWIFT_NAME(pinnedClientExportable());

@property (nonatomic,readonly,assign,getter=pinnedClientID) long long pinnedClientID NS_SWIFT_NAME(pinnedClientID);

- (long long)pinnedClientID NS_SWIFT_NAME(pinnedClientID());

@property (nonatomic,readonly,assign,getter=pinnedClientKeyExchangeAlgorithm) NSString* pinnedClientKeyExchangeAlgorithm NS_SWIFT_NAME(pinnedClientKeyExchangeAlgorithm);

- (NSString*)pinnedClientKeyExchangeAlgorithm NS_SWIFT_NAME(pinnedClientKeyExchangeAlgorithm());

@property (nonatomic,readonly,assign,getter=pinnedClientKeyExchangeKeyBits) int pinnedClientKeyExchangeKeyBits NS_SWIFT_NAME(pinnedClientKeyExchangeKeyBits);

- (int)pinnedClientKeyExchangeKeyBits NS_SWIFT_NAME(pinnedClientKeyExchangeKeyBits());

@property (nonatomic,readonly,assign,getter=pinnedClientNamedECCurve) NSString* pinnedClientNamedECCurve NS_SWIFT_NAME(pinnedClientNamedECCurve);

- (NSString*)pinnedClientNamedECCurve NS_SWIFT_NAME(pinnedClientNamedECCurve());

@property (nonatomic,readonly,assign,getter=pinnedClientPFSCipher) BOOL pinnedClientPFSCipher NS_SWIFT_NAME(pinnedClientPFSCipher);

- (BOOL)pinnedClientPFSCipher NS_SWIFT_NAME(pinnedClientPFSCipher());

@property (nonatomic,readonly,assign,getter=pinnedClientPreSharedIdentity) NSString* pinnedClientPreSharedIdentity NS_SWIFT_NAME(pinnedClientPreSharedIdentity);

- (NSString*)pinnedClientPreSharedIdentity NS_SWIFT_NAME(pinnedClientPreSharedIdentity());

@property (nonatomic,readonly,assign,getter=pinnedClientPreSharedIdentityHint) NSString* pinnedClientPreSharedIdentityHint NS_SWIFT_NAME(pinnedClientPreSharedIdentityHint);

- (NSString*)pinnedClientPreSharedIdentityHint NS_SWIFT_NAME(pinnedClientPreSharedIdentityHint());

@property (nonatomic,readonly,assign,getter=pinnedClientPublicKeyBits) int pinnedClientPublicKeyBits NS_SWIFT_NAME(pinnedClientPublicKeyBits);

- (int)pinnedClientPublicKeyBits NS_SWIFT_NAME(pinnedClientPublicKeyBits());

@property (nonatomic,readonly,assign,getter=pinnedClientRemoteAddress) NSString* pinnedClientRemoteAddress NS_SWIFT_NAME(pinnedClientRemoteAddress);

- (NSString*)pinnedClientRemoteAddress NS_SWIFT_NAME(pinnedClientRemoteAddress());

@property (nonatomic,readonly,assign,getter=pinnedClientRemotePort) int pinnedClientRemotePort NS_SWIFT_NAME(pinnedClientRemotePort);

- (int)pinnedClientRemotePort NS_SWIFT_NAME(pinnedClientRemotePort());

@property (nonatomic,readonly,assign,getter=pinnedClientResumedSession) BOOL pinnedClientResumedSession NS_SWIFT_NAME(pinnedClientResumedSession);

- (BOOL)pinnedClientResumedSession NS_SWIFT_NAME(pinnedClientResumedSession());

@property (nonatomic,readonly,assign,getter=pinnedClientSecureConnection) BOOL pinnedClientSecureConnection NS_SWIFT_NAME(pinnedClientSecureConnection);

- (BOOL)pinnedClientSecureConnection NS_SWIFT_NAME(pinnedClientSecureConnection());

@property (nonatomic,readonly,assign,getter=pinnedClientServerAuthenticated) BOOL pinnedClientServerAuthenticated NS_SWIFT_NAME(pinnedClientServerAuthenticated);

- (BOOL)pinnedClientServerAuthenticated NS_SWIFT_NAME(pinnedClientServerAuthenticated());

@property (nonatomic,readonly,assign,getter=pinnedClientSignatureAlgorithm) NSString* pinnedClientSignatureAlgorithm NS_SWIFT_NAME(pinnedClientSignatureAlgorithm);

- (NSString*)pinnedClientSignatureAlgorithm NS_SWIFT_NAME(pinnedClientSignatureAlgorithm());

@property (nonatomic,readonly,assign,getter=pinnedClientSymmetricBlockSize) int pinnedClientSymmetricBlockSize NS_SWIFT_NAME(pinnedClientSymmetricBlockSize);

- (int)pinnedClientSymmetricBlockSize NS_SWIFT_NAME(pinnedClientSymmetricBlockSize());

@property (nonatomic,readonly,assign,getter=pinnedClientSymmetricKeyBits) int pinnedClientSymmetricKeyBits NS_SWIFT_NAME(pinnedClientSymmetricKeyBits);

- (int)pinnedClientSymmetricKeyBits NS_SWIFT_NAME(pinnedClientSymmetricKeyBits());

@property (nonatomic,readonly,assign,getter=pinnedClientTotalBytesReceived) long long pinnedClientTotalBytesReceived NS_SWIFT_NAME(pinnedClientTotalBytesReceived);

- (long long)pinnedClientTotalBytesReceived NS_SWIFT_NAME(pinnedClientTotalBytesReceived());

@property (nonatomic,readonly,assign,getter=pinnedClientTotalBytesSent) long long pinnedClientTotalBytesSent NS_SWIFT_NAME(pinnedClientTotalBytesSent);

- (long long)pinnedClientTotalBytesSent NS_SWIFT_NAME(pinnedClientTotalBytesSent());

@property (nonatomic,readonly,assign,getter=pinnedClientValidationLog) NSString* pinnedClientValidationLog NS_SWIFT_NAME(pinnedClientValidationLog);

- (NSString*)pinnedClientValidationLog NS_SWIFT_NAME(pinnedClientValidationLog());

@property (nonatomic,readonly,assign,getter=pinnedClientVersion) NSString* pinnedClientVersion NS_SWIFT_NAME(pinnedClientVersion);

- (NSString*)pinnedClientVersion NS_SWIFT_NAME(pinnedClientVersion());

@property (nonatomic,readonly,assign,getter=pinnedClientCertCount) int pinnedClientCertCount NS_SWIFT_NAME(pinnedClientCertCount);

- (int)pinnedClientCertCount NS_SWIFT_NAME(pinnedClientCertCount());

- (NSData*)pinnedClientCertBytes:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertBytes(_:));

- (BOOL)pinnedClientCertCA:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertCA(_:));

- (NSData*)pinnedClientCertCAKeyID:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertCAKeyID(_:));

- (int)pinnedClientCertCertType:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertCertType(_:));

- (NSString*)pinnedClientCertCRLDistributionPoints:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertCRLDistributionPoints(_:));

- (NSString*)pinnedClientCertCurve:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertCurve(_:));

- (NSString*)pinnedClientCertFingerprint:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertFingerprint(_:));

- (NSString*)pinnedClientCertFriendlyName:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertFriendlyName(_:));

- (long long)pinnedClientCertHandle:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertHandle(_:));

- (NSString*)pinnedClientCertHashAlgorithm:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertHashAlgorithm(_:));

- (NSString*)pinnedClientCertIssuer:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertIssuer(_:));

- (NSString*)pinnedClientCertIssuerRDN:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertIssuerRDN(_:));

- (NSString*)pinnedClientCertKeyAlgorithm:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertKeyAlgorithm(_:));

- (int)pinnedClientCertKeyBits:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertKeyBits(_:));

- (NSString*)pinnedClientCertKeyFingerprint:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertKeyFingerprint(_:));

- (int)pinnedClientCertKeyUsage:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertKeyUsage(_:));

- (BOOL)pinnedClientCertKeyValid:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertKeyValid(_:));

- (NSString*)pinnedClientCertOCSPLocations:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertOCSPLocations(_:));

- (BOOL)pinnedClientCertOCSPNoCheck:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertOCSPNoCheck(_:));

- (int)pinnedClientCertOrigin:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertOrigin(_:));

- (NSString*)pinnedClientCertPolicyIDs:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertPolicyIDs(_:));

- (NSData*)pinnedClientCertPrivateKeyBytes:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertPrivateKeyBytes(_:));

- (BOOL)pinnedClientCertPrivateKeyExists:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertPrivateKeyExists(_:));

- (BOOL)pinnedClientCertPrivateKeyExtractable:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertPrivateKeyExtractable(_:));

- (NSData*)pinnedClientCertPublicKeyBytes:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertPublicKeyBytes(_:));

- (BOOL)pinnedClientCertQualified:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertQualified(_:));

- (int)pinnedClientCertQualifiedStatements:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertQualifiedStatements(_:));

- (NSString*)pinnedClientCertQualifiers:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertQualifiers(_:));

- (BOOL)pinnedClientCertSelfSigned:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSelfSigned(_:));

- (NSData*)pinnedClientCertSerialNumber:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSerialNumber(_:));

- (NSString*)pinnedClientCertSigAlgorithm:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSigAlgorithm(_:));

- (int)pinnedClientCertSource:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSource(_:));

- (NSString*)pinnedClientCertSubject:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSubject(_:));

- (NSString*)pinnedClientCertSubjectAlternativeName:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSubjectAlternativeName(_:));

- (NSData*)pinnedClientCertSubjectKeyID:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSubjectKeyID(_:));

- (NSString*)pinnedClientCertSubjectRDN:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertSubjectRDN(_:));

- (BOOL)pinnedClientCertValid:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertValid(_:));

- (NSString*)pinnedClientCertValidFrom:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertValidFrom(_:));

- (NSString*)pinnedClientCertValidTo:(int)pinnedClientCertIndex NS_SWIFT_NAME(pinnedClientCertValidTo(_:));

@property (nonatomic,readwrite,assign,getter=port,setter=setPort:) int port NS_SWIFT_NAME(port);

- (int)port NS_SWIFT_NAME(port());
- (void)setPort :(int)newPort NS_SWIFT_NAME(setPort(_:));

@property (nonatomic,readwrite,assign,getter=portRangeFrom,setter=setPortRangeFrom:) int portRangeFrom NS_SWIFT_NAME(portRangeFrom);

- (int)portRangeFrom NS_SWIFT_NAME(portRangeFrom());
- (void)setPortRangeFrom :(int)newPortRangeFrom NS_SWIFT_NAME(setPortRangeFrom(_:));

@property (nonatomic,readwrite,assign,getter=portRangeTo,setter=setPortRangeTo:) int portRangeTo NS_SWIFT_NAME(portRangeTo);

- (int)portRangeTo NS_SWIFT_NAME(portRangeTo());
- (void)setPortRangeTo :(int)newPortRangeTo NS_SWIFT_NAME(setPortRangeTo(_:));

@property (nonatomic,readonly,assign,getter=signingCertBytes) NSData* signingCertBytes NS_SWIFT_NAME(signingCertBytes);

- (NSData*)signingCertBytes NS_SWIFT_NAME(signingCertBytes());

@property (nonatomic,readwrite,assign,getter=signingCertCA,setter=setSigningCertCA:) BOOL signingCertCA NS_SWIFT_NAME(signingCertCA);

- (BOOL)signingCertCA NS_SWIFT_NAME(signingCertCA());
- (void)setSigningCertCA :(BOOL)newSigningCertCA NS_SWIFT_NAME(setSigningCertCA(_:));

@property (nonatomic,readonly,assign,getter=signingCertCAKeyID) NSData* signingCertCAKeyID NS_SWIFT_NAME(signingCertCAKeyID);

- (NSData*)signingCertCAKeyID NS_SWIFT_NAME(signingCertCAKeyID());

@property (nonatomic,readonly,assign,getter=signingCertCertType) int signingCertCertType NS_SWIFT_NAME(signingCertCertType);

- (int)signingCertCertType NS_SWIFT_NAME(signingCertCertType());

@property (nonatomic,readwrite,assign,getter=signingCertCRLDistributionPoints,setter=setSigningCertCRLDistributionPoints:) NSString* signingCertCRLDistributionPoints NS_SWIFT_NAME(signingCertCRLDistributionPoints);

- (NSString*)signingCertCRLDistributionPoints NS_SWIFT_NAME(signingCertCRLDistributionPoints());
- (void)setSigningCertCRLDistributionPoints :(NSString*)newSigningCertCRLDistributionPoints NS_SWIFT_NAME(setSigningCertCRLDistributionPoints(_:));

@property (nonatomic,readwrite,assign,getter=signingCertCurve,setter=setSigningCertCurve:) NSString* signingCertCurve NS_SWIFT_NAME(signingCertCurve);

- (NSString*)signingCertCurve NS_SWIFT_NAME(signingCertCurve());
- (void)setSigningCertCurve :(NSString*)newSigningCertCurve NS_SWIFT_NAME(setSigningCertCurve(_:));

@property (nonatomic,readonly,assign,getter=signingCertFingerprint) NSString* signingCertFingerprint NS_SWIFT_NAME(signingCertFingerprint);

- (NSString*)signingCertFingerprint NS_SWIFT_NAME(signingCertFingerprint());

@property (nonatomic,readonly,assign,getter=signingCertFriendlyName) NSString* signingCertFriendlyName NS_SWIFT_NAME(signingCertFriendlyName);

- (NSString*)signingCertFriendlyName NS_SWIFT_NAME(signingCertFriendlyName());

@property (nonatomic,readwrite,assign,getter=signingCertHandle,setter=setSigningCertHandle:) long long signingCertHandle NS_SWIFT_NAME(signingCertHandle);

- (long long)signingCertHandle NS_SWIFT_NAME(signingCertHandle());
- (void)setSigningCertHandle :(long long)newSigningCertHandle NS_SWIFT_NAME(setSigningCertHandle(_:));

@property (nonatomic,readwrite,assign,getter=signingCertHashAlgorithm,setter=setSigningCertHashAlgorithm:) NSString* signingCertHashAlgorithm NS_SWIFT_NAME(signingCertHashAlgorithm);

- (NSString*)signingCertHashAlgorithm NS_SWIFT_NAME(signingCertHashAlgorithm());
- (void)setSigningCertHashAlgorithm :(NSString*)newSigningCertHashAlgorithm NS_SWIFT_NAME(setSigningCertHashAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=signingCertIssuer) NSString* signingCertIssuer NS_SWIFT_NAME(signingCertIssuer);

- (NSString*)signingCertIssuer NS_SWIFT_NAME(signingCertIssuer());

@property (nonatomic,readwrite,assign,getter=signingCertIssuerRDN,setter=setSigningCertIssuerRDN:) NSString* signingCertIssuerRDN NS_SWIFT_NAME(signingCertIssuerRDN);

- (NSString*)signingCertIssuerRDN NS_SWIFT_NAME(signingCertIssuerRDN());
- (void)setSigningCertIssuerRDN :(NSString*)newSigningCertIssuerRDN NS_SWIFT_NAME(setSigningCertIssuerRDN(_:));

@property (nonatomic,readwrite,assign,getter=signingCertKeyAlgorithm,setter=setSigningCertKeyAlgorithm:) NSString* signingCertKeyAlgorithm NS_SWIFT_NAME(signingCertKeyAlgorithm);

- (NSString*)signingCertKeyAlgorithm NS_SWIFT_NAME(signingCertKeyAlgorithm());
- (void)setSigningCertKeyAlgorithm :(NSString*)newSigningCertKeyAlgorithm NS_SWIFT_NAME(setSigningCertKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=signingCertKeyBits) int signingCertKeyBits NS_SWIFT_NAME(signingCertKeyBits);

- (int)signingCertKeyBits NS_SWIFT_NAME(signingCertKeyBits());

@property (nonatomic,readonly,assign,getter=signingCertKeyFingerprint) NSString* signingCertKeyFingerprint NS_SWIFT_NAME(signingCertKeyFingerprint);

- (NSString*)signingCertKeyFingerprint NS_SWIFT_NAME(signingCertKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=signingCertKeyUsage,setter=setSigningCertKeyUsage:) int signingCertKeyUsage NS_SWIFT_NAME(signingCertKeyUsage);

- (int)signingCertKeyUsage NS_SWIFT_NAME(signingCertKeyUsage());
- (void)setSigningCertKeyUsage :(int)newSigningCertKeyUsage NS_SWIFT_NAME(setSigningCertKeyUsage(_:));

@property (nonatomic,readonly,assign,getter=signingCertKeyValid) BOOL signingCertKeyValid NS_SWIFT_NAME(signingCertKeyValid);

- (BOOL)signingCertKeyValid NS_SWIFT_NAME(signingCertKeyValid());

@property (nonatomic,readwrite,assign,getter=signingCertOCSPLocations,setter=setSigningCertOCSPLocations:) NSString* signingCertOCSPLocations NS_SWIFT_NAME(signingCertOCSPLocations);

- (NSString*)signingCertOCSPLocations NS_SWIFT_NAME(signingCertOCSPLocations());
- (void)setSigningCertOCSPLocations :(NSString*)newSigningCertOCSPLocations NS_SWIFT_NAME(setSigningCertOCSPLocations(_:));

@property (nonatomic,readwrite,assign,getter=signingCertOCSPNoCheck,setter=setSigningCertOCSPNoCheck:) BOOL signingCertOCSPNoCheck NS_SWIFT_NAME(signingCertOCSPNoCheck);

- (BOOL)signingCertOCSPNoCheck NS_SWIFT_NAME(signingCertOCSPNoCheck());
- (void)setSigningCertOCSPNoCheck :(BOOL)newSigningCertOCSPNoCheck NS_SWIFT_NAME(setSigningCertOCSPNoCheck(_:));

@property (nonatomic,readonly,assign,getter=signingCertOrigin) int signingCertOrigin NS_SWIFT_NAME(signingCertOrigin);

- (int)signingCertOrigin NS_SWIFT_NAME(signingCertOrigin());

@property (nonatomic,readwrite,assign,getter=signingCertPolicyIDs,setter=setSigningCertPolicyIDs:) NSString* signingCertPolicyIDs NS_SWIFT_NAME(signingCertPolicyIDs);

- (NSString*)signingCertPolicyIDs NS_SWIFT_NAME(signingCertPolicyIDs());
- (void)setSigningCertPolicyIDs :(NSString*)newSigningCertPolicyIDs NS_SWIFT_NAME(setSigningCertPolicyIDs(_:));

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyBytes) NSData* signingCertPrivateKeyBytes NS_SWIFT_NAME(signingCertPrivateKeyBytes);

- (NSData*)signingCertPrivateKeyBytes NS_SWIFT_NAME(signingCertPrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyExists) BOOL signingCertPrivateKeyExists NS_SWIFT_NAME(signingCertPrivateKeyExists);

- (BOOL)signingCertPrivateKeyExists NS_SWIFT_NAME(signingCertPrivateKeyExists());

@property (nonatomic,readonly,assign,getter=signingCertPrivateKeyExtractable) BOOL signingCertPrivateKeyExtractable NS_SWIFT_NAME(signingCertPrivateKeyExtractable);

- (BOOL)signingCertPrivateKeyExtractable NS_SWIFT_NAME(signingCertPrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=signingCertPublicKeyBytes) NSData* signingCertPublicKeyBytes NS_SWIFT_NAME(signingCertPublicKeyBytes);

- (NSData*)signingCertPublicKeyBytes NS_SWIFT_NAME(signingCertPublicKeyBytes());

@property (nonatomic,readonly,assign,getter=signingCertQualified) BOOL signingCertQualified NS_SWIFT_NAME(signingCertQualified);

- (BOOL)signingCertQualified NS_SWIFT_NAME(signingCertQualified());

@property (nonatomic,readwrite,assign,getter=signingCertQualifiedStatements,setter=setSigningCertQualifiedStatements:) int signingCertQualifiedStatements NS_SWIFT_NAME(signingCertQualifiedStatements);

- (int)signingCertQualifiedStatements NS_SWIFT_NAME(signingCertQualifiedStatements());
- (void)setSigningCertQualifiedStatements :(int)newSigningCertQualifiedStatements NS_SWIFT_NAME(setSigningCertQualifiedStatements(_:));

@property (nonatomic,readonly,assign,getter=signingCertQualifiers) NSString* signingCertQualifiers NS_SWIFT_NAME(signingCertQualifiers);

- (NSString*)signingCertQualifiers NS_SWIFT_NAME(signingCertQualifiers());

@property (nonatomic,readonly,assign,getter=signingCertSelfSigned) BOOL signingCertSelfSigned NS_SWIFT_NAME(signingCertSelfSigned);

- (BOOL)signingCertSelfSigned NS_SWIFT_NAME(signingCertSelfSigned());

@property (nonatomic,readwrite,assign,getter=signingCertSerialNumber,setter=setSigningCertSerialNumber:) NSData* signingCertSerialNumber NS_SWIFT_NAME(signingCertSerialNumber);

- (NSData*)signingCertSerialNumber NS_SWIFT_NAME(signingCertSerialNumber());
- (void)setSigningCertSerialNumber :(NSData*)newSigningCertSerialNumber NS_SWIFT_NAME(setSigningCertSerialNumber(_:));

@property (nonatomic,readonly,assign,getter=signingCertSigAlgorithm) NSString* signingCertSigAlgorithm NS_SWIFT_NAME(signingCertSigAlgorithm);

- (NSString*)signingCertSigAlgorithm NS_SWIFT_NAME(signingCertSigAlgorithm());

@property (nonatomic,readonly,assign,getter=signingCertSource) int signingCertSource NS_SWIFT_NAME(signingCertSource);

- (int)signingCertSource NS_SWIFT_NAME(signingCertSource());

@property (nonatomic,readonly,assign,getter=signingCertSubject) NSString* signingCertSubject NS_SWIFT_NAME(signingCertSubject);

- (NSString*)signingCertSubject NS_SWIFT_NAME(signingCertSubject());

@property (nonatomic,readwrite,assign,getter=signingCertSubjectAlternativeName,setter=setSigningCertSubjectAlternativeName:) NSString* signingCertSubjectAlternativeName NS_SWIFT_NAME(signingCertSubjectAlternativeName);

- (NSString*)signingCertSubjectAlternativeName NS_SWIFT_NAME(signingCertSubjectAlternativeName());
- (void)setSigningCertSubjectAlternativeName :(NSString*)newSigningCertSubjectAlternativeName NS_SWIFT_NAME(setSigningCertSubjectAlternativeName(_:));

@property (nonatomic,readwrite,assign,getter=signingCertSubjectKeyID,setter=setSigningCertSubjectKeyID:) NSData* signingCertSubjectKeyID NS_SWIFT_NAME(signingCertSubjectKeyID);

- (NSData*)signingCertSubjectKeyID NS_SWIFT_NAME(signingCertSubjectKeyID());
- (void)setSigningCertSubjectKeyID :(NSData*)newSigningCertSubjectKeyID NS_SWIFT_NAME(setSigningCertSubjectKeyID(_:));

@property (nonatomic,readwrite,assign,getter=signingCertSubjectRDN,setter=setSigningCertSubjectRDN:) NSString* signingCertSubjectRDN NS_SWIFT_NAME(signingCertSubjectRDN);

- (NSString*)signingCertSubjectRDN NS_SWIFT_NAME(signingCertSubjectRDN());
- (void)setSigningCertSubjectRDN :(NSString*)newSigningCertSubjectRDN NS_SWIFT_NAME(setSigningCertSubjectRDN(_:));

@property (nonatomic,readonly,assign,getter=signingCertValid) BOOL signingCertValid NS_SWIFT_NAME(signingCertValid);

- (BOOL)signingCertValid NS_SWIFT_NAME(signingCertValid());

@property (nonatomic,readwrite,assign,getter=signingCertValidFrom,setter=setSigningCertValidFrom:) NSString* signingCertValidFrom NS_SWIFT_NAME(signingCertValidFrom);

- (NSString*)signingCertValidFrom NS_SWIFT_NAME(signingCertValidFrom());
- (void)setSigningCertValidFrom :(NSString*)newSigningCertValidFrom NS_SWIFT_NAME(setSigningCertValidFrom(_:));

@property (nonatomic,readwrite,assign,getter=signingCertValidTo,setter=setSigningCertValidTo:) NSString* signingCertValidTo NS_SWIFT_NAME(signingCertValidTo);

- (NSString*)signingCertValidTo NS_SWIFT_NAME(signingCertValidTo());
- (void)setSigningCertValidTo :(NSString*)newSigningCertValidTo NS_SWIFT_NAME(setSigningCertValidTo(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSMode,setter=setSocketDNSMode:) int socketDNSMode NS_SWIFT_NAME(socketDNSMode);

- (int)socketDNSMode NS_SWIFT_NAME(socketDNSMode());
- (void)setSocketDNSMode :(int)newSocketDNSMode NS_SWIFT_NAME(setSocketDNSMode(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSPort,setter=setSocketDNSPort:) int socketDNSPort NS_SWIFT_NAME(socketDNSPort);

- (int)socketDNSPort NS_SWIFT_NAME(socketDNSPort());
- (void)setSocketDNSPort :(int)newSocketDNSPort NS_SWIFT_NAME(setSocketDNSPort(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSQueryTimeout,setter=setSocketDNSQueryTimeout:) int socketDNSQueryTimeout NS_SWIFT_NAME(socketDNSQueryTimeout);

- (int)socketDNSQueryTimeout NS_SWIFT_NAME(socketDNSQueryTimeout());
- (void)setSocketDNSQueryTimeout :(int)newSocketDNSQueryTimeout NS_SWIFT_NAME(setSocketDNSQueryTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSServers,setter=setSocketDNSServers:) NSString* socketDNSServers NS_SWIFT_NAME(socketDNSServers);

- (NSString*)socketDNSServers NS_SWIFT_NAME(socketDNSServers());
- (void)setSocketDNSServers :(NSString*)newSocketDNSServers NS_SWIFT_NAME(setSocketDNSServers(_:));

@property (nonatomic,readwrite,assign,getter=socketDNSTotalTimeout,setter=setSocketDNSTotalTimeout:) int socketDNSTotalTimeout NS_SWIFT_NAME(socketDNSTotalTimeout);

- (int)socketDNSTotalTimeout NS_SWIFT_NAME(socketDNSTotalTimeout());
- (void)setSocketDNSTotalTimeout :(int)newSocketDNSTotalTimeout NS_SWIFT_NAME(setSocketDNSTotalTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketIncomingSpeedLimit,setter=setSocketIncomingSpeedLimit:) int socketIncomingSpeedLimit NS_SWIFT_NAME(socketIncomingSpeedLimit);

- (int)socketIncomingSpeedLimit NS_SWIFT_NAME(socketIncomingSpeedLimit());
- (void)setSocketIncomingSpeedLimit :(int)newSocketIncomingSpeedLimit NS_SWIFT_NAME(setSocketIncomingSpeedLimit(_:));

@property (nonatomic,readwrite,assign,getter=socketLocalAddress,setter=setSocketLocalAddress:) NSString* socketLocalAddress NS_SWIFT_NAME(socketLocalAddress);

- (NSString*)socketLocalAddress NS_SWIFT_NAME(socketLocalAddress());
- (void)setSocketLocalAddress :(NSString*)newSocketLocalAddress NS_SWIFT_NAME(setSocketLocalAddress(_:));

@property (nonatomic,readwrite,assign,getter=socketLocalPort,setter=setSocketLocalPort:) int socketLocalPort NS_SWIFT_NAME(socketLocalPort);

- (int)socketLocalPort NS_SWIFT_NAME(socketLocalPort());
- (void)setSocketLocalPort :(int)newSocketLocalPort NS_SWIFT_NAME(setSocketLocalPort(_:));

@property (nonatomic,readwrite,assign,getter=socketOutgoingSpeedLimit,setter=setSocketOutgoingSpeedLimit:) int socketOutgoingSpeedLimit NS_SWIFT_NAME(socketOutgoingSpeedLimit);

- (int)socketOutgoingSpeedLimit NS_SWIFT_NAME(socketOutgoingSpeedLimit());
- (void)setSocketOutgoingSpeedLimit :(int)newSocketOutgoingSpeedLimit NS_SWIFT_NAME(setSocketOutgoingSpeedLimit(_:));

@property (nonatomic,readwrite,assign,getter=socketTimeout,setter=setSocketTimeout:) int socketTimeout NS_SWIFT_NAME(socketTimeout);

- (int)socketTimeout NS_SWIFT_NAME(socketTimeout());
- (void)setSocketTimeout :(int)newSocketTimeout NS_SWIFT_NAME(setSocketTimeout(_:));

@property (nonatomic,readwrite,assign,getter=socketUseIPv6,setter=setSocketUseIPv6:) BOOL socketUseIPv6 NS_SWIFT_NAME(socketUseIPv6);

- (BOOL)socketUseIPv6 NS_SWIFT_NAME(socketUseIPv6());
- (void)setSocketUseIPv6 :(BOOL)newSocketUseIPv6 NS_SWIFT_NAME(setSocketUseIPv6(_:));

@property (nonatomic,readwrite,assign,getter=TLSServerCertCount,setter=setTLSServerCertCount:) int TLSServerCertCount NS_SWIFT_NAME(TLSServerCertCount);

- (int)TLSServerCertCount NS_SWIFT_NAME(TLSServerCertCount());
- (void)setTLSServerCertCount :(int)newTLSServerCertCount NS_SWIFT_NAME(setTLSServerCertCount(_:));

- (NSData*)TLSServerCertBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertBytes(_:));

- (BOOL)TLSServerCertCA:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCA(_:));
- (void)setTLSServerCertCA:(int)tLSServerCertIndex :(BOOL)newTLSServerCertCA NS_SWIFT_NAME(setTLSServerCertCA(_:_:));

- (NSData*)TLSServerCertCAKeyID:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCAKeyID(_:));

- (int)TLSServerCertCertType:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCertType(_:));

- (NSString*)TLSServerCertCRLDistributionPoints:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCRLDistributionPoints(_:));
- (void)setTLSServerCertCRLDistributionPoints:(int)tLSServerCertIndex :(NSString*)newTLSServerCertCRLDistributionPoints NS_SWIFT_NAME(setTLSServerCertCRLDistributionPoints(_:_:));

- (NSString*)TLSServerCertCurve:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertCurve(_:));
- (void)setTLSServerCertCurve:(int)tLSServerCertIndex :(NSString*)newTLSServerCertCurve NS_SWIFT_NAME(setTLSServerCertCurve(_:_:));

- (NSString*)TLSServerCertFingerprint:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertFingerprint(_:));

- (NSString*)TLSServerCertFriendlyName:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertFriendlyName(_:));

- (long long)TLSServerCertHandle:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertHandle(_:));
- (void)setTLSServerCertHandle:(int)tLSServerCertIndex :(long long)newTLSServerCertHandle NS_SWIFT_NAME(setTLSServerCertHandle(_:_:));

- (NSString*)TLSServerCertHashAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertHashAlgorithm(_:));
- (void)setTLSServerCertHashAlgorithm:(int)tLSServerCertIndex :(NSString*)newTLSServerCertHashAlgorithm NS_SWIFT_NAME(setTLSServerCertHashAlgorithm(_:_:));

- (NSString*)TLSServerCertIssuer:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertIssuer(_:));

- (NSString*)TLSServerCertIssuerRDN:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertIssuerRDN(_:));
- (void)setTLSServerCertIssuerRDN:(int)tLSServerCertIndex :(NSString*)newTLSServerCertIssuerRDN NS_SWIFT_NAME(setTLSServerCertIssuerRDN(_:_:));

- (NSString*)TLSServerCertKeyAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyAlgorithm(_:));
- (void)setTLSServerCertKeyAlgorithm:(int)tLSServerCertIndex :(NSString*)newTLSServerCertKeyAlgorithm NS_SWIFT_NAME(setTLSServerCertKeyAlgorithm(_:_:));

- (int)TLSServerCertKeyBits:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyBits(_:));

- (NSString*)TLSServerCertKeyFingerprint:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyFingerprint(_:));

- (int)TLSServerCertKeyUsage:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyUsage(_:));
- (void)setTLSServerCertKeyUsage:(int)tLSServerCertIndex :(int)newTLSServerCertKeyUsage NS_SWIFT_NAME(setTLSServerCertKeyUsage(_:_:));

- (BOOL)TLSServerCertKeyValid:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertKeyValid(_:));

- (NSString*)TLSServerCertOCSPLocations:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOCSPLocations(_:));
- (void)setTLSServerCertOCSPLocations:(int)tLSServerCertIndex :(NSString*)newTLSServerCertOCSPLocations NS_SWIFT_NAME(setTLSServerCertOCSPLocations(_:_:));

- (BOOL)TLSServerCertOCSPNoCheck:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOCSPNoCheck(_:));
- (void)setTLSServerCertOCSPNoCheck:(int)tLSServerCertIndex :(BOOL)newTLSServerCertOCSPNoCheck NS_SWIFT_NAME(setTLSServerCertOCSPNoCheck(_:_:));

- (int)TLSServerCertOrigin:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertOrigin(_:));

- (NSString*)TLSServerCertPolicyIDs:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPolicyIDs(_:));
- (void)setTLSServerCertPolicyIDs:(int)tLSServerCertIndex :(NSString*)newTLSServerCertPolicyIDs NS_SWIFT_NAME(setTLSServerCertPolicyIDs(_:_:));

- (NSData*)TLSServerCertPrivateKeyBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyBytes(_:));

- (BOOL)TLSServerCertPrivateKeyExists:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyExists(_:));

- (BOOL)TLSServerCertPrivateKeyExtractable:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPrivateKeyExtractable(_:));

- (NSData*)TLSServerCertPublicKeyBytes:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertPublicKeyBytes(_:));

- (BOOL)TLSServerCertQualified:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualified(_:));

- (int)TLSServerCertQualifiedStatements:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualifiedStatements(_:));
- (void)setTLSServerCertQualifiedStatements:(int)tLSServerCertIndex :(int)newTLSServerCertQualifiedStatements NS_SWIFT_NAME(setTLSServerCertQualifiedStatements(_:_:));

- (NSString*)TLSServerCertQualifiers:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertQualifiers(_:));

- (BOOL)TLSServerCertSelfSigned:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSelfSigned(_:));

- (NSData*)TLSServerCertSerialNumber:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSerialNumber(_:));
- (void)setTLSServerCertSerialNumber:(int)tLSServerCertIndex :(NSData*)newTLSServerCertSerialNumber NS_SWIFT_NAME(setTLSServerCertSerialNumber(_:_:));

- (NSString*)TLSServerCertSigAlgorithm:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSigAlgorithm(_:));

- (int)TLSServerCertSource:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSource(_:));

- (NSString*)TLSServerCertSubject:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubject(_:));

- (NSString*)TLSServerCertSubjectAlternativeName:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectAlternativeName(_:));
- (void)setTLSServerCertSubjectAlternativeName:(int)tLSServerCertIndex :(NSString*)newTLSServerCertSubjectAlternativeName NS_SWIFT_NAME(setTLSServerCertSubjectAlternativeName(_:_:));

- (NSData*)TLSServerCertSubjectKeyID:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectKeyID(_:));
- (void)setTLSServerCertSubjectKeyID:(int)tLSServerCertIndex :(NSData*)newTLSServerCertSubjectKeyID NS_SWIFT_NAME(setTLSServerCertSubjectKeyID(_:_:));

- (NSString*)TLSServerCertSubjectRDN:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertSubjectRDN(_:));
- (void)setTLSServerCertSubjectRDN:(int)tLSServerCertIndex :(NSString*)newTLSServerCertSubjectRDN NS_SWIFT_NAME(setTLSServerCertSubjectRDN(_:_:));

- (BOOL)TLSServerCertValid:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValid(_:));

- (NSString*)TLSServerCertValidFrom:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValidFrom(_:));
- (void)setTLSServerCertValidFrom:(int)tLSServerCertIndex :(NSString*)newTLSServerCertValidFrom NS_SWIFT_NAME(setTLSServerCertValidFrom(_:_:));

- (NSString*)TLSServerCertValidTo:(int)tLSServerCertIndex NS_SWIFT_NAME(TLSServerCertValidTo(_:));
- (void)setTLSServerCertValidTo:(int)tLSServerCertIndex :(NSString*)newTLSServerCertValidTo NS_SWIFT_NAME(setTLSServerCertValidTo(_:_:));

@property (nonatomic,readwrite,assign,getter=TLSAutoValidateCertificates,setter=setTLSAutoValidateCertificates:) BOOL TLSAutoValidateCertificates NS_SWIFT_NAME(TLSAutoValidateCertificates);

- (BOOL)TLSAutoValidateCertificates NS_SWIFT_NAME(TLSAutoValidateCertificates());
- (void)setTLSAutoValidateCertificates :(BOOL)newTLSAutoValidateCertificates NS_SWIFT_NAME(setTLSAutoValidateCertificates(_:));

@property (nonatomic,readwrite,assign,getter=TLSBaseConfiguration,setter=setTLSBaseConfiguration:) int TLSBaseConfiguration NS_SWIFT_NAME(TLSBaseConfiguration);

- (int)TLSBaseConfiguration NS_SWIFT_NAME(TLSBaseConfiguration());
- (void)setTLSBaseConfiguration :(int)newTLSBaseConfiguration NS_SWIFT_NAME(setTLSBaseConfiguration(_:));

@property (nonatomic,readwrite,assign,getter=TLSCiphersuites,setter=setTLSCiphersuites:) NSString* TLSCiphersuites NS_SWIFT_NAME(TLSCiphersuites);

- (NSString*)TLSCiphersuites NS_SWIFT_NAME(TLSCiphersuites());
- (void)setTLSCiphersuites :(NSString*)newTLSCiphersuites NS_SWIFT_NAME(setTLSCiphersuites(_:));

@property (nonatomic,readwrite,assign,getter=TLSClientAuth,setter=setTLSClientAuth:) int TLSClientAuth NS_SWIFT_NAME(TLSClientAuth);

- (int)TLSClientAuth NS_SWIFT_NAME(TLSClientAuth());
- (void)setTLSClientAuth :(int)newTLSClientAuth NS_SWIFT_NAME(setTLSClientAuth(_:));

@property (nonatomic,readwrite,assign,getter=TLSECCurves,setter=setTLSECCurves:) NSString* TLSECCurves NS_SWIFT_NAME(TLSECCurves);

- (NSString*)TLSECCurves NS_SWIFT_NAME(TLSECCurves());
- (void)setTLSECCurves :(NSString*)newTLSECCurves NS_SWIFT_NAME(setTLSECCurves(_:));

@property (nonatomic,readwrite,assign,getter=TLSExtensions,setter=setTLSExtensions:) NSString* TLSExtensions NS_SWIFT_NAME(TLSExtensions);

- (NSString*)TLSExtensions NS_SWIFT_NAME(TLSExtensions());
- (void)setTLSExtensions :(NSString*)newTLSExtensions NS_SWIFT_NAME(setTLSExtensions(_:));

@property (nonatomic,readwrite,assign,getter=TLSForceResumeIfDestinationChanges,setter=setTLSForceResumeIfDestinationChanges:) BOOL TLSForceResumeIfDestinationChanges NS_SWIFT_NAME(TLSForceResumeIfDestinationChanges);

- (BOOL)TLSForceResumeIfDestinationChanges NS_SWIFT_NAME(TLSForceResumeIfDestinationChanges());
- (void)setTLSForceResumeIfDestinationChanges :(BOOL)newTLSForceResumeIfDestinationChanges NS_SWIFT_NAME(setTLSForceResumeIfDestinationChanges(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedIdentity,setter=setTLSPreSharedIdentity:) NSString* TLSPreSharedIdentity NS_SWIFT_NAME(TLSPreSharedIdentity);

- (NSString*)TLSPreSharedIdentity NS_SWIFT_NAME(TLSPreSharedIdentity());
- (void)setTLSPreSharedIdentity :(NSString*)newTLSPreSharedIdentity NS_SWIFT_NAME(setTLSPreSharedIdentity(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedKey,setter=setTLSPreSharedKey:) NSString* TLSPreSharedKey NS_SWIFT_NAME(TLSPreSharedKey);

- (NSString*)TLSPreSharedKey NS_SWIFT_NAME(TLSPreSharedKey());
- (void)setTLSPreSharedKey :(NSString*)newTLSPreSharedKey NS_SWIFT_NAME(setTLSPreSharedKey(_:));

@property (nonatomic,readwrite,assign,getter=TLSPreSharedKeyCiphersuite,setter=setTLSPreSharedKeyCiphersuite:) NSString* TLSPreSharedKeyCiphersuite NS_SWIFT_NAME(TLSPreSharedKeyCiphersuite);

- (NSString*)TLSPreSharedKeyCiphersuite NS_SWIFT_NAME(TLSPreSharedKeyCiphersuite());
- (void)setTLSPreSharedKeyCiphersuite :(NSString*)newTLSPreSharedKeyCiphersuite NS_SWIFT_NAME(setTLSPreSharedKeyCiphersuite(_:));

@property (nonatomic,readwrite,assign,getter=TLSRenegotiationAttackPreventionMode,setter=setTLSRenegotiationAttackPreventionMode:) int TLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(TLSRenegotiationAttackPreventionMode);

- (int)TLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(TLSRenegotiationAttackPreventionMode());
- (void)setTLSRenegotiationAttackPreventionMode :(int)newTLSRenegotiationAttackPreventionMode NS_SWIFT_NAME(setTLSRenegotiationAttackPreventionMode(_:));

@property (nonatomic,readwrite,assign,getter=TLSRevocationCheck,setter=setTLSRevocationCheck:) int TLSRevocationCheck NS_SWIFT_NAME(TLSRevocationCheck);

- (int)TLSRevocationCheck NS_SWIFT_NAME(TLSRevocationCheck());
- (void)setTLSRevocationCheck :(int)newTLSRevocationCheck NS_SWIFT_NAME(setTLSRevocationCheck(_:));

@property (nonatomic,readwrite,assign,getter=TLSSSLOptions,setter=setTLSSSLOptions:) int TLSSSLOptions NS_SWIFT_NAME(TLSSSLOptions);

- (int)TLSSSLOptions NS_SWIFT_NAME(TLSSSLOptions());
- (void)setTLSSSLOptions :(int)newTLSSSLOptions NS_SWIFT_NAME(setTLSSSLOptions(_:));

@property (nonatomic,readwrite,assign,getter=TLSTLSMode,setter=setTLSTLSMode:) int TLSTLSMode NS_SWIFT_NAME(TLSTLSMode);

- (int)TLSTLSMode NS_SWIFT_NAME(TLSTLSMode());
- (void)setTLSTLSMode :(int)newTLSTLSMode NS_SWIFT_NAME(setTLSTLSMode(_:));

@property (nonatomic,readwrite,assign,getter=TLSUseExtendedMasterSecret,setter=setTLSUseExtendedMasterSecret:) BOOL TLSUseExtendedMasterSecret NS_SWIFT_NAME(TLSUseExtendedMasterSecret);

- (BOOL)TLSUseExtendedMasterSecret NS_SWIFT_NAME(TLSUseExtendedMasterSecret());
- (void)setTLSUseExtendedMasterSecret :(BOOL)newTLSUseExtendedMasterSecret NS_SWIFT_NAME(setTLSUseExtendedMasterSecret(_:));

@property (nonatomic,readwrite,assign,getter=TLSUseSessionResumption,setter=setTLSUseSessionResumption:) BOOL TLSUseSessionResumption NS_SWIFT_NAME(TLSUseSessionResumption);

- (BOOL)TLSUseSessionResumption NS_SWIFT_NAME(TLSUseSessionResumption());
- (void)setTLSUseSessionResumption :(BOOL)newTLSUseSessionResumption NS_SWIFT_NAME(setTLSUseSessionResumption(_:));

@property (nonatomic,readwrite,assign,getter=TLSVersions,setter=setTLSVersions:) int TLSVersions NS_SWIFT_NAME(TLSVersions);

- (int)TLSVersions NS_SWIFT_NAME(TLSVersions());
- (void)setTLSVersions :(int)newTLSVersions NS_SWIFT_NAME(setTLSVersions(_:));

@property (nonatomic,readwrite,assign,getter=updatePeriod,setter=setUpdatePeriod:) int updatePeriod NS_SWIFT_NAME(updatePeriod);

- (int)updatePeriod NS_SWIFT_NAME(updatePeriod());
- (void)setUpdatePeriod :(int)newUpdatePeriod NS_SWIFT_NAME(setUpdatePeriod(_:));

@property (nonatomic,readwrite,assign,getter=userCount,setter=setUserCount:) int userCount NS_SWIFT_NAME(userCount);

- (int)userCount NS_SWIFT_NAME(userCount());
- (void)setUserCount :(int)newUserCount NS_SWIFT_NAME(setUserCount(_:));

- (NSData*)userAssociatedData:(int)userIndex NS_SWIFT_NAME(userAssociatedData(_:));
- (void)setUserAssociatedData:(int)userIndex :(NSData*)newUserAssociatedData NS_SWIFT_NAME(setUserAssociatedData(_:_:));

- (NSString*)userBasePath:(int)userIndex NS_SWIFT_NAME(userBasePath(_:));
- (void)setUserBasePath:(int)userIndex :(NSString*)newUserBasePath NS_SWIFT_NAME(setUserBasePath(_:_:));

- (NSData*)userCertificate:(int)userIndex NS_SWIFT_NAME(userCertificate(_:));
- (void)setUserCertificate:(int)userIndex :(NSData*)newUserCertificate NS_SWIFT_NAME(setUserCertificate(_:_:));

- (NSString*)userData:(int)userIndex NS_SWIFT_NAME(userData(_:));
- (void)setUserData:(int)userIndex :(NSString*)newUserData NS_SWIFT_NAME(setUserData(_:_:));

- (NSString*)userEmail:(int)userIndex NS_SWIFT_NAME(userEmail(_:));
- (void)setUserEmail:(int)userIndex :(NSString*)newUserEmail NS_SWIFT_NAME(setUserEmail(_:_:));

- (long long)userHandle:(int)userIndex NS_SWIFT_NAME(userHandle(_:));
- (void)setUserHandle:(int)userIndex :(long long)newUserHandle NS_SWIFT_NAME(setUserHandle(_:_:));

- (NSString*)userHashAlgorithm:(int)userIndex NS_SWIFT_NAME(userHashAlgorithm(_:));
- (void)setUserHashAlgorithm:(int)userIndex :(NSString*)newUserHashAlgorithm NS_SWIFT_NAME(setUserHashAlgorithm(_:_:));

- (int)userIncomingSpeedLimit:(int)userIndex NS_SWIFT_NAME(userIncomingSpeedLimit(_:));
- (void)setUserIncomingSpeedLimit:(int)userIndex :(int)newUserIncomingSpeedLimit NS_SWIFT_NAME(setUserIncomingSpeedLimit(_:_:));

- (int)userOtpAlgorithm:(int)userIndex NS_SWIFT_NAME(userOtpAlgorithm(_:));
- (void)setUserOtpAlgorithm:(int)userIndex :(int)newUserOtpAlgorithm NS_SWIFT_NAME(setUserOtpAlgorithm(_:_:));

- (int)userOTPLen:(int)userIndex NS_SWIFT_NAME(userOTPLen(_:));
- (void)setUserOTPLen:(int)userIndex :(int)newUserOTPLen NS_SWIFT_NAME(setUserOTPLen(_:_:));

- (int)userOtpValue:(int)userIndex NS_SWIFT_NAME(userOtpValue(_:));
- (void)setUserOtpValue:(int)userIndex :(int)newUserOtpValue NS_SWIFT_NAME(setUserOtpValue(_:_:));

- (int)userOutgoingSpeedLimit:(int)userIndex NS_SWIFT_NAME(userOutgoingSpeedLimit(_:));
- (void)setUserOutgoingSpeedLimit:(int)userIndex :(int)newUserOutgoingSpeedLimit NS_SWIFT_NAME(setUserOutgoingSpeedLimit(_:_:));

- (NSString*)userPassword:(int)userIndex NS_SWIFT_NAME(userPassword(_:));
- (void)setUserPassword:(int)userIndex :(NSString*)newUserPassword NS_SWIFT_NAME(setUserPassword(_:_:));

- (NSData*)userSharedSecret:(int)userIndex NS_SWIFT_NAME(userSharedSecret(_:));
- (void)setUserSharedSecret:(int)userIndex :(NSData*)newUserSharedSecret NS_SWIFT_NAME(setUserSharedSecret(_:_:));

- (NSData*)userSSHKey:(int)userIndex NS_SWIFT_NAME(userSSHKey(_:));
- (void)setUserSSHKey:(int)userIndex :(NSData*)newUserSSHKey NS_SWIFT_NAME(setUserSSHKey(_:_:));

- (NSString*)userUsername:(int)userIndex NS_SWIFT_NAME(userUsername(_:));
- (void)setUserUsername:(int)userIndex :(NSString*)newUserUsername NS_SWIFT_NAME(setUserUsername(_:_:));

@property (nonatomic,readwrite,assign,getter=websiteName,setter=setWebsiteName:) NSString* websiteName NS_SWIFT_NAME(websiteName);

- (NSString*)websiteName NS_SWIFT_NAME(websiteName());
- (void)setWebsiteName :(NSString*)newWebsiteName NS_SWIFT_NAME(setWebsiteName(_:));

  /* Methods */

- (void)cleanup NS_SWIFT_NAME(cleanup());

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (void)dropClient:(long long)connectionId :(BOOL)forced NS_SWIFT_NAME(dropClient(_:_:));

- (NSData*)getRequestBytes:(long long)connectionId NS_SWIFT_NAME(getRequestBytes(_:));

- (NSString*)getRequestHeader:(long long)connectionId :(NSString*)headerName NS_SWIFT_NAME(getRequestHeader(_:_:));

- (NSString*)getRequestString:(long long)connectionId NS_SWIFT_NAME(getRequestString(_:));

- (NSString*)getRequestUsername:(long long)connectionId NS_SWIFT_NAME(getRequestUsername(_:));

- (void)importBadCertificates NS_SWIFT_NAME(importBadCertificates());

- (void)importGoodCertificates NS_SWIFT_NAME(importGoodCertificates());

- (NSString*)listClients NS_SWIFT_NAME(listClients());

- (void)pinClient:(long long)connectionId NS_SWIFT_NAME(pinClient(_:));

- (NSData*)processGenericRequest:(NSData*)requestBytes :(BOOL)basicOnly NS_SWIFT_NAME(processGenericRequest(_:_:));

- (void)reset NS_SWIFT_NAME(reset());

- (void)start NS_SWIFT_NAME(start());

- (void)stop NS_SWIFT_NAME(stop());

@end

