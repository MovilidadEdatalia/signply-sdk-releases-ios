/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//PDFENCRYPTIONTYPES
#define PET_NONE                                           0

#define PET_PASSWORD                                       1

#define PET_CERTIFICATE                                    2

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxPDFEncryptorDelegate <NSObject>
@optional
- (void)onDocumentLoaded:(int*)cancel NS_SWIFT_NAME(onDocumentLoaded(_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

@end

@interface SecureBlackboxPDFEncryptor : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxPDFEncryptorDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasDocumentLoaded;

  BOOL m_delegateHasError;

  BOOL m_delegateHasNotification;

}

+ (SecureBlackboxPDFEncryptor*)pdfencryptor;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxPDFEncryptorDelegate> delegate;
- (id <SecureBlackboxPDFEncryptorDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxPDFEncryptorDelegate>)anObject;

  /* Events */

- (void)onDocumentLoaded:(int*)cancel NS_SWIFT_NAME(onDocumentLoaded(_:));

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readonly,assign,getter=documentInfoEncryptionAlgorithm) NSString* documentInfoEncryptionAlgorithm NS_SWIFT_NAME(documentInfoEncryptionAlgorithm);

- (NSString*)documentInfoEncryptionAlgorithm NS_SWIFT_NAME(documentInfoEncryptionAlgorithm());

@property (nonatomic,readonly,assign,getter=documentInfoEncryptionType) int documentInfoEncryptionType NS_SWIFT_NAME(documentInfoEncryptionType);

- (int)documentInfoEncryptionType NS_SWIFT_NAME(documentInfoEncryptionType());

@property (nonatomic,readonly,assign,getter=documentInfoMetadataEncrypted) BOOL documentInfoMetadataEncrypted NS_SWIFT_NAME(documentInfoMetadataEncrypted);

- (BOOL)documentInfoMetadataEncrypted NS_SWIFT_NAME(documentInfoMetadataEncrypted());

@property (nonatomic,readonly,assign,getter=documentInfoPermissions) int documentInfoPermissions NS_SWIFT_NAME(documentInfoPermissions);

- (int)documentInfoPermissions NS_SWIFT_NAME(documentInfoPermissions());

@property (nonatomic,readwrite,assign,getter=encryptionAlgorithm,setter=setEncryptionAlgorithm:) NSString* encryptionAlgorithm NS_SWIFT_NAME(encryptionAlgorithm);

- (NSString*)encryptionAlgorithm NS_SWIFT_NAME(encryptionAlgorithm());
- (void)setEncryptionAlgorithm :(NSString*)newEncryptionAlgorithm NS_SWIFT_NAME(setEncryptionAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertificateBytes) NSData* encryptionCertificateBytes NS_SWIFT_NAME(encryptionCertificateBytes);

- (NSData*)encryptionCertificateBytes NS_SWIFT_NAME(encryptionCertificateBytes());

@property (nonatomic,readwrite,assign,getter=encryptionCertificateCA,setter=setEncryptionCertificateCA:) BOOL encryptionCertificateCA NS_SWIFT_NAME(encryptionCertificateCA);

- (BOOL)encryptionCertificateCA NS_SWIFT_NAME(encryptionCertificateCA());
- (void)setEncryptionCertificateCA :(BOOL)newEncryptionCertificateCA NS_SWIFT_NAME(setEncryptionCertificateCA(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertificateCAKeyID) NSData* encryptionCertificateCAKeyID NS_SWIFT_NAME(encryptionCertificateCAKeyID);

- (NSData*)encryptionCertificateCAKeyID NS_SWIFT_NAME(encryptionCertificateCAKeyID());

@property (nonatomic,readonly,assign,getter=encryptionCertificateCertType) int encryptionCertificateCertType NS_SWIFT_NAME(encryptionCertificateCertType);

- (int)encryptionCertificateCertType NS_SWIFT_NAME(encryptionCertificateCertType());

@property (nonatomic,readwrite,assign,getter=encryptionCertificateCRLDistributionPoints,setter=setEncryptionCertificateCRLDistributionPoints:) NSString* encryptionCertificateCRLDistributionPoints NS_SWIFT_NAME(encryptionCertificateCRLDistributionPoints);

- (NSString*)encryptionCertificateCRLDistributionPoints NS_SWIFT_NAME(encryptionCertificateCRLDistributionPoints());
- (void)setEncryptionCertificateCRLDistributionPoints :(NSString*)newEncryptionCertificateCRLDistributionPoints NS_SWIFT_NAME(setEncryptionCertificateCRLDistributionPoints(_:));

@property (nonatomic,readwrite,assign,getter=encryptionCertificateCurve,setter=setEncryptionCertificateCurve:) NSString* encryptionCertificateCurve NS_SWIFT_NAME(encryptionCertificateCurve);

- (NSString*)encryptionCertificateCurve NS_SWIFT_NAME(encryptionCertificateCurve());
- (void)setEncryptionCertificateCurve :(NSString*)newEncryptionCertificateCurve NS_SWIFT_NAME(setEncryptionCertificateCurve(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertificateFingerprint) NSString* encryptionCertificateFingerprint NS_SWIFT_NAME(encryptionCertificateFingerprint);

- (NSString*)encryptionCertificateFingerprint NS_SWIFT_NAME(encryptionCertificateFingerprint());

@property (nonatomic,readonly,assign,getter=encryptionCertificateFriendlyName) NSString* encryptionCertificateFriendlyName NS_SWIFT_NAME(encryptionCertificateFriendlyName);

- (NSString*)encryptionCertificateFriendlyName NS_SWIFT_NAME(encryptionCertificateFriendlyName());

@property (nonatomic,readwrite,assign,getter=encryptionCertificateHandle,setter=setEncryptionCertificateHandle:) long long encryptionCertificateHandle NS_SWIFT_NAME(encryptionCertificateHandle);

- (long long)encryptionCertificateHandle NS_SWIFT_NAME(encryptionCertificateHandle());
- (void)setEncryptionCertificateHandle :(long long)newEncryptionCertificateHandle NS_SWIFT_NAME(setEncryptionCertificateHandle(_:));

@property (nonatomic,readwrite,assign,getter=encryptionCertificateHashAlgorithm,setter=setEncryptionCertificateHashAlgorithm:) NSString* encryptionCertificateHashAlgorithm NS_SWIFT_NAME(encryptionCertificateHashAlgorithm);

- (NSString*)encryptionCertificateHashAlgorithm NS_SWIFT_NAME(encryptionCertificateHashAlgorithm());
- (void)setEncryptionCertificateHashAlgorithm :(NSString*)newEncryptionCertificateHashAlgorithm NS_SWIFT_NAME(setEncryptionCertificateHashAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertificateIssuer) NSString* encryptionCertificateIssuer NS_SWIFT_NAME(encryptionCertificateIssuer);

- (NSString*)encryptionCertificateIssuer NS_SWIFT_NAME(encryptionCertificateIssuer());

@property (nonatomic,readwrite,assign,getter=encryptionCertificateIssuerRDN,setter=setEncryptionCertificateIssuerRDN:) NSString* encryptionCertificateIssuerRDN NS_SWIFT_NAME(encryptionCertificateIssuerRDN);

- (NSString*)encryptionCertificateIssuerRDN NS_SWIFT_NAME(encryptionCertificateIssuerRDN());
- (void)setEncryptionCertificateIssuerRDN :(NSString*)newEncryptionCertificateIssuerRDN NS_SWIFT_NAME(setEncryptionCertificateIssuerRDN(_:));

@property (nonatomic,readwrite,assign,getter=encryptionCertificateKeyAlgorithm,setter=setEncryptionCertificateKeyAlgorithm:) NSString* encryptionCertificateKeyAlgorithm NS_SWIFT_NAME(encryptionCertificateKeyAlgorithm);

- (NSString*)encryptionCertificateKeyAlgorithm NS_SWIFT_NAME(encryptionCertificateKeyAlgorithm());
- (void)setEncryptionCertificateKeyAlgorithm :(NSString*)newEncryptionCertificateKeyAlgorithm NS_SWIFT_NAME(setEncryptionCertificateKeyAlgorithm(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertificateKeyBits) int encryptionCertificateKeyBits NS_SWIFT_NAME(encryptionCertificateKeyBits);

- (int)encryptionCertificateKeyBits NS_SWIFT_NAME(encryptionCertificateKeyBits());

@property (nonatomic,readonly,assign,getter=encryptionCertificateKeyFingerprint) NSString* encryptionCertificateKeyFingerprint NS_SWIFT_NAME(encryptionCertificateKeyFingerprint);

- (NSString*)encryptionCertificateKeyFingerprint NS_SWIFT_NAME(encryptionCertificateKeyFingerprint());

@property (nonatomic,readwrite,assign,getter=encryptionCertificateKeyUsage,setter=setEncryptionCertificateKeyUsage:) int encryptionCertificateKeyUsage NS_SWIFT_NAME(encryptionCertificateKeyUsage);

- (int)encryptionCertificateKeyUsage NS_SWIFT_NAME(encryptionCertificateKeyUsage());
- (void)setEncryptionCertificateKeyUsage :(int)newEncryptionCertificateKeyUsage NS_SWIFT_NAME(setEncryptionCertificateKeyUsage(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertificateKeyValid) BOOL encryptionCertificateKeyValid NS_SWIFT_NAME(encryptionCertificateKeyValid);

- (BOOL)encryptionCertificateKeyValid NS_SWIFT_NAME(encryptionCertificateKeyValid());

@property (nonatomic,readwrite,assign,getter=encryptionCertificateOCSPLocations,setter=setEncryptionCertificateOCSPLocations:) NSString* encryptionCertificateOCSPLocations NS_SWIFT_NAME(encryptionCertificateOCSPLocations);

- (NSString*)encryptionCertificateOCSPLocations NS_SWIFT_NAME(encryptionCertificateOCSPLocations());
- (void)setEncryptionCertificateOCSPLocations :(NSString*)newEncryptionCertificateOCSPLocations NS_SWIFT_NAME(setEncryptionCertificateOCSPLocations(_:));

@property (nonatomic,readwrite,assign,getter=encryptionCertificateOCSPNoCheck,setter=setEncryptionCertificateOCSPNoCheck:) BOOL encryptionCertificateOCSPNoCheck NS_SWIFT_NAME(encryptionCertificateOCSPNoCheck);

- (BOOL)encryptionCertificateOCSPNoCheck NS_SWIFT_NAME(encryptionCertificateOCSPNoCheck());
- (void)setEncryptionCertificateOCSPNoCheck :(BOOL)newEncryptionCertificateOCSPNoCheck NS_SWIFT_NAME(setEncryptionCertificateOCSPNoCheck(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertificateOrigin) int encryptionCertificateOrigin NS_SWIFT_NAME(encryptionCertificateOrigin);

- (int)encryptionCertificateOrigin NS_SWIFT_NAME(encryptionCertificateOrigin());

@property (nonatomic,readwrite,assign,getter=encryptionCertificatePolicyIDs,setter=setEncryptionCertificatePolicyIDs:) NSString* encryptionCertificatePolicyIDs NS_SWIFT_NAME(encryptionCertificatePolicyIDs);

- (NSString*)encryptionCertificatePolicyIDs NS_SWIFT_NAME(encryptionCertificatePolicyIDs());
- (void)setEncryptionCertificatePolicyIDs :(NSString*)newEncryptionCertificatePolicyIDs NS_SWIFT_NAME(setEncryptionCertificatePolicyIDs(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertificatePrivateKeyBytes) NSData* encryptionCertificatePrivateKeyBytes NS_SWIFT_NAME(encryptionCertificatePrivateKeyBytes);

- (NSData*)encryptionCertificatePrivateKeyBytes NS_SWIFT_NAME(encryptionCertificatePrivateKeyBytes());

@property (nonatomic,readonly,assign,getter=encryptionCertificatePrivateKeyExists) BOOL encryptionCertificatePrivateKeyExists NS_SWIFT_NAME(encryptionCertificatePrivateKeyExists);

- (BOOL)encryptionCertificatePrivateKeyExists NS_SWIFT_NAME(encryptionCertificatePrivateKeyExists());

@property (nonatomic,readonly,assign,getter=encryptionCertificatePrivateKeyExtractable) BOOL encryptionCertificatePrivateKeyExtractable NS_SWIFT_NAME(encryptionCertificatePrivateKeyExtractable);

- (BOOL)encryptionCertificatePrivateKeyExtractable NS_SWIFT_NAME(encryptionCertificatePrivateKeyExtractable());

@property (nonatomic,readonly,assign,getter=encryptionCertificatePublicKeyBytes) NSData* encryptionCertificatePublicKeyBytes NS_SWIFT_NAME(encryptionCertificatePublicKeyBytes);

- (NSData*)encryptionCertificatePublicKeyBytes NS_SWIFT_NAME(encryptionCertificatePublicKeyBytes());

@property (nonatomic,readonly,assign,getter=encryptionCertificateQualified) BOOL encryptionCertificateQualified NS_SWIFT_NAME(encryptionCertificateQualified);

- (BOOL)encryptionCertificateQualified NS_SWIFT_NAME(encryptionCertificateQualified());

@property (nonatomic,readwrite,assign,getter=encryptionCertificateQualifiedStatements,setter=setEncryptionCertificateQualifiedStatements:) int encryptionCertificateQualifiedStatements NS_SWIFT_NAME(encryptionCertificateQualifiedStatements);

- (int)encryptionCertificateQualifiedStatements NS_SWIFT_NAME(encryptionCertificateQualifiedStatements());
- (void)setEncryptionCertificateQualifiedStatements :(int)newEncryptionCertificateQualifiedStatements NS_SWIFT_NAME(setEncryptionCertificateQualifiedStatements(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertificateQualifiers) NSString* encryptionCertificateQualifiers NS_SWIFT_NAME(encryptionCertificateQualifiers);

- (NSString*)encryptionCertificateQualifiers NS_SWIFT_NAME(encryptionCertificateQualifiers());

@property (nonatomic,readonly,assign,getter=encryptionCertificateSelfSigned) BOOL encryptionCertificateSelfSigned NS_SWIFT_NAME(encryptionCertificateSelfSigned);

- (BOOL)encryptionCertificateSelfSigned NS_SWIFT_NAME(encryptionCertificateSelfSigned());

@property (nonatomic,readwrite,assign,getter=encryptionCertificateSerialNumber,setter=setEncryptionCertificateSerialNumber:) NSData* encryptionCertificateSerialNumber NS_SWIFT_NAME(encryptionCertificateSerialNumber);

- (NSData*)encryptionCertificateSerialNumber NS_SWIFT_NAME(encryptionCertificateSerialNumber());
- (void)setEncryptionCertificateSerialNumber :(NSData*)newEncryptionCertificateSerialNumber NS_SWIFT_NAME(setEncryptionCertificateSerialNumber(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertificateSigAlgorithm) NSString* encryptionCertificateSigAlgorithm NS_SWIFT_NAME(encryptionCertificateSigAlgorithm);

- (NSString*)encryptionCertificateSigAlgorithm NS_SWIFT_NAME(encryptionCertificateSigAlgorithm());

@property (nonatomic,readonly,assign,getter=encryptionCertificateSource) int encryptionCertificateSource NS_SWIFT_NAME(encryptionCertificateSource);

- (int)encryptionCertificateSource NS_SWIFT_NAME(encryptionCertificateSource());

@property (nonatomic,readonly,assign,getter=encryptionCertificateSubject) NSString* encryptionCertificateSubject NS_SWIFT_NAME(encryptionCertificateSubject);

- (NSString*)encryptionCertificateSubject NS_SWIFT_NAME(encryptionCertificateSubject());

@property (nonatomic,readwrite,assign,getter=encryptionCertificateSubjectAlternativeName,setter=setEncryptionCertificateSubjectAlternativeName:) NSString* encryptionCertificateSubjectAlternativeName NS_SWIFT_NAME(encryptionCertificateSubjectAlternativeName);

- (NSString*)encryptionCertificateSubjectAlternativeName NS_SWIFT_NAME(encryptionCertificateSubjectAlternativeName());
- (void)setEncryptionCertificateSubjectAlternativeName :(NSString*)newEncryptionCertificateSubjectAlternativeName NS_SWIFT_NAME(setEncryptionCertificateSubjectAlternativeName(_:));

@property (nonatomic,readwrite,assign,getter=encryptionCertificateSubjectKeyID,setter=setEncryptionCertificateSubjectKeyID:) NSData* encryptionCertificateSubjectKeyID NS_SWIFT_NAME(encryptionCertificateSubjectKeyID);

- (NSData*)encryptionCertificateSubjectKeyID NS_SWIFT_NAME(encryptionCertificateSubjectKeyID());
- (void)setEncryptionCertificateSubjectKeyID :(NSData*)newEncryptionCertificateSubjectKeyID NS_SWIFT_NAME(setEncryptionCertificateSubjectKeyID(_:));

@property (nonatomic,readwrite,assign,getter=encryptionCertificateSubjectRDN,setter=setEncryptionCertificateSubjectRDN:) NSString* encryptionCertificateSubjectRDN NS_SWIFT_NAME(encryptionCertificateSubjectRDN);

- (NSString*)encryptionCertificateSubjectRDN NS_SWIFT_NAME(encryptionCertificateSubjectRDN());
- (void)setEncryptionCertificateSubjectRDN :(NSString*)newEncryptionCertificateSubjectRDN NS_SWIFT_NAME(setEncryptionCertificateSubjectRDN(_:));

@property (nonatomic,readonly,assign,getter=encryptionCertificateValid) BOOL encryptionCertificateValid NS_SWIFT_NAME(encryptionCertificateValid);

- (BOOL)encryptionCertificateValid NS_SWIFT_NAME(encryptionCertificateValid());

@property (nonatomic,readwrite,assign,getter=encryptionCertificateValidFrom,setter=setEncryptionCertificateValidFrom:) NSString* encryptionCertificateValidFrom NS_SWIFT_NAME(encryptionCertificateValidFrom);

- (NSString*)encryptionCertificateValidFrom NS_SWIFT_NAME(encryptionCertificateValidFrom());
- (void)setEncryptionCertificateValidFrom :(NSString*)newEncryptionCertificateValidFrom NS_SWIFT_NAME(setEncryptionCertificateValidFrom(_:));

@property (nonatomic,readwrite,assign,getter=encryptionCertificateValidTo,setter=setEncryptionCertificateValidTo:) NSString* encryptionCertificateValidTo NS_SWIFT_NAME(encryptionCertificateValidTo);

- (NSString*)encryptionCertificateValidTo NS_SWIFT_NAME(encryptionCertificateValidTo());
- (void)setEncryptionCertificateValidTo :(NSString*)newEncryptionCertificateValidTo NS_SWIFT_NAME(setEncryptionCertificateValidTo(_:));

@property (nonatomic,readwrite,assign,getter=encryptMetadata,setter=setEncryptMetadata:) BOOL encryptMetadata NS_SWIFT_NAME(encryptMetadata);

- (BOOL)encryptMetadata NS_SWIFT_NAME(encryptMetadata());
- (void)setEncryptMetadata :(BOOL)newEncryptMetadata NS_SWIFT_NAME(setEncryptMetadata(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=inputBytes,setter=setInputBytes:) NSData* inputBytes NS_SWIFT_NAME(inputBytes);

- (NSData*)inputBytes NS_SWIFT_NAME(inputBytes());
- (void)setInputBytes :(NSData*)newInputBytes NS_SWIFT_NAME(setInputBytes(_:));

@property (nonatomic,readwrite,assign,getter=inputFile,setter=setInputFile:) NSString* inputFile NS_SWIFT_NAME(inputFile);

- (NSString*)inputFile NS_SWIFT_NAME(inputFile());
- (void)setInputFile :(NSString*)newInputFile NS_SWIFT_NAME(setInputFile(_:));

@property (nonatomic,readonly,assign,getter=outputBytes) NSData* outputBytes NS_SWIFT_NAME(outputBytes);

- (NSData*)outputBytes NS_SWIFT_NAME(outputBytes());

@property (nonatomic,readwrite,assign,getter=outputFile,setter=setOutputFile:) NSString* outputFile NS_SWIFT_NAME(outputFile);

- (NSString*)outputFile NS_SWIFT_NAME(outputFile());
- (void)setOutputFile :(NSString*)newOutputFile NS_SWIFT_NAME(setOutputFile(_:));

@property (nonatomic,readwrite,assign,getter=ownerPassword,setter=setOwnerPassword:) NSString* ownerPassword NS_SWIFT_NAME(ownerPassword);

- (NSString*)ownerPassword NS_SWIFT_NAME(ownerPassword());
- (void)setOwnerPassword :(NSString*)newOwnerPassword NS_SWIFT_NAME(setOwnerPassword(_:));

@property (nonatomic,readwrite,assign,getter=permissions,setter=setPermissions:) int permissions NS_SWIFT_NAME(permissions);

- (int)permissions NS_SWIFT_NAME(permissions());
- (void)setPermissions :(int)newPermissions NS_SWIFT_NAME(setPermissions(_:));

@property (nonatomic,readwrite,assign,getter=userPassword,setter=setUserPassword:) NSString* userPassword NS_SWIFT_NAME(userPassword);

- (NSString*)userPassword NS_SWIFT_NAME(userPassword());
- (void)setUserPassword :(NSString*)newUserPassword NS_SWIFT_NAME(setUserPassword(_:));

  /* Methods */

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (void)encrypt NS_SWIFT_NAME(encrypt());

- (void)reset NS_SWIFT_NAME(reset());

@end

