/***********************************************************************
  SecureBlackbox 2024 for macOS and iOS
  Copyright (c) 2024 /n software inc.
************************************************************************/

#import <Foundation/Foundation.h>


#import "SecureBlackboxConstants.h"

//CERTTYPES
#define CT_UNKNOWN                                         0

#define CT_X509CERTIFICATE                                 1

#define CT_X509CERTIFICATE_REQUEST                         2

//QUALIFIEDSTATEMENTSTYPES
#define QST_NON_QUALIFIED                                  0

#define QST_QUALIFIED_HARDWARE                             1

#define QST_QUALIFIED_SOFTWARE                             2

//PKISOURCES
#define PKS_UNKNOWN                                        0

#define PKS_SIGNATURE                                      1

#define PKS_DOCUMENT                                       2

#define PKS_USER                                           3

#define PKS_LOCAL                                          4

#define PKS_ONLINE                                         5

//MESSAGEENCRYPTIONTYPES
#define MET_UNKNOWN                                        0

#define MET_CERT_ENCRYPTED                                 1

#define MET_KEY_ENCRYPTED                                  2

#define MET_CERT_ENCRYPTED_AND_AUTHENTICATED               3

#ifndef NS_SWIFT_NAME
#define NS_SWIFT_NAME(x)
#endif

@protocol SecureBlackboxMessageEncryptorDelegate <NSObject>
@optional
- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

@end

@interface SecureBlackboxMessageEncryptor : NSObject {
  @public void* m_pObj;
  @public CFMutableArrayRef m_rNotifiers;
  __unsafe_unretained id <SecureBlackboxMessageEncryptorDelegate> m_delegate;
  BOOL m_raiseNSException;
  BOOL m_delegateHasError;

  BOOL m_delegateHasNotification;

}

+ (SecureBlackboxMessageEncryptor*)messageencryptor;

- (id)init;
- (void)dealloc;

- (NSString*)lastError;
- (int)lastErrorCode;
- (int)eventErrorCode;

@property (nonatomic,readwrite,assign,getter=delegate,setter=setDelegate:) id <SecureBlackboxMessageEncryptorDelegate> delegate;
- (id <SecureBlackboxMessageEncryptorDelegate>)delegate;
- (void) setDelegate:(id <SecureBlackboxMessageEncryptorDelegate>)anObject;

  /* Events */

- (void)onError:(int)errorCode :(NSString*)description NS_SWIFT_NAME(onError(_:_:));

- (void)onNotification:(NSString*)eventID :(NSString*)eventParam NS_SWIFT_NAME(onNotification(_:_:));

  /* Properties */

@property (nonatomic,readwrite,assign,getter=RuntimeLicense,setter=setRuntimeLicense:) NSString* RuntimeLicense NS_SWIFT_NAME(RuntimeLicense);
- (NSString*)RuntimeLicense;
- (void)setRuntimeLicense:(NSString*)newRuntimeLicense;

@property (nonatomic,readonly,assign,getter=VERSION) NSString* VERSION NS_SWIFT_NAME(VERSION);
- (NSString*)VERSION;

@property (nonatomic,readwrite,assign,getter=raiseNSException,setter=setRaiseNSException:) BOOL raiseNSException NS_SWIFT_NAME(raiseNSException);
- (BOOL)raiseNSException NS_SWIFT_NAME(raiseNSException());
- (void)setRaiseNSException:(BOOL)newRaiseNSException NS_SWIFT_NAME(setRaiseNSException(_:));

@property (nonatomic,readwrite,assign,getter=bitsInKey,setter=setBitsInKey:) int bitsInKey NS_SWIFT_NAME(bitsInKey);

- (int)bitsInKey NS_SWIFT_NAME(bitsInKey());
- (void)setBitsInKey :(int)newBitsInKey NS_SWIFT_NAME(setBitsInKey(_:));

@property (nonatomic,readwrite,assign,getter=encryptionAlgorithm,setter=setEncryptionAlgorithm:) NSString* encryptionAlgorithm NS_SWIFT_NAME(encryptionAlgorithm);

- (NSString*)encryptionAlgorithm NS_SWIFT_NAME(encryptionAlgorithm());
- (void)setEncryptionAlgorithm :(NSString*)newEncryptionAlgorithm NS_SWIFT_NAME(setEncryptionAlgorithm(_:));

@property (nonatomic,readwrite,assign,getter=encryptionCertCount,setter=setEncryptionCertCount:) int encryptionCertCount NS_SWIFT_NAME(encryptionCertCount);

- (int)encryptionCertCount NS_SWIFT_NAME(encryptionCertCount());
- (void)setEncryptionCertCount :(int)newEncryptionCertCount NS_SWIFT_NAME(setEncryptionCertCount(_:));

- (NSData*)encryptionCertBytes:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertBytes(_:));

- (BOOL)encryptionCertCA:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertCA(_:));
- (void)setEncryptionCertCA:(int)encryptionCertIndex :(BOOL)newEncryptionCertCA NS_SWIFT_NAME(setEncryptionCertCA(_:_:));

- (NSData*)encryptionCertCAKeyID:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertCAKeyID(_:));

- (int)encryptionCertCertType:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertCertType(_:));

- (NSString*)encryptionCertCRLDistributionPoints:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertCRLDistributionPoints(_:));
- (void)setEncryptionCertCRLDistributionPoints:(int)encryptionCertIndex :(NSString*)newEncryptionCertCRLDistributionPoints NS_SWIFT_NAME(setEncryptionCertCRLDistributionPoints(_:_:));

- (NSString*)encryptionCertCurve:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertCurve(_:));
- (void)setEncryptionCertCurve:(int)encryptionCertIndex :(NSString*)newEncryptionCertCurve NS_SWIFT_NAME(setEncryptionCertCurve(_:_:));

- (NSString*)encryptionCertFingerprint:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertFingerprint(_:));

- (NSString*)encryptionCertFriendlyName:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertFriendlyName(_:));

- (long long)encryptionCertHandle:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertHandle(_:));
- (void)setEncryptionCertHandle:(int)encryptionCertIndex :(long long)newEncryptionCertHandle NS_SWIFT_NAME(setEncryptionCertHandle(_:_:));

- (NSString*)encryptionCertHashAlgorithm:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertHashAlgorithm(_:));
- (void)setEncryptionCertHashAlgorithm:(int)encryptionCertIndex :(NSString*)newEncryptionCertHashAlgorithm NS_SWIFT_NAME(setEncryptionCertHashAlgorithm(_:_:));

- (NSString*)encryptionCertIssuer:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertIssuer(_:));

- (NSString*)encryptionCertIssuerRDN:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertIssuerRDN(_:));
- (void)setEncryptionCertIssuerRDN:(int)encryptionCertIndex :(NSString*)newEncryptionCertIssuerRDN NS_SWIFT_NAME(setEncryptionCertIssuerRDN(_:_:));

- (NSString*)encryptionCertKeyAlgorithm:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertKeyAlgorithm(_:));
- (void)setEncryptionCertKeyAlgorithm:(int)encryptionCertIndex :(NSString*)newEncryptionCertKeyAlgorithm NS_SWIFT_NAME(setEncryptionCertKeyAlgorithm(_:_:));

- (int)encryptionCertKeyBits:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertKeyBits(_:));

- (NSString*)encryptionCertKeyFingerprint:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertKeyFingerprint(_:));

- (int)encryptionCertKeyUsage:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertKeyUsage(_:));
- (void)setEncryptionCertKeyUsage:(int)encryptionCertIndex :(int)newEncryptionCertKeyUsage NS_SWIFT_NAME(setEncryptionCertKeyUsage(_:_:));

- (BOOL)encryptionCertKeyValid:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertKeyValid(_:));

- (NSString*)encryptionCertOCSPLocations:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertOCSPLocations(_:));
- (void)setEncryptionCertOCSPLocations:(int)encryptionCertIndex :(NSString*)newEncryptionCertOCSPLocations NS_SWIFT_NAME(setEncryptionCertOCSPLocations(_:_:));

- (BOOL)encryptionCertOCSPNoCheck:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertOCSPNoCheck(_:));
- (void)setEncryptionCertOCSPNoCheck:(int)encryptionCertIndex :(BOOL)newEncryptionCertOCSPNoCheck NS_SWIFT_NAME(setEncryptionCertOCSPNoCheck(_:_:));

- (int)encryptionCertOrigin:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertOrigin(_:));

- (NSString*)encryptionCertPolicyIDs:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertPolicyIDs(_:));
- (void)setEncryptionCertPolicyIDs:(int)encryptionCertIndex :(NSString*)newEncryptionCertPolicyIDs NS_SWIFT_NAME(setEncryptionCertPolicyIDs(_:_:));

- (NSData*)encryptionCertPrivateKeyBytes:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertPrivateKeyBytes(_:));

- (BOOL)encryptionCertPrivateKeyExists:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertPrivateKeyExists(_:));

- (BOOL)encryptionCertPrivateKeyExtractable:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertPrivateKeyExtractable(_:));

- (NSData*)encryptionCertPublicKeyBytes:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertPublicKeyBytes(_:));

- (BOOL)encryptionCertQualified:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertQualified(_:));

- (int)encryptionCertQualifiedStatements:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertQualifiedStatements(_:));
- (void)setEncryptionCertQualifiedStatements:(int)encryptionCertIndex :(int)newEncryptionCertQualifiedStatements NS_SWIFT_NAME(setEncryptionCertQualifiedStatements(_:_:));

- (NSString*)encryptionCertQualifiers:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertQualifiers(_:));

- (BOOL)encryptionCertSelfSigned:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertSelfSigned(_:));

- (NSData*)encryptionCertSerialNumber:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertSerialNumber(_:));
- (void)setEncryptionCertSerialNumber:(int)encryptionCertIndex :(NSData*)newEncryptionCertSerialNumber NS_SWIFT_NAME(setEncryptionCertSerialNumber(_:_:));

- (NSString*)encryptionCertSigAlgorithm:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertSigAlgorithm(_:));

- (int)encryptionCertSource:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertSource(_:));

- (NSString*)encryptionCertSubject:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertSubject(_:));

- (NSString*)encryptionCertSubjectAlternativeName:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertSubjectAlternativeName(_:));
- (void)setEncryptionCertSubjectAlternativeName:(int)encryptionCertIndex :(NSString*)newEncryptionCertSubjectAlternativeName NS_SWIFT_NAME(setEncryptionCertSubjectAlternativeName(_:_:));

- (NSData*)encryptionCertSubjectKeyID:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertSubjectKeyID(_:));
- (void)setEncryptionCertSubjectKeyID:(int)encryptionCertIndex :(NSData*)newEncryptionCertSubjectKeyID NS_SWIFT_NAME(setEncryptionCertSubjectKeyID(_:_:));

- (NSString*)encryptionCertSubjectRDN:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertSubjectRDN(_:));
- (void)setEncryptionCertSubjectRDN:(int)encryptionCertIndex :(NSString*)newEncryptionCertSubjectRDN NS_SWIFT_NAME(setEncryptionCertSubjectRDN(_:_:));

- (BOOL)encryptionCertValid:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertValid(_:));

- (NSString*)encryptionCertValidFrom:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertValidFrom(_:));
- (void)setEncryptionCertValidFrom:(int)encryptionCertIndex :(NSString*)newEncryptionCertValidFrom NS_SWIFT_NAME(setEncryptionCertValidFrom(_:_:));

- (NSString*)encryptionCertValidTo:(int)encryptionCertIndex NS_SWIFT_NAME(encryptionCertValidTo(_:));
- (void)setEncryptionCertValidTo:(int)encryptionCertIndex :(NSString*)newEncryptionCertValidTo NS_SWIFT_NAME(setEncryptionCertValidTo(_:_:));

@property (nonatomic,readwrite,assign,getter=encryptionType,setter=setEncryptionType:) int encryptionType NS_SWIFT_NAME(encryptionType);

- (int)encryptionType NS_SWIFT_NAME(encryptionType());
- (void)setEncryptionType :(int)newEncryptionType NS_SWIFT_NAME(setEncryptionType(_:));

@property (nonatomic,readwrite,assign,getter=FIPSMode,setter=setFIPSMode:) BOOL FIPSMode NS_SWIFT_NAME(FIPSMode);

- (BOOL)FIPSMode NS_SWIFT_NAME(FIPSMode());
- (void)setFIPSMode :(BOOL)newFIPSMode NS_SWIFT_NAME(setFIPSMode(_:));

@property (nonatomic,readwrite,assign,getter=inputBytes,setter=setInputBytes:) NSData* inputBytes NS_SWIFT_NAME(inputBytes);

- (NSData*)inputBytes NS_SWIFT_NAME(inputBytes());
- (void)setInputBytes :(NSData*)newInputBytes NS_SWIFT_NAME(setInputBytes(_:));

@property (nonatomic,readwrite,assign,getter=inputFile,setter=setInputFile:) NSString* inputFile NS_SWIFT_NAME(inputFile);

- (NSString*)inputFile NS_SWIFT_NAME(inputFile());
- (void)setInputFile :(NSString*)newInputFile NS_SWIFT_NAME(setInputFile(_:));

@property (nonatomic,readwrite,assign,getter=key,setter=setKey:) NSData* key NS_SWIFT_NAME(key);

- (NSData*)key NS_SWIFT_NAME(key());
- (void)setKey :(NSData*)newKey NS_SWIFT_NAME(setKey(_:));

@property (nonatomic,readonly,assign,getter=outputBytes) NSData* outputBytes NS_SWIFT_NAME(outputBytes);

- (NSData*)outputBytes NS_SWIFT_NAME(outputBytes());

@property (nonatomic,readwrite,assign,getter=outputFile,setter=setOutputFile:) NSString* outputFile NS_SWIFT_NAME(outputFile);

- (NSString*)outputFile NS_SWIFT_NAME(outputFile());
- (void)setOutputFile :(NSString*)newOutputFile NS_SWIFT_NAME(setOutputFile(_:));

@property (nonatomic,readwrite,assign,getter=signedAttributeCount,setter=setSignedAttributeCount:) int signedAttributeCount NS_SWIFT_NAME(signedAttributeCount);

- (int)signedAttributeCount NS_SWIFT_NAME(signedAttributeCount());
- (void)setSignedAttributeCount :(int)newSignedAttributeCount NS_SWIFT_NAME(setSignedAttributeCount(_:));

- (NSString*)signedAttributeOID:(int)signedAttributeIndex NS_SWIFT_NAME(signedAttributeOID(_:));
- (void)setSignedAttributeOID:(int)signedAttributeIndex :(NSString*)newSignedAttributeOID NS_SWIFT_NAME(setSignedAttributeOID(_:_:));

- (NSData*)signedAttributeValue:(int)signedAttributeIndex NS_SWIFT_NAME(signedAttributeValue(_:));
- (void)setSignedAttributeValue:(int)signedAttributeIndex :(NSData*)newSignedAttributeValue NS_SWIFT_NAME(setSignedAttributeValue(_:_:));

@property (nonatomic,readwrite,assign,getter=unsignedAttributeCount,setter=setUnsignedAttributeCount:) int unsignedAttributeCount NS_SWIFT_NAME(unsignedAttributeCount);

- (int)unsignedAttributeCount NS_SWIFT_NAME(unsignedAttributeCount());
- (void)setUnsignedAttributeCount :(int)newUnsignedAttributeCount NS_SWIFT_NAME(setUnsignedAttributeCount(_:));

- (NSString*)unsignedAttributeOID:(int)unsignedAttributeIndex NS_SWIFT_NAME(unsignedAttributeOID(_:));
- (void)setUnsignedAttributeOID:(int)unsignedAttributeIndex :(NSString*)newUnsignedAttributeOID NS_SWIFT_NAME(setUnsignedAttributeOID(_:_:));

- (NSData*)unsignedAttributeValue:(int)unsignedAttributeIndex NS_SWIFT_NAME(unsignedAttributeValue(_:));
- (void)setUnsignedAttributeValue:(int)unsignedAttributeIndex :(NSData*)newUnsignedAttributeValue NS_SWIFT_NAME(setUnsignedAttributeValue(_:_:));

  /* Methods */

- (int)addAttribute:(NSString*)OID :(NSData*)value :(BOOL)signedAttribute NS_SWIFT_NAME(addAttribute(_:_:_:));

- (NSString*)config:(NSString*)configurationString NS_SWIFT_NAME(config(_:));

- (NSString*)doAction:(NSString*)actionID :(NSString*)actionParams NS_SWIFT_NAME(doAction(_:_:));

- (void)encrypt NS_SWIFT_NAME(encrypt());

- (void)reset NS_SWIFT_NAME(reset());

@end

