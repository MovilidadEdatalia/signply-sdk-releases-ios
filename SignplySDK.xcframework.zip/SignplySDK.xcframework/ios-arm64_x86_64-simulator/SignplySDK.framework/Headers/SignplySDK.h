//
//  SignplySDK.h
//  SignplySDK
//
//  Created by Mac Mini Edatalia on 12/05/2020.
//  Copyright © 2020 Mac Mini Edatalia. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

//! Project version number for SignplySDK.
FOUNDATION_EXPORT double SignplySDKVersionNumber;

//! Project version string for SignplySDK.
FOUNDATION_EXPORT const unsigned char SignplySDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SignplySDK/PublicHeader.h>


